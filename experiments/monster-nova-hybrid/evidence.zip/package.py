"""Archive completed evidence using an explicit allowlist, excluding private inputs."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEST = Path('/workspace/work/replay-finishing-handoffs/experiments/monster-nova-hybrid')
PANELS = ('phase1','phase1-score','phase1-ball','phase1-ball-v2','phase2','qualification')


def main():
    decision = json.loads((ROOT/'decision.json').read_text())
    assert decision['development_advance'], 'Use an explicit archive scope if qualification was not run'
    files = set(ROOT.glob('*.py')) | set(ROOT.glob('*.json')) | set(ROOT.glob('*.log'))
    files.discard(ROOT/'MANIFEST.json')
    files.add(ROOT/'REPORT.md')
    for directory in ('sources','opponents','reference'):
        files.update(p for p in (ROOT/directory).rglob('*') if p.is_file() and p.suffix in ('.py','.toml'))
    for panel in PANELS:
        folder = ROOT/panel
        assert (folder/'summary.json').exists() and (folder/'audit.json').exists()
        files.update(folder/name for name in ('registration.json','metadata.json','matches.jsonl','summary.json','audit.json','run.log'))
    manifest = {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    manifest['__note__'] = 'All original raw fixtures retained; no HARs, credentials, attachment paths, caches or unrelated work included.'
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    files.add(ROOT/'MANIFEST.json')
    archive = DEST/'evidence.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(files):
            info = zipfile.ZipInfo(str(p.relative_to(ROOT)),date_time=(2026,10,27,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644 << 16
            z.writestr(info,p.read_bytes())
    shutil.copyfile(ROOT/'REPORT.md', DEST/'README.md')
    shutil.copyfile(ROOT/'decision.json', DEST/'decision.json')
    for name in ('summary.json','audit.json'):
        shutil.copyfile(ROOT/'qualification'/name, DEST/('qualification-'+name))
    source = ROOT/'sources/gaps/team.py'
    assert source.read_bytes() == (DEST/'team.py').read_bytes()
    (DEST/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(DEST.iterdir()) if p.is_file() and p.name != 'SHA256SUMS'))
    print('Packaged',len(files),'files;',archive.stat().st_size,'archive bytes')


if __name__ == '__main__':
    main()
