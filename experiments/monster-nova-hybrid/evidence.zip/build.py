"""Independent NOVA + MONSTER16 hybrids; originals remain byte-identical."""
import ast
import copy
import hashlib
import json
from pathlib import Path

R=Path(__file__).resolve().parent
NOVA=Path('/workspace/work/div1-review-20261027/sources/div1/team.py')
MONSTER=Path('/workspace/work/monster16-review-20261027/sources/uploaded16/team.py')
assert hashlib.sha256(NOVA.read_bytes()).hexdigest()=='b10d96375fa0723db8d8966d099f96f340440f569b95f6751cfb9c66406be484'
assert hashlib.sha256(MONSTER.read_bytes()).hexdigest()=='e49870793a2076add0b95ea5306adeac94cd3f12eadf3685211ec543f4b3e415'

class MonsterNames(ast.NodeTransformer):
    def visit_Name(self,n):
        if n.id in ('unit','clip'):n.id='_m_'+n.id
        return n
    def visit_FunctionDef(self,n):
        if n.name in ('unit','clip'):n.name='_m_'+n.name
        return self.generic_visit(n)

cover='''
def _defend_spots(self,bx,by,path,t_them,j_them,O,P,n):
    spots=self._original_defend_spots(bx,by,path,t_them,j_them,O,P,n)
    m=self._hybrid_monster
    plan=self._plan
    if bx>=m.left+18.0 or (plan is not None and plan[1]>=self._hybrid_tick):
        return spots
    # Retain the keeper, primary chaser and all marking jobs. Only the two
    # existing blocking/cover jobs adopt MONSTER's projected mouth geometry.
    selected=[i for i,s in enumerate(spots) if s[3] in ('blk','cov')]
    if len(selected)!=2:
        return spots
    depth=m.LOCK_DEPTH if self._hybrid_lead>0 else m.SHELL_DEPTH
    distance=max(3.0,bx-m.left)
    ratio=_m_clip((bx-m.left-depth)/distance,0.60,1.0)
    centre=by*_m_clip(depth/distance,0.0,0.4)
    limit=m.goal+1.5
    centre=_m_clip(centre,-limit+5.4*ratio,limit-5.4*ratio)
    selected.sort(key=lambda i:spots[i][1])
    result=list(spots)
    for i,side in zip(selected,(-1,1)):
        result[i]=(m.left+depth,centre+side*5.4*ratio,True,spots[i][3])
    self._hybrid_counts['cover_updates']+=1
    return result
'''

gap='''
def _kick(self,k,bx,by,bvx,bvy,P,O,tick):
    m=self._hybrid_monster
    wall=bx>20.0 and sum(q[0]>m.right-3.5 and abs(q[1])<m.goal+1 for q in O)>=4
    if not wall:
        return self._original_kick(k,bx,by,bvx,bvy,P,O,tick)
    opponents=[(i+5,*q) for i,q in enumerate(O)]
    candidates=m.goal_aims((bx,by,bvx,bvy),opponents,True)
    extra=[]
    for f in candidates:
        y=f*m.goal
        if all(abs(y-old)>0.08 for old in GOAL_YS+WALL_YS+tuple(extra)):
            extra.append(y)
        if len(extra)>=3:
            break
    self._hybrid_counts['extra_aims']+=len(extra)
    return self._original_kick(k,bx,by,bvx,bvy,P,O,tick,GOAL_YS=tuple(extra)+GOAL_YS)
'''

corner='''
def _kick(self,k,bx,by,bvx,bvy,P,O,tick):
    action=self._original_kick(k,bx,by,bvx,bvy,P,O,tick)
    m=self._hybrid_monster
    if k==0 or bx<m.right-6.0 or abs(by)<m.goal-0.7:
        return action
    # Leave shots/clearances and passes to another player exactly as selected.
    # The only eligible change replaces the carrier's own planned dribble.
    if self._plan is None or self._plan[0]!=k:
        return action
    if perf_counter()>m.deadline:
        return action
    opponents=[(i+5,*q) for i,q in enumerate(O)]
    p=(k,*P[k])
    movement=action.get('movement',(0.0,0.0))
    self._hybrid_counts['corner_checks']+=1
    option=m.duel(p,(bx,by,bvx,bvy),opponents,movement)
    if option is None or option[0]<=6.0:
        return action
    _,kick,move,_=option
    if m.launch(p,(bx,by,bvx,bvy),kick,move) is None:
        return action
    self._plan=None
    self._hybrid_counts['corner_overrides']+=1
    return {'movement':move,'kick_direction':kick[0],'kick_power':kick[1]}
'''

wrapper='''
class MonsterNovaHybrid(TeamController):
    name='MONSTER NOVA Hybrid'
    version=VERSION

    def __init__(self):
        self._nova=_NovaPolicy()
        self._monster=_MonsterPolicy()
        self.reset(0)

    def reset(self,seed):
        self._nova.reset(seed)
        self._monster.reset(seed)
        self._hybrid_counts={'cover_updates':0,'extra_aims':0,'corner_checks':0,'corner_overrides':0}
        self._nova._hybrid_counts=self._hybrid_counts
        self._nova._hybrid_monster=self._monster

    def initial_formation(self,field):
        return None

    def act(self,obs):
        started=perf_counter()
        if not self._monster.ready:
            self._monster.setup(obs.field)
        self._monster.deadline=started+0.017
        self._nova._hybrid_tick=obs.tick
        self._nova._hybrid_lead=obs.score[0]-obs.score[1]
        # Use SDK exception accounting; new errors must not be hidden by the
        # source controller's broad fallback exception handler.
        return self._nova._act(obs)
'''

score_wrapper='''
class MonsterNovaHybrid(TeamController):
    name='MONSTER NOVA Hybrid'
    version=VERSION

    def __init__(self):
        self._nova=_NovaPolicy()
        self._monster=_MonsterPolicy()
        self.reset(0)

    def reset(self,seed):
        self._seed=seed
        self._nova.reset(seed)
        self._monster.reset(seed)
        self._mode='nova'
        self._previous_score=None
        self._hybrid_counts={'cover_updates':0,'extra_aims':0,'corner_checks':0,'corner_overrides':0,'monster_ticks':0,'mode_switches':0}
        self._nova._hybrid_counts=self._hybrid_counts
        self._nova._hybrid_monster=self._monster

    def initial_formation(self,field):
        return None

    def act(self,obs):
        started=perf_counter()
        score=tuple(obs.score)
        restart=(self._previous_score is not None and score!=self._previous_score
                 and math.hypot(*obs.ball.position)<0.5 and math.hypot(*obs.ball.velocity)<0.1)
        self._previous_score=score
        if restart:
            # A real goal resets the roster. Change the whole defensive unit
            # here, never during a reception or a live attacking action.
            wanted='monster' if score[0]>score[1] and obs.time_remaining<=60.0 else 'nova'
            if wanted!=self._mode:
                self._mode=wanted
                self._hybrid_counts['mode_switches']+=1
                if wanted=='monster':self._monster.reset(self._seed)
                else:self._nova.reset(self._seed)
        if self._mode=='monster':
            self._hybrid_counts['monster_ticks']+=1
            return self._monster.act(obs)
        if not self._monster.ready:self._monster.setup(obs.field)
        self._monster.deadline=started+0.017
        self._nova._hybrid_tick=obs.tick
        self._nova._hybrid_lead=score[0]-score[1]
        return self._nova._act(obs)
'''

ball_wrapper='''
class MonsterNovaHybrid(TeamController):
    name='MONSTER NOVA Hybrid'
    version=VERSION

    def __init__(self):
        self._nova=_NovaPolicy()
        self._monster=_MonsterPolicy()
        self.reset(0)

    def reset(self,seed):
        self._nova.reset(seed)
        self._monster.reset(seed)
        self._hybrid_counts={'cover_updates':0,'extra_aims':0,'corner_checks':0,'corner_overrides':0,'nova_kicks':0,'receiver_ticks':0}
        self._nova._hybrid_counts=self._hybrid_counts
        self._nova._hybrid_monster=self._monster

    def initial_formation(self,field):
        return self._monster.initial_formation(field)

    def act(self,obs):
        started=perf_counter()
        # Keep MONSTER's coupled movement geometry. NOVA receives the real
        # whole-decision start time so both engines share its14ms search budget.
        defended=self._monster.act(obs)
        self._nova._hybrid_started=started
        self._nova._hybrid_tick=obs.tick
        self._nova._hybrid_lead=obs.score[0]-obs.score[1]
        self._monster.deadline=started+0.017
        # NOVA may return a cached action dictionary. Overlay a copy, retaining
        # its original forecast actions for subsequent cache checks.
        actions=dict(self._nova._act(obs))
        plan=self._nova._plan
        live=(plan is not None and plan[1]>=obs.tick and
              (obs.ball.last_touch is None or obs.ball.last_touch<5))
        for pid,old in defended.players.items():
            chosen=actions[pid]
            if chosen.get('kick_direction') is not None:
                self._hybrid_counts['nova_kicks']+=1
                continue
            if live and pid==plan[0]:
                self._hybrid_counts['receiver_ticks']+=1
                continue
            if pid==4 and self._nova._chaser==4 and obs.ball.position[0]>=self._monster.left+20:
                continue
            actions[pid]={'movement':old.movement}
        return actions
'''

def build(name,features):
    n=ast.parse(NOVA.read_text())
    n.body=[x for x in n.body if not (isinstance(x,ast.Import) and any(a.name=='gc' for a in x.names)) and not (isinstance(x,ast.Try) and 'gc.freeze' in ast.unparse(x))]
    cls=next(x for x in n.body if isinstance(x,ast.ClassDef) and x.name=='MyTeam')
    cls.name='_NovaPolicy';cls.bases=[]
    if 'ball' in features:
        method=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='_act')
        assignment=method.body[0]
        assert isinstance(assignment,ast.Assign) and ast.unparse(assignment.targets[0])=='self._t_act'
        assignment.value=ast.parse('self._hybrid_started',mode='eval').body
    if 'cover' in features:
        method=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='_defend_spots')
        method.name='_original_defend_spots'
        cls.body.extend(ast.parse(cover).body)
    if 'gaps' in features or 'corner' in features:
        method=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='_kick')
        method.name='_original_kick'
        if features & {'gaps','corner'} == {'gaps','corner'}:
            # Compose proven individual wrappers: native kick -> gap aims ->
            # optional carrier-only corner finish. The same pass guard applies.
            g=ast.parse(gap).body[0];g.name='_gap_kick'
            c=ast.parse(corner.replace('self._original_kick(','self._gap_kick(')).body[0]
            cls.body.extend([g,c])
        else:cls.body.extend(ast.parse(gap if 'gaps' in features else corner).body)
    m=MonsterNames().visit(ast.parse(MONSTER.read_text()))
    for x in m.body:
        if isinstance(x,ast.ClassDef):x.name='_MonsterPolicy';x.bases=[]
    chosen_wrapper=ball_wrapper if 'ball' in features else score_wrapper if 'score' in features else wrapper
    w=chosen_wrapper.replace('VERSION',repr('dev1-'+name))
    tree=ast.Module(body=n.body+[ast.ImportFrom(module='soccer',names=[ast.alias(name='TeamAction'),ast.alias(name='PlayerAction')],level=0)]+[x for x in m.body if not isinstance(x,(ast.Import,ast.ImportFrom)) and not (isinstance(x,ast.Expr) and isinstance(x.value,ast.Constant) and isinstance(x.value.value,str))]+ast.parse(w).body,type_ignores=[])
    source=ast.unparse(ast.fix_missing_locations(tree))+'\n'
    p=R/'sources'/name/'team.py';p.parent.mkdir(parents=True,exist_ok=True)
    assert not p.exists(),p
    p.write_text(source)
    assert p.stat().st_size<262144
    assert sum(isinstance(x,ast.ClassDef) and any(isinstance(b,ast.Name) and b.id=='TeamController' for b in x.bases) for x in tree.body)==1
    return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),features=sorted(features),bytes=p.stat().st_size)

if __name__=='__main__':
    manifest={}
    for name,features in [('cover',{'cover'}),('gaps',{'gaps'}),('corner',{'corner'})]:manifest[name]=build(name,features)
    for name,p in [('baseline',NOVA),('monster16',MONSTER)]:
        out=R/'sources'/name/'team.py';out.parent.mkdir(exist_ok=True);out.write_bytes(p.read_bytes())
        manifest[name]=dict(path=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),features=[],bytes=out.stat().st_size)
    (R/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2))
