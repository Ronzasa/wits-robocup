"""Render the completed registered research; never run or select a policy."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads((ROOT/path).read_text())


def row(label, s):
    return (f"| {label} | {s['points']} | {s['wins']}–{s['draws']}–{s['losses']} | "
            f"{s['goals_for']}–{s['goals_against']} | {s['policy_errors']} | "
            f"{s['policy_timeouts']} | {s['decision_mean_ms']:.3f} / {s['decision_max_ms']:.3f} |")


def table(summary):
    names = {'baseline':'Original NOVA', 'monster16':'Original MONSTER16', 'gaps':'Gap-aiming hybrid'}
    return '\n'.join([
        '| Controller | Points | W–D–L | Goals for–against | SDK errors | Raw misses | Mean / max ms |',
        '|---|---:|---:|---:|---:|---:|---:|',
        *[row(names.get(n,n),s) for n,s in summary.items()],
    ])


def render():
    decision = read('decision.json')
    phase2 = read('phase2/summary.json')
    files = ['phase1','phase1-score','phase1-ball','phase1-ball-v2','phase2']
    if (ROOT/'qualification/summary.json').exists():
        files.append('qualification')
    total = sum(sum(s['matches'] for s in read(f'{p}/summary.json')['summary'].values()) for p in files)
    text = f'''# MONSTER–NOVA hybrid research

**Experimental branch only. No champion replacement.**

Decision: **{'qualified for explicit user review' if decision['eligible'] else 'no qualified hybrid upgrade'}**.
{decision['reason']}

The uploaded MONSTER16 (`e4987079…`) and NOVA/div1.py (`b10d9637…`) are frozen.
The selected experimental `team.py` is NOVA's movement, receiving and kick
evaluation with up to three MONSTER gap-aim candidates against a visible packed
goal-line wall. NOVA still evaluates and chooses the kick. This is a small shot
search change, not a transplant of MONSTER's permanent four-player home defence.
It is **not evidence of a Division 1 ranking**.

## Broader development

Eight frozen opponent styles, two fresh development seeds, both sides, both
kickoffs and two formation profiles: 128 full matches per controller.

{table(phase2['summary'])}

The one-point development lead was sufficient only for the preregistered advance
to qualification. It was not accepted as proof of a stronger controller.

'''
    if 'qualification' in files:
        q = read('qualification/summary.json')
        audit = read('qualification/audit.json')
        text += f'''## Untouched qualification

One candidate was frozen before any qualification fixture. Eight untouched seeds,
eight styles, balanced sides/kickoffs and both formation profiles: 512 matches
per controller. All 1,536 fixtures were completed, with no qualification tuning,
early stopping or optional seed extensions.

{table(q['summary'])}

| Paired comparison | Points / fixture difference | Seed-block bootstrap 95% CI | Additional raw misses / 1,000 fixtures |
|---|---:|---:|---:|
'''
        for control in ('baseline','monster16'):
            c = audit['comparisons']['gaps'][control]
            lo,hi = c['seed_block_95']
            text += f"| gaps − {control} | {c['points_difference_per_fixture']:+.4f} | [{lo:+.4f}, {hi:+.4f}] | {c['additional_raw_misses_per1000']:+.3f} |\n"
        text += '\nQualification points by opponent, 64 fixtures per controller per style:\n\n'
        text += '| Opponent | NOVA points | MONSTER16 points | Hybrid points | Hybrid goals |\n|---|---:|---:|---:|---:|\n'
        for opponent, group in q['by_opponent'].items():
            s = group['gaps']
            text += f"| {opponent} | {group['baseline']['points']} | {group['monster16']['points']} | {s['points']} | {s['goals_for']}–{s['goals_against']} |\n"
        text += '\nRegistered gates:\n\n'
        for control,gates in decision['gates']['paired_comparisons'].items():
            for name,passed in gates.items():
                text += f"- {control}: {name}: **{'PASS' if passed else 'FAIL'}**.\n"
        for name,passed in decision['gates'].items():
            if name != 'paired_comparisons':
                text += f"- {name}: **{'PASS' if passed else 'FAIL'}**.\n"
        diagnostic = ROOT/'timing-reproductions.json'
        if diagnostic.exists():
            d = read(diagnostic.name)
            text += '\nBounded timing diagnostics (original qualification misses remain counted):\n\n'
            labels = sorted({r['source'] for r in d['rows']})
            for label in labels:
                rs = [r for r in d['rows'] if r['source']==label]
                stats = [r['result']['stats'][r['candidate_slot']] for r in rs]
                text += (f"- {label}: {len(rs)} exact-fixture reruns; "
                         f"{sum(s['policy_timeouts'] for s in stats)} deadline misses, "
                         f"{sum(s['policy_errors'] for s in stats)} SDK errors; "
                         f"max {max(s['decision_time_ms']['max_ms'] for s in stats):.3f} ms.\n")
            text += '\nFailure to reproduce a spike does not establish an environmental cause. No timing event was excluded.\n'
    text += '''
## Independent experiments and rejected components

| Isolated change | Development outcome | Decision |
|---|---|---|
| Projected defensive block/cover targets in NOVA | 113 vs NOVA 129 points; 22 vs 12 conceded | Reject; partial geometry does not retain MONSTER's full defensive unit |
| MONSTER gap aims in NOVA | 130 vs NOVA 129 points | Sole component advanced to broader development and qualification |
| Near-post duel on the carrier's own dribble | 161 eligible checks, zero overrides; tied NOVA | Inactive; do not combine |
| Whole defensive-engine switch only at goal resets, leading in final minute | 42 switches, 65,843 MONSTER decisions; tied NOVA on points | No points gain; do not combine |
| MONSTER movement with NOVA kicks/receiving | Original prototype 86 vs MONSTER 90; then discovered cache alias mutation | Excluded from selection; raw evidence retained |
| Corrected ball-control transplant | 84 vs MONSTER 90; 24–14 vs 24–10 goals | Reject; improved pass completion did not improve winning |

The cache correction copies NOVA's outer action dictionary before movement
overlays. NOVA can return the dictionary stored in its short-lived action cache.
The original prototype fails the added cache regression; the corrected version
passes it. Its results were recorded separately, never overwritten.

## Method and reliability limits

- All fixtures use the unchanged native engine 0.1.0, official config
  `372990895c7eca2a`, 2,400 ticks and the actual 20 ms SDK decision accounting.
- One timed worker at a time; fresh interpreter for each fixture. Original NOVA
  calls `gc.freeze()` at import. New hybrid sources omit that global side effect;
  the original upload is byte-identical and isolated between fixtures.
- The `default` profile uses native default rosters. The `controller` profile
  applies each controller's official initial formation before reset. For policies
  without a custom formation these setups can coincide; they are not independent
  seed samples.
- Confidence intervals resample whole seeds over all matched opponents, sides,
  kickoffs and profiles. Repeated development cohorts are not pooled as fresh
  independent evidence. Eight qualification seeds remain a limited sample.
- Raw deadline events from **both** teams remain in every record, including
  opposing-controller events. No event was deleted or attributed to the host
  without evidence. Gate calculations use each tested controller's own events.
- A temporary execution-tool connection loss occurred during qualification. The
  same native batch process continued and its files remained intact; no fixture
  restart, replacement run or seed change was needed. The incident is recorded.
- The frozen NOVA `act()` has an internal exception fallback. Its zero SDK errors
  do not prove zero swallowed exceptions. Hybrids call its internal policy directly
  so new errors surface through official SDK accounting.
- `extra_aims` counts proposed shot targets, not accepted kicks, successful
  executions or goals attributable to the feature. Other counters likewise
  describe checks/overrides/mode decisions rather than causal conversions.
- Derived uncollected passes are attempts minus completions minus interceptions;
  the native engine does not provide a separate first-touch quality statistic.
- Fixtures use frozen local opponents. They do not reproduce the live league's
  current opponent population or establish a league division.

## Files and reproduction

- `team.py`: frozen gap-aiming challenger, self-contained, experimental only.
- `evidence.zip`: originals, all variants, opponent snapshots, registrations,
  raw JSONL results, summaries, audits, intake reports, regression logs and tools.
- `decision.json`: machine-readable original qualification gates and decision.

Extract `evidence.zip` and use the official course SDK in `PYTHONPATH`:

```sh
python audit.py phase1 phase1-score phase1-ball phase1-ball-v2 phase2 qualification
python reproduce.py phase2 --out fresh-phase2
```

Use a new output directory, one timed run at a time. The reproducer verifies
source hashes, remaps archived absolute paths, and retains the exact seeds and
fixture arrangements. Native reruns may differ with machine timing and runtime
search budgets. Never overwrite the recorded evidence.

The archived `build.py` is the original experimental builder, with its original
workspace input locations preserved as provenance. The generated single-file
sources are included; rebuilding is not necessary to reproduce matches. Source
paths in old registrations likewise preserve their original locations and are
remapped by `reproduce.py` and `audit.py`.

`main`, active `my-team/team.py`, uploaded originals and archived champions were
not changed. Promotion requires explicit user approval even if every gate passes.
'''
    text += f'\nTotal recorded full tournament fixtures: **{total:,}**, including repeated development controls. Timing diagnostic reruns are separate and never pooled into qualification.\n'
    return text


if __name__ == '__main__':
    (ROOT/'REPORT.md').write_text(render())
