"""Apply the registered qualification gates without changing or selecting code."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def decide():
    plan = json.loads((ROOT/'research-plan.json').read_text())
    phase = json.loads((ROOT/'phase2/summary.json').read_text())
    candidate = 'gaps'
    summary = phase['summary']
    advanced = (summary[candidate]['points'] > summary['baseline']['points']
                and summary[candidate]['policy_errors'] == 0)
    decision = dict(candidate=candidate,
                    source_sha256=hashlib.sha256((ROOT/'sources/gaps/team.py').read_bytes()).hexdigest(),
                    development_advance=advanced,
                    promoted=False,
                    active_champion_changed=False)
    if not advanced:
        decision.update(eligible=False, reason='Failed the registered development advance: must strictly exceed NOVA points with zero SDK errors.')
        return decision
    report = json.loads((ROOT/'qualification/summary.json').read_text())
    audited = json.loads((ROOT/'qualification/audit.json').read_text())
    registration = json.loads((ROOT/'qualification/registration.json').read_text())
    assert registration['seeds'] == plan['qualification']['seeds']
    assert set(registration['opponents']) == set(plan['qualification']['styles'])
    assert registration['sources'][candidate]['sha256'] == decision['source_sha256']
    assert audited['complete'] and audited['balanced']
    s = report['summary'][candidate]
    assert s['matches'] == plan['qualification']['fixtures_per_source']
    intake = json.loads((ROOT/'gaps-intake.json').read_text())
    source = ROOT/'sources/gaps/team.py'
    tree = ast.parse(source.read_text())
    controls = {}
    for control in ('baseline','monster16'):
        paired = audited['comparisons'][candidate][control]
        controls[control] = dict(
            positive_paired_95_lower=paired['seed_block_95'][0] > 0,
            additional_raw_deadline_misses_per1000=paired['additional_raw_misses_per1000'] <= 2,
            worst_style_decline=min(paired['style_difference_per_fixture'].values()) >= -0.25,
            worst_formation_profile_decline=min(paired['profile_difference_per_fixture'].values()) >= -0.1,
        )
    gates = dict(
        paired_comparisons=controls,
        zero_policy_exceptions=s['policy_errors'] == 0,
        official_intake=bool(intake['ok']),
        single_sdk_class=sum(isinstance(n,ast.ClassDef) and any(isinstance(b,ast.Name) and b.id=='TeamController' for b in n.bases) for n in tree.body) == 1,
        code_bytes_max=source.stat().st_size <= 262144,
    )
    flat = [v for group in controls.values() for v in group.values()]
    flat.extend(v for k,v in gates.items() if k != 'paired_comparisons')
    decision.update(eligible=all(flat), gates=gates,
                    reason=('Eligible for explicit user review; no automatic promotion.' if all(flat)
                            else 'Rejected for promotion: at least one original qualification gate failed.'))
    return decision


if __name__ == '__main__':
    result = decide()
    (ROOT/'decision.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
