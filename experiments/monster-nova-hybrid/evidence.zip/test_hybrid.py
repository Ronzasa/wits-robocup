"""Role/pass preservation and source-isolation regressions, not strength proof."""
import ast,copy,math,unittest
from pathlib import Path
from soccer import SoccerEnv
from soccer.helpers import load_controller
from build import MonsterNames
R=Path(__file__).resolve().parent

class HybridTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with SoccerEnv() as e:cls.field=e.field
    def controller(self,name):
        c=load_controller(str(R/'sources'/name/'team.py'));c.reset(1);c._monster.setup(self.field)
        c._nova._hybrid_tick=200;c._nova._hybrid_lead=0
        return c
    def fixture(self):
        P=[(-48.,0.,0.,0.,0),(-39.,3.,0.,0.,0),(-35.,-5.,0.,0.,0),(-30.,12.,0.,0.,0),(0.,0.,0.,0.,0)]
        O=[(48.,0.,0.,0.,0),(-38.,1.,0.,0.,0),(-30.,8.,0.,0.,0),(-25.,-9.,0.,0.,0),(10.,10.,0.,0.,0)]
        return P,O,[(-40.,4.)]*65
    def test_other_nova_methods_are_identical(self):
        t=ast.parse((R/'sources/baseline/team.py').read_text());before=next(n for n in t.body if isinstance(n,ast.ClassDef))
        original={n.name:ast.dump(n) for n in before.body if isinstance(n,ast.FunctionDef)}
        for label in ('cover','gaps','corner'):
            t=ast.parse((R/'sources'/label/'team.py').read_text());c=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='_NovaPolicy')
            for f in c.body:
                if not isinstance(f,ast.FunctionDef):continue
                g=copy.deepcopy(f)
                if g.name.startswith('_original_'):g.name=g.name.replace('_original_','_',1)
                elif g.name in ('_kick','_defend_spots') and ((label=='cover' and g.name=='_defend_spots') or (label!='cover' and g.name=='_kick')):continue
                self.assertEqual(original[g.name],ast.dump(g),(label,g.name))
    def test_frozen_monster_physics_preserved(self):
        t=MonsterNames().visit(ast.parse((R/'sources/monster16/team.py').read_text()));original=next(n for n in t.body if isinstance(n,ast.ClassDef))
        funcs=lambda c:{f.name:ast.dump(f) for f in c.body if isinstance(f,ast.FunctionDef)}
        for label in ('cover','gaps','corner'):
            t=ast.parse((R/'sources'/label/'team.py').read_text());c=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='_MonsterPolicy')
            self.assertEqual(funcs(original),funcs(c))
    def test_cover_changes_only_existing_block_and_cover_jobs(self):
        p,o,path=self.fixture();c=self.controller('cover');n=c._nova
        a=n._original_defend_spots(-40.,4.,path,5,1,o,p,3);b=n._defend_spots(-40.,4.,path,5,1,o,p,3)
        self.assertEqual(len(a),len(b));self.assertEqual(n._hybrid_counts['cover_updates'],1)
        for old,new in zip(a,b):
            self.assertEqual(old[3],new[3])
            if old[3] not in ('blk','cov'):self.assertEqual(old,new)
    def test_cover_preserves_live_reception_and_normal_midfield(self):
        p,o,path=self.fixture();n=self.controller('cover')._nova;n._plan=(2,230)
        self.assertEqual(n._original_defend_spots(-40.,4.,path,5,1,o,p,3),n._defend_spots(-40.,4.,path,5,1,o,p,3))
        n._plan=None
        self.assertEqual(n._original_defend_spots(-20.,4.,path,5,1,o,p,3),n._defend_spots(-20.,4.,path,5,1,o,p,3))
    def test_gap_search_is_bounded_and_preserves_normal_kicks(self):
        c=self.controller('gaps');n=c._nova;calls=[];sentinel=object()
        n._original_kick=lambda *args,**kw:(calls.append(kw) or sentinel)
        p,o,_=self.fixture();self.assertIs(n._kick(1,0.,0.,0.,0.,p,o,200),sentinel);self.assertEqual(calls[-1],{})
        o=[(48.8,y,0.,0.,0) for y in (-5.4,-1.8,1.8,5.4,0.)]
        self.assertIs(n._kick(1,35.,8.,0.,0.,p,o,200),sentinel)
        self.assertLessEqual(n._hybrid_counts['extra_aims'],3)
        self.assertIn('GOAL_YS',calls[-1])
    def test_corner_never_replaces_another_receivers_pass(self):
        c=self.controller('corner');n=c._nova;p,o,_=self.fixture();sentinel={'movement':(0.,0.),'kick_direction':(1.,0.),'kick_power':.5}
        def chosen(*args):n._plan=(2,230);return sentinel
        n._original_kick=chosen
        self.assertIs(n._kick(4,48.,7.2,0.,0.,p,o,200),sentinel)
        self.assertEqual(n._hybrid_counts['corner_checks'],0)
    def test_corner_requires_executable_contact(self):
        c=self.controller('corner');n=c._nova;m=c._monster;p,o,_=self.fixture();sentinel={'movement':(0.,0.),'kick_direction':(1.,0.),'kick_power':.5}
        def chosen(*args):n._plan=(4,230);return sentinel
        n._original_kick=chosen;m.deadline=math.inf;m.duel=lambda *args:(20.,((.8,-.6),1.),(0.,0.),None)
        self.assertIs(n._kick(4,48.,7.2,0.,0.,p,o,200),sentinel)
        self.assertEqual(n._hybrid_counts['corner_overrides'],0)
    def test_source_limits_and_no_gc_freeze(self):
        for label in ('cover','gaps','corner'):
            p=R/'sources'/label/'team.py';s=p.read_text();t=ast.parse(s)
            self.assertNotIn('gc.freeze',s);self.assertLess(p.stat().st_size,262144)
            self.assertEqual(sum(isinstance(c,ast.ClassDef) and any(isinstance(b,ast.Name) and b.id=='TeamController' for b in c.bases) for c in t.body),1)

if __name__=='__main__':unittest.main()
