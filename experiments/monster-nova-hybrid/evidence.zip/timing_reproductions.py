"""Bounded diagnostics of raw qualifier misses; never replace recorded results."""
import hashlib
import json
from pathlib import Path
from isolated_match import native_match

ROOT = Path(__file__).resolve().parent


def main():
    # Require the original full panel to have finished. Repeats cannot qualify a
    # candidate, alter its measured misses, or establish an environmental cause.
    assert (ROOT/'qualification/summary.json').exists()
    output = ROOT/'timing-reproductions.json'
    assert not output.exists()
    reg = json.loads((ROOT/'qualification/registration.json').read_text())
    rows = [json.loads(x) for x in (ROOT/'qualification/matches.jsonl').read_text().splitlines()]
    cases = [r for r in rows if any(e['side']==r['candidate_slot'] and e['elapsed_ms']>20
                                  for e in r['telemetry']['slow'])]
    assert len(cases) <= 12, 'Unexpected widespread failure: investigate before broad reruns'
    results = []
    for case in cases:
        candidate = reg['sources'][case['source']]
        opponent = reg['opponents'][case['opponent_name']]
        for item in (candidate,opponent):
            assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
        for repeat in range(3):
            result,telemetry,roster = native_match(candidate['path'],opponent['path'],case['seed'],
                case['candidate_slot'],case['candidate_takes_kickoff'],
                dict(reg,formation_profile=case['formation_profile']))
            row = {k:case[k] for k in ('source','opponent_name','seed','candidate_slot',
                                       'candidate_takes_kickoff','formation_profile')}
            row.update(repeat=repeat,result=result,telemetry=telemetry,initial_roster=roster)
            results.append(row)
    report = dict(repeats_per_slow_fixture=3, original_slow_fixtures=len(cases),rows=results,
                  replaces_qualification=False, source_or_gate_changes=False,
                  limitation='A non-reproduced spike does not prove an environmental cause. All original raw misses remain counted.')
    output.write_text(json.dumps(report,indent=2)+'\n')
    for label in reg['sources']:
        rs = [r for r in results if r['source']==label]
        if rs:
            stats = [r['result']['stats'][r['candidate_slot']] for r in rs]
            print(label, len(rs), 'diagnostic repeats;',sum(s['policy_timeouts'] for s in stats),
                  'raw misses;',sum(s['policy_errors'] for s in stats),'SDK errors; max ms',
                  max(s['decision_time_ms']['max_ms'] for s in stats))


if __name__ == '__main__':
    main()
