"""Whole-policy handoffs occur only at native goal-reset boundaries."""
import unittest
from pathlib import Path
from types import SimpleNamespace as N
from soccer import SoccerEnv
from soccer.helpers import load_controller
R=Path(__file__).resolve().parent
class Handoffs(unittest.TestCase):
    def setUp(self):
        self.c=load_controller(str(R/'sources/score-reset/team.py'));self.c.reset(9)
        with SoccerEnv() as e:self.field=e.field
        self.a=object();self.b=object()
        self.c._nova._act=lambda obs:self.a
        self.c._monster.act=lambda obs:self.b
    def obs(self,score=(0,0),remaining=50.,position=(0.,0.),velocity=(0.,0.)):
        return N(score=score,time_remaining=remaining,ball=N(position=position,velocity=velocity),tick=1400,field=self.field)
    def test_enters_monster_only_on_second_half_lead_restart(self):
        self.assertIs(self.c.act(self.obs()),self.a)
        self.assertIs(self.c.act(self.obs(score=(1,0))),self.b)
        self.assertEqual(self.c._hybrid_counts['mode_switches'],1)
    def test_early_goal_preserves_nova(self):
        self.c.act(self.obs(remaining=90.))
        self.assertIs(self.c.act(self.obs(score=(1,0),remaining=90.)),self.a)
    def test_live_actions_are_not_interrupted(self):
        self.c.act(self.obs())
        self.c._nova._plan=(3,1500)
        self.assertIs(self.c.act(self.obs(score=(1,0),position=(20.,5.),velocity=(8.,1.))),self.a)
        self.assertEqual(self.c._nova._plan,(3,1500))
    def test_equalizer_restores_attack_and_clears_stale_plan(self):
        self.c.act(self.obs());self.c.act(self.obs(score=(1,0)))
        self.c._nova._plan=(3,1500)
        self.assertIs(self.c.act(self.obs(score=(1,1))),self.a)
        self.assertIsNone(self.c._nova._plan)
        self.assertEqual(self.c._hybrid_counts['mode_switches'],2)
    def test_reset_restores_normal_opening(self):
        self.c.act(self.obs());self.c.act(self.obs(score=(1,0)))
        self.c.reset(10)
        self.assertEqual(self.c._mode,'nova');self.assertIsNone(self.c._previous_score)
        self.assertEqual(self.c._hybrid_counts['monster_ticks'],0)
if __name__=='__main__':unittest.main()
