"""MONSTER movement / NOVA action handoff and reception preservation."""
import os,unittest
from pathlib import Path
from types import SimpleNamespace as N
from soccer import SoccerEnv,TeamAction,PlayerAction
from soccer.helpers import load_controller
R=Path(__file__).resolve().parent
class BallIntegration(unittest.TestCase):
    def setUp(self):
        self.c=load_controller(str(R/'sources'/os.environ.get('BALL_VARIANT','monster-ball')/'team.py'));self.c.reset(9)
        with SoccerEnv() as e:self.c._monster.setup(e.field)
        self.m=TeamAction({i:PlayerAction(movement=(-.5,.1)) for i in range(5)})
        self.n={i:{'movement':(.5,-.1)} for i in range(5)}
        self.c._monster.act=lambda obs:self.m
        self.c._nova._act=lambda obs:{i:dict(v) for i,v in self.n.items()}
        self.c._nova._chaser=4
    def obs(self,bx=0.,last_touch=4):
        return N(tick=200,score=(0,0),ball=N(position=(bx,0.),last_touch=last_touch))
    def test_four_cover_movements_are_preserved(self):
        a=self.c.act(self.obs())
        for i in range(4):self.assertEqual(a[i]['movement'],self.m.players[i].movement)
        self.assertEqual(a[4],self.n[4])
    def test_outlet_stays_forward_during_deep_defence(self):
        a=self.c.act(self.obs(bx=-40.))
        self.assertEqual(a[4]['movement'],self.m.players[4].movement)
    def test_nova_kick_keeps_its_contact_movement(self):
        self.n[1]={'movement':(0.,0.),'kick_direction':(1.,0.),'kick_power':.8}
        a=self.c.act(self.obs(bx=-40.))
        self.assertEqual(a[1],self.n[1]);self.assertEqual(self.c._hybrid_counts['nova_kicks'],1)
    def test_live_receiver_is_not_pulled_back_into_wall(self):
        self.c._nova._plan=(2,220)
        a=self.c.act(self.obs(last_touch=1))
        self.assertEqual(a[2],self.n[2]);self.assertEqual(self.c._hybrid_counts['receiver_ticks'],1)
    def test_opponent_touch_invalidates_receiving_override(self):
        self.c._nova._plan=(2,220)
        a=self.c.act(self.obs(last_touch=6))
        self.assertEqual(a[2]['movement'],self.m.players[2].movement)
    def test_real_shared_budget_start_is_set(self):
        from time import perf_counter
        before=perf_counter();self.c.act(self.obs());after=perf_counter()
        self.assertLessEqual(before,self.c._nova._hybrid_started)
        self.assertLessEqual(self.c._nova._hybrid_started,after)
    def test_nova_cached_action_dictionary_is_not_modified(self):
        self.c._nova._act=lambda obs:self.n
        before={i:dict(v) for i,v in self.n.items()}
        self.c.act(self.obs())
        self.assertEqual(self.n,before)
if __name__=='__main__':unittest.main()
