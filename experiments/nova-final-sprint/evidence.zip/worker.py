"""One unmodified-policy native fixture in a fresh interpreter."""
import json,sys
from pathlib import Path
from native_driver import native_match
request=json.loads(Path(sys.argv[1]).read_text())
result,telemetry,roster=native_match(request['candidate'],request['opponent'],request['seed'],request['side'],request['kick'],request['reg'])
Path(sys.argv[2]).write_text(json.dumps(dict(result=result,telemetry=telemetry,initial_roster=roster)))
