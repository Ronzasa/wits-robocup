"""Freeze sources and a balanced native panel before the first fixture."""
import argparse,hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('--sources',nargs='+',type=Path,required=True);p.add_argument('--opponents',nargs='+',type=Path,required=True);p.add_argument('--seeds',nargs='+',type=int,required=True);p.add_argument('--scope',required=True);a=p.parse_args();a.folder.mkdir()
def item(path):return dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
reg=dict(sources={v.parent.name:item(v) for v in a.sources},opponents={v.parent.name:item(v) for v in a.opponents},seeds=a.seeds,formation_profiles=['default','controller'],order_seed=4127076001,config_path='/workspace/work/replay-finishing-handoffs/configs/default.toml',config_hash='372990895c7eca2a',engine_version='0.1.0',deadline_ms=20,max_ticks=2400,workers=1,scope=a.scope,promotion=False,harness_sha256={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['batch.py','native_driver.py','worker.py','isolated_match.py']})
(a.folder/'registration.json').write_text(json.dumps(reg,indent=2)+'\n');print('Registered',len(reg['sources'])*len(reg['opponents'])*len(reg['seeds'])*8,'full native fixtures')
