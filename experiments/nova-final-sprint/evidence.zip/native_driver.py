"""Official native decisions, raw20ms accounting, selectable formation profile."""
from soccer import SoccerEnv,TeamController,runner
from soccer.helpers import load_controller

def native_match(candidate,opponent,seed,side,kick,reg):
    paths=[candidate,opponent]
    if side:paths.reverse()
    controllers=[load_controller(p) for p in paths]
    profile=reg.get('formation_profile','default')
    assert profile in ('default','controller')
    telemetry=dict(first_goal=None,slow=[],formation_corrections=[])
    with SoccerEnv(config_path=reg['config_path'],max_ticks=2400,per_decision_timeout_ms=20.,team_ids=('policy_a','policy_b')) as env:
        if profile=='controller':
            for slot,c in enumerate(controllers):
                formation=runner._formation(c,env)
                if formation is not None:telemetry['formation_corrections'].append(dict(side=slot,count=env.set_formation(slot,formation)))
        for c in controllers:c.reset(seed)
        observations=env.reset(seed=seed,kickoff_team=side if kick else 1-side)
        initial_roster=[list(p.position) for p in list(observations['team_a'].my_players)+list(observations['team_a'].opponents)]
        previous=[TeamController.idle(observations[key]) for key in ('team_a','team_b')]
        while not env.finished:
            actions={}
            for slot,key in ((0,'team_a'),(1,'team_b')):
                obs=observations[key]
                action,elapsed,error=runner._decide(controllers[slot],obs)
                if slot==side and telemetry['first_goal'] is None and sum(obs.score):telemetry['first_goal']='candidate' if obs.score[0]>obs.score[1] else 'opponent'
                if error is None:previous[slot]=action
                else:action=previous[slot]
                if elapsed>20. or error is not None:telemetry['slow'].append(dict(side=slot,tick=obs.tick,elapsed_ms=elapsed,error=error))
                env.record_decision(slot,elapsed,error)
                actions[key]=action
            if env.finished:break
            observations,_=env.step(actions)
        result=env.result()
    assert result['engine_version']==reg['engine_version'] and result['config_hash']==reg['config_hash']
    assert not result.get('platform_error')
    telemetry['hybrid_counts']=dict(getattr(controllers[side],'_hybrid_counts',{}))
    return result,telemetry,initial_roster
