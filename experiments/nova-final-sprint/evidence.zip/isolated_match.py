"""Fresh interpreter per native fixture; contain uploaded module GC side effects."""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

def native_match(candidate,opponent,seed,side,kick,reg):
    with tempfile.TemporaryDirectory(prefix='div1-native-') as tmp:
        root=Path(tmp)
        request=root/'request.json';out=root/'result.json'
        request.write_text(json.dumps(dict(candidate=candidate,opponent=opponent,seed=seed,side=side,kick=kick,reg=reg)))
        p=subprocess.run([sys.executable,str(Path(__file__).with_name('worker.py')),str(request),str(out)],capture_output=True,text=True,timeout=120)
        if p.returncode:
            raise RuntimeError('Native worker failed: '+p.stderr[-4000:])
        d=json.loads(out.read_text())
        return d['result'],d['telemetry'],d['initial_roster']
