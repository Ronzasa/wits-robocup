"""Guard role/pass preservation and the isolated wall-only movement boundary."""
import ast
import copy
import unittest
from pathlib import Path
from soccer.helpers import load_controller

ROOT=Path(__file__).resolve().parent
LABELS=('patient-wall','responsive-wall','rebound-depth','wall-pressure')


class SprintTests(unittest.TestCase):
    def policy(self,label):
        c=load_controller(str(ROOT/'sources'/label/'team.py'));c.reset(1)
        c._late=False;c._behind=False
        return c

    def shape(self,c,pin,n=4):
        opponents=[(49.,y,0.,0.,0) for y in (0.,-5.4,-1.8,1.8,5.4)]
        return c._attack_spots(35.,5.,[(35.,5.)]*65,0,opponents,n,pin)

    def test_normal_attacking_roles_are_identical(self):
        base=self.shape(self.policy('baseline'),False)
        for label in LABELS:self.assertEqual(base,self.shape(self.policy(label),False),label)

    def test_rebound_moves_preserve_rest_defender_and_support(self):
        base=self.shape(self.policy('baseline'),True)
        for label in ('rebound-depth','wall-pressure'):
            changed=self.shape(self.policy(label),True)
            self.assertEqual(base[2:],changed[2:])
            self.assertNotEqual(base[:2],changed[:2])
            self.assertEqual([p[3] for p in base],[p[3] for p in changed])

    def test_kick_variants_do_not_change_any_attack_targets(self):
        for pin in (False,True):
            base=self.shape(self.policy('baseline'),pin)
            for label in ('patient-wall','responsive-wall'):
                self.assertEqual(base,self.shape(self.policy(label),pin))

    def test_keeper_defence_movement_receiving_physics_are_frozen(self):
        t=ast.parse((ROOT/'sources/baseline/team.py').read_text())
        original=next(n for n in t.body if isinstance(n,ast.ClassDef))
        functions={n.name:ast.dump(n) for n in original.body if isinstance(n,ast.FunctionDef)}
        allowed={'__init__','reset','act','_kick','_attack_spots'}
        for label in LABELS:
            t=ast.parse((ROOT/'sources'/label/'team.py').read_text())
            cls=next(n for n in t.body if isinstance(n,ast.ClassDef))
            for f in cls.body:
                if isinstance(f,ast.FunctionDef) and f.name not in allowed:
                    self.assertEqual(functions[f.name],ast.dump(f),(label,f.name))

    def test_no_hidden_new_policy_exceptions(self):
        for label in LABELS:
            c=self.policy(label)
            def broken(obs):raise ValueError('diagnostic sentinel')
            c._act=broken
            with self.assertRaisesRegex(ValueError,'diagnostic sentinel'):c.act(None)

    def test_source_contract_and_original_gc_behavior(self):
        original=ast.parse((ROOT/'sources/baseline/team.py').read_text())
        freeze=[ast.dump(n) for n in original.body if isinstance(n,ast.Try) and 'gc.freeze' in ast.unparse(n)]
        for label in LABELS:
            p=ROOT/'sources'/label/'team.py';t=ast.parse(p.read_text())
            self.assertLess(p.stat().st_size,262144)
            self.assertEqual(sum(isinstance(n,ast.ClassDef) and any(isinstance(b,ast.Name) and b.id=='TeamController' for b in n.bases) for n in t.body),1)
            self.assertEqual(freeze,[ast.dump(n) for n in t.body if isinstance(n,ast.Try) and 'gc.freeze' in ast.unparse(n)])


if __name__=='__main__':unittest.main()
