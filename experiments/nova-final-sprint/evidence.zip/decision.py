"""Apply the preregistered deadline-sprint gates, with original NOVA fallback."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def read(p):return json.loads((ROOT/p).read_text())


def decide():
    selection=read('phase1-selection.json');candidate=selection['candidate']
    result={'candidate':candidate,'selected':'baseline','promoted_to_active_champion':False}
    if not candidate or not (ROOT/'phase2/summary.json').exists():
        result.update(eligible=False,reason='No completed positive broader development; retain untouched NOVA.')
        return result
    phase=read('phase2/summary.json')['summary']
    advance=phase[candidate]['points']>phase['baseline']['points'] and phase[candidate]['policy_errors']==0
    result['development_advance']=advance
    if not advance:
        result.update(eligible=False,reason='Did not strictly improve original NOVA in broader development; retain untouched NOVA.')
        return result
    if not (ROOT/'qualification/summary.json').exists():
        result.update(eligible=False,reason='Qualification incomplete; retain untouched NOVA.')
        return result
    q=read('qualification/summary.json');audit=read('qualification/audit.json');reg=read('qualification/registration.json');plan=read('research-plan.json')
    assert reg['seeds']==plan['qualification']['seeds']
    assert set(reg['opponents'])==set(plan['qualification']['styles'])
    assert audit['complete'] and audit['balanced']
    s=q['summary'][candidate];assert s['matches']==512
    source=ROOT/'sources'/candidate/'team.py'
    assert hashlib.sha256(source.read_bytes()).hexdigest()==reg['sources'][candidate]['sha256']
    tree=ast.parse(source.read_text());controls={}
    for label in ('baseline','monster16'):
        p=audit['comparisons'][candidate][label]
        controls[label]={'positive_paired_95_lower':p['seed_block_95'][0]>0,
                         'additional_raw_misses_per1000':p['additional_raw_misses_per1000']<=2,
                         'worst_style_decline':min(p['style_difference_per_fixture'].values())>=-0.25,
                         'worst_profile_decline':min(p['profile_difference_per_fixture'].values())>=-0.1}
    gates={'paired_controls':controls,'zero_policy_exceptions':s['policy_errors']==0,
           'official_intake':read(f'{candidate}-intake.json')['ok'],
           'single_sdk_class':sum(isinstance(n,ast.ClassDef) and any(isinstance(b,ast.Name) and b.id=='TeamController' for b in n.bases) for n in tree.body)==1,
           'code_bytes_max':source.stat().st_size<=262144}
    flags=[v for c in controls.values() for v in c.values()]+[v for k,v in gates.items() if k!='paired_controls']
    eligible=all(flags)
    result.update(eligible=eligible,gates=gates,selected=candidate if eligible else 'baseline',
                  source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  reason='Qualified experimental NOVA upgrade; active champion remains unchanged.' if eligible else 'Original confidence or reliability gate failed; retain untouched NOVA.')
    return result


if __name__=='__main__':
    result=decide();(ROOT/'decision.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
