"""Audit balanced raw native fixtures and compare policies by whole-seed blocks.

No native matches are run. Repeated development panels are never pooled as
independent evidence. Original registration paths may be remapped after export.
"""
import argparse
import hashlib
import itertools
import json
import random
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relocated(value):
    p = Path(value)
    for directory in ('sources', 'opponents'):
        if directory in p.parts:
            i = p.parts.index(directory)
            return ROOT.joinpath(*p.parts[i:])
    return p


def points(row):
    side = row['candidate_slot']
    a, b = row['result']['score'][side], row['result']['score'][1-side]
    return 3 if a > b else 1 if a == b else 0


def key(row):
    return (row['opponent_name'], row['seed'], row['candidate_slot'],
            row['candidate_takes_kickoff'], row['formation_profile'])


def compare(candidate, control):
    before = {key(row): row for row in control}
    differences = defaultdict(list)
    styles = defaultdict(list)
    profiles = defaultdict(list)
    for row in candidate:
        change = points(row) - points(before[key(row)])
        differences[row['seed']].append(change)
        styles[row['opponent_name']].append(change)
        profiles[row['formation_profile']].append(change)
    means = [sum(v)/len(v) for _, v in sorted(differences.items())]
    rng = random.Random(3260260099)
    boots = sorted(sum(rng.choices(means, k=len(means)))/len(means)
                   for _ in range(10000))
    misses = lambda rows: sum(r['result']['stats'][r['candidate_slot']]['policy_timeouts'] for r in rows)
    return dict(
        points_difference=sum(points(r) for r in candidate)-sum(points(r) for r in control),
        points_difference_per_fixture=sum(means)/len(means),
        seed_block_95=[boots[250], boots[9749]],
        seed_blocks=len(means),
        seed_means={str(s): sum(v)/len(v) for s, v in sorted(differences.items())},
        style_difference_per_fixture={s: sum(v)/len(v) for s,v in sorted(styles.items())},
        profile_difference_per_fixture={s: sum(v)/len(v) for s,v in sorted(profiles.items())},
        additional_raw_misses_per1000=(misses(candidate)-misses(control))*1000/len(candidate),
    )


def audit(folder):
    reg = json.loads((folder/'registration.json').read_text())
    rows = [json.loads(line) for line in (folder/'matches.jsonl').read_text().splitlines()]
    expected = set(itertools.product(reg['opponents'], reg['seeds'], (0,1),
                                     (True,False), reg['formation_profiles']))
    grouped = {name: [] for name in reg['sources']}
    seen = {name: set() for name in grouped}
    slow = []
    for row in rows:
        label = row['source']
        k = key(row)
        assert k in expected and k not in seen[label], (label,k)
        seen[label].add(k)
        grouped[label].append(row)
        result = row['result']
        assert result['ticks'] == 2400 and result['terminal_reason'] == 'time_limit'
        assert result['engine_version'] == reg['engine_version']
        assert result['config_hash'] == reg['config_hash']
        assert not result.get('platform_error')
        kickoff = row['candidate_slot'] if row['candidate_takes_kickoff'] else 1-row['candidate_slot']
        assert result['kickoff_team'] == kickoff
        events = row['telemetry']['slow']
        for side in (0,1):
            stats = result['stats'][side]
            assert stats['decision_time_ms']['count'] == 2400
            assert stats['policy_timeouts'] == sum(e['side']==side and e['elapsed_ms']>20 for e in events)
            assert stats['policy_errors'] == sum(e['side']==side and e['error'] is not None for e in events)
        for event in events:
            slow.append(dict(source=label, fixture=k, **event))
    for name, keys in seen.items():
        assert keys == expected, (name, len(keys), len(expected))
    for name, item in {**reg['sources'],**reg['opponents']}.items():
        assert digest(relocated(item['path'])) == item['sha256'], name
    for name, expected_hash in reg['harness_sha256'].items():
        assert digest(ROOT/name) == expected_hash, ('harness',name)
    result = dict(
        fixtures=len(rows), fixtures_per_source=len(expected),
        sources={name: item['sha256'] for name,item in reg['sources'].items()},
        complete=True, balanced=True, raw_slow_events=slow,
        comparisons={candidate: {control: compare(rs, cs)
                                 for control,cs in grouped.items() if control != candidate}
                     for candidate,rs in grouped.items()},
        counters={name: dict(sum((Counter(r['telemetry'].get('hybrid_counts',{}))
                                 for r in rs), Counter())) for name,rs in grouped.items()},
        warning=('Repeated panels are not independent. No promotion is implied. '
                 + ('Development is exposed and adaptive; two seeds cannot establish a reliable upgrade.'
                    if len(reg['seeds']) == 2 else 'Confidence intervals resample whole seeds, not individual matches.')),
    )
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('folders', nargs='+', type=Path)
    a = p.parse_args()
    for folder in a.folders:
        result = audit(folder)
        (folder/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
        print(folder.name, result['fixtures'], 'balanced complete fixtures; slow events:',len(result['raw_slow_events']))
