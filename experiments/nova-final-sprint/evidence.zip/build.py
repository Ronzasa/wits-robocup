"""Four independent, one-constant NOVA experiments; no combined tactics."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'sources/baseline/team.py'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='b10d96375fa0723db8d8966d099f96f340440f569b95f6751cfb9c66406be484'
VARIANTS={'patient-wall':('PB_X',99.0),'responsive-wall':('WALL_D',1),'rebound-depth':('PB_FX',43.0),'wall-pressure':('PB_FX',48.0)}


def build(label,constant,value):
    tree=ast.parse(BASE.read_text())
    found=False
    for n in tree.body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==constant for t in n.targets):
            n.value=ast.Constant(value);found=True
    assert found
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MyTeam')
    for n in cls.body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='version' for t in n.targets):n.value=ast.Constant('31s-'+label)
        if not isinstance(n,ast.FunctionDef):continue
        if n.name in ('__init__','reset'):
            n.body+=ast.parse("self._hybrid_counts={'wall_kicks':0,'wall_shapes':0}").body
        elif n.name=='act':
            # Surface any real controller exception through official accounting.
            n.body=ast.parse('return self._act(obs)').body
        elif n.name=='_kick':
            for i,s in enumerate(n.body):
                if isinstance(s,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='pin' for t in s.targets):
                    n.body[i+1:i+1]=ast.parse("if nw>=4 and bx>30.0:self._hybrid_counts['wall_kicks']+=1").body
                    break
            else:raise AssertionError('No pin detection')
        elif n.name=='_attack_spots':
            for s in n.body:
                if isinstance(s,ast.If) and ast.unparse(s.test)=='pin and qx > 20.0':
                    s.body[:0]=ast.parse("self._hybrid_counts['wall_shapes']+=1").body
                    break
            else:raise AssertionError('No wall shapes')
    text=ast.unparse(ast.fix_missing_locations(tree))+'\n'
    p=ROOT/'sources'/label/'team.py';p.parent.mkdir();p.write_text(text)
    return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'constant':constant,'value':value,'bytes':p.stat().st_size}


if __name__=='__main__':
    result={name:build(name,*change) for name,change in VARIANTS.items()}
    (ROOT/'source-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
