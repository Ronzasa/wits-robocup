"""Replay one registered panel with the official installed soccer SDK.

Only file locations are remapped; seeds, policies, formations and gates stay
unchanged. The new output directory must not exist. Run one copy at a time.
"""
import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('panel', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--config', type=Path, default=ROOT/'reference/default.toml')
    args = parser.parse_args()
    assert not args.out.exists(), 'Use a new output folder'
    registration = args.panel/'registration.json'
    reg = json.loads(registration.read_text())
    for category in ('sources', 'opponents'):
        for name, item in reg[category].items():
            old = Path(item['path'])
            index = old.parts.index(category)
            new = ROOT.joinpath(*old.parts[index:])
            assert hashlib.sha256(new.read_bytes()).hexdigest() == item['sha256'], name
            item['path'] = str(new)
    reg['config_path'] = str(args.config.resolve())
    reg['reproduction_of'] = dict(registration=str(registration),
                                  sha256=hashlib.sha256(registration.read_bytes()).hexdigest())
    args.out.mkdir(parents=True)
    (args.out/'registration.json').write_text(json.dumps(reg,indent=2)+'\n')
    # The frozen batch uses the repository benchmark module. Supply its exact
    # archived copy when the original workspace does not exist.
    spec = importlib.util.spec_from_file_location('benchmark', ROOT/'reference/benchmark.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    sys.modules['benchmark'] = module
    sys.path.insert(0, str(ROOT))
    from batch import run
    run(args.out)


if __name__ == '__main__':
    main()
