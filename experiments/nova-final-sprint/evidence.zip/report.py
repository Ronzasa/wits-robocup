"""Produce the final submission selection and preserve every experiment."""
import hashlib
import json
import shutil
import zipfile
from datetime import datetime,timezone,timedelta
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DEST=Path('/workspace/work/replay-finishing-handoffs/experiments/nova-final-sprint')


def read(p):return json.loads((ROOT/p).read_text())


def table(summary):
    names={'baseline':'Original NOVA','monster16':'MONSTER16'}
    return '\n'.join(['| Controller | Points | W–D–L | Goals | SDK errors | Raw misses | Mean / max ms |',
                     '|---|---:|---:|---:|---:|---:|---:|']+
       [f"| {names.get(n,n)} | {s['points']} | {s['wins']}–{s['draws']}–{s['losses']} | {s['goals_for']}–{s['goals_against']} | {s['policy_errors']} | {s['policy_timeouts']} | {s['decision_mean_ms']:.3f} / {s['decision_max_ms']:.3f} |" for n,s in summary.items()])


def main():
    decision=read('decision.json');selected=decision['selected'];candidate=decision['candidate']
    source=ROOT/'sources'/selected/'team.py'
    assert read(f'{selected}-intake.json')['ok']
    shutil.copyfile(source,DEST/'team.py')
    assert (DEST/'original/team.py').read_bytes()==(ROOT/'sources/baseline/team.py').read_bytes()
    panels=[p for p in ('phase1','phase2','qualification') if (ROOT/p/'summary.json').exists()]
    prepared=datetime.now(timezone(timedelta(hours=2))).isoformat(timespec='seconds')
    text=f'''# NOVA final sprint — submission selection

**Selected file: `{selected}`.** {decision['reason']}

`team.py` contains the exact selected source, SHA256 `{hashlib.sha256(source.read_bytes()).hexdigest()}`.
`original/team.py` remains the untouched NOVA fallback, SHA256
`b10d96375fa0723db8d8966d099f96f340440f569b95f6751cfb9c66406be484`.
Prepared: {prepared} (Africa/Johannesburg). `main`, active `my-team/team.py` and
archived champions remain unchanged. This experimental submission selection does
not automatically promote the repository champion or update the school upload.

## Change under test

NOVA normally forces a shot against a packed wall after the ball reaches x>30,
even when its own shot model gives it a poor chance. `patient-wall` changes only
`PB_X` from30 to99, allowing the ordinary shot/pass/dribble value comparison to
decide those touches. High-confidence shots remain eligible. Goalkeeper,
defensive cover, receiver planning, movement, contact and ball forecasts retain
their original algorithms. New variants surface exceptions through SDK accounting;
opportunity counters are diagnostic additions. Source metadata identifies each
variant; tactical methods do not read the version.

Four independent single-constant variants were frozen before development:
patient-wall (`PB_X=99`), responsive-wall (`WALL_D=1`), rebound-depth
(`PB_FX=43`) and wall-pressure (`PB_FX=48`). No features were combined. The first
screen selected only the highest-point eligible variant; the others were rejected.
'''
    labels={'phase1':'Initial exposed development: two fresh seeds, four styles, 64 fixtures per source',
            'phase2':'Broader exposed development: two further fresh seeds, eight styles, 128 fixtures per source',
            'qualification':'Untouched qualification: eight fresh seeds, eight styles, 512 fixtures per source'}
    for panel in panels:
        d=read(f'{panel}/summary.json')
        text+=f'\n## {labels[panel]}\n\n'+table(d['summary'])+'\n'
    if 'qualification' not in panels:
        text+='\nQualification was **not started** because the chosen variant did not clear broader development. Its preregistered qualification seeds remain unused. Against MONSTER in broader development, patient play drew all16fixtures; original NOVA had1win,13draws and2losses. Both earned16points. Avoiding losses also removed the only win, so this did not solve the draw-conversion problem.\n'
    if (ROOT/'timing-reproductions.json').exists():
        diag=read('timing-reproductions.json')
        text+='\n### Bounded timing diagnosis\n\n'
        for label in sorted({r['source'] for r in diag['rows']}):
            rows=[r for r in diag['rows'] if r['source']==label]
            stats=[r['result']['stats'][r['candidate_slot']] for r in rows]
            text+=f"{label}: {len(rows)} exact-fixture repeats, {sum(s['policy_timeouts'] for s in stats)} raw misses, {sum(s['policy_errors'] for s in stats)} SDK errors, maximum {max(s['decision_time_ms']['max_ms'] for s in stats):.3f}ms. The original miss stays counted; these repeats do not establish an environmental cause.\n"
    if 'qualification' in panels:
        a=read('qualification/audit.json')
        text+='\nPaired comparisons resample whole seed blocks, using the original fixed 10,000-replicate bootstrap.\n\n'
        text+='| Comparison | Point difference / fixture | Paired seed-block 95% interval | Additional raw misses / 1,000 |\n|---|---:|---:|---:|\n'
        for control in ('baseline','monster16'):
            c=a['comparisons'][candidate][control];lo,hi=c['seed_block_95']
            text+=f"| {candidate} − {control} | {c['points_difference_per_fixture']:+.4f} | [{lo:+.4f}, {hi:+.4f}] | {c['additional_raw_misses_per1000']:+.3f} |\n"
        text+='\nRegistered gates:\n\n'
        for control,flags in decision['gates']['paired_controls'].items():
            for name,passed in flags.items():text+=f"- {control}: {name}: **{'PASS' if passed else 'FAIL'}**.\n"
        for name,passed in decision['gates'].items():
            if name!='paired_controls':text+=f"- {name}: **{'PASS' if passed else 'FAIL'}**.\n"
    text+='''
## Reliability and interpretation

- Official engine0.1.0, config372990895c7eca2a, full2,400ticks and unchanged20ms
  SDK enforcement. One timed native worker at a time; a fresh process per fixture.
- Original NOVA's authored `gc.freeze()` is preserved identically in variants;
  it is contained between fixtures. No new GC, clock, affinity or SDK changes.
- Both field assignments and kickoffs, plus default/controller formation profiles.
  Profiles can coincide physically; they are not independent seed samples.
- Frozen original NOVA contains an internal fallback exception handler. Its SDK
  error count does not prove zero swallowed exceptions. New variants call the
  policy directly so their exceptions are counted by the official SDK.
- Raw misses from either side are retained. Clean diagnostic reruns, if any,
  never erase a miss or prove its cause was environmental.
- Two-seed development intervals cannot establish a reliable upgrade. Only one
  frozen candidate may qualify, without tuning, early stopping or optional
  extensions. Incomplete evaluation or any failed gate selects original NOVA.
- Wall counters count opportunities, not goals or causal conversions. The first
  screen's points gain came from fewer losses; scoring was unchanged.
- This local panel does not contain the actual controllers of every school
  league leader and does not establish a Division1 ranking. Recent league stats
  identify a draw-heavy weakness but cannot prove an individual tactical cause.

## Evidence and reproduction

`evidence.zip` contains all frozen variants and controls, opponent snapshots,
registrations, raw native rows, summaries, integrity audits, regression tests,
official intakes and reproduction tools. Original registrations preserve their
workspace paths as provenance. The reproducer remaps only file locations.

Extract the archive and use the official course SDK:

```sh
python audit.py phase1 phase2 qualification
python reproduce.py phase2 --out new-development-reproduction
```

Run only completed panels, use a new output folder, and run one timed worker at
a time. The original evidence is never overwritten. Only the selected `team.py`
is uploaded to the school; auxiliary Python files are research tools.
'''
    text=text.replace('python audit.py phase1 phase2 qualification','python audit.py '+' '.join(panels))
    (ROOT/'REPORT.md').write_text(text);(DEST/'README.md').write_text(text)
    files=set(ROOT.glob('*.py'))|set(ROOT.glob('*.json'))|set(ROOT.glob('*.log'))|{ROOT/'REPORT.md'}
    files.discard(ROOT/'MANIFEST.json')
    for folder in ('sources','opponents','reference'):
        files.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.toml'))
    for panel in panels:
        assert (ROOT/panel/'audit.json').exists()
        files.update(ROOT/panel/n for n in ('registration.json','metadata.json','matches.jsonl','summary.json','audit.json','run.log'))
    manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');files.add(ROOT/'MANIFEST.json')
    with zipfile.ZipFile(DEST/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(files):
            info=zipfile.ZipInfo(str(p.relative_to(ROOT)),(2026,10,27,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            z.writestr(info,p.read_bytes())
    shutil.copyfile(ROOT/'decision.json',DEST/'decision.json')
    if 'qualification' in panels:
        for name in ('summary.json','audit.json'):
            shutil.copyfile(ROOT/'qualification'/name,DEST/('qualification-'+name))
    paths=[p for p in DEST.rglob('*') if p.is_file() and p.name!='SHA256SUMS']
    (DEST/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(DEST)}\n' for p in sorted(paths)))
    print('Selected',selected,'prepared',prepared,'archived',len(files),'files')


if __name__=='__main__':main()
