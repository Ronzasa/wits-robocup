import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'vendor'))
import cv2,numpy as np
ROOT=Path(__file__).parent

def glyphs(im,cx):
 hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV);out={}
 for color,lo,hi in [('blue',(90,90,110),(125,255,255)),('red',(0,100,100),(18,255,255))]:
  mask=cv2.inRange(hsv,np.array(lo),np.array(hi));mask[:, :int(cx)-48]=0;mask[:,int(cx)+48:]=0;mask[95:]=0
  ct,ll,stats,cents=cv2.connectedComponentsWithStats(mask)
  cand=[s for s in stats[1:] if s[3]>=15 and s[2]>=4 and s[4]>30]
  if not cand:out[color]=None;continue
  s=max(cand,key=lambda s:s[3]);x,y,w,h,_=s
  patch=mask[y:y+h,x:x+w];out[color]=cv2.resize(patch,(16,24),interpolation=cv2.INTER_NEAREST)>0
 return out

def main():
 templates={}
 # Labels are checked directly in original-resolution scoreboards.
 for n,which,label in [(1,'start',0),(5,'start',1),(3,'last',2),(2,'last',3)]:
  im=cv2.imread(str(ROOT/('game%d-%s.png'%(n,which))));rect=json.loads((ROOT/('game%d-tracking.json'%n)).read_text())['rect'];cx=rect[0]+rect[2]/2
  g=glyphs(im,cx);templates[label]=g['red' if label==3 else 'blue']
 for label,t in templates.items():
  assert t is not None,label
 jobs=json.loads((ROOT/'score-clock.json').read_text());result=[]
 for row in jobs:
  n=row['game'];f=round(row['video_s']*30);path=ROOT/'ocr'/('%02d-%06d.png'%(n,f))
  if not path.exists():path=ROOT/'ocr'/('%02d-last.png'%n)
  im=cv2.imread(str(path));g=glyphs(im,300);score=[];quality=[]
  for color in ('blue','red'):
   if g[color] is None:score.append(None);quality.append(0);continue
   errors={label:np.mean(np.logical_xor(t,g[color])) for label,t in templates.items()};v=min(errors,key=errors.get);score.append(v);quality.append(float(1-errors[v]))
  result.append({**row,'score_ocr':row['score'],'score':score,'score_similarity':quality})
 (ROOT/'timeline.json').write_text(json.dumps(result,indent=2)+'\n')
 for n in range(1,11):
  vals=[x for x in result if x['game']==n];old=None;changes=[]
  for v in vals:
   if min(v['score_similarity'])<.8:continue
   if v['score']!=old:
    changes.append({k:v[k] for k in ('video_s','score','tick','score_similarity')});old=v['score']
  print(n,changes,flush=True)
if __name__=='__main__':main()
