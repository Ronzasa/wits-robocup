import os,sys,json,re,subprocess,math
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,str(Path(__file__).parent/'vendor'))
import cv2,numpy as np
ROOT=Path(__file__).parent

def ocr(item):
 n,second,path=item
 im=cv2.imread(str(path));im=cv2.resize(im,None,fx=2,fy=2)
 ok,b=cv2.imencode('.png',im)
 p=subprocess.run(['tesseract','stdin','stdout','--psm','6'],input=b.tobytes(),capture_output=True,env={**os.environ,'OMP_THREAD_LIMIT':'1'})
 text=p.stdout.decode(errors='replace');norm=text.replace('Q','0').replace('O','0')
 m=re.search(r'([0-9])\s*[—–\-]\s*([0-9])',norm)
 tick=re.search(r'tick\s*([0-9]+)\s*/\s*2400',norm,re.I)
 return {'game':n,'video_s':second,'score':list(map(int,m.groups())) if m else None,'tick':int(tick[1]) if tick else None,'text':text}

def detect(im,rect):
 x0,y0,W,H=rect;hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV);players=[]
 for color,lo,hi in [('blue',(85,70,110),(125,255,255)),('red',(0,75,110),(16,255,255))]:
  mask=cv2.inRange(hsv,np.array(lo),np.array(hi));mask[:int(y0)+2]=0;mask[:, :int(x0)+2]=0;mask[:,int(x0+W)-2:]=0;mask[int(y0+H)-2:]=0
  count,labels,stats,cents=cv2.connectedComponentsWithStats(mask)
  boxes=[s[:4].astype(float) for s in stats[1:] if 12<s[4]<200 and 3<s[2]<17 and 3<s[3]<17]
  groups=[]
  for b in boxes:
   cx,cy=b[:2]+b[2:]/2
   group=next((g for g in groups if np.linalg.norm(np.array([cx,cy])-np.mean([z[:2]+z[2:]/2 for z in g],axis=0))<7),None)
   if group is None:groups.append([b])
   else:group.append(b)
  for g in groups:
   left=min(b[0] for b in g);top=min(b[1] for b in g);right=max(b[0]+b[2] for b in g);bottom=max(b[1]+b[3] for b in g)
   if right-left<7 or bottom-top<7:continue
   cx,cy=(left+right)/2,(top+bottom)/2
   players.append({'color':color,'px':[cx,cy],'pos':[(cx-x0)/W*100-50,30-(cy-y0)/W*100]})
 b,g,r=cv2.split(im);white=((r>185)&(g>185)&(b>185)&(np.maximum(np.maximum(r,g),b)-np.minimum(np.minimum(r,g),b)<45)).astype('uint8')
 white[:int(y0)+2]=0;white[:,:int(x0)+2]=0;white[:,int(x0+W)-2:]=0;white[int(y0+H)-2:]=0
 count,labels,stats,cents=cv2.connectedComponentsWithStats(white)
 balls=[]
 for s,c in zip(stats[1:],cents[1:]):
  if not (8<=s[4]<=65 and 2<=s[2]<=11 and 2<=s[3]<=11):continue
  distance=min((math.dist(c,p['px']) for p in players),default=100.)
  if distance<5.0:continue
  if np.linalg.norm(c-np.array([x0+W/2,y0+H/2]))<4:continue
  balls.append({'px':c.tolist(),'pos':[(c[0]-x0)/W*100-50,30-(c[1]-y0)/W*100],'area':int(s[4]),'size':s[2:4].tolist(),'near_player_px':distance})
 return players,balls

def main():
 rows=json.loads((ROOT/'recordings.json').read_text());jobs=[];summary=[]
 (ROOT/'ocr').mkdir(exist_ok=True)
 for row in rows:
  n=row['game'];cap=cv2.VideoCapture(row['path']);fps=cap.get(cv2.CAP_PROP_FPS);records=[];i=0;rect=None
  final=None
  while True:
   ok,im=cap.read()
   if not ok:break
   if rect is None:
    b,g,r=cv2.split(im);field=((g.astype(float)>r*1.25)&(g.astype(float)>b*1.15)&(g>50)).astype('uint8')
    k=cv2.morphologyEx(field,cv2.MORPH_CLOSE,np.ones((7,7),'uint8'));_,l,s,c=cv2.connectedComponentsWithStats(k);x,y,w,h,a=s[1:][s[1:,4].argmax()]
    rect=[int(x)-2,int(y)-1,int(w)+2,(int(w)+2)*.6]
   players,balls=detect(im,rect)
   records.append({'frame':i,'video_s':i/fps,'players':players,'balls':balls})
   if i%15==0:
    path=ROOT/'ocr'/('%02d-%06d.png'%(n,i));x,y,w,h=rect
    cv2.imwrite(str(path),im[:min(int(y)-5,110),max(0,int(x+w/2-300)):int(x+w/2+300)])
    jobs.append((n,i/fps,path))
   final=im;i+=1
  cap.release()
  path=ROOT/'ocr'/('%02d-last.png'%n);x,y,w,h=rect
  cv2.imwrite(str(path),final[:min(int(y)-5,110),max(0,int(x+w/2-300)):int(x+w/2+300)]);jobs.append((n,(i-1)/fps,path))
  cv2.imwrite(str(ROOT/('game%d-last.png'%n)),final)
  (ROOT/('game%d-tracking.json'%n)).write_text(json.dumps({'game':n,'rect':rect,'fps':fps,'cropped':rect[1]+rect[3]>final.shape[0],'frames':records}))
  summary.append({'game':n,'rect':rect,'frames':i,'fps':fps,'cropped':rect[1]+rect[3]>final.shape[0]})
  print('tracked',n,i,rect,flush=True)
 (ROOT/'tracking-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 with ThreadPoolExecutor(max_workers=4) as pool:
  out=list(pool.map(ocr,jobs))
 (ROOT/'score-clock.json').write_text(json.dumps(out,indent=2)+'\n')
 for n in range(1,11):
  vals=[x for x in out if x['game']==n];changes=[];old=None
  for v in vals:
   if v['score'] is not None and v['score']!=old:
    changes.append({k:v[k] for k in ('video_s','score','tick')});old=v['score']
  print('score',n,changes,'final',vals[-1],flush=True)
if __name__=='__main__':main()
