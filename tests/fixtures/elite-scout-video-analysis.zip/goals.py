import sys,json,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'vendor'))
import cv2,numpy as np
from PIL import Image,ImageDraw
from read_scores import glyphs
ROOT=Path(__file__).parent

def main():
 manifest=json.loads((ROOT/'recordings.json').read_text());timeline=json.loads((ROOT/'timeline.json').read_text());events=[]
 for n in range(1,11):
  meta=manifest[n-1];track=json.loads((ROOT/('game%d-tracking.json'%n)).read_text());x,y,w,h=track['rect'];cx=x+w/2
  temps={}
  for game,which,label in [(1,'start',0),(5,'start',1),(3,'last',2),(2,'last',3)]:
   a=json.loads((ROOT/('game%d-tracking.json'%game)).read_text());xx,yy,ww,hh=a['rect'];g=glyphs(cv2.imread(str(ROOT/('game%d-%s.png'%(game,which)))),xx+ww/2);temps[label]=g['red' if label==3 else 'blue']
  cap=cv2.VideoCapture(meta['path']);vals=[r for r in timeline if r['game']==n];old=None;previous=0.;num=0
  for row in vals:
   s=row['score']
   if None in s:continue
   if old is None:old=s;previous=row['video_s'];continue
   if s==old:previous=row['video_s'];continue
   if any(b<a for a,b in zip(old,s)) or sum(s)-sum(old)!=1:raise RuntimeError((n,old,s))
   lo=int(previous*30);hi=int(row['video_s']*30)
   while lo+1<hi:
    mid=(lo+hi)//2;cap.set(cv2.CAP_PROP_POS_FRAMES,mid);ok,im=cap.read();g=glyphs(im,cx);score=[]
    for c in ('blue','red'):
     score.append(min(temps,key=lambda d:np.mean(np.logical_xor(temps[d],g[c]))) if g[c] is not None else None)
    if score==s:hi=mid
    else:lo=mid
   sec=hi/30;num+=1
   team='Gabriel Behane' if (s[0]>old[0])==(n%2==1) else 'Zamokuhle Maziya'
   clocks=[(r['video_s'],r['tick']) for r in vals if r['tick'] is not None and 0<=r['tick']<=2400]
   tick=float(np.interp(sec,[a for a,b in clocks],[b for a,b in clocks]))
   event={'game':n,'goal':num,'scorer':team,'video_s':sec,'match_s_approx':tick/20,'score_before':old,'score_after':s}
   sheet=Image.new('RGB',(1680,4*370),'#18212b');d=ImageDraw.Draw(sheet)
   for i,dt in enumerate(np.linspace(-1.6,.05,12)):
    t=max(0,sec+dt);cap.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,im=cap.read()
    if not ok:continue
    crop=im[max(0,int(y)-1):min(im.shape[0],int(y+h)+2),int(x):int(x+w)]
    tile=Image.fromarray(cv2.cvtColor(crop,cv2.COLOR_BGR2RGB));px=i%3*560;py=i//3*370
    sheet.paste(tile,(px,py+30));native=np.interp(t,[a for a,b in clocks],[b for a,b in clocks])/20
    d.text((px+6,py+7),'g%d goal%d %s | video %.2fs | match ~%.1fs'%(n,num,team.split()[0],t,native),fill='white')
   dest=ROOT/('g%d-goal%d.jpg'%(n,num));sheet.save(dest,quality=94);event['storyboard']=str(dest);events.append(event)
   old=s;previous=row['video_s']
  cap.release()
 (ROOT/'goals.json').write_text(json.dumps(events,indent=2)+'\n')
 for e in events:print(e)
if __name__=='__main__':main()
