from pathlib import Path
import json,numpy as np
from scipy.stats import theilslopes
root=Path(__file__).parent;rows=json.loads((root/'timeline.json').read_text());fits=[]
for n in range(1,11):
 vals=[r for r in rows if r['game']==n and r['tick'] is not None and 0<=r['tick']<2370]
 x=np.array([r['video_s'] for r in vals]);y=np.array([r['tick'] for r in vals]);s,b,*_=theilslopes(y,x)
 good=np.abs(y-(s*x+b))<8
 slope,offset=np.polyfit(x[good],y[good],1)
 fits.append({'game':n,'ticks_per_video_second':slope,'start_tick':offset,'clock_samples':len(vals),'rejected_clock_ocr':int(sum(~good))})
 for r in rows:
  if r['game']==n:r['tick_raw']=r['tick'];r['tick']=min(2400,max(0,slope*r['video_s']+offset))
(root/'timeline.json').write_text(json.dumps(rows,indent=2)+'\n');(root/'clock-fits.json').write_text(json.dumps(fits,indent=2)+'\n')
print(json.dumps(fits,indent=2))
