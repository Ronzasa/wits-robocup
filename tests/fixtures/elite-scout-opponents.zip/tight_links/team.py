"""Pep Guardiola 2011 FC Barcelona: coordinated control.

Kahn, Beckenbauer, Iniesta, Messi and Ronaldo retain equal engine attributes.
Intentional receivers follow the actual projected ball path. Pressured touches
compare whole-path interception risk through the next kick opportunity.

Only public observations drive decisions in the SDK canonical frame.
No opponent identity, supplied seed, file or service influences decisions.
"""
import math

from soccer import PlayerAction, TeamAction, TeamController


def _clip(value, low, high):
    return low if value < low else high if value > high else value


def _unit(x, y):
    length = math.hypot(x, y)
    if length < 1e-8:
        return 0.0, 0.0
    return x / length, y / length


class Guardiola2011(TeamController):
    name = "Pep Guardiola 2011 FC Barcelona"
    version = "4.0-coordinated-control"
    PLAYER_ROLES = {
        0: "Oliver Kahn | goalkeeper",
        1: "Beckenbauer | libero",
        2: "Iniesta | pivot",
        3: "Messi | creator",
        4: "Ronaldo Nazario | striker",
    }
    DRIBBLE_SPEED = 6.5
    SHOOT_RANGE = 34.0
    PASSING = True
    PREDICTIVE_KEEPER = True
    SAFE_RECYCLE = True

    def __init__(self):
        self.reset(0)

    def reset(self, seed):
        # The supplied seed is deliberately unused.
        self._ready = False
        self._restart_until = -1
        self._restart_owner = None
        self._chaser = -1
        self._last_score = None
        self._touch_movement = None
        self._pass_plan = None
        self._receive_plan = None

    def initial_formation(self, field):
        w, h = field.width, field.height
        circle = field.centre_circle_radius
        return [
            (field.my_goal[0] + 3.0, 0.0),
            (-0.26 * w, 0.0),
            (-0.15 * w, -0.13 * h),
            (-0.15 * w, 0.20 * h),
            (-circle - 1.8, 0.0),
        ]

    def _setup(self, field):
        self._dt = 1.0 / field.simulation_hz
        self._hz = field.simulation_hz
        self._speed = field.max_speed
        self._acc = field.acceleration * self._dt
        self._friction = field.ball_friction
        self._log_friction = math.log(self._friction)
        self._impulse = field.kick_impulse
        self._range = field.kick_range
        self._eta_range = self._range * 0.8
        self._left = field.my_goal[0]
        self._right = field.opponent_goal[0]
        self._half_height = field.height * 0.5
        self._mouth = max(0.0, field.goal_width * 0.5 - 0.6)
        self._circle = field.centre_circle_radius
        self._contact = field.player_radius + field.ball_radius
        # Public course profile: player damping, wall restitution, ball cap.
        self._damping = 0.9
        self._wall = 0.75
        self._ball_cap = 30.0
        # Closed-form displacements for collision-free forecast samples.
        self._drag = tuple(self._friction ** tick for tick in range(81))
        self._roll = tuple(self._dt * (1.0 - drag) / (1.0 - self._friction)
                           for drag in self._drag)
        self._forecast_steps = tuple((tick * self._dt, self._roll[tick])
                                    for tick in (0, 3, 6, 10, 15, 22, 30, 42, 58, 80))
        self._ready = True

    def _target(self, x, y):
        return (_clip(x, self._left + 2.0, self._right - 2.0),
                _clip(y, -self._half_height + 2.0, self._half_height - 2.0))

    def _move(self, p, target, friends=()):
        dx, dy = target[0] - p[1], target[1] - p[2]
        gap = math.hypot(dx, dy)
        # Reuse exactly the norm that _unit would calculate again.
        if gap < 1e-8:
            ux, uy = 0.0, 0.0
        else:
            ux, uy = dx / gap, dy / gap
        for other in friends:
            if other[0] == p[0]:
                continue
            sx, sy = p[1] - other[1], p[2] - other[2]
            d = math.hypot(sx, sy)
            if 0.01 < d < 3.0:
                force = (3.0 - d) * 0.22 / d
                ux += sx * force
                uy += sy * force
        ux, uy = _unit(ux, uy)
        desired = min(self._speed, gap * 5.0)
        ax = (ux * desired - p[3] * self._damping) / self._acc
        ay = (uy * desired - p[4] * self._damping) / self._acc
        length = math.hypot(ax, ay)
        if length > 1.0:
            return ax / length, ay / length
        return ax, ay

    def _eta(self, p, x, y):
        dx, dy = x - p[1], y - p[2]
        d = math.hypot(dx, dy)
        if d < 1e-6:
            return 0.0
        speed_towards = (dx * p[3] + dy * p[4]) / d
        sideways = abs(dx * p[4] - dy * p[3]) / d
        startup = max(0.0, 1.0 - speed_towards / self._speed) * 0.30
        return max(0.0, d - self._eta_range) / self._speed + startup + sideways * 0.025

    def _crossing_ticks(self, position, velocity, bound):
        if abs(velocity) < 1e-9:
            return 81
        distance = bound - position if velocity > 0.0 else position + bound
        fraction = 1.0 - max(0.0, distance) * (1.0 - self._friction) / (abs(velocity) * self._dt)
        if fraction <= 0.0:
            return 81
        # Boundaries reflect only after crossing, not merely touching.
        return max(1, int(math.log(fraction) / self._log_friction) + 1)

    def _trajectory(self, bx, by, vx, vy):
        radius = 0.45
        xwall, ywall = self._right - radius, self._half_height - radius
        reach = self._forecast_steps[-1][1]
        if abs(bx + vx * reach) < xwall and abs(by + vy * reach) < ywall:
            return [(t, bx + vx * distance, by + vy * distance)
                    for t, distance in self._forecast_steps]
        # Advance analytically between the few wall contacts. Each contact
        # uses the same discrete overshoot/reflection as the stepped model.
        samples = [(0.0, bx, by)]
        elapsed = 0
        hit = min(self._crossing_ticks(bx, vx, xwall),
                  self._crossing_ticks(by, vy, ywall))
        for wanted in (3, 6, 10, 15, 22, 30, 42, 58, 80):
            while hit <= wanted:
                steps = hit - elapsed
                scale = self._roll[steps]
                bx += vx * scale
                by += vy * scale
                if by > ywall:
                    by = ywall * 2.0 - by
                    vy = -abs(vy) * self._wall
                elif by < -ywall:
                    by = -ywall * 2.0 - by
                    vy = abs(vy) * self._wall
                if abs(bx) > xwall:
                    if abs(by) <= self._mouth + 0.6:
                        samples.append((hit * self._dt, _clip(bx, -xwall, xwall), by))
                        return samples
                    if bx > xwall:
                        bx = xwall * 2.0 - bx
                        vx = -abs(vx) * self._wall
                    else:
                        bx = -xwall * 2.0 - bx
                        vx = abs(vx) * self._wall
                drag = self._drag[steps]
                vx *= drag
                vy *= drag
                elapsed = hit
                hit = elapsed + min(self._crossing_ticks(bx, vx, xwall),
                                    self._crossing_ticks(by, vy, ywall))
            scale = self._roll[wanted - elapsed]
            samples.append((wanted * self._dt, bx + vx * scale, by + vy * scale))
        return samples

    def _intercept(self, p, samples):
        # Keep the original operation order, but load player data and field
        # invariants once instead of calling _eta for every forecast sample.
        _, px, py, pvx, pvy = p
        speed, kick_range = self._speed, self._eta_range
        hypot = math.hypot
        best_cost = None
        best_x = best_y = 0.0
        for t, x, y in samples:
            dx, dy = x - px, y - py
            d = hypot(dx, dy)
            if d < 1e-6:
                eta = 0.0
            else:
                speed_towards = (dx * pvx + dy * pvy) / d
                sideways = abs(dx * pvy - dy * pvx) / d
                startup = 1.0 - speed_towards / speed
                if startup <= 0.0:
                    startup = 0.0
                startup *= 0.30
                distance = d - kick_range
                if distance <= 0.0:
                    distance = 0.0
                eta = distance / speed + startup + sideways * 0.025
            if eta <= t + 0.06:
                return (eta if eta > t else t), (x, y)
            cost = eta + t * 0.12
            if best_cost is None or cost < best_cost:
                best_cost, best_x, best_y = cost, x, y
        return None if best_cost is None else (best_cost, (best_x, best_y))

    def _closest_eta(self, players, target):
        # Strict comparison preserves min's first-player tie breaking.
        best = None
        best_eta = None
        x, y = target
        for p in players:
            eta = self._eta(p, x, y)
            if best is None or eta < best_eta:
                best, best_eta = p, eta
        return best

    def _role_closest_eta(self, players, target, cover=False):
        # Roles settle close races; distance still controls assignments.
        # The largest preference is only 0.09 seconds, so the libero can
        # step out while another nearby player provides defensive cover.
        best = None
        best_eta = None
        x, y = target
        for p in players:
            eta = self._eta(p, x, y)
            if p[0] == 1:  # Beckenbauer: cover or goal-side marking.
                eta -= 0.09 if cover else 0.045
            elif p[0] == 2:  # Iniesta: retain the next defensive option.
                eta -= 0.045 if cover else 0.025
            if best is None or eta < best_eta:
                best, best_eta = p, eta
        return best

    def _role_support(self, p, bx, by, lane):
        # Start with the existing forward support shape, then adjust a few
        # units for each role. Neither defender is anchored far from play.
        if p[0] == 1:
            return self._target(bx + 6.0, by * 0.2 + lane * 0.5)
        if p[0] == 2:
            return self._target(bx + 7.0, by * 0.2 + lane * 0.7)
        if p[0] == 3:
            return self._target(bx + 10.0, by * 0.2 + lane * 0.8)
        if p[0] == 4:
            return self._target(bx + 15.0, by * 0.2 + lane * 0.3)
        return self._target(bx + 12.0, by * 0.2 + lane)

    def _flight(self, distance, speed):
        if speed <= 0.01:
            return 20.0
        fraction = 1.0 - distance * (1.0 - self._friction) / (speed * self._dt)
        if fraction <= 0.001:
            return 20.0
        return max(0.0, math.log(fraction) / self._log_friction * self._dt)

    def _kick_to_velocity(self, vx, vy, tx, ty):
        dx, dy = tx - vx, ty - vy
        length = math.hypot(dx, dy)
        if length < 0.03:
            return None
        power = min(1.0, length / self._impulse)
        return (dx / length, dy / length), power

    def _shot_velocity(self, bx, by, vx, vy, target_y):
        ux, uy = _unit(self._right - bx, target_y - by)
        along = vx * ux + vy * uy
        perpendicular_sq = max(0.0, vx * vx + vy * vy - along * along)
        if perpendicular_sq >= self._impulse * self._impulse:
            return None
        speed = min(self._ball_cap, along + math.sqrt(self._impulse ** 2 - perpendicular_sq))
        if speed < 9.0:
            return None
        return ux * speed, uy * speed, speed

    def _pass_velocity(self, bx, by, vx, vy, tx, ty):
        # A kick adds at most one impulse: evaluate the trajectory that is
        # actually achievable, including the ball's existing sideways speed.
        ux, uy = _unit(tx - bx, ty - by)
        along = vx * ux + vy * uy
        sideways_sq = max(0.0, vx * vx + vy * vy - along * along)
        if sideways_sq >= self._impulse * self._impulse:
            return None
        reach = math.sqrt(self._impulse * self._impulse - sideways_sq)
        speed = _clip(17.0, max(0.0, along - reach), min(self._ball_cap, along + reach))
        if speed < 9.0:
            return None
        return ux * speed, uy * speed, speed

    def _lane(self, bx, by, tx, ty, speed, opponents):
        dx, dy = tx - bx, ty - by
        length = math.hypot(dx, dy)
        if length < 0.1:
            return -10.0
        ux, uy = dx / length, dy / length
        room = 12.0
        for p in opponents:
            along = (p[1] - bx) * ux + (p[2] - by) * uy
            if along < -1.0 or along > length + 1.5:
                continue
            t = self._flight(max(0.0, along), speed)
            lead = min(0.65, t)
            x, y = p[1] + p[3] * lead, p[2] + p[4] * lead
            along = _clip((x - bx) * ux + (y - by) * uy, 0.0, length)
            lateral = math.hypot(x - bx - along * ux, y - by - along * uy)
            needed = self._contact + min(3.5, t * 1.2)
            room = min(room, lateral - needed)
        return room

    def _original_choose_kick(self, p, bx, by, vx, vy, friends, opponents):
        release = self._escape_release(p,bx,by,vx,vy,opponents)
        if release is not None:
            return release
        goal_distance = math.hypot(self._right - bx, by)
        finisher = p[0] in (3, 4)
        best_shot = None
        for fraction in (-1.0, -0.75, -0.5, 0.0, 0.5, 0.75, 1.0):
            y = self._mouth * fraction
            velocity = self._shot_velocity(bx, by, vx, vy, y)
            if velocity is None:
                continue
            sx, sy, speed = velocity
            room = self._lane(bx, by, self._right, y, speed, opponents)
            if finisher:
                # Rank only eligible Messi/Ronaldo aims. A blocked near aim
                # must not hide a clear far aim, and drag must allow the ball
                # to reach this actual point on the goal line.
                distance = math.hypot(self._right - bx, y - by)
                flight = self._flight(distance, speed)
                if flight >= 20.0:
                    continue
                ordinary = ((goal_distance < self.SHOOT_RANGE and room > 0.0)
                            or (goal_distance < 15.0 and room > -2.0))
                # Only an already fast ball permits the modest extension.
                # It must reach an open aim quickly with useful speed left.
                extended = (goal_distance < 38.0 and speed >= 24.0
                            and flight <= 2.0 and room > 1.75
                            and speed * self._friction ** (flight * self._hz) >= 12.0)
                if not (ordinary or extended):
                    continue
            score = room - abs(y - by) * 0.025
            if best_shot is None or score > best_shot[0]:
                best_shot = (score, room, sx, sy)
        if best_shot is not None:
            _, room, sx, sy = best_shot
            if finisher or (goal_distance < self.SHOOT_RANGE and room > 0.0) or (goal_distance < 15.0 and room > -2.0):
                return self._kick_to_velocity(vx, vy, sx, sy)

        pressure = min((math.hypot(o[1] - bx, o[2] - by) for o in opponents), default=100.0)
        best_pass = None
        best_break = None
        if self.PASSING:
            for receiver in friends:
                if receiver[0] in (p[0], 0):
                    continue
                gain = receiver[1] - bx
                recycle = gain < 3.0 and p[0] != 0
                if recycle and (not self.SAFE_RECYCLE or pressure >= 3.5 or
                                gain < -8.0 or receiver[1] < self._left + 15.0):
                    continue
                tx, ty = receiver[1], receiver[2]
                velocity = None
                for _ in range(2):
                    velocity = self._pass_velocity(bx, by, vx, vy, tx, ty)
                    if velocity is None:
                        break
                    t = min(1.6, self._flight(math.hypot(tx - bx, ty - by), velocity[2]))
                    tx, ty = self._target(receiver[1] + receiver[3] * t * 0.8,
                                          receiver[2] + receiver[4] * t * 0.8)
                if velocity is None:
                    continue
                gap = math.hypot(tx - bx, ty - by)
                if not 5.0 < gap < 35.0:
                    continue
                velocity = self._pass_velocity(bx, by, vx, vy, tx, ty)
                if velocity is None:
                    continue
                room = self._lane(bx, by, tx, ty, velocity[2], opponents)
                if room < 0.5:
                    continue
                if recycle:
                    outlet_pressure = min((math.hypot(tx - o[1] - o[3] * 0.4,
                                                     ty - o[2] - o[4] * 0.4)
                                           for o in opponents), default=100.0)
                    # Recycling must release pressure, rather than merely
                    # inflate possession or invite danger beside our keeper.
                    if outlet_pressure < max(4.5, pressure + 1.0):
                        continue
                receiver_space = min((math.hypot(tx - o[1] - o[3] * 0.4,
                                                  ty - o[2] - o[4] * 0.4)
                                      for o in opponents), default=100.0)
                # These are decision preferences, not player stat bonuses.
                # Every role retains the same achievable-velocity, lane and
                # pressured-recycle requirements above.
                if p[0] == 1:       # Beckenbauer: composed progression.
                    score = (tx - bx) * 0.045 + min(room, 6.0) * 0.20 - gap * 0.023
                elif p[0] == 2:     # Iniesta: short, safe progressive links.
                    score = (tx - bx) * 0.05 + min(room, 6.0) * 0.20 - gap * 0.024
                elif p[0] == 3:     # Messi: progressive links to the striker.
                    score = (tx - bx) * 0.065 + min(room, 6.0) * 0.16 - gap * 0.02
                    if receiver[0] == 4 and gain >= 6.0 and abs(ty) < self._half_height * 0.5:
                        score += 0.10
                elif p[0] == 4:     # Ronaldo Nazario: face the opponent goal.
                    score = (tx - bx) * 0.07 + min(room, 6.0) * 0.16 - gap * 0.02
                else:
                    score = (tx - bx) * 0.05 + min(room, 6.0) * 0.16 - gap * 0.02
                candidate = (score, velocity[0], velocity[1], receiver[0], tx, ty)
                if best_pass is None or score > best_pass[0]:
                    best_pass = candidate
                if (gain >= 8.0 and gap >= 9.0 and room >= 1.75
                        and receiver_space >= 4.5 and bx < 32.0
                        and (best_break is None or score > best_break[0])):
                    best_break = candidate
            chosen = best_pass if (pressure < 4.5 or p[0] == 0) else best_break
            if chosen is not None:
                # Ronaldo can advance through a genuinely clear central
                # corridor. A viable clear shot has already taken priority.
                # Keep the safe outlet when the carry would meet a defender.
                if (p[0] == 4 and bx > 5.0 and goal_distance > 15.0
                        and abs(by) < self._half_height * 0.5 and pressure >= 6.5):
                    cx, cy, tx, ty, clearance = self._carry_velocity(p, bx, by, pressure, opponents)
                    if (tx - bx >= 3.5 and clearance >= 5.0
                            and self._lane(bx, by, tx, ty, math.hypot(cx, cy), opponents) > 1.0):
                        return self._kick_to_velocity(vx, vy, cx, cy)
                self._pass_plan = (chosen[3], chosen[4], chosen[5])
                return self._kick_to_velocity(vx, vy, chosen[1], chosen[2])

        if p[0] == 0:
            # Clear laterally out of danger when no safe outlet is available.
            side = -1.0 if by > 0.0 else 1.0
            ux, uy = _unit(1.0, side * 0.6)
            return self._kick_to_velocity(vx, vy, ux * 22.0, uy * 22.0)

        cx, cy, _, _, _ = self._carry_velocity(p, bx, by, pressure, opponents)
        return self._kick_to_velocity(vx, vy, cx, cy)

    def _carry_velocity(self, p, bx, by, pressure, opponents):
        # Messi uses a shorter control horizon under pressure. Open-field
        # touches retain the team's existing speed, and no role exceeds it.
        close_control = p[0] == 3 and pressure < 4.5
        lookahead = 3.5 if close_control else 5.0
        touch_speed = min(self.DRIBBLE_SPEED, 7.0) if close_control else self.DRIBBLE_SPEED
        forward_weight = 0.70 if p[0] == 4 else 0.45
        centre_weight = 0.06 if p[0] in (3, 4) else 0.04
        best = None
        goal_ux, goal_uy = _unit(self._right - bx, -by)
        for dx, dy in ((goal_ux, goal_uy), (1.0, 0.0), (0.85, 0.53), (0.85, -0.53)):
            tx, ty = self._target(bx + dx * lookahead, by + dy * lookahead)
            clearance = min((math.hypot(tx - o[1] - o[3] * 0.2,
                                        ty - o[2] - o[4] * 0.2) for o in opponents), default=15.0)
            score = min(clearance, 10.0) + (tx - bx) * forward_weight - abs(ty) * centre_weight
            if best is None or score > best[0]:
                best = (score, dx, dy, tx, ty, clearance)
        return best[1] * touch_speed, best[2] * touch_speed, best[3], best[4], best[5]

    def _requested_velocity(self, vx, vy, kick):
        direction, power = kick
        sx = vx + direction[0] * power * self._impulse
        sy = vy + direction[1] * power * self._impulse
        speed = math.hypot(sx, sy)
        if speed > self._ball_cap:
            sx *= self._ball_cap / speed
            sy *= self._ball_cap / speed
        return sx, sy

    def _carrier_contact(self, p, bx, by, sx, sy, movement):
        # One free movement step, then just the carrier's first ball contact.
        pvx = p[3] * self._damping + movement[0] * self._acc
        pvy = p[4] * self._damping + movement[1] * self._acc
        speed = math.hypot(pvx, pvy)
        if speed > self._speed:
            pvx *= self._speed / speed
            pvy *= self._speed / speed
        px, py = p[1] + pvx * self._dt, p[2] + pvy * self._dt
        if math.hypot(px - bx, py - by) >= self._range - 0.18:
            return None
        x, y = bx + sx * self._dt, by + sy * self._dt
        sx *= self._friction
        sy *= self._friction
        rx, ry = x - px, y - py
        gap = math.hypot(rx, ry)
        if 1e-8 < gap < self._contact:
            nx, ny = rx / gap, ry / gap
            x, y = px + nx * self._contact, py + ny * self._contact
            closing = (sx - pvx) * nx + (sy - pvy) * ny
            if closing < 0.0:
                # Documented ground player/ball restitution is 0.25.
                impulse = -1.25 * closing
                sx += impulse * nx
                sy += impulse * ny
        return x, y, sx, sy

    def _legacy_choose_kick(self, p, bx, by, vx, vy, friends, opponents):
        self._touch_movement = None
        kick = self._original_choose_kick(p, bx, by, vx, vy, friends, opponents)
        if (kick is None or bx >= 0.0 or bx <= self._left + 3.0
                or abs(by) >= self._half_height - 3.0):
            return kick
        sx, sy = self._requested_velocity(vx, vy, kick)
        if sx <= 2.0:
            return kick
        movement = self._move(p, (bx + 0.3, by))
        original = self._carrier_contact(p, bx, by, sx, sy, movement)
        if original is None or original[2] >= -2.0:
            return kick

        # Retain the exact kick if braking or moving away prevents its return.
        brake_x = -p[3] * self._damping / self._acc
        brake_y = -p[4] * self._damping / self._acc
        brake_length = math.hypot(brake_x, brake_y)
        if brake_length > 1.0:
            brake_x /= brake_length
            brake_y /= brake_length
        away = _unit(p[1] - bx, p[2] - by)
        for alternative in ((brake_x, brake_y), away):
            outcome = self._carrier_contact(p, bx, by, sx, sy, alternative)
            if outcome is not None and outcome[2] >= -2.0:
                self._touch_movement = alternative
                return kick

        # Try the smallest requested rotation first. Re-evaluate the capped
        # actual impulse instead of assuming the rotated velocity is feasible.
        for degrees in (30.0, -30.0, 60.0, -60.0):
            angle = math.radians(degrees)
            cosine, sine = math.cos(angle), math.sin(angle)
            tx, ty = sx * cosine - sy * sine, sx * sine + sy * cosine
            alternative = self._kick_to_velocity(vx, vy, tx, ty)
            if alternative is None:
                continue
            ax, ay = self._requested_velocity(vx, vy, alternative)
            outcome = self._carrier_contact(p, bx, by, ax, ay, movement)
            if ax > 2.0 and outcome is not None and outcome[2] >= -2.0:
                return alternative
        return kick


    def _escape_release(self, p, bx, by, vx, vy, opponents):
        if p[0] == 0 or bx > 2.0:
            return None
        pressure=min((math.hypot(o[1]-bx,o[2]-by) for o in opponents),default=100.0)
        if pressure>=4.0:
            return None
        best=None
        for width in (-16.0,-8.0,0.0,8.0,16.0):
            tx,ty=self._target(bx+28.0,by*0.3+width)
            ux,uy=_unit(tx-bx,ty-by)
            along=vx*ux+vy*uy
            side=max(0.0,vx*vx+vy*vy-along*along)
            if side>=self._impulse**2:
                continue
            speed=min(28.0,along+math.sqrt(self._impulse**2-side))
            if speed<14.0:
                continue
            room=self._lane(bx,by,tx,ty,speed,opponents)
            score=room-abs(ty)*0.025
            if best is None or score>best[0]:
                best=score,self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
        return None if best is None else best[1]


    def _endpoint_controlled_touch(self, p, bx, by, vx, vy, opponents):
        # Evaluate reachable short touches after our own body contact. The
        # final point is a collection opportunity, not a possession claim.
        base_angle = math.atan2(-by, self._right - bx)
        original_distance = math.hypot(self._right - bx, by)
        best = None
        for angle_offset in (0.0, -0.45, 0.45, -0.9, 0.9, -1.35, 1.35):
            angle = base_angle + angle_offset
            ux, uy = math.cos(angle), math.sin(angle)
            for speed in (6.0, 9.0):
                kick = self._kick_to_velocity(vx, vy, ux*speed, uy*speed)
                if kick is None:
                    continue
                sx, sy = self._requested_velocity(vx, vy, kick)
                movement = self._move(p, self._target(bx+ux*3.0, by+uy*3.0))
                contact = self._carrier_contact(p, bx, by, sx, sy, movement)
                if contact is None:
                    continue
                x, y, rx, ry = contact
                horizon = 0.30
                drag = self._friction**(horizon*self._hz)
                scale = self._dt*(1.0-drag)/(1.0-self._friction)
                tx, ty = x+rx*scale, y+ry*scale
                if abs(ty) > self._half_height-1.5 or tx < self._left+3.0:
                    continue
                own_eta = self._eta(p, tx, ty)
                enemy_eta = min((self._eta(o, tx, ty) for o in opponents),default=10.0)
                clearance = min((math.hypot(tx-o[1]-o[3]*0.22,
                                            ty-o[2]-o[4]*0.22)
                                 for o in opponents),default=15.0)
                progress = original_distance-math.hypot(self._right-tx, ty)
                retain = _clip(enemy_eta-own_eta, -1.0, 1.0)
                score = (progress*0.85 + min(clearance,8.0)*0.45
                         + retain*3.5 - max(0.0,own_eta-0.5)*4.0)
                if rx < -2.0 and bx < 0.0:
                    score -= 5.0
                if best is None or score > best[0]:
                    best = score, kick, movement
        return best

    def _choose_kick(self, p, bx, by, vx, vy, friends, opponents):
        self._pass_plan = None
        kick = self._legacy_choose_kick(p,bx,by,vx,vy,friends,opponents)
        if p[0] == 0 or kick is None:
            return kick
        sx, sy = self._requested_velocity(vx,vy,kick)
        if math.hypot(sx,sy) > 10.5:
            return kick
        planned = self._controlled_touch(p,bx,by,vx,vy,opponents)
        if planned is not None:
            self._touch_movement = planned[2]
            return planned[1]
        return kick

    def _touch_path(self, p, bx, by, vx, vy, kick, movement, opponents):
        sx,sy = self._requested_velocity(vx,vy,kick)
        contact = self._carrier_contact(p,bx,by,sx,sy,movement)
        if contact is None:
            return None
        x,y,sx,sy = contact
        pvx=p[3]*self._damping+movement[0]*self._acc
        pvy=p[4]*self._damping+movement[1]*self._acc
        player_speed=math.hypot(pvx,pvy)
        if player_speed>self._speed:
            pvx*=self._speed/player_speed
            pvy*=self._speed/player_speed
        px,py=p[1]+pvx*self._dt,p[2]+pvy*self._dt
        initial_distance=math.hypot(self._right-bx,by)
        margin=4.0
        recapture=None
        cooldowns=getattr(self,'_enemy_cooldowns',{})
        for tick in range(1,12):
            elapsed=tick*self._dt
            if abs(y)>self._half_height-1.0 or x<self._left+2.0:
                return None
            # Evaluate the complete path, not just the endpoint beyond a
            # blocker. Public cooldowns distinguish an available tackle.
            steps=tick+1
            coast=self._dt*self._damping*(1.0-self._damping**steps)/(1.0-self._damping)
            reach=(self._dt*self._acc/(1.0-self._damping)
                   *(steps-self._damping*(1.0-self._damping**steps)/(1.0-self._damping)))
            for enemy in opponents:
                if cooldowns.get(enemy[0],0)>tick:
                    continue
                cx=enemy[1]+enemy[3]*coast
                cy=enemy[2]+enemy[4]*coast
                # Any legal acceleration sequence lies inside this reachable
                # disc. This includes immediate short tackles without the
                # generic ETA estimator's artificial startup delay.
                remaining=math.hypot(x-cx,y-cy)-reach-self._range
                margin=min(margin,remaining/self._speed)
            gap=math.hypot(x-px,y-py)
            if tick>=5 and gap<self._range-0.15:
                recapture=elapsed
                break
            if tick==11:
                break
            # Simulate the carrier's receding chase and every subsequent
            # body collision until their next legal touch is available.
            player=(p[0],px,py,pvx,pvy)
            chase=self._target(x+sx*0.15,y+sy*0.15)
            move=self._move(player,chase)
            pvx=pvx*self._damping+move[0]*self._acc
            pvy=pvy*self._damping+move[1]*self._acc
            player_speed=math.hypot(pvx,pvy)
            if player_speed>self._speed:
                pvx*=self._speed/player_speed
                pvy*=self._speed/player_speed
            px+=pvx*self._dt
            py+=pvy*self._dt
            x+=sx*self._dt
            y+=sy*self._dt
            sx*=self._friction
            sy*=self._friction
            dx,dy=x-px,y-py
            gap=math.hypot(dx,dy)
            if 1e-8<gap<self._contact:
                nx,ny=dx/gap,dy/gap
                x,y=px+nx*self._contact,py+ny*self._contact
                closing=(sx-pvx)*nx+(sy-pvy)*ny
                if closing<0.0:
                    sx-=1.25*closing*nx
                    sy-=1.25*closing*ny
        if recapture is None:
            recapture=0.55+self._eta((p[0],px,py,pvx,pvy),x,y)
        progress=initial_distance-math.hypot(self._right-x,y)
        clearance=min((math.hypot(x-q[1]-q[3]*0.25,y-q[2]-q[4]*0.25)
                       for q in opponents),default=15.0)
        score=(progress*0.85+min(clearance,8.0)*0.25
               +_clip(margin,-0.6,0.6)*8.0-max(0.0,recapture-0.25)*8.0)
        return score,margin,recapture

    def _controlled_touch(self,p,bx,by,vx,vy,opponents):
        original=self._endpoint_controlled_touch(p,bx,by,vx,vy,opponents)
        pressure=min((math.hypot(q[1]-bx,q[2]-by) for q in opponents),default=100.0)
        if original is None or pressure>=5.5:
            return original
        original_path=self._touch_path(p,bx,by,vx,vy,original[1],original[2],opponents)
        # Open short touches preserve the established attack. Only a path
        # with a possible tackle before collection triggers a new search.
        if original_path is not None and original_path[1]>=0.10:
            return original
        best=None
        if original_path is not None:
            best=(original_path[0],original[1],original[2],original_path[1])
        base_angle=math.atan2(-by,self._right-bx)
        for offset in (0.0,-0.6,0.6,-1.2,1.2,-1.8,1.8):
            angle=base_angle+offset
            ux,uy=math.cos(angle),math.sin(angle)
            for speed in (5.0,8.0):
                kick=self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
                if kick is None:
                    continue
                move=self._move(p,self._target(bx+ux*3.0,by+uy*3.0))
                path=self._touch_path(p,bx,by,vx,vy,kick,move,opponents)
                if path is None or path[2]>0.70:
                    continue
                if best is None or path[0]>best[0]:
                    best=(path[0],kick,move,path[1])
        if best is not None:
            return best[:3]
        return original

    def act(self, obs):
        if not self._ready:
            self._setup(obs.field)
            self._restart_until = obs.tick + int(3.0 * self._hz)
            self._restart_owner = obs.ball.controlling_team
        # A changed public score identifies a goal without copying or
        # scanning event payloads in the decision loop.
        score = obs.score
        if self._last_score is not None and score != self._last_score:
            self._restart_until = obs.tick + int(3.0 * self._hz)
            self._restart_owner = 0 if score[1] > self._last_score[1] else 1
            self._chaser = -1
            self._receive_plan = None
        self._last_score = score
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        if math.hypot(bx, by) > 0.7 or math.hypot(vx, vy) > 0.15:
            self._restart_until = -1
        protected = (obs.tick < self._restart_until and self._restart_owner == 1)
        friends = [(p.id, *p.position, *p.velocity) for p in obs.my_players]
        opponents = [(p.id, *p.position, *p.velocity) for p in obs.opponents]
        self._enemy_cooldowns = {p.id:p.kick_cooldown_ticks for p in obs.opponents}
        actions = TeamAction(debug={"roles": self.PLAYER_ROLES})
        if not friends:
            return actions
        keeper = friends[0]
        outfield = friends[1:] or friends
        samples = self._trajectory(bx, by, vx, vy)
        races = {}
        chaser = None
        chaser_eta = None
        previous = None
        for p in outfield:
            race = self._intercept(p, samples)
            races[p[0]] = race
            if chaser is None or race[0] < chaser_eta:
                chaser, chaser_eta = p, race[0]
            if p[0] == self._chaser:
                previous = p
        if previous is not None and races[previous[0]][0] < races[chaser[0]][0] + 0.12:
            chaser = previous
        self._chaser = chaser[0]
        enemy_eta = None
        for o in opponents:
            eta = self._intercept(o, samples)[0]
            if enemy_eta is None or eta < enemy_eta:
                enemy_eta = eta
        if enemy_eta is None:
            enemy_eta = 100.0
        attack = races[chaser[0]][0] <= enemy_eta + 0.12

        keeper_x = self._left + 2.2
        keeper_y = by * 2.2 / max(3.0, bx - self._left)
        # Stay central while a slow approach can still be redirected. Commit
        # only after a fast, near-term shot reveals its actual goal-line path.
        if (self.PREDICTIVE_KEEPER and vx < -8.0
                and math.hypot(vx, vy) >= 12.0 and bx > keeper_x):
            time_to_line = (keeper_x - bx) / vx
            if 0.0 < time_to_line < 1.25:
                keeper_y = by + vy * time_to_line
        keeper_target = (keeper_x, _clip(keeper_y, -self._mouth, self._mouth))
        if bx < self._left + 10.0 and self._eta(keeper, bx, by) < races[chaser[0]][0] * 0.85:
            keeper_target = self._target(bx, by)

        targets = {keeper[0]: keeper_target, chaser[0]: self._target(*races[chaser[0]][1])}
        free = [p for p in outfield if p[0] != chaser[0]]
        if free:
            cover_target = self._target(min(28.0, bx - 2.0),
                                        _clip(by, -self._half_height + 2.0, self._half_height - 2.0))
            cover = self._role_closest_eta(free, cover_target, cover=True)
            if cover[0] == 1:
                cover_target = self._target(min(28.0, bx - 3.5), cover_target[1])
            elif cover[0] == 2:
                cover_target = self._target(min(28.0, bx - 2.75), cover_target[1])
            targets[cover[0]] = cover_target
            free = [p for p in free if p[0] != cover[0]]
        if attack:
            spread = max(7.0, 15.0 - max(0.0, bx - 20.0) * 0.35)
            free.sort(key=lambda p: p[2])
            for index, p in enumerate(free):
                lane = 0.0 if len(free) == 1 else -spread + 2.0 * spread * index / (len(free) - 1)
                targets[p[0]] = self._role_support(p, bx, by, lane)
        else:
            threats = sorted(opponents, key=lambda p: p[1] + abs(p[2]) * 0.2)
            for threat in threats:
                if not free:
                    break
                if math.hypot(threat[1] - bx, threat[2] - by) < 3.5:
                    continue
                ux, uy = _unit(self._left - threat[1], -threat[2])
                target = self._target(threat[1] + ux * 3.0, threat[2] + uy * 3.0)
                marker = self._role_closest_eta(free, target)
                targets[marker[0]] = target
                free = [p for p in free if p[0] != marker[0]]
            for p in free:
                targets[p[0]] = self._target(bx - 9.0, p[2] * 0.5)

        receive_target = None
        if self._receive_plan is not None:
            recipient, passer, expiry = self._receive_plan
            recipient_player = next((p for p in outfield if p[0] == recipient), None)
            if (recipient_player is None or obs.tick > expiry
                    or obs.ball.last_touch not in (None, passer)
                    or math.hypot(vx, vy) < 9.0):
                self._receive_plan = None
            else:
                race = races[recipient]
                if race[0] <= races[chaser[0]][0]+0.25 and race[0] <= enemy_eta+0.15:
                    targets[recipient] = self._target(*race[1])

        carrier = None
        carrier_gap = None
        for p in friends:
            if obs.can_kick(p[0]):
                gap = math.hypot(p[1] - bx, p[2] - by)
                if carrier is None or gap < carrier_gap:
                    carrier, carrier_gap = p, gap
        launched_pass = None
        for p in friends:
            target = targets.get(p[0], (p[1], p[2]))
            if protected and math.hypot(p[1], p[2]) < self._circle + 5.0:
                ux, uy = _unit(p[1], p[2])
                target = (ux * (self._circle + 3.0), uy * (self._circle + 3.0))
            kick = None
            if carrier is not None and p[0] == carrier[0] and not protected:
                # The carrier's original general movement was immediately
                # replaced; _move is pure, so calculate only the used value.
                movement = self._move(p, (bx + 0.3, by))
                nx = p[3] * self._damping + movement[0] * self._acc
                ny = p[4] * self._damping + movement[1] * self._acc
                speed = math.hypot(nx, ny)
                if speed > self._speed:
                    nx *= self._speed / speed
                    ny *= self._speed / speed
                # The engine moves players before checking kick range.
                distance_next = math.hypot(p[1] + nx * self._dt - bx,
                                           p[2] + ny * self._dt - by)
                if distance_next < self._range - 0.18:
                    kick = self._choose_kick(p, bx, by, vx, vy, friends, opponents)
                    if self._touch_movement is not None:
                        movement = self._touch_movement
                    self._receive_plan = None
                    if kick is not None and self._pass_plan is not None:
                        recipient = self._pass_plan[0]
                        sx, sy = self._requested_velocity(vx, vy, kick)
                        launch = self._carrier_contact(p, bx, by, sx, sy, movement)
                        if launch is not None and math.hypot(launch[2], launch[3]) > 10.5:
                            # Correct for our own body contact, including a kick
                            # changed by the pre-existing own-half return guard.
                            trajectory = self._trajectory(*launch)
                            receiver = next((q for q in outfield if q[0] == recipient), None)
                            if receiver is not None:
                                receiver_race = self._intercept(receiver, trajectory)
                                nearest = min(self._intercept(q, trajectory)[0] for q in outfield)
                                enemy_race = min((self._intercept(q, trajectory)[0] for q in opponents),default=100.0)
                                if receiver_race[0] <= nearest+0.25 and receiver_race[0] <= enemy_race+0.15:
                                    launched_pass = recipient, receiver_race[1]
                                    self._receive_plan = (recipient,p[0],obs.tick+int(2.6*self._hz))
            else:
                movement = self._move(p, target, friends if p[0] != chaser[0] and p[0] != 0 else ())
            if kick is None:
                actions.set(p[0], PlayerAction(movement=movement))
            else:
                actions.set(p[0], PlayerAction(movement=movement,
                                               kick_direction=kick[0],
                                               kick_power=kick[1]))
        if launched_pass is not None:
            recipient, target = launched_pass
            receiver = next(p for p in outfield if p[0] == recipient)
            actions.set(recipient,PlayerAction(movement=self._move(receiver,self._target(*target))))
        return actions
