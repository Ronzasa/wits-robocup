"""Local test opponent: compact defence, double pressing, direct counters.

This is a diagnostic sparring partner, not an asserted league-strength team.
It reads only documented observations and the public course physics profile.
"""
import math

from soccer import PlayerAction, TeamAction, TeamController


def _unit(x, y):
    length = math.hypot(x, y)
    return (x / length, y / length) if length > 1e-9 else (0.0, 0.0)


def _clip(value, lower, upper):
    return max(lower, min(upper, value))


class FastCounter(TeamController):
    name = "Research Compact Fast Counter"
    version = "1"

    def __init__(self):
        self.reset(0)

    def reset(self, seed):
        self._score = None
        self._restart_until = -1
        self._restart_owner = None

    def initial_formation(self, field):
        return [(field.my_goal[0] + 2.4, 0.0),
                (-0.30 * field.width, -0.15 * field.height),
                (-0.30 * field.width, 0.15 * field.height),
                (-field.centre_circle_radius - 2.0, -3.0),
                (-field.centre_circle_radius - 2.0, 3.0)]

    def _target(self, x, y):
        return (_clip(x, self.left + 1.8, self.right - 1.8),
                _clip(y, -self.half + 1.8, self.half - 1.8))

    def _move(self, p, target):
        dx, dy = target[0] - p[1], target[1] - p[2]
        distance = math.hypot(dx, dy)
        ux, uy = _unit(dx, dy)
        desired = min(self.speed, distance * 5.0)
        ax = (ux * desired - p[3] * 0.9) / self.acc
        ay = (uy * desired - p[4] * 0.9) / self.acc
        length = math.hypot(ax, ay)
        return (ax / length, ay / length) if length > 1.0 else (ax, ay)

    def _eta(self, p, x, y):
        dx, dy = x - p[1], y - p[2]
        distance = math.hypot(dx, dy)
        closing = (dx * p[3] + dy * p[4]) / max(distance, 1e-9)
        return (max(0.0, distance - self.reach * 0.8) / self.speed
                + max(0.0, 1.0 - closing / self.speed) * 0.3)

    def _forecast(self, bx, by, vx, vy):
        # Short stepped forecasts include the public ground-ball wall profile.
        result = [(0.0, bx, by)]
        for tick in range(1, 41):
            bx += vx * self.dt
            by += vy * self.dt
            if by > self.half - 0.45:
                by = 2.0 * (self.half - 0.45) - by
                vy = -abs(vy) * 0.75
            elif by < -self.half + 0.45:
                by = -2.0 * (self.half - 0.45) - by
                vy = abs(vy) * 0.75
            if bx > self.right - 0.45:
                if abs(by) < self.mouth + 0.7:
                    result.append((tick * self.dt, self.right - 0.45, by))
                    break
                bx = 2.0 * (self.right - 0.45) - bx
                vx = -abs(vx) * 0.75
            elif bx < self.left + 0.45:
                if abs(by) < self.mouth + 0.7:
                    result.append((tick * self.dt, self.left + 0.45, by))
                    break
                bx = 2.0 * (self.left + 0.45) - bx
                vx = abs(vx) * 0.75
            vx *= self.friction
            vy *= self.friction
            if tick in (3, 6, 10, 15, 22, 30, 40):
                result.append((tick * self.dt, bx, by))
        return result

    def _intercept(self, p, samples):
        best = None
        for time, x, y in samples:
            arrival = self._eta(p, x, y)
            if arrival < time + 0.07:
                return max(arrival, time), (x, y)
            cost = arrival + 0.15 * time
            if best is None or cost < best[0]:
                best = cost, (x, y)
        return best

    def _aligned_kick(self, vx, vy, dx, dy, wanted=None):
        ux, uy = _unit(dx, dy)
        parallel = vx * ux + vy * uy
        perpendicular_sq = max(0.0, vx * vx + vy * vy - parallel * parallel)
        feasible = parallel + math.sqrt(max(0.0, self.impulse ** 2 - perpendicular_sq))
        if feasible <= 0.0 or perpendicular_sq > self.impulse ** 2:
            return (ux, uy), 1.0
        speed = min(30.0, feasible if wanted is None else min(feasible, wanted))
        kx, ky = ux * speed - vx, uy * speed - vy
        length = math.hypot(kx, ky)
        if length < 0.03:
            return None
        return (kx / length, ky / length), min(1.0, length / self.impulse)

    def _lane(self, bx, by, tx, ty, opponents):
        dx, dy = tx - bx, ty - by
        length = math.hypot(dx, dy)
        ux, uy = _unit(dx, dy)
        clearance = 15.0
        for p in opponents:
            along = (p[1] - bx) * ux + (p[2] - by) * uy
            if 0.0 < along < length + 1.5:
                lateral = abs((p[1] - bx) * uy - (p[2] - by) * ux)
                clearance = min(clearance, lateral - 1.7)
        return clearance

    def _kick(self, p, bx, by, vx, vy, friends, opponents):
        # Counter style: prioritise full-power shots and long vertical releases.
        if p[0] != 0 and self.right - bx < 40.0:
            goal_y = max((-self.mouth, self.mouth, 0.0),
                         key=lambda y: self._lane(bx, by, self.right, y, opponents))
            return self._aligned_kick(vx, vy, self.right - bx, goal_y - by)
        candidates = []
        for other in friends[1:]:
            if other[0] == p[0] or other[1] < bx + 7.0:
                continue
            tx, ty = self._target(other[1] + other[3] * 0.8,
                                  other[2] + other[4] * 0.8)
            lane = self._lane(bx, by, tx, ty, opponents)
            if lane > -0.3:
                candidates.append((tx - bx + lane * 2.0, tx, ty))
        if candidates:
            _, tx, ty = max(candidates)
        else:
            # Different exit channels avoid always sending the ball at a crowd.
            endpoints = [(bx + 35.0, by * 0.3 - 10.0),
                         (bx + 35.0, by * 0.3 + 10.0), (bx + 35.0, 0.0)]
            tx, ty = max(endpoints,
                         key=lambda target: self._lane(bx, by, *target, opponents))
        return self._aligned_kick(vx, vy, tx - bx, ty - by)

    def act(self, obs):
        if obs.tick == 0:
            self.reset(0)
        field = obs.field
        self.left, self.right = field.my_goal[0], field.opponent_goal[0]
        self.half, self.mouth = field.height * 0.5, field.goal_width * 0.5 - 0.7
        self.circle, self.reach = field.centre_circle_radius, field.kick_range
        self.speed, self.dt = field.max_speed, 1.0 / field.simulation_hz
        self.acc = field.acceleration * self.dt
        self.impulse, self.friction = field.kick_impulse, field.ball_friction
        if self._score is None or obs.score != self._score:
            self._restart_owner = (obs.ball.controlling_team if self._score is None
                                   else 0 if obs.score[1] > self._score[1] else 1)
            self._restart_until = obs.tick + int(3.0 * field.simulation_hz)
        self._score = obs.score
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        if math.hypot(bx, by) > 0.7 or math.hypot(vx, vy) > 0.15:
            self._restart_until = -1
        protected = obs.tick < self._restart_until and self._restart_owner == 1
        friends = [(p.id, *p.position, *p.velocity) for p in obs.my_players]
        opponents = [(p.id, *p.position, *p.velocity) for p in obs.opponents]
        actions = TeamAction()
        if not friends:
            return actions
        keeper = friends[0]
        outfield = friends[1:] or friends
        samples = self._forecast(bx, by, vx, vy)
        races = {p[0]: self._intercept(p, samples) for p in outfield}
        ordered = sorted(outfield, key=lambda p: races[p[0]][0])
        first = ordered[0]
        enemy_eta = min((self._intercept(p, samples)[0] for p in opponents), default=100.0)
        attacking = races[first[0]][0] < enemy_eta + 0.1
        keeper_x = self.left + 2.2
        keeper_y = by * 2.2 / max(3.0, bx - self.left)
        if vx < -1.0 and bx > keeper_x:
            needed = (keeper_x - bx) / vx
            if 0.0 < needed < self.dt / (1.0 - self.friction):
                keeper_y = by + vy * needed
        targets = {keeper[0]: (keeper_x, _clip(keeper_y, -self.mouth, self.mouth)),
                   first[0]: self._target(*races[first[0]][1])}
        if (bx < self.left + 11.0
                and self._eta(keeper, bx, by) < min(enemy_eta + 0.05, races[first[0]][0] * 0.8)):
            targets[keeper[0]] = self._target(bx, by)
        remaining = ordered[1:]
        if remaining:
            second = remaining[0]
            # Defend with two arriving bodies; on a counter, the second runs ahead.
            targets[second[0]] = (self._target(bx + 15.0, -by * 0.4)
                                    if attacking else self._target(*races[second[0]][1]))
        for index, p in enumerate(remaining[1:]):
            lane = (-1.0 if index % 2 == 0 else 1.0)
            x = min(-8.0, bx - 9.0) if not attacking else min(35.0, bx + 18.0)
            y = by * 0.25 + lane * (7.0 if not attacking else 13.0)
            targets[p[0]] = self._target(x, y)
        carrier = min((p for p in friends if obs.can_kick(p[0])),
                      key=lambda p: math.hypot(p[1] - bx, p[2] - by), default=None)
        for p in friends:
            target = targets.get(p[0], (p[1], p[2]))
            if protected and math.hypot(p[1], p[2]) < self.circle + 5.0:
                ux, uy = _unit(p[1], p[2])
                if ux == 0.0 and uy == 0.0:
                    ux = -1.0
                target = (ux * (self.circle + 3.0), uy * (self.circle + 3.0))
            movement = self._move(p, target)
            kick = None
            if carrier is not None and p[0] == carrier[0] and not protected:
                movement = self._move(p, (bx + 0.2, by))
                nx, ny = p[3] * 0.9 + movement[0] * self.acc, p[4] * 0.9 + movement[1] * self.acc
                speed = math.hypot(nx, ny)
                if speed > self.speed:
                    nx, ny = nx * self.speed / speed, ny * self.speed / speed
                if math.hypot(p[1] + nx * self.dt - bx, p[2] + ny * self.dt - by) < self.reach - 0.18:
                    kick = self._kick(p, bx, by, vx, vy, friends, opponents)
            actions.set(p[0], PlayerAction(movement=movement) if kick is None else
                        PlayerAction(movement=movement, kick_direction=kick[0], kick_power=kick[1]))
        return actions
