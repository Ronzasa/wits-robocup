"""Recompute paired results from retained native records, without new games."""
from pathlib import Path
import hashlib,json,random,collections
R=Path(__file__).resolve().parent;baseline='1bf09f5fcab940eae8f387ef36030d302dfe9e52aa6ae0fe82f48742ea6e85b7';rows_all=[];base_rows=[];check={};reliability={}
for name in ['baseline-field','development','stagger-development','qualification']:
 p=R/name;reg=json.loads((p/'registration.json').read_text());rows=[json.loads(x) for x in (p/'matches.jsonl').read_text().splitlines()]
 assert len(rows)==len(reg['sources'])*len(reg['opponents'])*len(reg['seeds'])*4
 assert len({(x['source'],x['opponent_name'],x['seed'],x['candidate_slot'],x['candidate_takes_kickoff']) for x in rows})==len(rows)
 counts={'source_errors':0,'source_raw_misses':0,'opponent_errors':0,'opponent_raw_misses':0}
 for x in rows:
  assert x['result']['ticks']==2400 and x['result']['terminal_reason']=='time_limit'
  assert x['result']['engine_version']=='0.1.0' and x['result']['config_hash']=='372990895c7eca2a'
  for label,idx in [('source',x['candidate_slot']),('opponent',1-x['candidate_slot'])]:
   s=x['result']['stats'][idx];counts[label+'_errors']+=s['policy_errors'];counts[label+'_raw_misses']+=s['policy_timeouts']
  if reg['sources'][x['source']]['sha256']==baseline:base_rows.append(x)
 for v in reg['sources'].values():assert hashlib.sha256(Path(v['path']).read_bytes()).hexdigest()==v['sha256']
 rows_all+=rows;check[name]=len(rows);reliability[name]=counts
q=json.loads((R/'qualification/summary.json').read_text());style={n:d['finalist']['points']-d['baseline']['points'] for n,d in q['by_opponent'].items()};paired=q['paired_vs_baseline']['finalist']
qr=[json.loads(x) for x in (R/'qualification/matches.jsonl').read_text().splitlines()]
pts=lambda x:3 if x['result']['score'][x['candidate_slot']]>x['result']['score'][1-x['candidate_slot']] else 1 if x['result']['score'][x['candidate_slot']]==x['result']['score'][1-x['candidate_slot']] else 0
key=lambda x:(x['opponent_name'],x['seed'],x['candidate_slot'],x['candidate_takes_kickoff']);a={key(x):x for x in qr if x['source']=='finalist'};b={key(x):x for x in qr if x['source']=='baseline'};assert a.keys()==b.keys()
blocks=collections.defaultdict(list)
for k,x in a.items():blocks[x['seed']].append(pts(x)-pts(b[k]))
means=[sum(v)/len(v) for _,v in sorted(blocks.items())];rng=random.Random(3260260099);boots=sorted(sum(rng.choices(means,k=len(means)))/len(means) for _ in range(10000));ci=[boots[250],boots[9749]];assert ci==paired['seed_block_95']
for n in ['baseline','finalist']:
 rr=[x for x in qr if x['source']==n];assert sum(pts(x) for x in rr)==q['summary'][n]['points']
G=dict(positive_points_lower=ci[0]>0,zero_exceptions=q['summary']['finalist']['policy_errors']==0,raw_miss_gate=paired['additional_raw_misses_per1000']<=2,style_gate=all(v/32>=-.25 for v in style.values()),official_intake=json.loads((R/'challenger-intake.json').read_text())['ok'])
bmax=max(x['result']['stats'][x['candidate_slot']]['decision_time_ms']['max_ms'] for x in base_rows);decisions=sum(x['result']['stats'][x['candidate_slot']]['decision_time_ms']['count'] for x in base_rows)
report=dict(full_native_attempts=len(rows_all),by_cohort=check,reliability_by_cohort=reliability,baseline_calls=decisions,baseline_fixtures=len(base_rows),baseline_max_ms=bmax,qualification_points={n:q['summary'][n]['points'] for n in ['baseline','finalist']},paired_points=paired,per_style_points_difference=style,gates=G,recommendation='Retain uploaded MONSTER13 unchanged; reject outlet12 challenger for insufficient league-point evidence',promote=False)
(R/'final-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
