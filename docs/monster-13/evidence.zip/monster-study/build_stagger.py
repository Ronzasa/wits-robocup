"""Reserve the nearest ready guard; let farther guard clear first."""
from pathlib import Path
import hashlib,ast,json
R=Path(__file__).resolve().parent;s=(R/'candidates/baseline/team.py').read_text()
anchor='''        actions = TeamAction(debug={"text": "MONSTER four-cover counter"})
        for i, p in enumerate(friends):
'''
new='''        actions = TeamAction(debug={"text": "MONSTER four-cover counter"})
        # Do not spend every nearby defender's independent cooldown at once.
        # A farther guard clears; the nearest stays ready for the rebound.
        home_ready = []
        if not protected:
            for i, p in enumerate(friends[:4]):
                if not obs.can_kick(i):
                    continue
                aim = (self.left+depth, (5.4, -1.8, 1.8, -5.4)[i])
                if self.ADAPTIVE_POSTS and bx<self.left+12 and abs(by)>4.0 and i==(0 if by>0 else 3):
                    side = 1 if by>0 else -1
                    aim = (max(self.left+self.pr+0.02,min(self.left+depth,bx-0.6)),
                           side*clip(abs(by),5.4,self.goal+2.5))
                moved = self.player_step(p, self.move(p, aim))
                gap = math.hypot(moved[1]-bx, moved[2]-by)
                if gap < self.kr-0.04:
                    home_ready.append((gap, i))
        home_kicker = max(home_ready)[1] if len(home_ready)>1 else None
        for i, p in enumerate(friends):
'''
assert s.count(anchor)==1;s=s.replace(anchor,new)
a='''            elif i<4 and not protected and obs.can_kick(i):
''';b='''            elif i<4 and not protected and obs.can_kick(i) and (home_kicker is None or i==home_kicker):
''';assert s.count(a)==1;s=s.replace(a,b)
p=R/'candidates/stagger/team.py';p.parent.mkdir(parents=True);p.write_text(s);compile(s,str(p),'exec')
(R/'stagger-manifest.json').write_text(json.dumps(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),hypothesis='preserve independent cooldown of nearest covering player while another ready in-range defender clears',scope='experimental; ignores future opponent response; no guarantee'),indent=2)+'\n')
