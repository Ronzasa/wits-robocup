"""Record one public native diagnostic fixture; default roster and20ms unchanged."""
import argparse,json,sys
from pathlib import Path
from soccer import SoccerEnv,TeamController,runner,read_replay
from soccer.helpers import load_controller
P=Path('/workspace/work/replay-finishing-handoffs')
p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--opponent',type=Path,required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--side',type=int,choices=[0,1],required=True);p.add_argument('--own-kickoff',action=argparse.BooleanOptionalAction,default=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir()
paths=[a.candidate,a.opponent];paths.reverse() if a.side else None
controllers=[load_controller(str(x)) for x in paths];slow=[]
with SoccerEnv(config_path=str(P/'configs/default.toml'),max_ticks=2400,per_decision_timeout_ms=20,record_replay=str(a.out/'match.rep')) as env:
 for c in controllers:c.reset(a.seed)
 obs=env.reset(seed=a.seed,kickoff_team=a.side if a.own_kickoff else 1-a.side)
 previous=[TeamController.idle(obs[k]) for k in ['team_a','team_b']]
 while not env.finished:
  actions={}
  for i,k in enumerate(['team_a','team_b']):
   action,elapsed,error=runner._decide(controllers[i],obs[k]);env.record_decision(i,elapsed,error)
   if error is None:previous[i]=action
   else:action=previous[i]
   if error is not None or elapsed>20:slow.append(dict(side=i,tick=obs[k].tick,elapsed_ms=elapsed,error=error))
   actions[k]=action
  if env.finished:break
  obs,_=env.step(actions)
 result=env.result()
d=read_replay(str(a.out/'match.rep'),True)
if isinstance(d,str):d=json.loads(d)
(a.out/'replay.json').write_text(json.dumps(d))
(a.out/'result.json').write_text(json.dumps(dict(result=result,slow=slow,scope='posthoc native diagnostic, not qualification'),indent=2)+'\n')
print('Score',result['score'],'keys',list(d))
for e in d['events']:
 if e.get('kind')=='goal':print(e)
