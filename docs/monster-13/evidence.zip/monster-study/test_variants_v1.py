"""Focused action regressions, public synthetic inputs; not match results."""
import ast,math,unittest
from pathlib import Path
from types import SimpleNamespace as N
from soccer import SoccerEnv
from soccer.helpers import load_controller
R=Path(__file__).resolve().parent
class Actions(unittest.TestCase):
 def setUp(self):
  with SoccerEnv() as e:self.field=e.field
 def controller(self,n):
  c=load_controller(str(R/'candidates'/n/'team.py'));c.reset(1);c.setup(self.field);return c
 def obs(self,score=(0,0),bx=-48.,by=0.,holder=0):
  def p(i,x,y):return N(id=i,position=(x,y),velocity=(0.,0.),kick_cooldown_ticks=0)
  return N(field=self.field,tick=200,score=score,my_goal=self.field.my_goal,opponent_goal=self.field.opponent_goal,
   my_players=[p(i,-48.8,y) for i,y in enumerate([5.4,-1.8,1.8,-5.4])]+[p(4,-20.,21.)],
   opponents=[p(i+5,x,y) for i,(x,y) in enumerate([(48.,0.),(8.,-4.),(8.,4.),(-30.,10.),(-30.,-10.)])],
   ball=N(position=(bx,by),velocity=(0.,0.),controlling_team=holder,last_touch=None),can_kick=lambda pid:pid==1)
 def equal(self,a,b):
  return (a.movement,a.kick_direction,a.kick_power)==(b.movement,b.kick_direction,b.kick_power)
 def test_central_clear_only_changes_ready_home_kick(self):
  o=self.obs();a=self.controller('baseline').shell_act(o,False);b=self.controller('central-clear').shell_act(o,False)
  self.assertEqual(b.players[1].kick_direction,(1.,0.));self.assertEqual(b.players[1].kick_power,1.)
  for i in [0,2,3,4]:self.assertTrue(self.equal(a.players[i],b.players[i]))
 def test_central_clear_preserves_outer_and_protected_actions(self):
  for bx,by,protected in [(-40.,0.,False),(-48.,10.,False),(-48.,0.,True)]:
   o=self.obs(bx=bx,by=by);a=self.controller('baseline').shell_act(o,protected);b=self.controller('central-clear').shell_act(o,protected)
   self.assertTrue(all(self.equal(a.players[i],b.players[i]) for i in range(5)))
 def test_outlet_shift_preserves_four_covering_actions(self):
  o=self.obs();a=self.controller('baseline').shell_act(o,False);b=self.controller('outlet12').shell_act(o,False)
  self.assertFalse(self.equal(a.players[4],b.players[4]));self.assertTrue(all(self.equal(a.players[i],b.players[i]) for i in range(4)))
 def test_depth_change_only_when_leading(self):
  o=self.obs();a=self.controller('baseline').shell_act(o,False);b=self.controller('hold-depth').shell_act(o,False)
  self.assertTrue(all(self.equal(a.players[i],b.players[i]) for i in range(5)))
  o=self.obs(score=(1,0));a=self.controller('baseline').shell_act(o,False);b=self.controller('hold-depth').shell_act(o,False)
  self.assertTrue(self.equal(a.players[4],b.players[4]));self.assertFalse(self.equal(a.players[1],b.players[1]))
 def test_release_attacks_only_when_gate_active(self):
  for score,expected in [((0,0),'MONSTER four-cover counter'),((0,1),'MONSTER predictive pressure')]:
   o=self.obs(score=score,bx=-10.);o.can_kick=lambda pid:False
   a=self.controller('release').act(o);self.assertEqual(a.debug['text'],expected)
   self.assertEqual(set(a.players),set(range(5)))
   for v in a.players.values():self.assertLessEqual(math.hypot(*v.movement),1.000001)
 def test_no_other_physics_changes(self):
  base=ast.parse((R/'candidates/baseline/team.py').read_text());c0=next(n for n in base.body if isinstance(n,ast.ClassDef))
  funcs=lambda c:{n.name:ast.dump(n) for n in c.body if isinstance(n,ast.FunctionDef)}
  for name in ['release','hold-depth','outlet12','central-clear']:
   c=next(n for n in ast.parse((R/'candidates'/name/'team.py').read_text()).body if isinstance(n,ast.ClassDef))
   for n,v in funcs(c0).items():
    if name=='central-clear' and n=='shell_act':continue
    self.assertEqual(v,funcs(c)[n])
if __name__=='__main__':unittest.main()
