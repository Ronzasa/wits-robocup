"""Package public controller research without uploaded HAR credentials."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent;L=Path('/workspace/work/div6-leader-20261026');P=Path('/workspace/work/replay-finishing-handoffs');D=P/'docs/monster-13'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
payload={}
for prefix,root in [('monster-study',R),('historical-leader-study',L)]:
 for p in root.rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts or p.suffix in ('.pyc','.rep'):continue
  if p.name in ['STATE.md','table-private.json'] or p==L/'model/rows.json':continue
  assert p.suffix.lower() not in ['.har','.zip']
  payload[prefix+'/'+p.relative_to(root).as_posix()]=p
for rel in ['my-team/team.py','experiments/monster-13/uploaded/team.py','experiments/monster-13/challenger/team.py','tools/benchmarks/default_roster.py','tools/benchmarks/benchmark.py','tools/benchmarks/champion_hunt_match.py','configs/default.toml','docs/monster-13/README.md']:
 payload['repo/'+rel]=P/rel
assert sha(P/'my-team/team.py')==sha(P/'experiments/monster-13/uploaded/team.py')=='1bf09f5fcab940eae8f387ef36030d302dfe9e52aa6ae0fe82f48742ea6e85b7'
assert sha(P/'experiments/monster-13/challenger/team.py')=='da67afd105219835349ea27ff7c8967d1af7ee3cfa312f3810480c9cfac6c0a4'
manifest=dict(schema=1,branch='monster-13-review',parent_commit='149a5470756b6deb9d0e4ba7507c963903a77eed',submission='Original user-designated MONSTER13, unchanged bytes',experimental_modification_promoted=False,privacy_exclusions=['Original uploaded ZIP/HAR','request headers and cookies','full table capture','redundant model feature rows','internal STATE.md','Python caches','duplicate binary diagnostic replay'],payload={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(payload.items())})
out=D/'evidence.zip'
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(payload.items()):z.write(p,n)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n,v in manifest['payload'].items():
  b=z.read(n);assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'],n
manifest['archive']=dict(bytes=out.stat().st_size,sha256=sha(out),all_payload_hashes_and_crc_verified=True)
(D/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(files=len(payload),**manifest['archive']),indent=2))
