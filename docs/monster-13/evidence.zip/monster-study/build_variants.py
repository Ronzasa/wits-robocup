from pathlib import Path
import hashlib,json,ast
R=Path(__file__).resolve().parent;P=R/'candidates/baseline/team.py';raw=P.read_bytes();assert hashlib.sha256(raw).hexdigest()=='1bf09f5fcab940eae8f387ef36030d302dfe9e52aa6ae0fe82f48742ea6e85b7'
s=raw.decode().replace('\r\n','\n')
variants={'release':s.replace('    SHELL_RELEASE = False','    SHELL_RELEASE = True'), 'hold-depth':s.replace('    LOCK_DEPTH = 3.3','    LOCK_DEPTH = 1.2'), 'outlet12':s.replace('    OUTLET_X = -20.0','    OUTLET_X = -12.0')}
old='''                kick = ((ux, uy), 1.0)
''';assert s.count(old)==1
new='''                # Maximize the outward impulse in the dangerous goalmouth.
                # This does not assume the resulting body contact is safe.
                if bx < self.left+5.0 and abs(by) < self.goal+2.0:
                    ux, uy = 1.0, 0.0
                kick = ((ux, uy), 1.0)
'''
variants['central-clear']=s.replace(old,new)
manifest={}
for name,src in variants.items():
 out=R/'candidates'/name/'team.py';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(src);compile(src,str(out),'exec')
 manifest[name]=dict(path=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),bytes=out.stat().st_size)
(R/'variants-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Built',list(variants))
