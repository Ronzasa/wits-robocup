"""Independent last-moment keeper brake for a public simultaneous-kick threat."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/work/replay-finishing-handoffs/my-team/team.py')
src=BASE.read_text();assert hashlib.sha256(src.encode()).hexdigest()=='27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce'
head,sep,body=src.rpartition('    def act(self, obs):\n');assert sep and 'self._fallback.act(obs)' in body
s=head+'    def _uncontested_act(self, obs):\n'+body
s+='''

    def act(self, obs):
        actions = self._uncontested_act(obs)
        if not obs.my_players:
            return actions
        keeper = obs.my_players[0]
        bx, by = obs.ball.position
        if bx >= obs.my_goal[0] + 6.0 or abs(by) >= 10.0 or not obs.can_kick(keeper.id):
            return actions
        if not any(q.kick_cooldown_ticks == 0 and
                   math.hypot(q.position[0] - bx, q.position[1] - by) <= obs.field.kick_range
                   for q in obs.opponents):
            return actions
        # A collision can turn a nominal forward clearance into an own goal.
        # Preserve the other four actions and remove the keeper's contested kick.
        brake = _unit(-keeper.velocity[0], -keeper.velocity[1])
        actions.set(keeper.id, PlayerAction(movement=brake))
        policy = self._specialist if self._active else self._fallback
        if policy._receive_plan is not None and policy._receive_plan[1] == keeper.id:
            policy._receive_plan = None
            policy._receive_aim = None
            policy._bank_receive = None
            policy._relay_receive = None
        return actions
'''
s=s.replace("version = 'champion-hunt-adaptive-1.0'", "version = 'div6-contest-brake-dev1'")
compile(s,'contest-brake','exec');out=ROOT/'contest-brake/team.py';out.parent.mkdir(exist_ok=True);out.write_text(s)
manifest_path=ROOT/'manifest.json';manifest=json.loads(manifest_path.read_text());manifest['contest-brake']=dict(path=str(out),sha256=hashlib.sha256(s.encode()).hexdigest(),bytes=len(s.encode()),base_sha256=hashlib.sha256(src.encode()).hexdigest())
tmp=manifest_path.with_suffix('.tmp');tmp.write_text(json.dumps(manifest,indent=2)+'\n');tmp.replace(manifest_path)
print(json.dumps(manifest['contest-brake'],indent=2))
