# Independent keeper safety hypotheses

Frozen behavior baseline: current adaptive controller at `my-team/team.py`, SHA-256 `27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce`. Sources are experimental and not promoted. Build with `python build.py`; inspect `manifest.json` for source identities. All sources compile, have one SDK `TeamController` subclass and fit under 262,144 bytes.

## Variants

- **nearpost**: In both helper policies, anticipate a near-post shot before its velocity exists when the enemy controls/last touches a ball within 12 units of our goal and at lateral distance >55% of goal half-width. Aim the keeper at ball y (clamped by the existing keeper limit) and prevent a sweep override during that specific threat. Ordinary predictive velocity logic still takes over after the ball is kicked. Only `_FallbackPolicy._v10_act` and `_SpecialistPolicy._opening_act` change.
- **depth-only**: Change normal keeper home depth from 2.2 units to 1.2 units. All other decisions remain identical. Only the same two keeper-target methods change; wall/siege keeper positions are deliberately not altered. This isolates depth from anticipation.
- **clearance-guard**: Add one postprocessing wrapper around the original outer `act`. Preserve the full original behavior unless a selected, currently legal keeper kick in our final 12 units has a modeled contact-plus-short-flight own-goal risk. Reuse `_requested_velocity` and `_carrier_contact`, then evaluate at most 21 legal kick/movement alternatives (seven full-power directions × original/retreat/still movement). Replace only with a positive-forward-velocity launch that clears that local risk. When replacement invalidates a keeper pass, discard the tied reception contract. No unrelated player's action changes. If a safer candidate is unavailable, retain the original action.

The clearance guard is a **local model**, not a physically guaranteed save. It ignores opposing simultaneous impulses, future defender actions and most future player contacts; end-wall/aperture prediction is approximate. Its purpose is to isolate an obvious keeper self-contact failure with bounded arithmetic. It should not be used to claim opponent interception or pass safety.

## Executed local checks

`audit.py` performs exact method AST comparisons and isolated synthetic contact regressions; it does not run native matches or timed qualification. It checks:

1. All general movement, attacking and shooting methods remain unchanged, and the wrapper's renamed original action method has an identical body.
2. A safe existing keeper action object is returned unchanged.
3. At recorded `entry-12` pre-states 504 and 1545, the old kick's modeled post-contact x velocities are approximately −1.162806 and −7.964204. The guard selects alternatives with +13.867655 and +21.204401 x velocities, respectively, preserves the unrelated outfielder action, respects movement/power ranges and clears the obsolete keeper reception contract.

These last checks use public recorded states as synthetic inputs, not injected simulator states. They establish consistent local arithmetic; the root study's separate faithful native replay and short keeper interventions are the appropriate causal evidence. The native-repro agent reports guard prevented the two corresponding own-goals in its short fixed-other-actions windows, but did **not** prevent the simultaneous opposing-kick own-goal in `entry-01`. Do not claim three out of three saves, a guaranteed prevention rate, or an independent match win from these windows.

No native tournament or complete-match experiment was run by this builder. Root-run development and fresh validation must establish league-point, reliability and runtime results before any promotion. Source files have not changed since their first manifest was supplied for testing.

## Later independent contest-brake candidate

Built separately with `build_contest.py` from the same frozen baseline. It changes only the outer controller `act` and preserves that original body under `_uncontested_act`. At a ball x within six units of our goal and |y|<10, require the keeper to be currently in kicking range/off cooldown and at least one opposing off-cooldown player to be within the public kick range. In that situation remove the keeper's kick, issue unit braking against its existing velocity, preserve all other players' action objects and discard any reception contract tied to that keeper's interrupted pass. It is a simple local contact guard, not an opponent policy predictor or a guaranteed save.

`audit_contest.py` executes four pure synthetic/static checks: keeper-only brake/cancellation with untouched other-player action, preservation when enemy cooldown/range or keeper eligibility excludes the threat, preservation at outer spatial boundaries, and positive activation on the actual public pre-state at `entry-01` tick1004 where simultaneous kicks precede the own-goal. No native decision loop is run by that test. `audit-contest.json` records success and source hash.

SHA-256: `de02d417af8a72d2b67c03e5af4ac948f721278da8a0962e1233ac08932de37b`; bytes: 239,309. Root-run short causal interventions and timed independent matches are required to judge it. All previous candidate source files remain unchanged.
