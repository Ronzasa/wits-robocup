"""Static bounded-diff and isolated post-clearance regression checks."""
import ast,hashlib,json,sys,unittest
from pathlib import Path
from types import SimpleNamespace as N
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/work/replay-finishing-handoffs/my-team/team.py')
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import TeamAction,PlayerAction
from soccer.helpers import load_controller

def methods(code):
 tree=ast.parse(code);result={}
 for c in tree.body:
  if isinstance(c,ast.ClassDef):
   for n in c.body:
    if isinstance(n,ast.FunctionDef):result.setdefault((c.name,n.name),[]).append(ast.dump(n,include_attributes=False))
 return result

def audit():
 base=methods(BASE.read_text());out={}
 for name in ('nearpost','depth-only','clearance-guard'):
  path=ROOT/name/'team.py';tree=ast.parse(path.read_text());m=methods(path.read_text())
  changed=[list(k) for k in base.keys()|m.keys() if base.get(k)!=m.get(k)]
  wrappers=[n.name for n in tree.body if isinstance(n,ast.ClassDef) and any(isinstance(b,ast.Name) and b.id=='TeamController' for b in n.bases)]
  assert wrappers==['AdaptiveChampion']
  assert path.stat().st_size<262144
  allowed={('_FallbackPolicy','_v10_act'),('_SpecialistPolicy','_opening_act')} if name!='clearance-guard' else {('AdaptiveChampion','act'),('AdaptiveChampion','_unguarded_act')}
  assert {tuple(k) for k in changed}==allowed,(name,changed)
  if name=='clearance-guard':
   actual=ast.parse(path.read_text());klass=next(x for x in actual.body if isinstance(x,ast.ClassDef) and x.name=='AdaptiveChampion')
   old=next(x for x in klass.body if isinstance(x,ast.FunctionDef) and x.name=='_unguarded_act');old.name='act'
   assert [ast.dump(old,include_attributes=False)]==base[('AdaptiveChampion','act')]
  out[name]=dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),changed_methods=sorted(changed),sdk_wrappers=wrappers,bytes=path.stat().st_size)
 return out

class Clearance(unittest.TestCase):
 def controller(self):
  c=load_controller(str(ROOT/'clearance-guard/team.py'));p=c._fallback
  # Native field constants, no environment/time loop required.
  f=N(simulation_hz=20.,max_speed=8.,acceleration=20.,ball_friction=.985,kick_impulse=22.,kick_range=2.2,
      my_goal=(-50.,0.),opponent_goal=(50.,0.),height=68.,goal_width=14.,centre_circle_radius=10.,ball_radius=.45,player_radius=1.)
  p._setup(f);return c,p,f
 def test_unthreatened_original_action_object_is_preserved(self):
  c,p,f=self.controller();player=N(id=0,position=(-47.8,0.),velocity=(0.,0.))
  o=N(my_players=[player],my_goal=f.my_goal,ball=N(position=(-46.8,0.),velocity=(0.,0.)),can_kick=lambda pid:True)
  a=TeamAction({0:PlayerAction(movement=(0.,0.),kick_direction=(1.,0.),kick_power=1.)});c._unguarded_act=lambda obs:a
  self.assertIs(c.act(o),a);self.assertEqual(a.players[0].kick_direction,(1.,0.))
 def test_two_recorded_contact_reversals_get_forward_clearances(self):
  replay=json.loads((ROOT.parent/'replays/entry-12.json').read_text())
  for tick in (504,1545):
   with self.subTest(tick=tick):
    c,p,f=self.controller();state=replay['frames'][tick]
    cmd=replay['frames'][tick+1]['players'][5]['action'];q=state['players'][5]
    pair=lambda v:(-v['x'],-v['y'])
    player=N(id=0,position=pair(q['position']),velocity=pair(q['velocity']))
    o=N(my_players=[player],my_goal=f.my_goal,ball=N(position=pair(state['ball_position']),velocity=pair(state['ball_velocity'])),can_kick=lambda pid:True)
    original=PlayerAction(movement=pair(cmd['movement']),kick_direction=pair(cmd['kick_direction']),kick_power=cmd['kick_power'])
    other=PlayerAction(movement=(0.,1.));a=TeamAction({0:original,1:other});c._unguarded_act=lambda obs:a
    p._receive_plan=(4,0,2000)
    own=(0,*player.position,*player.velocity)
    before=p._carrier_contact(own,*o.ball.position,*p._requested_velocity(*o.ball.velocity,(original.kick_direction,original.kick_power)),original.movement)
    self.assertLess(before[2],0.)
    result=c.act(o);action=result.players[0]
    self.assertNotEqual(action,original)
    after=p._carrier_contact(own,*o.ball.position,*p._requested_velocity(*o.ball.velocity,(action.kick_direction,action.kick_power)),action.movement)
    self.assertGreater(after[2],.5)
    self.assertIs(result.players[1],other)
    self.assertIsNone(p._receive_plan)
    self.assertLessEqual(sum(x*x for x in action.movement),1.+1e-8)
    self.assertTrue(0.<=action.kick_power<=1.)

if __name__=='__main__':
 report=audit();suite=unittest.defaultTestLoader.loadTestsFromTestCase(Clearance)
 r=unittest.TextTestRunner().run(suite);report['synthetic_checks_passed']=r.wasSuccessful();report['native_matches_run']=0
 (ROOT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
 assert r.wasSuccessful();print(json.dumps(report,indent=2))
