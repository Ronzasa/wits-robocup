"""Pure synthetic/static checks of the independently frozen contest brake."""
import ast,hashlib,json,math,unittest
from pathlib import Path
from types import SimpleNamespace as N
from audit import methods,BASE,ROOT,TeamAction,PlayerAction,load_controller
SOURCE=ROOT/'contest-brake/team.py'
class Contest(unittest.TestCase):
 def fixture(self,cooldown=0,enemy_distance=1.5,keeper_can=True):
  c=load_controller(str(SOURCE));keeper=N(id=0,position=(-48.8,-5.6),velocity=(1.,-.5))
  enemy=N(id=9,position=(-49.,-7.+enemy_distance),velocity=(0.,0.),kick_cooldown_ticks=cooldown)
  obs=N(my_players=[keeper],opponents=[enemy],my_goal=(-50.,0.),field=N(kick_range=2.2),ball=N(position=(-49.,-7.)),can_kick=lambda pid:keeper_can)
  own=PlayerAction(movement=(1.,0.),kick_direction=(1.,0.),kick_power=1.)
  other=PlayerAction(movement=(0.,1.));actions=TeamAction({0:own,1:other})
  c._uncontested_act=lambda obs:actions
  return c,obs,actions,own,other
 def test_contested_near_goal_brakes_only_keeper(self):
  c,obs,actions,own,other=self.fixture();c._fallback._receive_plan=(3,0,50)
  result=c.act(obs);a=result.players[0]
  self.assertIsNone(a.kick_direction)
  self.assertAlmostEqual(math.hypot(*a.movement),1.)
  self.assertLess(sum(x*y for x,y in zip(a.movement,obs.my_players[0].velocity)),0.)
  self.assertIs(result.players[1],other)
  self.assertIsNone(c._fallback._receive_plan)
 def test_cooldown_out_of_range_or_no_keeper_kick_preserves_actions(self):
  for args in [dict(cooldown=1),dict(enemy_distance=2.2001),dict(keeper_can=False)]:
   with self.subTest(args=args):
    c,obs,a,own,other=self.fixture(**args);self.assertIs(c.act(obs).players[0],own)
 def test_outside_own_six_or_ten_y_preserves_actions(self):
  for x,y in [(-44.,-7.),(-49.,10.)]:
   c,obs,a,own,other=self.fixture();obs.ball.position=(x,y)
   self.assertIs(c.act(obs).players[0],own)
 def test_recorded_joint_kick_state_triggers(self):
  d=json.loads((ROOT.parent/'replays/entry-01.json').read_text());state=d['frames'][1004]
  def pair(v):return (v['x'],v['y'])
  q=state['players'][0];player=N(id=0,position=pair(q['position']),velocity=pair(q['velocity']))
  opponents=[N(id=i,position=pair(q['position']),kick_cooldown_ticks=q['kick_cooldown_ticks']) for i,q in enumerate(state['players']) if i>=5]
  ball=pair(state['ball_position']);can=q['kick_cooldown_ticks']==0 and math.dist(player.position,ball)<=2.2
  o=N(my_players=[player],opponents=opponents,my_goal=(-50.,0.),field=N(kick_range=2.2),ball=N(position=ball),can_kick=lambda pid:can)
  c,_,a,old,other=self.fixture();c._uncontested_act=lambda obs:a
  result=c.act(o);self.assertIsNone(result.players[0].kick_direction)
  self.assertNotEqual(result.players[0],old)

if __name__=='__main__':
 baseline=methods(BASE.read_text());current=methods(SOURCE.read_text())
 changed=sorted(k for k in baseline.keys()|current.keys() if baseline.get(k)!=current.get(k))
 assert set(changed)=={('AdaptiveChampion','act'),('AdaptiveChampion','_uncontested_act')}
 tree=ast.parse(SOURCE.read_text());klass=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='AdaptiveChampion')
 old=next(x for x in klass.body if isinstance(x,ast.FunctionDef) and x.name=='_uncontested_act');old.name='act'
 assert [ast.dump(old,include_attributes=False)]==baseline[('AdaptiveChampion','act')]
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Contest);r=unittest.TextTestRunner().run(suite)
 result=dict(sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),tests=r.testsRun,passed=r.wasSuccessful(),changed_methods=changed,native_matches_run=0)
 (ROOT/'audit-contest.json').write_text(json.dumps(result,indent=2)+'\n');assert r.wasSuccessful();print(json.dumps(result,indent=2))
