"""Independent minimal defensive hypotheses from frozen adaptive champion."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/work/replay-finishing-handoffs/my-team/team.py')
src=BASE.read_text();assert hashlib.sha256(src.encode()).hexdigest()=='27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce'
variants={}
# Restrict the extra near-post positioning to an actual nearby enemy touch.
anchor='''        keeper_y = by * 2.2 / max(3.0, bx - self._left)
'''
near='''        keeper_y = by * 2.2 / max(3.0, bx - self._left)
        near_post_threat = (bx < self._left + 12.0 and abs(by) > self._goal_half * 0.55
                            and (obs.ball.controlling_team == 1 or obs.ball.last_touch in {q[0] for q in opponents}))
        if near_post_threat:
            keeper_y = by
'''
assert src.count(anchor)==2
# Both inherited helpers are guarded; no outfield targets or shot methods change.
s=src.replace(anchor,near)
# Keep the proactive post position from being overwritten by a late sweep.
anchor2='''        if sweep:
            keeper_target = self._target(bx, by)
'''
assert s.count(anchor2)==2
s=s.replace(anchor2,'''        if sweep and not near_post_threat:
            keeper_target = self._target(bx, by)
''')
variants['nearpost']=s
# Independent depth-only candidate: keep every other old decision intact.
variants['depth-only']=src.replace('else self._left + 2.2','else self._left + 1.2').replace('keeper_x = self._left + 2.2','keeper_x = self._left + 1.2')
# Current wrapper's act is last function in source; rename only that method.
head,sep,body=src.rpartition('    def act(self, obs):\n')
assert sep and 'self._fallback.act(obs)' in body
s=head+'    def _unguarded_act(self, obs):\n'+body
s+='''

    def act(self, obs):
        actions = self._unguarded_act(obs)
        if not obs.my_players:
            return actions
        keeper = obs.my_players[0]
        original = actions.players.get(keeper.id)
        if original is None or original.kick_direction is None or not obs.can_kick(keeper.id):
            return actions
        policy = self._specialist if self._active else self._fallback
        if not policy._ready or obs.ball.position[0] > obs.my_goal[0] + 12.0:
            return actions
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        p = (keeper.id, *keeper.position, *keeper.velocity)
        def launch(kick, movement):
            sx, sy = policy._requested_velocity(vx, vy, kick)
            return policy._carrier_contact(p, bx, by, sx, sy, movement)
        def own_goal_risk(state):
            if state is None:
                return False
            x, y, sx, sy = state
            wall = policy._half_height - policy._ball_radius
            for _ in range(12):
                if x <= policy._left + policy._ball_radius and abs(y) <= policy._goal_half + 0.1:
                    return True
                if sx >= 0.0:
                    return False
                x += sx * policy._dt
                y += sy * policy._dt
                if abs(y) > wall:
                    side = 1.0 if y > 0.0 else -1.0
                    y = side * wall * 2.0 - y
                    sy = -side * abs(sy) * policy._wall
                # Native end-wall responses outside the mouth can return a ball.
                if x < policy._left + policy._ball_radius and abs(y) > policy._goal_half:
                    x = 2.0 * (policy._left + policy._ball_radius) - x
                    sx = abs(sx) * policy._wall
                sx *= policy._friction
                sy *= policy._friction
            return False
        proposed = (original.kick_direction, original.kick_power)
        state = launch(proposed, original.movement)
        if not own_goal_risk(state):
            return actions
        best = None
        # Bounded one-frame contact rollouts, followed by short free-ball checks.
        for movement in (original.movement, (-1.0, 0.0), (0.0, 0.0)):
            for direction in ((1.0, 0.0), (0.85, 0.5267826876), (0.85, -0.5267826876),
                              (0.55, 0.8351646544), (0.55, -0.8351646544), (0.0, 1.0), (0.0, -1.0)):
                kick = (direction, 1.0)
                candidate = launch(kick, movement)
                if candidate is None or own_goal_risk(candidate) or candidate[2] <= 0.5:
                    continue
                score = candidate[2] - abs(candidate[3]) * 0.05
                if best is None or score > best[0]:
                    best = (score, movement, kick)
        if best is None:
            return actions
        _, movement, kick = best
        actions.set(keeper.id, PlayerAction(movement=movement, kick_direction=kick[0], kick_power=kick[1]))
        if policy._receive_plan is not None and policy._receive_plan[1] == keeper.id:
            policy._receive_plan = None
            policy._receive_aim = None
            policy._bank_receive = None
            policy._relay_receive = None
        return actions
'''
variants['clearance-guard']=s
manifest={}
for name,s in variants.items():
 s=s.replace("version = 'champion-hunt-adaptive-1.0'",f"version = 'div6-{name}-dev1'")
 compile(s,name,'exec');out=ROOT/name/'team.py';out.parent.mkdir(exist_ok=True);out.write_text(s)
 manifest[name]=dict(path=str(out),sha256=hashlib.sha256(s.encode()).hexdigest(),bytes=len(s.encode()),base_sha256=hashlib.sha256(src.encode()).hexdigest())
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
