"""Read-only combination review: exact AST preservation and public-state synthetics.

No native match/environment loops. Recorded decisions are bottom-layer fixtures,
not injected simulator states or counterfactual competitive evidence.
"""
import ast,hashlib,json,math,sys
from pathlib import Path
from types import SimpleNamespace as N
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'keeper-candidates'))
from audit import methods,Clearance,TeamAction,PlayerAction,load_controller

BASE=(ROOT/'candidates/baseline/team.py').read_text()
SOURCES={name:ROOT/'candidates'/name/'team.py' for name in ('keeper-package','nearpost-package','cover-package')}

def tree_class(code,name):
 return next(n for n in ast.parse(code).body if isinstance(n,ast.ClassDef) and n.name==name)
def method_node(code,cls,name):
 return next(n for n in tree_class(code,cls).body if isinstance(n,ast.FunctionDef) and n.name==name)
def renamed_dump(node,name):
 node.name=name;return ast.dump(node,include_attributes=False)
def assigns(code):
 out={}
 for c in ast.parse(code).body:
  if isinstance(c,ast.ClassDef):
   for n in c.body:
    if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
     out[c.name,n.targets[0].id]=ast.dump(n.value,include_attributes=False)
 return out

def static(name,path):
 code=path.read_text();base=methods(BASE);actual=methods(code)
 guard=(ROOT/'keeper-candidates/clearance-guard/team.py').read_text()
 contest=(ROOT/'keeper-candidates/contest-brake/team.py').read_text()
 expected_overrides={}
 if name=='nearpost-package':
  near=(ROOT/'keeper-candidates/nearpost/team.py').read_text()
  for k in [('_FallbackPolicy','_v10_act'),('_SpecialistPolicy','_opening_act')]:expected_overrides[k]=methods(near)[k]
 if name=='cover-package':
  cover=(ROOT/'candidates/goal-side-cover/team.py').read_text();k=('_FallbackPolicy','_cover_shape');expected_overrides[k]=methods(cover)[k]
 for k,v in base.items():
  if k==('AdaptiveChampion','act'):continue
  assert actual[k]==expected_overrides.get(k,v),(name,k,'unexpected method change')
 assert actual['AdaptiveChampion','_unguarded_act']==[renamed_dump(method_node(BASE,'AdaptiveChampion','act'),'_unguarded_act')]
 assert actual['AdaptiveChampion','_uncontested_act']==[renamed_dump(method_node(guard,'AdaptiveChampion','act'),'_uncontested_act')]
 assert actual['AdaptiveChampion','act']==methods(contest)['AdaptiveChampion','act']
 assert set(actual)==set(base)|{('AdaptiveChampion','_unguarded_act'),('AdaptiveChampion','_uncontested_act')}
 ba,aa=assigns(BASE),assigns(code)
 differences=[list(k) for k in ba.keys()|aa.keys() if ba.get(k)!=aa.get(k)]
 assert {tuple(x) for x in differences}=={('_FallbackPolicy','LOCK_LEAD'),('_FallbackPolicy','LOCK_TIME'),('_FallbackPolicy','TRAIL_WALL'),('AdaptiveChampion','version')},differences
 for flag in ('LOCK_LEAD','LOCK_TIME','TRAIL_WALL'):
  node=next(n for n in tree_class(code,'_FallbackPolicy').body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id==flag)
  assert ast.literal_eval(node.value)==0
 wrappers=[c.name for c in ast.parse(code).body if isinstance(c,ast.ClassDef) and any(isinstance(b,ast.Name) and b.id=='TeamController' for b in c.bases)]
 assert wrappers==['AdaptiveChampion']
 assert len(code.encode())<=262144
 compile(code,str(path),'exec')
 return dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=len(code.encode()),one_sdk_subclass=True,wrapper_order='original _unguarded_act -> clearance _uncontested_act -> contest act',exact_independent_override_asts=[list(k) for k in expected_overrides],other_method_asts_preserved=True,changed_assignments=sorted(differences))

def field():
 return N(simulation_hz=20.,max_speed=8.,acceleration=20.,ball_friction=.985,kick_impulse=22.,kick_range=2.2,
   my_goal=(-50.,0.),opponent_goal=(50.,0.),height=68.,goal_width=14.,centre_circle_radius=10.,ball_radius=.45,player_radius=1.)

def recorded_fixture(path,tick):
 d=json.loads(path.read_text());us=d['header']['team_ids'].index('401976-nkqubela-hokwana');sign=1 if us==0 else -1
 frame=d['frames'][tick];commands=d['frames'][tick+1]
 pair=lambda p:(sign*p['x'],sign*p['y'])
 def player(q,pid):return N(id=pid,position=pair(q['position']),velocity=pair(q['velocity']),kick_cooldown_ticks=q['kick_cooldown_ticks'])
 own=[player(q,i) for i,q in enumerate(frame['players'][us*5:us*5+5])]
 opponents=[player(q,i+5) for i,q in enumerate(frame['players'][(1-us)*5:(1-us)*5+5])]
 ball=N(position=pair(frame['ball_position']),velocity=pair(frame['ball_velocity']))
 obs=N(my_players=own,opponents=opponents,my_goal=(-50.,0.),field=field(),ball=ball,
   can_kick=lambda pid:own[pid].kick_cooldown_ticks==0 and math.dist(own[pid].position,ball.position)<=2.2)
 a=TeamAction()
 for i,q in enumerate(commands['players'][us*5:us*5+5]):
  cmd=q['action'];a.set(i,PlayerAction(movement=pair(cmd['movement']),kick_direction=pair(cmd['kick_direction']) if cmd['kick_direction'] else None,kick_power=cmd['kick_power']))
 return obs,a

def synthetic(name,path):
 reports=[]
 for filename,tick in [('entry-01.json',1004),('entry-12.json',504),('entry-12.json',1545)]:
  controller=load_controller(str(path));policy=controller._fallback;policy._setup(field())
  obs,a=recorded_fixture(ROOT/'replays'/filename,tick);old=dict(a.players)
  policy._receive_plan=(3,0,2000)
  controller._unguarded_act=lambda obs:a
  result=controller.act(obs)
  assert all(result.players[pid] is old[pid] for pid in (1,2,3,4)),(name,filename,tick,'other action changed')
  action=result.players[0]
  contested=obs.can_kick(0) and any(q.kick_cooldown_ticks==0 and math.dist(q.position,obs.ball.position)<=obs.field.kick_range for q in obs.opponents)
  if contested:
   assert action.kick_direction is None
   assert abs(math.hypot(*action.movement)-1.0)<1e-8 or math.hypot(*obs.my_players[0].velocity)<1e-8
   assert sum(x*y for x,y in zip(action.movement,obs.my_players[0].velocity))<=0
  else:
   assert action.kick_direction is not None
   player=(0,*obs.my_players[0].position,*obs.my_players[0].velocity)
   launch=policy._carrier_contact(player,*obs.ball.position,*policy._requested_velocity(*obs.ball.velocity,(action.kick_direction,action.kick_power)),action.movement)
   assert launch is not None and launch[2]>.5
  assert action is not old[0]
  assert policy._receive_plan is None and policy._receive_aim is None and policy._bank_receive is None and policy._relay_receive is None
  assert math.hypot(*action.movement)<=1.+1e-6
  assert 0.<=action.kick_power<=1.
  reports.append(dict(replay=filename,prestate_tick=tick,enemy_ready_in_range=contested,keeper_replaced=True,kick_suppressed=action.kick_direction is None,other_four_actions_identical=True,stale_keeper_pass_cleared=True,action=action.as_dict()))
 # A safe uncontested keeper action must survive both wrapper layers exactly.
 c=load_controller(str(path));c._fallback._setup(field());p=N(id=0,position=(-47.8,0.),velocity=(0.,0.),kick_cooldown_ticks=0)
 o=N(my_players=[p],opponents=[N(id=5,position=(10.,0.),kick_cooldown_ticks=0)],my_goal=(-50.,0.),field=field(),ball=N(position=(-46.8,0.),velocity=(0.,0.)),can_kick=lambda pid:True)
 old=PlayerAction(movement=(0.,0.),kick_direction=(1.,0.),kick_power=1.);a=TeamAction({0:old});c._unguarded_act=lambda obs:a
 assert c.act(o).players[0] is old
 return dict(recorded_cases=reports,safe_uncontested_action_preserved=True)

def cover_fixture(path):
 c=load_controller(str(path));p=c._fallback;p._setup(field())
 friends=[(0,-48.,0.,0.,0.),(1,-20.,0.,0.,0.),(2,-28.,3.,0.,0.),(3,0.,8.,0.,0.),(4,5.,-8.,0.,0.)]
 enemies=[(5,45.,0.,0.,0.),(6,-30.,6.,0.,0.)]
 o=N(tick=500,ball=N(position=(-30.,6.),controlling_player=6,last_touch=6))
 races={1:(.7,(-30.,6.))};targets={0:(-48.,0.),1:(-30.,6.),2:(-20.,6.),3:(0.,8.),4:(5.,-8.)}
 p._shape_cover_id=2
 original=dict(targets);p._cover_shape(o,friends,enemies,friends[1],races,.1,targets)
 assert targets[2][0] < -30. and targets[2][1] < 6.
 assert all(targets[pid]==original[pid] for pid in (0,1,3,4))
 # The existing guard's live verified reception target wins over new cover.
 targets=dict(original);p._receive_plan=(2,3,510);p._cover_shape(o,friends,enemies,friends[1],races,.1,targets)
 assert targets==original
 return dict(existing_guard_goal_side=True,keeper_chaser_outlets_unchanged=True,live_guard_reception_preserved=True)

if __name__=='__main__':
 manifest=json.loads((ROOT/'combinations-manifest.json').read_text());report=dict(native_matches_run=0,scope='read-only static AST and synthetic public-recorded-state checks; not save or win proof',sources={})
 for name,path in SOURCES.items():
  result=static(name,path);assert result['sha256']==manifest[name]['sha256']
  result['synthetic']=synthetic(name,path)
  if name=='cover-package':result['cover_synthetic']=cover_fixture(path)
  report['sources'][name]=result
 report['passed']=True
 (ROOT/'combinations-audit.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
