# Bounded diagnostic repeats of raw deadline misses

The original `screen-current/matches.jsonl` contains five raw over-20ms decisions in three fixture records. Two are candidate/source-role misses targeted here: baseline seed3260261103, side0, no own kickoff, tick1163 (**33.090139ms**); nearpost same seed/side/kickoff, tick1612 (**26.023922ms**). Three other misses are on opposing roles: clearance-guard fixture seed3260261104 tick322, and nearpost fixture seed3260261103 ticks1761/2298. The original full records remain untouched, and all five remain counted.

Exactly four full native fixtures were repeated, two for each targeted source. Repeat1 passively samples outer `perf_counter_ns` wall time and `thread_time_ns` around the **actual unchanged SDK `runner._decide`** at the selected tick. Repeat2 adds `cProfile` for that single selected decision. All other decisions use the unchanged call. The copied decision/failure loop still reports the original SDK elapsed time to native20ms accounting, retains the prior action on policy error and obeys native termination. No GC/affinity controls, sleeps, timer changes or deadline overrides were used.

| Source / target decision | SDK elapsed, plain | Outer wall, plain | Thread CPU, plain | SDK elapsed, profiled | Thread CPU, profiled |
| --- | ---: | ---: | ---: | ---: | ---: |
| Baseline / tick1163 | 0.097478ms | 0.100993ms | 0.098487ms | 0.333505ms | 0.338924ms |
| Nearpost / tick1612 | 0.954263ms | 0.957888ms | 0.955310ms | 2.505929ms | 2.511845ms |

All four repeats completed 2400ticks with **zero policy exceptions and zero raw deadline misses on either side**. The original long decisions were **not reproduced**. These diagnostic fixtures do not replace original benchmark records or add independent qualification evidence.

## Observed paths

Both selected decisions run ordinary fallback `Pep positional control`; the adaptive specialist is inactive, wall recognition is unconfirmed, and no siege observation exists.

- Baseline tick1163: score1–2, ball(−5.786807,−27.730946), velocity(−25.281107,+3.850351). No live reception contract. Its profiled decision makes9 heuristic `_intercept` calls and one ball trajectory. `_intercept` totals about0.0897ms cumulative; no carrier pass/shoot search dominates this decision.
- Nearpost tick1612: score2–2, ball(+2.130958,−0.401416), velocity(+9.337213,−3.034316). No live reception contract. The carrier decision makes one `_search_links`,9 `_link_option` and9 `_pass_race` calls;24 verified/runtime interception calls arise within those pass alternatives. Profiled link search totals about1.3342ms, pass races0.7833ms, ordinary legacy kick evaluation0.5454ms and controlled touch0.3148ms cumulative. These nested times overlap and must not be summed as disjoint costs. Distinct alternatives are not established duplicate queries.

Wall time tracks thread CPU closely in the **clean repetitions**. That does not determine what happened during the original uninstrumented33ms/26ms calls. Scheduling pauses, GC or other runtime effects remain possible, as does an unreproduced expensive path. There is insufficient evidence to attribute the original failures to the environment or to claim a controller optimization fixed them.

## Evidence

- `diagnose.py`: executed diagnostic harness.
- `summary.json`: exact original slow fixture descriptors plus four repeat outcomes.
- `baseline-repeat{1,2}.json`, `nearpost-repeat{1,2}.json`: source hashes, full native results, all raw misses, selected public observations and controller mode fields, wall/CPU timing.
- `*-repeat2.pstats`: selected-decision profiler output; the JSON lists the40 largest cumulative entries.
- `run.log`: original stdout.

No timing tournaments were run concurrently with these four diagnostic fixtures. Source and opponent hashes match the frozen registrations. All repeats are diagnostic only, and source files were not changed.
