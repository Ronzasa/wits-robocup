# Public-replay reactive opponent surrogate

`team.py` is a compact, legal-action **stress model** fitted to Milla Singh's visible geometry and ball handling. It is **not the leader's source code**, and a native win against this model is not evidence of beating the actual leader. No original source or hidden state is available.

The observed family is a deep goalkeeper, two deeper outfield players, two higher runners, one player selected to chase the predicted ball, repeated low-power touches and occasional full-power releases. The keeper settles 1.8 units ahead of the goal. Deeper players often settle at canonical x=8 and y=±4 when level, or ±5 while ahead. Higher players often settle at x=38, y=±2.5 while ahead. This is not a permanent five-player goal wall.

The many requested ball speeds near 8.2 motivated the model's controlled-touch speed. This is the speed requested by adding kick impulse to the **recorded pre-step ball velocity**, not a guarantee of actual post-contact speed. Native player contacts or intervening actions can change that result. The model intentionally approximates these interactions.

## Fit and validation

The partition and fidelity checks were recorded in `registration.json` before fitting. Seeds1000/1001 supply fitting data; seeds1002/1003 supply the first held-out state-action assessment. Frames are aligned as input state t → movement/kick requests recorded in frame t+1; the latter's movement integrates into the next player velocity. Goal/reset transitions and kickoff phases are excluded.

Training-only coarse search chose defender lag12 and attacker lead18. `fidelity.json` includes all metrics. Held-out movement median angular errors by IDs0..4 are approximately **0.0002°,20.3°,17.0°,17.9°,27.4°**; mean vector errors are **0.136,0.618,0.601,0.544,0.633**. The near-zero keeper angular median mostly reflects its fixed-x vertical movement and does not mean exact goalkeeper behavior.

The public `can_kick` condition overlaps all **377/377 held-out non-kickoff recorded kick requests**. This supports prompt kicking whenever ready and in range. Kick **choices** remain only partly reconstructed: median direction error **35.4°**, mean power error **0.366**. Internal plans, exact lane evaluation, defender assignments and contact-sensitive kick correction are not recovered. Thus this model is useful as an aggressive reactive style, not a high-fidelity digital twin. Action agreement on captured states does not establish closed-loop match strength or predict behavior under unseen states.

Frozen V1 source SHA-256: `43cdff68d4ad3f6ddd04faf5823170f10563f5bccee0659b6c7be7b42edce224`.

## Exploratory kick-response tree

`tree-team.py` is a separate bounded, readable decision-tree surrogate with unchanged V1 movement geometry. It was fitted only on the training matches, after V1's holdout results were inspected; these are exploratory checks on already-exposed holdout matches, not a pristine second validation set. It has eight leaves and public ball/player/nearest-enemy features. The emitted runtime code uses only `math` and `soccer`; scikit-learn is used offline by the fitter only.

It improves held-out mean power error to **0.128**, but worsens direction error to **47.0°** and suppresses most full-power releases: **4** predicted near-full requests versus **71** recorded. This is not a clear overall fidelity improvement and is not recommended over V1 as the main stress style. Keep both to expose model uncertainty, rather than selecting using native tournament outcomes. Detailed metrics and caveats are in `tree-fidelity.json`.

Frozen tree source SHA-256: `460de92a7240f7528cd925696b800c8b5e1903dcbdadc6d5c22919098c563315`.

## Execution status

Both files compile and load through the official SDK. No native match or timed smoke has been run by the model builder, to avoid CPU contention with the central runner's tournaments. Runtime legality and match reliability must therefore be established independently before treating either as a tournament opponent. No competition controller, opponent source, simulator or SDK file was modified.

`characterize.py`, `evaluate.py` and `fit_kicks.py` reproduce the offline characterization and fitting. They require the four sanitized response-body replays under `../replays/`, the complete official SDK on PYTHONPATH, and NumPy/scikit-learn offline. No HAR request headers, cookies or authentication material are read or retained here. `rows.json` is a redundant public-state characterization intermediate; it can be excluded from evidence packaging because the source replays and scripts reproduce it.
