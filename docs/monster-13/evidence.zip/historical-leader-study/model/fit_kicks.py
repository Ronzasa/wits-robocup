"""Training-only bounded public-feature kick-response tree for a surrogate.

Readable emitted decision tree is an approximation, not recovered opponent code.
V1 stays untouched. V2 is exploratory validation after V1 fidelity was inspected.
"""
import json,math,hashlib
from pathlib import Path
import numpy as np
from sklearn.tree import DecisionTreeRegressor
ROOT=Path(__file__).resolve().parent
rows=[]
for path in sorted((ROOT.parent/'replays').glob('*.json')):
 d=json.loads(path.read_text());side=next(i for i,t in enumerate(d['header']['team_ids']) if 'milla' in t);sg=1 if side==0 else -1
 def pair(x):return sg*x['x'],sg*x['y']
 for f,g in zip(d['frames'],d['frames'][1:]):
  if f['score']!=g['score'] or f['kickoff'] is not None:continue
  bx,by=pair(f['ball_position']);vx,vy=pair(f['ball_velocity']);enemy=[pair(f['players'][5*(1-side)+j]['position']) for j in range(5)];ky=enemy[0][1]
  for pid in range(1,5):
   p=f['players'][5*side+pid];a=g['players'][5*side+pid]['action']
   if a['kick_direction'] is None:continue
   px,py=pair(p['position']);pvx,pvy=pair(p['velocity']);ux,uy=pair(a['kick_direction']);power=a['kick_power'];near=min(math.hypot(qx-bx,qy-by) for qx,qy in enemy)
   features=[bx,by,vx,vy,px-bx,py-by,pvx,pvy,near,ky,1. if f['possession_team']==side else 0.]
   rows.append((d['header']['seed'],features,[ux*power,uy*power],(ux,uy),power))
train=[r for r in rows if r[0] in (1000,1001)];test=[r for r in rows if r[0] in (1002,1003)]
# Hyperparameters fixed before this tree's first holdout assessment.
model=DecisionTreeRegressor(max_depth=5,min_samples_leaf=8,random_state=3249102001)
model.fit([r[1] for r in train],[r[2] for r in train]);t=model.tree_
lines=['def learned_impulse(f):']
def emit(i,depth):
 indent='    '*depth
 if t.children_left[i]==t.children_right[i]:
  x,y=t.value[i,:,0];lines.append(indent+'return ('+repr(float(x))+', '+repr(float(y))+')')
 else:
  lines.append(indent+f'if f[{t.feature[i]}] <= {repr(float(t.threshold[i]))}:');emit(t.children_left[i],depth+1)
  lines.append(indent+'else:');emit(t.children_right[i],depth+1)
emit(0,1)
base=(ROOT/'team.py').read_text();start=base.index('     pressure=min(');end=base.index('   if kick is None:',start)
replacement='''     near=min(math.hypot(q.position[0]-bx,q.position[1]-by) for q in enemies)
     px,py=p.position;pvx,pvy=p.velocity
     dx,dy=learned_impulse([bx,by,vx,vy,px-bx,py-by,pvx,pvy,near,keeper.position[1],1. if own else 0.])
     ux,uy=unit(dx,dy);kick=((ux,uy),clip(math.hypot(dx,dy),0.,1.))
'''
base=base[:start]+replacement+base[end:]
base=base.replace("version='public-replay-fit-0.1'","version='public-replay-fit-tree-0.2'")
base+='\n\n'+'\n'.join(lines)+'\n';compile(base,'tree-team.py','exec')
(ROOT/'tree-team.py').write_text(base)
report={'kind':'exploratory public-feature surrogate kick-response tree','source_sha256':hashlib.sha256(base.encode()).hexdigest(),'fit_seeds':[1000,1001],'holdout_seeds':[1002,1003],'max_depth':5,'min_samples_leaf':8,'leaf_count':int(model.get_n_leaves()),'features':['ball_x','ball_y','ball_vx','ball_vy','player_minus_ball_x','player_minus_ball_y','player_vx','player_vy','nearest_enemy_to_ball','enemy_keeper_y','our_possession'],'scope_note':'Kick tree fit only to train. V1 holdout inspected before this exploratory revision; these are not pristine new validation seeds. Movement geometry unchanged from V1; native strength not established.'}
for label,data in [('train',train),('holdout',test)]:
 pred=model.predict([r[1] for r in data]);angles=[];powers=[];vector=[];full=0
 for r,(x,y) in zip(data,pred):
  n=math.hypot(x,y);dot=(x*r[3][0]+y*r[3][1])/max(n,1e-12);angles.append(math.degrees(math.acos(max(-1,min(1,dot)))));powers.append(abs(n-r[4]));vector.append(math.dist((x,y),r[2]));full+=n>=.95
 report[label]=dict(kicks=len(data),direction_median_error_degrees=float(np.median(angles)),power_mean_absolute_error=float(np.mean(powers)),impulse_vector_mean_absolute_error=float(np.mean(vector)),predicted_near_full_power=full,recorded_near_full_power=sum(r[4]>=.95 for r in data))
(ROOT/'tree-fidelity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
