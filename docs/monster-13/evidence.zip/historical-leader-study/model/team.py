"""Reactive Milla-style SURROGATE, not recovered leader code.

Fitted only to public replay seeds 1000/1001. Frozen and assessed on1002/1003.
Its geometry and kick heuristics are intentionally simple; match wins against
this model are not wins against Milla Singh's actual controller.
"""
import math
from soccer import TeamController, TeamAction, PlayerAction

def clip(x,a,b):return max(a,min(b,x))
def unit(x,y):
 d=math.hypot(x,y);return (x/d,y/d) if d>1e-9 else (0.,0.)

class LeaderSurrogate(TeamController):
 name='Milla-style reactive surrogate'
 version='public-replay-fit-0.1'
 # Values below are training-only fits or observed stationary coordinates.
 DEF_LAG=12.0
 ATT_LEAD=18.0
 MOVE_GAIN=1.0
 VELOCITY_BRAKE=0.25
 KEEPER_GAIN=0.2
 DRIBBLE_SPEED=8.2
 POST=6.5
 def reset(self,seed):pass
 def move(self,p,target):
  x,y=p.position;vx,vy=p.velocity
  ax=self.MOVE_GAIN*(target[0]-x)-self.VELOCITY_BRAKE*vx
  ay=self.MOVE_GAIN*(target[1]-y)-self.VELOCITY_BRAKE*vy
  d=max(1.,math.hypot(ax,ay));return ax/d,ay/d
 def forecast(self,obs,t):
  bx,by=obs.ball.position;vx,vy=obs.ball.velocity
  n=t*obs.field.simulation_hz
  drag=obs.field.ball_friction**n
  run=(1-drag)/(1-obs.field.ball_friction)/obs.field.simulation_hz
  x,y=bx+vx*run,by+vy*run
  wall=obs.field.height*.5-obs.field.ball_radius
  for _ in range(4):
   if y>wall:y=2*wall-y
   elif y< -wall:y=-2*wall-y
   else:break
  return clip(x,obs.my_goal[0]+.5,obs.opponent_goal[0]-.5),y
 def act(self,obs):
  bx,by=obs.ball.position;vx,vy=obs.ball.velocity
  friends=list(obs.my_players);outfield=friends[1:]
  predict=self.forecast(obs,.22)
  def eta(p):
   dx,dy=predict[0]-p.position[0],predict[1]-p.position[1]
   d=math.hypot(dx,dy);along=(dx*p.velocity[0]+dy*p.velocity[1])/max(.001,d)
   return max(0,d-2.0)/8.+max(0,1-along/8)*.22
  chaser=min(outfield,key=eta).id
  lead=obs.score[0]>obs.score[1]
  own=obs.ball.controlling_team==0
  targets={}
  defx=clip(bx-self.DEF_LAG,-36.,8.) if own else clip(bx-10.,-36.,-18.)
  ay=2.5 if lead else 7.
  for p in outfield:
   if p.id==chaser:targets[p.id]=predict
   elif p.id in (1,2):targets[p.id]=(defx,(-1 if p.id==1 else 1)*(5. if lead else 4.))
   else:targets[p.id]=(clip(bx+self.ATT_LEAD,-5.,38.),(-ay if p.id==3 else ay))
  gy=clip(by*self.KEEPER_GAIN,-5.6,5.6)
  if vx< -1. and bx< -12.:
   # Friction-aware projected arrival, reflected to legal pitch, bounded horizon.
   t=clip((-48.2-bx)/vx,0.,2.)
   gy=clip(self.forecast(obs,t)[1],-5.6,5.6)
  targets[0]=(obs.my_goal[0]+1.8,gy)
  a=TeamAction()
  enemies=list(obs.opponents)
  keeper=enemies[0]
  for p in friends:
   move=self.move(p,targets[p.id]);kick=None
   if obs.can_kick(p.id):
    if p.id==0:
     ux,uy=unit(1.,-.15*by);kick=((ux,uy),1.)
    else:
     pressure=min(math.hypot(q.position[0]-bx,q.position[1]-by) for q in enemies)
     ygoal=-self.POST if keeper.position[1]>=0 else self.POST
     full=(bx>9. and abs(by)<11.) or (bx< -12. and pressure<3.0)
     if full:
      # Compensate inherited ball velocity while retaining maximum impulse.
      ux,uy=unit(obs.opponent_goal[0]-bx,ygoal-by)
      along=vx*ux+vy*uy;lateral=max(0.,vx*vx+vy*vy-along*along)
      speed=min(30.,along+math.sqrt(max(0.,22.*22.-lateral)))
      dx,dy=ux*speed-vx,uy*speed-vy
     else:
      ux,uy=unit(obs.opponent_goal[0]+2.-bx,clip(-by*.12,-2.,2.)-by)
      dx,dy=ux*self.DRIBBLE_SPEED-vx,uy*self.DRIBBLE_SPEED-vy
     ux,uy=unit(dx,dy);power=clip(math.hypot(dx,dy)/22.,0.,1.)
     kick=((ux,uy),power)
   if kick is None:a.set(p.id,PlayerAction(movement=move))
   else:a.set(p.id,PlayerAction(movement=move,kick_direction=kick[0],kick_power=kick[1]))
  return a
