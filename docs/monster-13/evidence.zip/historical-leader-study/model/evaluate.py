"""Train fixed public geometry parameters, then untouched replay-state holdout."""
import json,math,itertools,hashlib,sys,statistics
from pathlib import Path
from types import SimpleNamespace as NS
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer.helpers import load_controller
model=load_controller(str(ROOT/'team.py'))
field=NS(simulation_hz=20.,ball_friction=.985,height=60.,ball_radius=.45)
rows=[]
for path in sorted((ROOT.parent/'replays').glob('*.json')):
 d=json.loads(path.read_text());side=next(i for i,t in enumerate(d['header']['team_ids']) if 'milla' in t);sg=1 if side==0 else -1
 def pair(x):return sg*x['x'],sg*x['y']
 for f,g in zip(d['frames'],d['frames'][1:]):
  if f['score']!=g['score'] or f['kickoff'] is not None:continue
  def player(i):
   p=f['players'][i];return NS(id=i-5*side if (i//5)==side else i-5*(1-side)+5,position=pair(p['position']),velocity=pair(p['velocity']),kick_cooldown_ticks=p['kick_cooldown_ticks'])
  own=[player(5*side+i) for i in range(5)];enemy=[player(5*(1-side)+i) for i in range(5)]
  b=pair(f['ball_position']);bv=pair(f['ball_velocity']);pos=f['possession_team'];ourpos=None if pos is None else 0 if pos==side else 1
  obs=NS(tick=f['tick'],score=(f['score'][side],f['score'][1-side]),my_players=own,opponents=enemy,ball=NS(position=b,velocity=bv,controlling_team=ourpos),field=field,my_goal=(-50.,0.),opponent_goal=(50.,0.),can_kick=lambda pid,own=own,b=b:own[pid].kick_cooldown_ticks==0 and math.dist(own[pid].position,b)<=2.2)
  actions=[g['players'][5*side+i]['action'] for i in range(5)]
  truth=[dict(move=pair(a['movement']),kick=None if a['kick_direction'] is None else pair(a['kick_direction']),power=a['kick_power']) for a in actions]
  rows.append((d['header']['seed'],obs,truth))
train=[r for r in rows if r[0] in (1000,1001)];holdout=[r for r in rows if r[0] in (1002,1003)]
# Coarse geometry search uses training-only every20th state, movement errors only.
best=None
for dl,al in itertools.product((12.,16.,20.),(8.,12.,18.)):
 model.DEF_LAG=dl;model.ATT_LEAD=al;errors=[]
 for _,obs,truth in train[::20]:
  action=model.act(obs)
  errors.extend(math.dist(action.players[i].movement,truth[i]['move']) for i in range(1,5))
 score=statistics.mean(errors)
 if best is None or score<best[0]:best=(score,dl,al)
model.DEF_LAG=best[1];model.ATT_LEAD=best[2]
# Freeze selected constants in source before holdout metrics.
p=ROOT/'team.py';text=p.read_text().replace('DEF_LAG=16.0',f'DEF_LAG={best[1]}').replace('ATT_LEAD=12.0',f'ATT_LEAD={best[2]}');p.write_text(text)
report={'scope':'Public-observation action fidelity only; not native matchup strength or actual leader code','train_seeds':[1000,1001],'holdout_seeds':[1002,1003],'selected_constants':{'DEF_LAG':best[1],'ATT_LEAD':best[2]},'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'limitation':'Simple geometry and kick heuristic; internal plans, assignments, cooldown races and adaptive branches are not recovered. Actions are next-frame aligned. Replay-state agreement does not validate closed-loop behavior.'}
for label,samples in [('train',train),('holdout',holdout)]:
 errors=[[] for i in range(5)];angular=[[] for i in range(5)];kk=[];tp=fp=fn=0;powers=[]
 for _,obs,truth in samples:
  action=model.act(obs)
  for i in range(5):
   pred=action.players[i];act=truth[i];errors[i].append(math.dist(pred.movement,act['move']))
   if math.hypot(*pred.movement)>.05 and math.hypot(*act['move'])>.05:
    dot=sum(x*y for x,y in zip(pred.movement,act['move']))/(math.hypot(*pred.movement)*math.hypot(*act['move']));angular[i].append(math.degrees(math.acos(max(-1,min(1,dot)))))
   truekick=act['kick'] is not None;predkick=pred.kick_direction is not None
   if truekick and predkick:
    tp+=1;dot=sum(x*y for x,y in zip(pred.kick_direction,act['kick']));kk.append(math.degrees(math.acos(max(-1,min(1,dot)))));powers.append(abs(pred.kick_power-act['power']))
   elif predkick:fp+=1
   elif truekick:fn+=1
 report[label]=dict(frames=len(samples),movement_mean_vector_error_by_pid=[statistics.mean(e) for e in errors],movement_median_angle_error_degrees_by_pid=[statistics.median(e) for e in angular],kick_requests_recorded=tp+fn,kick_requests_model=tp+fp,kick_request_overlap=tp,kick_direction_median_error_degrees=statistics.median(kk),kick_power_mean_absolute_error=statistics.mean(powers))
(ROOT/'fidelity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
