import json,math,collections,statistics
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
rows=[]
for p in sorted((ROOT.parent/'replays').glob('*.json')):
 d=json.loads(p.read_text());seed=d['header']['seed'];side=next(i for i,t in enumerate(d['header']['team_ids']) if 'milla' in t);sg=1 if side==0 else -1
 def v(q):return tuple(sg*q[k] for k in ('x','y'))
 for f,g in zip(d['frames'],d['frames'][1:]):
  if f['score']!=g['score'] or g['tick']!=f['tick']+1:continue
  for pid in range(5):
   own=f['players'][5*side+pid];act=g['players'][5*side+pid]['action'];b=v(f['ball_position']);bv=v(f['ball_velocity']);pos=v(own['position']);vel=v(own['velocity']);move=v(act['movement']);kick=None if act['kick_direction'] is None else v(act['kick_direction'])
   rows.append(dict(seed=seed,side=side,tick=f['tick'],score=(f['score'][side],f['score'][1-side]),pid=pid,ball=b,bv=bv,pos=pos,vel=vel,move=move,kick=kick,power=act['kick_power'],kickoff=f['kickoff'],cooldown=own['kick_cooldown_ticks'],controlled=f['controlled'],possession=f['possession_team'],ourpossession=f['possession_team']==side))
# Save public compact fit rows (source replays retained separately).
(ROOT/'rows.json').write_text(json.dumps(rows))
for partition,seeds in [('train',(1000,1001)),('holdout',(1002,1003))]:
 rr=[r for r in rows if r['seed'] in seeds];print(partition)
 for pid in range(5):
  q=[r for r in rr if r['pid']==pid and r['kickoff'] is None];print('pid',pid,'samples',len(q),'unit',sum(math.hypot(*r['move'])>.999 for r in q)/len(q))
 q=[r for r in rr if r['pid']==0 and r['kickoff'] is None and abs(r['move'][1])<.95 and abs(r['ball'][1])<20 and r['bv'][0]>-1]
 X=np.array([[r['ball'][1],r['pos'][1],r['vel'][1],r['bv'][1],1] for r in q]);Y=np.array([r['move'][1] for r in q]);co,*_=np.linalg.lstsq(X,Y,rcond=None);print('keeper regression',co,'mae',np.mean(abs(X@co-Y)))
 kk=[r for r in rr if r['kick'] is not None];print('kicks',len(kk),'meanpow',statistics.mean(r['power'] for r in kk),'full',sum(r['power']>.999 for r in kk))
 after=[]
 for r in kk:
  vx=r['bv'][0]+22*r['power']*r['kick'][0];vy=r['bv'][1]+22*r['power']*r['kick'][1];after.append(math.hypot(vx,vy))
 print('requested speed distribution',collections.Counter(round(v,1) for v in after).most_common(15))
 print('examples')
 for r in kk[:12]:
  vx=r['bv'][0]+22*r['power']*r['kick'][0];vy=r['bv'][1]+22*r['power']*r['kick'][1]
  print(r['pid'],r['tick'],tuple(round(v,2) for v in r['ball']),tuple(round(v,2) for v in r['kick']),round(r['power'],3),'velocity',round(vx,2),round(vy,2),'goaly',None if abs(vx)<1e-6 else round(r['ball'][1]+(50-r['ball'][0])*vy/vx,2))
