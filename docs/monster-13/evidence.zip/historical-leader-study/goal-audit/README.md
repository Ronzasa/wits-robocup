# Four Milla Singh–Nkqubela Hokwana replay audit

Four complete, faithful replay-format-4 matches, seeds 1000–1003, engine `0.1.0`, config `372990895c7eca2a`. Nkqubela loses all four; aggregate goals **1–10**. These are descriptive replay measurements, not a native test of a newly built counter. The source used for either team is not identified by a code hash; both replay version labels are `1`.

**Critical mapping:** use `header.team_ids` and `frames[*].score`. `recorded.teams` stays in fixture-label order even when the native sides swap. Thus entry05 final native score `[2,1]` is a Milla win, not a user win.

## What actually wins these games

1. **Controlled repeated touches, then a late near-post shot.** Milla has 775 accepted kicks, of which 583 (75.23%) have power below0.35 and119 (15.35%) are full power. There are675 same-player next-kick intervals of exactly5 ticks. Nkqubela has328 accepted kicks,84 (25.61%) below0.35 and125 (38.11%) full power. These are accepted-touch classifications, not inferred pass-completion statistics. The replay does not support describing Milla as an indiscriminate maximum-power clearer.
2. **Large control advantage.** Milla has3318 controlled ticks out of9600 (34.56%), versus710 (7.40%) for Nkqubela. A possession-team phase is distinct from actual controlled-ball status; these counts use `controlled=true`.
3. **Six close shots beat a late keeper.** All six normal Milla goals use a full-power final kick from normalized x46.27–47.39. The goal follows1–4 ticks (0.05–0.20s) later. Every one finishes near a post, with recorded pre-goal |y|5.99–7.14. At the final kick the keeper is1.97–3.81y units away from that later ball lane and there are zero goal-side user outfielders. A reactive ball-velocity target receives very little warning; the defensive failure develops before the final shot.
4. **Four goals are user own-goals.** Three are credited to the user goalkeeper, one to an outfielder. Two observed goalkeeper clearances point away from the goal but leave the native post-contact ball moving toward it. Another own-goal follows simultaneous opposing kicks and a later keeper-body touch. A requested direction alone does not establish a safe clearance.
5. **The user stops mounting attacks at a two-goal deficit.** Four or more user players occupy the home-goal wall for3550 of9600 ticks (36.98%), exclusively while trailing by at least two. There are4085 trailing-by-two ticks, so the wall is occupied for86.90% of that period. In those4085 ticks the user has only33 controlled ticks and55 accepted kicks. This is the same visible footprint as a two-goal-deficit wall policy, but the replay alone does not prove the submitted source.
6. **Milla never builds the packed goal wall.** The leader has zero ticks with four players in its home-goal wall. A wall-pushing counter targets a different opponent behavior from the one that wins these fixtures.

## Every Milla goal

Coordinates below normalize the scoring team to attack the goal at x=+50. `Launch` is the last accepted kick before the goal; for own-goals that may be a defending clearance rather than a Milla shot. Pre-goal y is the last continuous replay position, not an interpolated exact goal-line crossing.

| Replay / seed | Goal tick | Type | Final launch (x,y) | Keeper (x,y) at launch | Last-kick to goal | Goal-side outfielders |
| --- | ---: | --- | --- | --- | ---: | ---: |
| entry-01.json /1000 | 309 | near-post shot | (46.83,-5.22) | (47.51,-2.24) | 2 ticks | 0 |
| entry-01.json /1000 | 648 | near-post shot | (46.58,-7.56) | (47.10,-4.02) | 2 ticks | 0 |
| entry-01.json /1000 | 1008 | keeper own-goal | (49.24,7.35) | (48.85,5.62) | 4 ticks | 0 |
| entry-05.json /1001 | 909 | near-post shot | (46.44,5.31) | (46.42,2.67) | 2 ticks | 0 |
| entry-05.json /1001 | 2260 | near-post shot | (47.39,6.38) | (46.88,3.68) | 1 ticks | 0 |
| entry-08.json /1002 | 270 | near-post shot | (46.27,-11.30) | (47.77,-5.18) | 4 ticks | 0 |
| entry-08.json /1002 | 917 | near-post shot | (46.56,5.70) | (47.80,2.56) | 2 ticks | 0 |
| entry-08.json /1002 | 1691 | outfielder own-goal | (49.62,-6.82) | (48.80,5.60) | 0 ticks | 0 |
| entry-12.json /1003 | 515 | keeper own-goal | (49.52,-7.44) | (47.99,-7.15) | 11 ticks | 0 |
| entry-12.json /1003 | 1547 | keeper own-goal | (49.29,-7.18) | (47.81,-6.45) | 2 ticks | 0 |

## The clearance failures in detail

- **Entry12, tick504 → goal515:** the keeper accepts a full-power almost horizontal kick away from its own right-hand goal. The frame505 native ball velocity is still **(+1.162813,+15.614590)**. It then travels upward along the goal line and crosses for a keeper own-goal. The replay shows the outcome; it does not uniquely separate every contact/collision contribution.
- **Entry12, tick1545 → goal1547:** a keeper kick toward global(−0.807231,−0.590235), power0.832703, produces frame1546 velocity **(+7.964209,+5.761327)** toward its own goal after the native interaction. This is another concrete regression fixture for post-contact clearance safety.
- **Entry01, tick1004 → goal1008:** both user keeper0 and Milla player9 kick in the same tick. The keeper requests(1,0) at full power; Milla requests(−0.423124,+0.906072) at full power. Frame1005 continues toward the user goal. A keeper-body touch at1006 makes the keeper last touch; the goal is credited as an own-goal at1008. A one-kicker forecast cannot certify this exchange.
- **Entry08, tick1691:** user outfielder4 requests a full-power forward clearance in the same tick as the goal. The keeper and other outfielders are in the home wall. Native goal attribution is to outfielder4 as an own-goal. The precise final trajectory is reset in the next frame, so the replay should not be used to invent unrecorded post-clearance coordinates.

## Why I believe a counter is plausible

Milla is not invulnerable: Nkqubela scores a normal near-post goal in entry05 at tick1181. The final user kick is at1173 from normalized(41.56,2.94); the leader keeper starts at(48.05,0.88), and the ball reaches pre-goal y6.28 eight ticks later. This is evidence of a real scoring route, not proof that a new controller wins the matchup.

The most grounded interventions to test independently are:

1. **Remove the two-goal-deficit surrender behavior.** Continue contesting midfield and executing normal attack/reception plans while behind. Preserve kickoff protection. The parent should test this single policy switch before combining changes.
2. **Anticipate an opponent controlled dribble near the post.** At carrier x35–43, position the designated cover goal-side and let the keeper cover the threatened post early. Test lateral control and approach momentum; do not wait for a25–29-speed shot at x46–47. Keep the central corridor protected when the carrier is central and avoid universal deep cover.
3. **Make goalkeeper clearances execution-aware.** Check actual post-move kick range, kick impulse plus incoming velocity, goalkeeper/body contact and plausible same-tick opponent kicks before approving a clearance. Preserve the replay scenes above as focused regression inputs. Do not assume reducing power alone fixes the geometry.
4. **Attack the moment the leader is collecting its next soft touch.** Its regular five-tick repeat interaction and low-power possession pattern create a predictable next collection point. Any presser change should use actual reachable movement and leave one goal-side covering player.
5. **Preserve a near-post scoring option in transition.** The single user goal proves one route past Milla's keeper. Improve collectible advances and retain shots into visible post gaps; merely adding more maximum-power kicks would copy the wrong part of the leader's behavior.

These are hypotheses for native testing against transparent opponent models. Replays contain outputs from four fixed trajectories; they do not expose the opponent's decision function in new states. A frozen-action replay is not an adaptive opponent and a fitted model is not the original source. Winning such a model cannot establish a live win against Milla.

## Integrity and limitations

- All four replays have2401 contiguous frames,2400 played ticks, `faithful=true` and no forfeit. There are no per-decision timings, so 20ms compliance or policy-exception counts cannot be inferred from these files.
- All five recorded kick rejections belong to Milla and say `out_of_range`; there is no observed `on_cooldown` spam pattern. Both recorded fouls also belong to Milla player9 (entry08 ticks975 and1748). User fouls and kick rejections are zero in these records.
- Side-wall/end-wall bounces occur in the buildup. None of the six normal leader goals needs a wall bounce after its final full-power kick; each last launch is a direct finishing sequence. Earlier bounces do not establish an intentional wall-pass policy.
- The `goal-clips.json` scenes are observed public replay inputs and actions, not permission to inject arbitrary state into the native simulator. `analyze_replay.py` also emits candidate body contacts and kinematically matching wall reflections; those are labeled diagnostics, not authoritative private collision events.
- No raw HAR, request headers, cookies, account tokens or private table data are included in this audit directory. Sanitized public replay response bodies are the only inputs.

## Reproduce

Run `python goal-audit/analyze_replay.py replays/entry-01.json --out goal-audit/entry-01-analysis.json` for each replay, using new output paths if those already exist. Then run `python goal-audit/summarize.py` and `python goal-audit/report.py`. The reports, goal table and short goal clips are deterministic products of the four sanitized response bodies.
