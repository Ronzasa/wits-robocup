"""Read-only v4 native replay audit. All team IDs and positions remain explicit."""
import argparse
from collections import Counter,defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics


def point(v):return v['x'],v['y']
def length(v):return math.hypot(v['x'],v['y'])
def quantile(values,q):
    values=sorted(values);return values[min(len(values)-1,int((len(values)-1)*q))] if values else None
def desc(values):return {'count':len(values),'mean':statistics.mean(values) if values else None,'median':statistics.median(values) if values else None,'p10':quantile(values,.1),'p90':quantile(values,.9),'max':max(values) if values else None}
def angle(v):return math.degrees(math.atan2(v['y'],v['x']))
def grid(angles):return {str(step):sum(abs(a/step-round(a/step))*step<.001 for a in angles)/len(angles) if angles else None for step in (.25,.5,1.,2.,5.,10.,45.,90.)}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('replay',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args();assert not a.out.exists()
    raw=a.replay.read_bytes();d=json.loads(raw);h=d['header'];fs=d['frames'];events=d['events'];cfg=h['config'];dt=1/cfg['match']['simulation_hz'];hz=1/dt
    ids=[p['id'] for p in h['initial_roster']];idx={pid:i for i,pid in enumerate(ids)};owners={p['id']:p['team'] for p in h['initial_roster']};frames={f['tick']:f for f in fs}
    assert len(fs)==d['total_frames']==2401 and [f['tick'] for f in fs]==list(range(2401))
    assert all(len(f['players'])==10 for f in fs)
    kicks=[e for e in events if e['kind']=='kick'];goal_events=[e for e in events if e['kind']=='goal']
    mapping={}
    for offset in (0,1):
        matches=0
        for e in kicks:
            cmd=frames.get(e['tick']+offset,{}).get('players',[{}]*10)[idx[e['player']]].get('action')
            if cmd and cmd.get('kick_direction') is not None and max(abs(cmd['kick_direction'][k]-e['direction'][k]) for k in ('x','y'))<.0001 and abs(cmd['kick_power']-e['power'])<.0001:matches+=1
        mapping[str(offset)]=matches
    offset=max((0,1),key=lambda n:mapping[str(n)])
    records=[];team_stats=[]
    for side in (0,1):
        sign=1 if side==0 else -1;own=[i for i,pid in enumerate(ids) if owners[pid]==side];outfield=own[1:];keeper=own[0]
        ownk=[e for e in kicks if e['team']==side];cmds=[p['action'] for f in fs[1:] for i,p in enumerate(f['players']) if i in own and p.get('action')]
        moving=[c for c in cmds if length(c['movement'])>.01]
        width=[];nearest=[];crowd=[];depth=[];keeper_y=[];player_stats={};control_ticks=0;controlled_handoffs=0;last_holder=None
        for f in fs[:-1]:
            ps=f['players'];b=point(f['ball_position']);width.append(max(ps[i]['position']['y'] for i in outfield)-min(ps[i]['position']['y'] for i in outfield))
            nearest.append(min(math.dist(point(ps[i]['position']),b) for i in outfield));crowd.append(sum(math.dist(point(ps[i]['position']),b)<=5 for i in outfield))
            depth.append(50+sign*ps[keeper]['position']['x']);keeper_y.append(abs(ps[keeper]['position']['y']))
            if f['controlled'] and f['possession_team']==side:
                control_ticks+=1
                if last_holder is not None and f['possession_player']!=last_holder:controlled_handoffs+=1
                last_holder=f['possession_player']
        for i in own:
            commands=[f['players'][i]['action'] for f in fs[1:] if f['players'][i]['action']]
            ang=[angle(c['movement']) for c in commands if length(c['movement'])>.01]
            player_stats[str(ids[i])]={'kick_count':sum(e['player']==ids[i] for e in ownk),
                'controlled_ticks':sum(f['controlled'] and f['possession_player']==ids[i] for f in fs[:-1]),
                'movement_full_throttle_fraction':sum(length(c['movement'])>.999 for c in commands)/len(commands),
                'movement_angle_grid_fraction':grid(ang),'most_common_rounded_headings':Counter(round(x,2) for x in ang).most_common(8),
                'attack_x':desc([sign*f['players'][i]['position']['x'] for f in fs[:-1]]),
                'speed':desc([length(f['players'][i]['velocity']) for f in fs[:-1]])}
        kick_details=[]
        for e in ownk:
            f=frames[e['tick']];after=frames[e['tick']+1];q=f['players'][idx[e['player']]];post=after['players'][idx[e['player']]]
            bx,by=point(f['ball_position']);sx,sy=point(after['ball_position']);vx,vy=point(f['ball_velocity']);pspeed=length(post['velocity'])
            kd={'tick':e['tick'],'seconds':e['tick']/hz,'player':e['player'],'attack_ball':[sign*bx,sign*by],
                'power':e['power'],'kick_direction_global':point(e['direction']),
                'ball_speed_before':math.hypot(vx,vy),'ball_speed_after':length(after['ball_velocity']),
                'postmove_gap_to_preball':math.dist(point(post['position']),(bx,by)),
                'relative_speed_before':math.hypot(vx-q['velocity']['x'],vy-q['velocity']['y']),
                'opponent_distance':min(math.dist(point(f['players'][j]['position']),(bx,by)) for j in range(10) if j not in own),
                'goal_ward_component':sign*e['direction']['x'],
                'future_same_kicker':None}
            later=next((x for x in ownk if x['player']==e['player'] and x['tick']>e['tick']),None)
            if later:kd['future_same_kicker']=later['tick']-e['tick']
            kick_details.append(kd)
        groups=Counter(e['tick'] for e in ownk)
        stats={'side':side,'team':h['team_ids'][side],'visible_goals':fs[-1]['score'][side],
            'accepted_kicks':len(ownk),'requested_kicks':sum(c['kick_direction'] is not None and c['kick_power']>0 for c in cmds),
            'accepted_power_counts':dict(Counter(round(e['power'],3) for e in ownk)),
            'controlled_ticks':control_ticks,'controlled_share_all_ticks':control_ticks/2400,
            'phase_possession_ticks':sum(f['possession_team']==side for f in fs[:-1]),
            'ball_in_attacking_half_fraction':sum(sign*f['ball_position']['x']>0 for f in fs[:-1])/2400,
            'outfield_width':desc(width),'nearest_outfielder_to_ball':desc(nearest),
            'mean_outfielders_within5':statistics.mean(crowd),'keeper_depth_from_goal':desc(depth),'keeper_absolute_y':desc(keeper_y),
            'kick_gap_ticks':desc([b['tick']-a['tick'] for a,b in zip(ownk,ownk[1:])]),
            'same_player_five_tick_repeats':sum(k['future_same_kicker']==5 for k in kick_details),
            'simultaneous_same_team_kick_frames':{str(k):v for k,v in groups.items() if v>1},'players':player_stats,'kicks':kick_details}
        team_stats.append(stats)
    wall_witnesses=[];body_candidates=[];motion_matches=0;motion_total=0;max_clean_ball_error=0;clean_flights=0
    kick_ticks={e['tick'] for e in kicks}
    for old,new in zip(fs,fs[1:]):
        for i,(p,q) in enumerate(zip(old['players'],new['players'])):
            cmd=q['action']
            if not cmd:continue
            vx=p['velocity']['x']*.9+cmd['movement']['x'];vy=p['velocity']['y']*.9+cmd['movement']['y'];speed=math.hypot(vx,vy)
            if speed>8:vx*=8/speed;vy*=8/speed
            x=max(-49,min(49,p['position']['x']+vx*dt));y=max(-29,min(29,p['position']['y']+vy*dt))
            err=max(abs(x-q['position']['x']),abs(y-q['position']['y']),abs(vx-q['velocity']['x']),abs(vy-q['velocity']['y']))
            motion_total+=1;motion_matches+=err<.002
        if old['score']!=new['score'] or old['tick'] in kick_ticks:continue
        x,y=point(old['ball_position']);vx,vy=point(old['ball_velocity']);x+=vx*dt;y+=vy*dt;walls=[]
        if abs(y)>29.55:
            s=1 if y>0 else -1;y=s*59.1-y;vy=-s*abs(vy)*.75;walls.append('side')
        if abs(x)>49.55:
            if abs(y)<=7:continue
            s=1 if x>0 else -1;x=s*99.1-x;vx=-s*abs(vx)*.75;walls.append('end')
        expected=(x,y,vx*.985,vy*.985);actual=(*point(new['ball_position']),*point(new['ball_velocity']))
        err=max(abs(a-b) for a,b in zip(expected,actual))
        if err<.003:
            clean_flights+=1;max_clean_ball_error=max(max_clean_ball_error,err)
            if walls:wall_witnesses.append({'tick':old['tick'],'kind':walls,'ball_before':[*point(old['ball_position']),*point(old['ball_velocity'])],'ball_after':list(actual)})
        elif new['ball_last_touch'] is not None:
            pid=new['ball_last_touch'];q=new['players'][idx[pid]];gap=math.dist(point(new['ball_position']),point(q['position']))
            if abs(gap-1.45)<.005:body_candidates.append({'tick':old['tick'],'player':pid,'team':owners[pid],'gap':gap,'speed_before':length(old['ball_velocity']),'speed_after':length(new['ball_velocity'])})
    goals=[]
    for e in goal_events:
        f=frames[e['tick']];side=e['team'];sign=1 if side==0 else -1
        prior=[x for x in kicks if e['tick']-160<=x['tick']<=e['tick']]
        last=prior[-1] if prior else None
        score_at=next(x['tick'] for x in fs if x['tick']>=e['tick'] and x['score'][side]>f['score'][side])
        goals.append({'event':e,'seconds':e['tick']/hz,'score_changes_frame':score_at,'ball_pre_goal':[*point(f['ball_position']),*point(f['ball_velocity'])],
            'last_kick':last,'last_kick_seconds_before_goal':(e['tick']-last['tick'])/hz if last else None,
            'preceding8s_kicks':prior,'preceding8s_verified_wall_bounces':[x for x in wall_witnesses if e['tick']-160<=x['tick']<=e['tick']],
            'preceding8s_body_candidates':[x for x in body_candidates if e['tick']-160<=x['tick']<=e['tick']]})
    out={'input':str(a.replay),'sha256':hashlib.sha256(raw).hexdigest(),'header':h,'recorded_metadata':d.get('recorded'),
        'visible_final_score':fs[-1]['score'],'frames':len(fs),'contiguous':True,'events':dict(Counter(e['kind'] for e in events)),
        'action_frame_offset_matches':mapping,'accepted_kick_events':len(kicks),'chosen_action_frame_offset':offset,
        'motion_recurrence_matches':motion_matches,'motion_recurrence_samples':motion_total,
        'unperturbed_ball_flight_steps':clean_flights,'clean_ball_max_error':max_clean_ball_error,
        'teams':team_stats,'goals':goals,'verified_wall_bounces':wall_witnesses,'body_contact_candidates':body_candidates}
    a.out.write_text(json.dumps(out,indent=2)+'\n')
    for t in team_stats:
        print(t['team'],'goals',t['visible_goals'],'kicks',t['accepted_kicks'],'powers',t['accepted_power_counts'],'controlledticks',t['controlled_ticks'],'width',round(t['outfield_width']['mean'],2),'keeperdepth',round(t['keeper_depth_from_goal']['mean'],2),'stacked',t['simultaneous_same_team_kick_frames'])
    print('Goal summaries',json.dumps(goals,indent=2))
    print('Action mapping',mapping,'motion matches',motion_matches,motion_total,'walls',len(wall_witnesses),'contacts',len(body_candidates))

if __name__=='__main__':main()
