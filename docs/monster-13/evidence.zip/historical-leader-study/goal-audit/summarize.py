"""Recompute goal/role evidence from sanitized public replay response bodies.

No controller/source attribution, hidden state, native injections or competitions.
Raw HAR request headers/cookies are deliberately never read here.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,math,statistics,csv
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent

def xy(q):return (q['x'],q['y'])
def mag(q):return math.hypot(q['x'],q['y'])
def normalized(q,sign):return [sign*q['x'],sign*q['y']]
def role_side(header,text):return next(i for i,t in enumerate(header['team_ids']) if text in t)
def scalar_summary(v):return dict(count=len(v),mean=statistics.mean(v) if v else None,median=statistics.median(v) if v else None,max=max(v) if v else None)
def rows_for_team(d,side):
 h=d['header'];fs=d['frames'];ids={x['id']:i for i,x in enumerate(h['initial_roster'])};sign=1 if side==0 else -1
 members=[p['id'] for p in h['initial_roster'] if p['team']==side];outfield=members[1:]
 kicks=[e for e in d['events'] if e['kind']=='kick' and e['team']==side]
 next_same=[b['tick']-a['tick'] for pid in members for a,b in zip([e for e in kicks if e['player']==pid],[e for e in kicks if e['player']==pid][1:])]
 wall=[];control=0;td=0;tdwall=0;post2control=0;post2kicks=0;positions=[];after_speed=[]
 for f in fs[:-1]:
  own=[f['players'][ids[p]] for p in members]
  packed=sum(sign*p['position']['x']<-47.0 and abs(p['position']['y'])<9.0 for p in own)>=4
  down=f['score'][1-side]-f['score'][side]>=2
  if packed:wall.append(f['tick'])
  control+=bool(f['controlled'] and f['possession_team']==side)
  td+=down;tdwall+=down and packed
  post2control+=bool(down and f['controlled'] and f['possession_team']==side)
 for e in kicks:
  if e['power']<.35:after_speed.append(mag(fs[e['tick']+1]['ball_velocity']))
  if fs[e['tick']]['score'][1-side]-fs[e['tick']]['score'][side]>=2:post2kicks+=1
 return dict(team=h['team_ids'][side],side=side,goals=fs[-1]['score'][side],accepted_kicks=len(kicks),soft_below_point35=sum(e['power']<.35 for e in kicks),full_power=sum(e['power']>.999 for e in kicks),power_sum=sum(e['power'] for e in kicks),same_player_five_tick_repeats=sum(g==5 for g in next_same),controlled_ticks=control,wall_ticks=len(wall),trailing_by_two_ticks=td,wall_while_trailing_by_two=tdwall,controlled_while_trailing_by_two=post2control,kicks_while_trailing_by_two=post2kicks,keeper_kicks=sum(e['player']==members[0] for e in kicks),fouls=sum(e['kind']=='foul' and e['team']==side for e in d['events']),kick_rejections=dict(Counter(e.get('reason') for e in d['events'] if e['kind']=='kick_rejected' and e['team']==side)),soft_kick_ball_speed_after=scalar_summary(after_speed))

def goal_row(d,p,e):
 h=d['header'];fs={f['tick']:f for f in d['frames']};ids={q['id']:i for i,q in enumerate(h['initial_roster'])};side=e['team'];defender=1-side;sign=1 if side==0 else -1
 keeper=next(q['id'] for q in h['initial_roster'] if q['team']==defender)
 accepted=[v for v in d['events'] if v['kind']=='kick' and v['tick']<=e['tick']]
 last=accepted[-1];own=[v for v in accepted if v['team']==defender]
 final=fs[e['tick']];launch=fs[last['tick']]
 snapshots=[]
 for tick in sorted(set([max(0,e['tick']-20),max(0,e['tick']-12),last['tick'],last['tick']+1,max(0,e['tick']-1),e['tick']])):
  f=fs[tick];gk=f['players'][ids[keeper]]
  snapshots.append(dict(tick=tick,ball=normalized(f['ball_position'],sign),ball_velocity=normalized(f['ball_velocity'],sign),ball_last_touch=f['ball_last_touch'],keeper=normalized(gk['position'],sign),keeper_velocity=normalized(gk['velocity'],sign),keeper_action=gk['action']))
 f=fs[last['tick']];gk=f['players'][ids[keeper]]
 outfield=[f['players'][ids[q['id']]] for q in h['initial_roster'] if q['team']==defender and q['id']!=keeper]
 result=dict(replay=p.name,seed=h['seed'],tick=e['tick'],seconds=e['tick']/20,scoring_team=h['team_ids'][side],scorer=e['scorer'],own_goal=e['own_goal'],keeper_id=keeper,last_kick=last,ticks_from_last_kick_to_goal=e['tick']-last['tick'],ball_at_last_kick=normalized(f['ball_position'],sign),keeper_at_last_kick=normalized(gk['position'],sign),keeper_y_difference_to_pre_goal_ball=abs(gk['position']['y']-final['ball_position']['y']),goal_side_outfielders_at_last_kick=sum(sign*q['position']['x']>=sign*f['ball_position']['x'] for q in outfield),pre_goal_ball=normalized(final['ball_position'],sign),pre_goal_ball_velocity=normalized(final['ball_velocity'],sign),last_defending_kick=own[-1] if own else None,context=snapshots)
 if own:
  k=own[-1];post=fs[k['tick']+1]
  result['after_last_defending_kick']=dict(tick=k['tick']+1,ball=normalized(post['ball_position'],sign),velocity=normalized(post['ball_velocity'],sign),last_touch=post['ball_last_touch'])
 return result

def main():
 matches=[];goals=[];clips=[]
 for p in sorted((ROOT/'replays').glob('*.json')):
  d=json.loads(p.read_text());h=d['header'];own=role_side(h,'hokwana');leader=role_side(h,'milla-singh')
  assert len(d['frames'])==2401 and all(f['tick']==i for i,f in enumerate(d['frames']))
  assert h['config_hash']=='372990895c7eca2a' and d['recorded']['faithful'] is True and d['recorded']['forfeit_by'] is None
  matches.append(dict(replay=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seed=h['seed'],kickoff_team=h['kickoff_team'],header_team_ids=h['team_ids'],recorded_teams=d['recorded']['teams'],actual_final_score=d['frames'][-1]['score'],user=rows_for_team(d,own),leader=rows_for_team(d,leader)))
  for e in d['events']:
   if e['kind']=='goal':
    row=goal_row(d,p,e);goals.append(row)
    clips.append(dict(replay=p.name,seed=h['seed'],event=e,team_ids=h['team_ids'],initial_roster=h['initial_roster'],frames=d['frames'][max(0,e['tick']-24):e['tick']+2],events=[v for v in d['events'] if e['tick']-24<=v['tick']<=e['tick']]))
 totals={}
 numeric=['goals','accepted_kicks','soft_below_point35','full_power','power_sum','same_player_five_tick_repeats','controlled_ticks','wall_ticks','trailing_by_two_ticks','wall_while_trailing_by_two','controlled_while_trailing_by_two','kicks_while_trailing_by_two','keeper_kicks','fouls']
 for label in ('user','leader'):
  total={k:sum(m[label][k] for m in matches) for k in numeric};total['kick_rejections']={}
  for m in matches:
   for k,v in m[label]['kick_rejections'].items():total['kick_rejections'][k]=total['kick_rejections'].get(k,0)+v
  total.update(controlled_fraction=total['controlled_ticks']/9600,mean_accepted_power=total['power_sum']/total['accepted_kicks'],soft_fraction=total['soft_below_point35']/total['accepted_kicks'],full_power_fraction=total['full_power']/total['accepted_kicks'])
  totals[label]=total
 leader_goals=[g for g in goals if 'milla-singh' in g['scoring_team']]
 summary=dict(scope='Four descriptive, faithful public replays. No exact-source attribution, independent native qualification or private opponent controller.',matches=matches,totals=totals,leader_goal_counts=dict(total=len(leader_goals),normal=sum(not g['own_goal'] for g in leader_goals),opponent_own_goals=sum(g['own_goal'] for g in leader_goals),keeper_own_goals=sum(g['own_goal'] and g['scorer']==g['keeper_id'] for g in leader_goals)),goals=goals,limitations=['Team version labels are 1; no submitted-source hash.','recorded.teams is fixture-label order; header.team_ids and frames.score define simulation sides.','No per-decision durations, policy debug plans or exact opponent code.','Kick powers are not pass labels; pass completion is not inferred.','Pre-goal ball position is not an exact measured goal-line crossing.','Wall/body matches from analyze_replay.py are kinematic diagnostics, not private engine event disclosures.'])
 (OUT/'findings.json').write_text(json.dumps(summary,indent=2)+'\n')
 (OUT/'goal-clips.json').write_text(json.dumps(clips,indent=2)+'\n')
 with (OUT/'goals.csv').open('w',newline='') as f:
  fields=['replay','seed','tick','seconds','scoring_team','scorer','own_goal','keeper_id','ticks_from_last_kick_to_goal','ball_at_last_kick','keeper_at_last_kick','keeper_y_difference_to_pre_goal_ball','goal_side_outfielders_at_last_kick','pre_goal_ball','pre_goal_ball_velocity']
  writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows({k:g[k] for k in fields} for g in goals)
 print(json.dumps(dict(totals=totals,leader_goal_counts=summary['leader_goal_counts']),indent=2))
if __name__=='__main__':main()
