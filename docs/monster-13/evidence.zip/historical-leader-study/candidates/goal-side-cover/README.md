# Isolated goal-side counter cover

Frozen input: `../baseline/team.py`, SHA-256 `27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce`.

Candidate: `team.py`, SHA-256 `3263b946869dbd1feb14d128b7de2d2cf6adb2ac5e22818f2cd21e3d3a4e2b86`.

Only `_FallbackPolicy._cover_shape` changes. The builder parses the frozen input, inserts one conditional branch, and verifies that replacing that method back restores the exact AST of the complete original file. Specialist policy, scoring locks, all movement/pass/shot methods and wrapper behavior remain unchanged.

The replay hypothesis is that the existing guard follows only two to three units behind a dangerous ball and the current cover adjustment merely changes lateral position for wide balls. A modest extra goal-side distance may intercept the path toward the near post before a fast close-range shot becomes a goalkeeper emergency. This is a hypothesis, not a demonstrated competitive gain.

The override applies when:

- The original controller does not regard possession as secure.
- The ball has canonical x below 8.
- An enemy is the public ball holder, or an enemy is within 3.2 units and its ball-arrival estimate is within 0.2 seconds of the primary chaser.

It moves only the already designated covering outfield player to ball x minus 8, clamped by the standard field-derived movement boundaries. Its y coordinate lies on the line from own goal centre to the current ball. It never chooses a second defender. The goalkeeper, primary chaser and other two outfield targets are untouched, preserving their existing outlet opportunities. A guard with a live reception/relay/tactical-reception contract is not retargeted.

There is no temporal latch or extra state: secure possession or an absent threat immediately falls back to the original cover rule on the next decision. The old wide-cover behavior outside the new threat zone is retained. Complexity is O(players), with no trajectory sampling, searches or extra rollouts.

Nine synthetic arbitration tests passed, covering the goal-side assignment, exactly one changed target, immediate recovery on secure possession/threat disappearance, all three live plan types at the expiry boundary, expired plans, keeper/chaser exclusion, preserved legacy behavior outside the zone, loose-ball race filtering, and a nonstandard field bound case.

The first synthetic test run failed because its fake FieldView omitted `player_radius`; adding that required fixture attribute fixed the harness. No candidate code was changed in response.

Run `python build.py` to regenerate the candidate and `python test_cover.py` to rerun synthetic checks, with the complete SDK available. The scripts use the existing absolute study paths and do not write to the repository's active submission. No native matches, deadline timing or promotion are claimed by this build.
