"""Synthetic target-arbitration tests only. No native matches or timings."""
import json,math,sys,unittest
from pathlib import Path
from types import SimpleNamespace as N
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer.helpers import load_controller
ROOT=Path(__file__).resolve().parent

def field(left=-50.,right=50.,height=60.):
 return N(simulation_hz=20,max_speed=8.,acceleration=20.,ball_friction=.985,kick_impulse=22.,kick_range=2.2,my_goal=(left,0.),opponent_goal=(right,0.),height=height,goal_width=14.,centre_circle_radius=9.15,player_radius=1.,ball_radius=.45)

class Cover(unittest.TestCase):
 def setUp(self):
  self.new=load_controller(str(ROOT/'team.py'))._fallback
  self.old=load_controller(str(ROOT.parent/'baseline/team.py'))._fallback
  for s in (self.new,self.old):s._setup(field());s._shape_cover_id=2
  self.friends=[(0,-47.,0.,0.,0.),(1,-11.,3.,0.,0.),(2,-13.,6.,0.,0.),(3,0.,-12.,0.,0.),(4,5.,14.,0.,0.)]
  self.chaser=self.friends[1];self.races={p[0]:(.5,(0.,0.)) for p in self.friends}
  self.opponents=[(5,45.,0.,0.,0.),(6,-11.5,4.,0.,0.),(7,0.,5.,0.,0.),(8,10.,-10.,0.,0.),(9,12.,12.,0.,0.)]
  self.obs=N(tick=100,ball=N(position=(-12.,4.),controlling_player=6,last_touch=6),score=(0,0))
 def targets(self):return {0:(-47.8,0.),1:(-12.,4.),2:(-14.,8.),3:(0.,-12.),4:(5.,14.)}
 def runcover(self,s,targets,eta=.1):
  s._cover_shape(self.obs,self.friends,self.opponents,self.chaser,self.races,eta,targets)
 def test_moves_only_existing_guard_goal_side(self):
  before=self.targets();after=before.copy();self.runcover(self.new,after)
  self.assertEqual([k for k in after if after[k]!=before[k]],[2])
  self.assertAlmostEqual(after[2][0],-20.)
  self.assertAlmostEqual(after[2][1],4.*30./38.)
  self.assertLess(after[2][0],self.obs.ball.position[0])
  self.assertEqual([after[i] for i in (0,1,3,4)],[before[i] for i in (0,1,3,4)])
 def test_returns_immediately_for_secure_possession(self):
  threatened=self.targets();self.runcover(self.new,threatened)
  self.obs.ball.controlling_player=1;self.obs.ball.last_touch=1
  expected=self.targets();actual=self.targets();self.runcover(self.old,expected);self.runcover(self.new,actual)
  self.assertEqual(actual,expected);self.assertEqual(actual,self.targets())
 def test_returns_immediately_when_enemy_leaves(self):
  threatened=self.targets();self.runcover(self.new,threatened)
  self.obs.ball.controlling_player=None;self.obs.ball.last_touch=None
  self.opponents=[(5,40.,0.,0.,0.)]
  actual=self.targets();self.runcover(self.new,actual,eta=2.)
  self.assertEqual(actual,self.targets())
 def test_protects_each_live_reception_contract_including_expiry(self):
  for attr in ('_receive_plan','_relay_receive','_x_reception'):
   for s in (self.new,):
    for a in ('_receive_plan','_relay_receive','_x_reception'):setattr(s,a,None)
    setattr(s,attr,(2,4,100,(0.,0.)) if attr=='_x_reception' else (2,4,100))
    after=self.targets();self.runcover(s,after);self.assertEqual(after,self.targets(),attr)
 def test_expired_plan_does_not_block_recovery_cover(self):
  self.new._receive_plan=(2,4,99)
  after=self.targets();self.runcover(self.new,after);self.assertEqual(after[2][0],-20.)
 def test_never_uses_keeper_or_chaser_as_new_cover(self):
  for guard in (None,0,1):
   self.new._shape_cover_id=guard;after=self.targets();self.runcover(self.new,after);self.assertEqual(after,self.targets())
 def test_outside_threat_zone_retains_original_wide_cover_rule(self):
  self.obs.ball.position=(10.,20.);self.opponents=[(6,10.2,20.,0.,0.)]
  actual=self.targets();expected=self.targets();self.runcover(self.new,actual);self.runcover(self.old,expected)
  self.assertEqual(actual,expected)
 def test_loose_ball_requires_close_enemy_race(self):
  self.obs.ball.controlling_player=None;self.obs.ball.last_touch=None
  after=self.targets();self.runcover(self.new,after,eta=.1);self.assertEqual(after[2][0],-20.)
  after=self.targets();self.runcover(self.new,after,eta=1.0);self.assertEqual(after,self.targets())
 def test_respects_field_derived_bounds(self):
  self.new._setup(field(-60.,60.,40.));self.new._shape_cover_id=2
  self.obs.ball.position=(-55.,19.);self.opponents=[(6,-54.,19.,0.,0.)]
  after=self.targets();self.runcover(self.new,after)
  self.assertGreaterEqual(after[2][0],-58.);self.assertLessEqual(after[2][0],58.)
  self.assertLessEqual(abs(after[2][1]),18.)

if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Cover))
 payload=dict(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),passed=result.wasSuccessful(),scope='Synthetic target arbitration; no native matches or timing evidence')
 (ROOT/'tests.json').write_text(json.dumps(payload,indent=2)+'\n')
 raise SystemExit(not result.wasSuccessful())
