"""Build one isolated goal-side cover change from the frozen current baseline."""
from pathlib import Path
import ast,hashlib,json
ROOT=Path('/workspace/work/div6-leader-20261026')
SOURCE=ROOT/'candidates/baseline/team.py'
DEST=Path(__file__).resolve().parent
FROZEN='27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce'
raw=SOURCE.read_bytes();assert hashlib.sha256(raw).hexdigest()==FROZEN
source=raw.decode();tree=ast.parse(source)
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='_FallbackPolicy')
method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_cover_shape')
lines=source.splitlines(keepends=True)
original=''.join(lines[method.lineno-1:method.end_lineno])
anchor='''        if secure or abs(by) < 12.0 or pressure > 5.0:
'''
assert original.count(anchor)==1
insert='''        # Counter cover: move only the existing guard, never add a defender.
        # This public-state condition is reevaluated each tick; no recovery latch.
        enemy_has_ball = any(o[0] == obs.ball.controlling_player for o in opponents)
        counter_threat = (not secure and bx < 8.0 and
                          (enemy_has_ball or
                           (pressure <= 3.2 and races[chaser[0]][0] + 0.2 >= enemy_eta)))
        if counter_threat:
            guard_id = self._shape_cover_id
            if guard_id in (None, 0, chaser[0]) or guard_id not in targets:
                return
            # Reception was verified earlier in act(); preserve its target.
            for plan in (self._receive_plan, self._relay_receive, self._x_reception):
                if plan is not None and plan[0] == guard_id and plan[2] >= obs.tick:
                    return
            tx, _ = self._target(bx - 8.0, 0.0)
            fraction = _clip((tx - self._left) / max(0.001, bx - self._left), 0.0, 1.0)
            targets[guard_id] = self._target(tx, by * fraction)
            return
'''
replacement=original.replace(anchor,insert+anchor)
result=''.join(lines[:method.lineno-1])+replacement+''.join(lines[method.end_lineno:])
compile(result,'team.py','exec')
(DEST/'team.py').write_text(result)
new=ast.parse(result)
# Prove that the complete file is unchanged after normalizing this one method.
new_cls=next(n for n in new.body if isinstance(n,ast.ClassDef) and n.name=='_FallbackPolicy')
new_method=next(n for n in new_cls.body if isinstance(n,ast.FunctionDef) and n.name=='_cover_shape')
new_cls.body[new_cls.body.index(new_method)]=method
assert ast.dump(tree,include_attributes=False)==ast.dump(new,include_attributes=False)
manifest=dict(source=str(SOURCE),source_sha256=FROZEN,challenger=str(DEST/'team.py'),sha256=hashlib.sha256(result.encode()).hexdigest(),bytes=len(result.encode()),changed_methods=['_FallbackPolicy._cover_shape'],all_other_asts_equal=True,native_matches_run=False,promotion=False,algorithm=dict(threat='not secure AND ball x<8 AND (enemy holder OR nearest enemy within3.2 and enemy race within own chaser +.2)',assignment='existing non-keeper/non-chaser designated guard only',depth='ball x minus8, clamped through existing field-derived _target',lateral='goal-facing projection from own goal centre to ball',receiver_protection=['_receive_plan','_relay_receive','_x_reception'],outlets='other two outfield targets untouched; no extra defenders assigned',recovery='condition checked each decision; original cover rule applies immediately when threat disappears',runtime='O(players), no rollouts or caches'))
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
