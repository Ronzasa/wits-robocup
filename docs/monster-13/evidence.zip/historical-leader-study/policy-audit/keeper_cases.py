"""Contact-model diagnostic on two observed keeper own-goal launches.

Alternative proposals are model evaluations, not replay counterfactual goals.
"""
import json,math,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from replay_fingerprint import *
def rollout(s,launch):
 x,y,vx,vy=launch;wall=s._half_height-s._ball_radius
 for n in range(40):
  # model only: conservative own goal corridor at actual goal line.
  if x < s._left and abs(y) <= s._goal_half:return dict(own_goal=True,ticks=n)
  x+=vx*s._dt;y+=vy*s._dt
  if abs(y)>wall:y=math.copysign(2*wall-abs(y),y);vy=-vy*s._wall
  if x<s._left+s._ball_radius and abs(y)>s._goal_half:
   x=2*(s._left+s._ball_radius)-x;vx=abs(vx)*s._wall
  vx*=s._friction;vy*=s._friction
 return dict(own_goal=False,position=(x,y),velocity=(vx,vy))
def main():
 d=json.loads((ROOT/'replays/entry-12.json').read_text());c=load_controller(str(SOURCE));c.reset(d['header']['seed']);rows=[]
 with SoccerEnv(config_path='/workspace/work/replay-finishing-handoffs/configs/default.toml') as e:field=e.field
 for t,f in enumerate(d['frames'][:1546]):
  obs=obs_of(d,f,1,field);a=c.act(obs)
  if t not in (504,1545):continue
  s=c._fallback;p=(0,*obs.my_players[0].position,*obs.my_players[0].velocity);bx,by=obs.ball.position;vx,vy=obs.ball.velocity;old=a.players[0];kick=(old.kick_direction,old.kick_power)
  launch=s._carrier_contact(p,bx,by,*s._requested_velocity(vx,vy,kick),old.movement)
  after=d['frames'][t+1];actual=(*pair(after['ball_position'],-1),*pair(after['ball_velocity'],-1))
  moves=[('original',old.movement),('away',_unit(p[1]-bx,p[2]-by)),('brake',_unit(-p[3],-p[4]))]
  options=[]
  for name,movement in moves:
   for angle in range(-90,91,15):
    theta=math.radians(angle);candidate=((math.cos(theta),math.sin(theta)),1.0)
    out=s._carrier_contact(p,bx,by,*s._requested_velocity(vx,vy,candidate),movement)
    if out is None:continue
    risk=rollout(s,out)
    options.append(dict(movement_name=name,movement=movement,kick=candidate,launch=out,model_risk=risk))
  safe=[o for o in options if not o['model_risk']['own_goal']]
  safe.sort(key=lambda o:o['launch'][2],reverse=True)
  rows.append(dict(tick=t,recorded=old.as_dict(),predicted=launch,actual=actual,contact_error=max(abs(a-b) for a,b in zip(launch,actual)),original_risk=rollout(s,launch),alternatives_count=len(options),model_safe_count=len(safe),best_model_alternatives=safe[:6]))
 (ROOT/'policy-audit/keeper-cases.json').write_text(json.dumps(dict(scope='model-only alternative search on public replay states; no native counterfactual validation',cases=rows),indent=2)+'\n')
 for r in rows:print(r['tick'],r['contact_error'],r['model_safe_count'],r['best_model_alternatives'][:1])
def _unit(x,y):
 d=math.hypot(x,y)
 return (x/d,y/d) if d>1e-9 else (0.,0.)
if __name__=='__main__':main()
