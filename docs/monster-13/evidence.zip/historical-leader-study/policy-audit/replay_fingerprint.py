"""Read-only controller response fingerprint on public replay observations.

No state injection or matches: observations are reconstructed from replay data,
using only the official native public FieldView. Source attribution is inferred,
not proven by a replay source hash.
"""
import hashlib,json,math,sys
from pathlib import Path
from types import SimpleNamespace as N
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv
from soccer.helpers import load_controller
ROOT=Path('/workspace/work/div6-leader-20261026')
SOURCE=Path('/workspace/work/replay-finishing-handoffs/my-team/team.py')
def pair(d,sgn):return (d['x']*sgn,d['y']*sgn)
def obs_of(d,f,side,field):
 sgn=1 if side==0 else -1
 conv=lambda pid:None if pid is None else (pid-side*5 if side*5<=pid<side*5+5 else pid-(1-side)*5+5)
 def player(i,p):return N(id=conv(i),position=pair(p['position'],sgn),velocity=pair(p['velocity'],sgn),kick_cooldown_ticks=p['kick_cooldown_ticks'])
 own=[player(i,f['players'][i]) for i in range(side*5,side*5+5)]
 enemy=[player(i,f['players'][i]) for i in range((1-side)*5,(1-side)*5+5)]
 ball=N(position=pair(f['ball_position'],sgn),velocity=pair(f['ball_velocity'],sgn),last_touch=conv(f['ball_last_touch']),controlling_team=None if f['possession_team'] is None else int(f['possession_team']!=side),controlling_player=conv(f['possession_player']))
 return N(tick=f['tick'],max_ticks=2400,time_remaining=1-f['tick']/2400,score=tuple(f['score'][i] for i in (side,1-side)),field=field,my_goal=field.my_goal,opponent_goal=field.opponent_goal,my_players=own,opponents=enemy,ball=ball,can_kick=lambda pid:own[pid].kick_cooldown_ticks==0 and math.dist(own[pid].position,ball.position)<=field.kick_range)
def expected(f,side):
 sgn=1 if side==0 else -1;out={}
 for i in range(5):
  a=f['players'][side*5+i]['action'];out[i]=dict(movement=pair(a['movement'],sgn),kick_direction=None if a['kick_direction'] is None else pair(a['kick_direction'],sgn),kick_power=a['kick_power'])
 return out

def main():
 rows=[]
 with SoccerEnv(config_path='/workspace/work/replay-finishing-handoffs/configs/default.toml') as e:field=e.field
 for path in sorted((ROOT/'replays').glob('*.json')):
  d=json.loads(path.read_text());side=next(i for i,s in enumerate(d['header']['team_ids']) if 'nkqubela' in s);c=load_controller(str(SOURCE));c.reset(d['header']['seed'])
  record=dict(file=path.name,seed=d['header']['seed'],side=side,source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),exact_ticks=0,close_player_actions=0,player_actions=0,first_mismatches=[],wall_ticks=0,specialist_ticks=0,first_two_down_tick=None,first_wall_tick=None,score_at_wall=None)
  first_bad=None;allmax=0;mode_runs=[];last_mode=None
  for t,f in enumerate(d['frames'][:-1]):
   obs=obs_of(d,f,side,field);a=c.act(obs);exp=expected(d['frames'][t+1],side)
   if c._active:mode='specialist';record['specialist_ticks']+=1
   elif obs.score[1]-obs.score[0]>=2 or obs.score[0]>obs.score[1]:mode='lock-wall';record['wall_ticks']+=1
   else:mode='normal'
   if mode!=last_mode:mode_runs.append(dict(tick=t,mode=mode,score=obs.score));last_mode=mode
   if obs.score[1]-obs.score[0]>=2 and record['first_two_down_tick'] is None:record['first_two_down_tick']=t
   if mode=='lock-wall' and record['first_wall_tick'] is None:record['first_wall_tick']=t;record['score_at_wall']=obs.score
   mismatch=[];tickmax=0
   for i in range(5):
    actual=a.players[i];ex=exp[i];err=max(abs(actual.movement[j]-ex['movement'][j]) for j in (0,1));same_none=(actual.kick_direction is None)==(ex['kick_direction'] is None)
    if same_none and actual.kick_direction is not None:
     q=actual.kick_direction;norm=math.hypot(*q);q=(q[0]/norm,q[1]/norm);err=max(err,max(abs(q[j]-ex['kick_direction'][j]) for j in (0,1)),abs(actual.kick_power-ex['kick_power']))
    if not same_none:err=max(err,1.)
    close=err<2e-4;record['player_actions']+=1;record['close_player_actions']+=close
    if not close:mismatch.append(i)
    tickmax=max(tickmax,err)
   allmax=max(allmax,tickmax)
   if not mismatch:record['exact_ticks']+=1
   else:
    if first_bad is None:first_bad=t
    if len(record['first_mismatches'])<5:record['first_mismatches'].append(dict(tick=t,score=obs.score,players=mismatch,max_error=tickmax,ours={i:a.players[i].as_dict() for i in mismatch},replay={i:exp[i] for i in mismatch}))
  record.update(first_mismatch_tick=first_bad,prefix_matching_ticks=first_bad if first_bad is not None else 2400,max_error=allmax,mode_runs=mode_runs)
  rows.append(record);print(path.name,record['prefix_matching_ticks'],record['exact_ticks'],record['wall_ticks'],record['specialist_ticks'],flush=True)
 (ROOT/'policy-audit/fingerprint.json').write_text(json.dumps(dict(scope='synthetic replay-observation response fingerprint; no matches, no timing evidence; float tolerance2e-4',source=str(SOURCE),matches=rows),indent=2)+'\n')
if __name__=='__main__':main()
