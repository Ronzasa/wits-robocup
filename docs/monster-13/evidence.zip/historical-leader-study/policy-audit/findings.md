# Current-policy audit against Milla Singh

Read-only source and replay-response audit; no controller changes or competition trials.

Current source SHA-256: `27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce`.

## Main findings

1. **The fallback abandons attack at a two-goal deficit.** It enters the five-player wall at ticks649,918 and1548 in seeds1000,1002 and1003. That consumes **4,085/9,600 captured ticks (42.55%)**. The specialist never activates against Milla. Test `TRAIL_WALL=0` independently.

2. **Existing physics already predicts keeper own-goals.** At seed1003 ticks504 and1545, the current carrier-contact forecast reproduces the native next ball state within8.8e-6 and2.4e-5. A forward kick direction does not imply forward post-contact velocity. The correction in `_legacy_choose_kick` skips bx<=left+3 and allows vx>=−2, so it excludes or tolerates precisely these risky launches. Apply a final keeper-only alternative selection after both kick and movement are known. Never blindly suppress a kick: at tick504 the no-kick free step immediately enters the goal opening.

3. **Try the cheapest soft-control change first.** `_endpoint_controlled_touch` tests6 and9-unit/s candidates; 9 remains above player speed8 after the five-tick cooldown. Change only9 to7.5 and keep existing executable touch scoring. Separately test `DRIBBLE_SPEED=7.5`; do not combine until evidence supports it. The larger follow-up is to align actual five-tick carrier chase commands with `_touch_path` rather than introduce more theoretical reachability.

4. **Contested keeper sweeps are insufficiently gated.** The enemy-race comparison only applies outside the mouth+1 band. Consider gating all sweeps with an opponent-arrival margin, independently of keeper clearance safety. Near-post misses also motivate testing depth1.8 versus2.2 as a separate change. These positioning ideas remain hypotheses.

## Source attribution and limitations

The current controller matches all **12,000 player commands /2,400 frames** of the seed1001 replay within2e-4 using reconstructed public observations. Across all four it matches every normal-play frame (5,515 frames), and43,571/48,000 player commands overall. The first differences occur only after the two-goal wall is entered, where recorded throttle differs. This strongly ties the captured normal policy to the current fallback but is not a replay source-hash proof.

Reconstruction uses only public replay fields plus the official public FieldView. There is no hidden-state injection, no engine change, no timing evidence and no simulated win claim. Model proposals in `keeper-cases.json` are not native counterfactual outcomes. The one-goal lock was never entered in these four games, so disabling it is a separate source-risk experiment rather than a captured explanation.

Artifacts: `replay_fingerprint.py`, `fingerprint.json`, `keeper_cases.py`, `keeper-cases.json`, and detailed `findings.json`.
