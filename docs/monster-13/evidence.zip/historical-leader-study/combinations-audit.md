# Combined-controller review

**No blocking correctness finding in the reviewed source combinations.** This is a read-only static/synthetic review, not tournament qualification or a guarantee against all keeper collisions. No native match or environment loops were run by this audit. `audit_combinations.py` reproduces the checks; `combinations-audit.json` records exact outputs.

| Package | SHA-256 | Bytes |
| --- | --- | ---: |
| keeper-package | `dee3bb7aaccad574bbb72e7f6c69b98cd29a26928c10c5970331693709b7fc10` | 242,579 |
| nearpost-package | `1f5787ce18415793735314807fd3b35bc2cb6328058a176aa24d0de5f433c6c4` | 243,151 |
| cover-package | `171da7c96694e9de82ac46054f45ea42e59d69979cd5765e1bd757b8aa32704a` | 243,676 |

Each source hash agrees with the frozen combinations manifest, compiles, defines exactly one SDK `TeamController` subclass, and remains below 262,144 bytes.

## Exact composition and preservation

The call chain is **`act` (contest brake) → `_uncontested_act` (clearance guard) → `_unguarded_act` (original adaptive dispatch)**. Exact function AST comparisons establish:

- `_unguarded_act` has the original adaptive `act` body, with only its name changed.
- `_uncontested_act` has the independent clearance-guard `act` body, with only its name changed.
- The final `act` is byte-structure equivalent at AST level to the independent contest-brake `act`.
- Every helper method in keeper-package matches the frozen champion.
- Nearpost-package overrides only `_FallbackPolicy._v10_act` and `_SpecialistPolicy._opening_act`, identically to the independent nearpost candidate.
- Cover-package overrides only `_FallbackPolicy._cover_shape`, identically to the independent goal-side-cover candidate.
- The only class-assignment changes relative to baseline are controller version and fallback `LOCK_LEAD=0`, `LOCK_TIME=0.0`, `TRAIL_WALL=0`. No cooldown, player-speed, impulse, physics, shot or pass-verification constant changed.

These flags disable the fallback's all-five lead/trailing bunker. They do not remove the specialist's existing conditional four-player wall plus outlet; that original behavior is deliberately preserved.

## Executed wrapper regressions

All three packages passed the same recorded-public-state fixtures, with replay commands supplied as the original bottom-layer decision. These fixtures test wrapper arbitration and arithmetic; they do not inject a state into the simulator or establish competitive saves.

- **entry-01 pre-state 1004:** public ready enemy within kick range triggers the outer contest brake. Keeper kick is suppressed, movement opposes current keeper velocity, the other four action objects remain identical, and the tied keeper pass contract is cleared.
- **entry-12 pre-states 504 and 1545:** no ready enemy is in public kick range, so the outer brake preserves the clearance correction. Corrected kicks remain present and their inherited single-contact model has positive forward x velocity. The other four actions remain identical and the obsolete keeper pass contract is cleared.
- **Safe uncontested clearance:** its exact original keeper action object survives both wrappers in every package.

For each modified keeper action, movement norm and kick power remain legal. There is no change to SDK signatures and no missing-player action introduced by either wrapper in these fixtures. The guards do not manufacture cooldown readiness: they use the existing `can_kick` and opposing public cooldown/range conditions.

## Cover arbitration

A separate synthetic counterattack makes only the existing guard move goal-side; keeper, chaser and both outlet targets remain unchanged. A live verified reception assigned to that guard preserves its original target. Both checks passed. The override is checked against its independent source AST; all other defensive and receiver-planning methods remain unchanged.

## Limits and lifecycle note

The local clearance forecast still omits simultaneous opposing impulses and most future player contacts. The contest brake handles one public immediate-threat condition; it is not a complete opponent prediction system. Runtime and league strength must come from the root's native development and untouched validation results.

The two guards immediately clear `_receive_plan`, `_receive_aim`, `_bank_receive` and `_relay_receive` when their interrupted/replaced keeper pass owns that contract. They preserve all other players' current-frame actions. They do not directly clear `_x_reception`; the original normal-action lifecycle invalidates it on the next normal decision when the primary reception plan is absent. Consequently cover-package may conservatively keep a stale recipient exemption for that intervening cover calculation. No persistent invalid plan or exception was observed in the audited cases. Clearing only a keeper-owned `_x_reception` would be a small optional cleanup, but it would change the frozen source and require a new freeze and appropriate checks.

All frozen source and result files were left intact.
