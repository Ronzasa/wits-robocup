from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
P=Path('/workspace/work/replay-finishing-handoffs/my-team/team.py')
s=P.read_text();assert hashlib.sha256(P.read_bytes()).hexdigest()=='27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce'
print([(line.strip()) for line in s.splitlines() if 'TRAIL_WALL =' in line or 'LOCK_LEAD =' in line or 'LOCK_TIME =' in line])
variants={'baseline':s,'no-trail':s.replace('    TRAIL_WALL = 2','    TRAIL_WALL = 0'),'no-lock':s.replace('    TRAIL_WALL = 2','    TRAIL_WALL = 0').replace('    LOCK_LEAD = 1','    LOCK_LEAD = 0').replace('    LOCK_TIME = 1.0','    LOCK_TIME = 0.0')}
# Only fallback endpoint touch candidates change; specialist already uses7.5.
assert s.count('for speed in (6.0, 9.0):')>=1
variants['touch75']=s.replace('for speed in (6.0, 9.0):','for speed in (6.0, 7.5):',1)
m={}
for n,src in variants.items():
 out=R/'candidates'/n/'team.py';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(src);compile(src,str(out),'exec');m[n]=dict(path=str(out),sha256=hashlib.sha256(src.encode()).hexdigest())
(R/'flags-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
