"""Public native replay resimulation and short keeper counterfactuals.

No hidden state, source/SDK changes or physics injection. Recorded other-player
commands are fixed after an intervention; alternatives are short causal probes,
not games against the unknown reactive leader controller.
"""
import argparse,hashlib,itertools,json,math,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
REPO=Path('/workspace/work/replay-finishing-handoffs')
SDK=Path('/workspace/work/exploit-lab/student-sdk')
sys.path.insert(0,str(SDK))
from soccer import SoccerEnv
from soccer.helpers import load_controller

def pair(v):return float(v['x']),float(v['y'])
def mul(p,f):return p[0]*f[0],p[1]*f[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def infer(obs):
 a,b=obs['team_a'],obs['team_b'];world={p.id-5:p.position for p in a.opponents}
 error,sx,sy=min((max(math.dist(world[p.id],(sx*p.position[0],sy*p.position[1])) for p in b.my_players),sx,sy) for sx,sy in itertools.product((-1,1),repeat=2))
 assert error<1e-5
 return [(1,1),(sx,sy)]
def actions(frame,frames):
 out={}
 for side,key in enumerate(('team_a','team_b')):
  f=frames[side];acts={}
  for i in range(5):
   a=frame['players'][side*5+i]['action'];move=mul(pair(a['movement']),f)
   row=dict(movement=move)
   if a['kick_direction'] is not None:row.update(kick_direction=mul(pair(a['kick_direction']),f),kick_power=a['kick_power'])
   acts[i]=row
  out[key]=acts
 return out

def state(obs):
 a=obs['team_a']
 return dict(tick=a.tick,score=list(a.score),ball_position=list(a.ball.position),ball_velocity=list(a.ball.velocity),ball_last_touch=a.ball.last_touch,players=[dict(id=p.id,position=list(p.position),velocity=list(p.velocity),cooldown=p.kick_cooldown_ticks) for p in list(a.my_players)+list(a.opponents)])
def errors(obs,frame):
 a=obs['team_a'];players=list(a.my_players)+list(a.opponents)
 return dict(ball_position=math.dist(a.ball.position,pair(frame['ball_position'])),ball_velocity=math.dist(a.ball.velocity,pair(frame['ball_velocity'])),player_position=max(math.dist(p.position,pair(q['position'])) for p,q in zip(players,frame['players'])),player_velocity=max(math.dist(p.velocity,pair(q['velocity'])) for p,q in zip(players,frame['players'])),score_equal=list(a.score)==frame['score'])

def run(path,variant=None,start=None,stop=None,action_kind=None):
 d=json.loads(path.read_text());h=d['header'];fs=d['frames'];our_side=next(i for i,s in enumerate(h['team_ids']) if 'nkqubela' in s)
 controller=load_controller(str(variant)) if variant else None
 if controller:controller.reset(h['seed'])
 maximum={k:0. for k in ('ball_position','ball_velocity','player_position','player_velocity')};first_score_mismatch=None;trace=[];goals=[];prior_score=[0,0]
 max_tick=2400 if stop is None else stop
 with SoccerEnv(config_path=str(REPO/'configs/default.toml'),max_ticks=2400) as env:
  obs=env.reset(seed=h['seed'],kickoff_team=h['kickoff_team']);frames=infer(obs)
  assert env.config_hash==h['config_hash'] and env.engine_version==h['engine_version']
  initial_error=errors(obs,fs[0]);assert initial_error['player_position']<4e-6
  for decision_tick in range(max_tick):
   act=actions(fs[decision_tick+1],frames)
   suggested=controller.act(obs[('team_a','team_b')[our_side]]) if controller else None
   if start is not None and decision_tick>=start:
    if suggested:
     a=suggested.players[0];act[('team_a','team_b')[our_side]][0]=a.as_dict()
    else:
     own=obs[('team_a','team_b')[our_side]];p=own.my_players[0]
     if action_kind=='hold':replacement={'movement':(0.,0.)}
     elif action_kind=='brake':
      v=p.velocity;den=max(1.,math.hypot(*v));replacement={'movement':(-v[0]/den,-v[1]/den)}
     elif action_kind=='no-kick':
      replacement=act[('team_a','team_b')[our_side]][0].copy();replacement.pop('kick_direction',None);replacement.pop('kick_power',None)
     else:raise ValueError(action_kind)
     act[('team_a','team_b')[our_side]][0]=replacement
   if start is not None and decision_tick>=max(0,start-1):
    trace.append(dict(state=state(obs),keeper_action=act[('team_a','team_b')[our_side]][0],opponent_actions=act[('team_a','team_b')[1-our_side]]))
   obs,_=env.step(act)
   err=errors(obs,fs[decision_tick+1])
   for k in maximum:maximum[k]=max(maximum[k],err[k])
   if not err['score_equal'] and first_score_mismatch is None:first_score_mismatch=decision_tick+1
   score=list(obs['team_a'].score)
   if score!=prior_score:goals.append(dict(tick=decision_tick+1,before=prior_score,after=score));prior_score=score
  result=env.result()
  terminal=state(obs)
 row=dict(input=path.name,replay_sha256=digest(path),seed=h['seed'],our_side=our_side,scope='faithful replay resimulation' if start is None else 'short fixed-other-actions keeper intervention',variant=str(variant) if variant else action_kind,variant_sha256=digest(variant) if variant else None,start_decision_tick=start,stop_tick=max_tick,maximum_recorded_state_errors=maximum,first_score_mismatch=first_score_mismatch,goals=goals,result=result,terminal=terminal,initial_error=initial_error)
 if trace:row['trace']=trace
 return row

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--counterfactuals',action='store_true');args=p.parse_args()
 rows=[run(p) for p in sorted((ROOT/'replays').glob('*.json'))]
 report=dict(scope='native public reset/step ordinary-action resimulation; not timed matches',fidelity=rows,config_hash='372990895c7eca2a',engine_version='0.1.0')
 if args.counterfactuals:
  cf=[]
  cases=[('entry-12.json',503,515),('entry-12.json',1544,1547),('entry-01.json',1003,1008)]
  variants=[ROOT/'keeper-candidates'/n/'team.py' for n in ('clearance-guard','nearpost','depth-only')]
  for name,start,goal in cases:
   for kind in ('no-kick','hold','brake'):
    cf.append(run(ROOT/'replays'/name,start=start,stop=goal+8,action_kind=kind))
   for v in variants:cf.append(run(ROOT/'replays'/name,variant=v,start=start,stop=goal+8))
  # Close-range normal goals need anticipatory positioning, not one-frame reaction.
  for path in sorted((ROOT/'replays').glob('*.json')):
   d=json.loads(path.read_text());leader=next(i for i,s in enumerate(d['header']['team_ids']) if 'milla-singh' in s)
   for e in d['events']:
    if e['kind']=='goal' and e['team']==leader and not e.get('own_goal'):
     for v in variants[1:]:cf.append(run(path,variant=v,start=max(0,e['tick']-41),stop=e['tick']+8))
  report['counterfactuals']=cf
 with args.out.open('x') as f:json.dump(report,f,indent=2)
 for r in rows:print('FIDELITY',r['input'],r['maximum_recorded_state_errors'],r['first_score_mismatch'],r['result']['score'])
 if 'counterfactuals' in report:
  for r in report['counterfactuals']:
   print('CF',r['input'],r['start_decision_tick'],Path(r['variant']).parent.name if r['variant_sha256'] else r['variant'],r['terminal']['score'],r['goals'][-2:])
if __name__=='__main__':main()
