# Native replay reproduction and keeper counterfactuals

All four supplied v4 replays were reproduced through the official native engine using only `SoccerEnv.reset` and ordinary `step` actions. No simulator state, physics, SDK or opponent controller was modified. The original opponent source is unknown.

## Fidelity

Configuration `372990895c7eca2a`, engine `0.1.0`; exact replay seed, kickoff and default native roster. Team-B canonical reflection was inferred and checked from the two public initial observation views. Recorded actions in frame t+1 are applied to public state t.

- Every one of the 2,401 score frames in each replay matches the native resimulation.
- Maximum ball-position error across all four: 2.041e-6 pitch units.
- Maximum ball-velocity error: 1.197e-6 units/second.
- Maximum player-position error: 2.081e-6 pitch units.
- Maximum player-velocity error: 3.358e-7 units/second.
- Header-side final scores: entry01 0–3, entry05 2–1, entry08 0–3, entry12 2–0; all are user losses after respecting header team order.

Replay event tick labels use the pre-transition clock: the goal event at tick515 appears in the state score at tick516. This is not a reproduction mismatch.

## Keeper own-goal windows

The variant controller is teacher-forced with the actual public observations before intervention. Its actions are ignored before the intervention window. During the window only its goalkeeper action is applied; all other commands continue on their recorded tape. Simple no-kick/hold/brake alternatives are also measured. This is a short fixed-other-actions causal experiment, **not a match against the unknown reactive Milla controller**.

`Avoided` below means no opponent goal within the short specified window in which the original replay contains one. It does not establish indefinite prevention or match victory.

| Replay / decision window | No kick, original movement | Hold | Brake | Clearance guard | Near-post variant | Depth-only variant |
| --- | --- | --- | --- | --- | --- | --- |
| entry12, 503→523 (original goal event515) | Avoided | Avoided | Avoided | Avoided | Conceded | Avoided |
| entry12, 1544→1555 (original goal event1547) | Avoided | Avoided | Avoided | Avoided | Conceded | Conceded |
| entry01, 1003→1016 (original goal event1008) | Conceded | Avoided | Avoided | Conceded | Conceded | Conceded |

Clearance guard's two successful entry12 windows end with the ball moving away from the user's right-hand goal: respectively world x≈38.07, vx≈−10.56; x≈39.87, vx≈−18.51. This is stronger evidence than merely observing no goal at the original frame.

The simultaneous-opponent-kick case entry01 shows why canceling our kick alone is insufficient. No-kick with original movement and the current clearance guard both concede. Hold/brake instead let the native contact response send the ball away from the user's left-hand goal: at window end x≈−41.50/vx≈+11.24 for hold and x≈−41.85/vx≈+10.94 for brake. These examples support evaluating the movement/body geometry as well as requested kick direction, and considering a nearby ready opponent's same-tick impulse. They do **not** support making the keeper permanently passive.

## Normal near-post goals

For each of the six normal Milla goals, nearpost and depth-only policies control only our keeper beginning 41 ticks before the goal-event label. Both avoid/delay **one of six** original goals through event tick+8: entry08 goal270. Neither prevents the other five within those windows. The earlier intuition that generic near-post/deeper positioning would fix most goals is not supported by these probes.

`summary.json` has normalized opponent-goal deltas for every window and is the authoritative compact result. `native-results.json` preserves full fidelity metrics, hashes, traces, actions, public terminal states and native results. `run.log` contains original output in header-side score order; do not infer user/leader side from filename or the display-order `recorded.teams` list.

## Reproduce

Use a complete official native SDK. From the original study layout:

```bash
PYTHONPATH=/workspace/work/exploit-lab/student-sdk \
python /workspace/work/div6-leader-20261026/native-repro/reproduce.py \
  --out NEW_RESULTS.json --counterfactuals
```

Output creation is exclusive. The three input keeper sources under `../keeper-candidates/` are hashed in each result; changed variants require a new output and should be treated as new experiments. These runs are untimed mechanics reproductions. They do not establish compliance with the 20ms decision deadline, league points, statistical significance or candidate promotion.
