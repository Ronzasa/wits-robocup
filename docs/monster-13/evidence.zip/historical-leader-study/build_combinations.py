import ast,hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
base=(R/'candidates/baseline/team.py').read_text()
def method(src,cls,name):
 tree=ast.parse(src);c=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
 n=next(n for n in c.body if isinstance(n,ast.FunctionDef) and n.name==name)
 return ''.join(src.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
def unlock(s):return s.replace('    TRAIL_WALL = 2','    TRAIL_WALL = 0').replace('    LOCK_LEAD = 1','    LOCK_LEAD = 0').replace('    LOCK_TIME = 1.0','    LOCK_TIME = 0.0')
s=(R/'keeper-candidates/clearance-guard/team.py').read_text()
# Stack contest guard outside the contact correction; each acts only on keeper.
head,sep,body=s.rpartition('    def act(self, obs):\n');assert sep
s=head+'    def _uncontested_act(self, obs):\n'+body+'\n\n'+method((R/'keeper-candidates/contest-brake/team.py').read_text(),'AdaptiveChampion','act')+'\n'
packages={'keeper-package':unlock(s)}
near=(R/'keeper-candidates/nearpost/team.py').read_text();p=s
for cls,name in [('_FallbackPolicy','_v10_act'),('_SpecialistPolicy','_opening_act')]:
 old=method(p,cls,name);p=p.replace(old,method(near,cls,name),1)
packages['nearpost-package']=unlock(p)
cover=(R/'candidates/goal-side-cover/team.py').read_text();old=method(s,'_FallbackPolicy','_cover_shape')
packages['cover-package']=unlock(s.replace(old,method(cover,'_FallbackPolicy','_cover_shape'),1))
manifest={}
for n,src in packages.items():
 out=R/'candidates'/n/'team.py';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(src);compile(src,str(out),'exec')
 assert len(src.encode())<=262144
 manifest[n]=dict(path=str(out),sha256=hashlib.sha256(src.encode()).hexdigest(),bytes=len(src.encode()),promotion=False)
(R/'combinations-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
