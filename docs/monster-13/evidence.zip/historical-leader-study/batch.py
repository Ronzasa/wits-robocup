"""Frozen native paired research. No promotion, one timed worker, raw failures retained."""
import argparse,hashlib,json,random,sys
from pathlib import Path
from collections import defaultdict
REPO=Path('/workspace/work/replay-finishing-handoffs')
sys.path.insert(0,str(REPO/'tools/benchmarks'))
from default_roster import native_match
from benchmark import aggregate,points
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(folder):
 reg=json.loads((folder/'registration.json').read_text());policy={**reg['sources'],**reg['opponents']}
 for n,v in policy.items():assert digest(v['path'])==v['sha256'],n
 fixtures=[(op,seed,side,kick) for op in reg['opponents'] for seed in reg['seeds'] for side in (0,1) for kick in (True,False)];random.Random(reg['order_seed']).shuffle(fixtures)
 rows={n:[] for n in reg['sources']};rng=random.Random(reg['order_seed']+1)
 (folder/'metadata.json').write_text(json.dumps(dict(harness_sha256=digest(__file__),driver_sha256=digest(REPO/'tools/benchmarks/default_roster.py'),registration_sha256=digest(folder/'registration.json')),indent=2)+'\n')
 with (folder/'matches.jsonl').open('x') as f:
  for index,(op,seed,side,kick) in enumerate(fixtures):
   labels=list(rows);rng.shuffle(labels)
   for n in labels:
    result,telemetry,roster=native_match(reg['sources'][n]['path'],reg['opponents'][op]['path'],seed,side,kick,reg)
    row=dict(source=n,opponent_name=op,seed=seed,candidate_slot=side,candidate_takes_kickoff=kick,result=result,telemetry=telemetry,initial_roster=roster)
    rows[n].append(row);f.write(json.dumps(row)+'\n');f.flush()
   if (index+1)%4==0:print('PROGRESS',index+1,'/',len(fixtures),{n:sum(points(r) for r in rs) for n,rs in rows.items()},flush=True)
 summary={n:aggregate(rs) for n,rs in rows.items()};by={op:{n:aggregate([r for r in rs if r['opponent_name']==op]) for n,rs in rows.items()} for op in reg['opponents']}
 compare={};key=lambda r:(r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])
 baseline={key(r):r for r in rows['baseline']}
 for n,rs in rows.items():
  blocks=defaultdict(list)
  for r in rs:blocks[r['seed']].append(points(r)-points(baseline[key(r)]))
  means=[sum(v)/len(v) for _,v in sorted(blocks.items())];br=random.Random(3260260099)
  boots=sorted(sum(br.choices(means,k=len(means)))/len(means) for _ in range(10000))
  compare[n]=dict(points_difference_per_fixture=sum(means)/len(means),seed_block_95=[boots[250],boots[9749]],additional_raw_misses_per1000=(summary[n]['policy_timeouts']-summary['baseline']['policy_timeouts'])*1000/len(rs))
 report=dict(summary=summary,by_opponent=by,paired_vs_baseline=compare,scope=reg['scope'],promotion=False)
 (folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 for n,v in policy.items():assert digest(v['path'])==v['sha256'],n
 print('DONE',json.dumps({n:dict(points=s['points'],WDL=[s['wins'],s['draws'],s['losses']],errors=s['policy_errors'],misses=s['policy_timeouts']) for n,s in summary.items()}),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder',type=Path);run(p.parse_args().folder)
