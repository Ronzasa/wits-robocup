"""Extract replay response bodies; never export HAR request headers/cookies/URLs."""
import argparse,hashlib,json,urllib.parse,zipfile,base64
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('out',type=Path);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(a.archive) as z:
 names=[n for n in z.namelist() if n.lower().endswith('.har')];assert len(names)==1
 entries=json.loads(z.read(names[0]))['log']['entries']
manifest=[];selected=None
for i,e in enumerate(entries):
 path=urllib.parse.urlsplit(e['request']['url']).path;c=e.get('response',{}).get('content',{})
 raw=c.get('text','');raw=base64.b64decode(raw).decode() if c.get('encoding')=='base64' else raw
 if path.endswith('/replay'):
  d=json.loads(raw);assert all(k in d for k in ['header','frames','events','recorded'])
  out=a.out/('entry-%02d.json'%i)
  if out.exists():assert out.read_text()==raw
  else:out.write_text(raw)
  manifest.append(dict(file=out.name,sha256=hashlib.sha256(raw.encode()).hexdigest(),seed=d['header']['seed'],team_ids=d['header']['team_ids'],faithful=d['recorded']['faithful'],frames=len(d['frames'])))
 elif path.endswith('/table') and selected is None:
  d=json.loads(raw);keys=['slug','name','rank','division','played','points','wins','draws','losses','goals_for','goals_against','policy_errors','policy_timeouts','decision_mean_ms','last_updated']
  selected=[{k:e.get(k) for k in keys} for e in d['standings'] if e.get('slug') in ['403495-milla-singh','401976-nkqubela-hokwana']]
(a.out/'safe-manifest.json').write_text(json.dumps(dict(upload_sha256=hashlib.sha256(a.archive.read_bytes()).hexdigest(),replays=manifest,selected_standings=selected,excluded='HAR and all request metadata, cookies and headers'),indent=2)+'\n')
print('Extracted',len(manifest),'replays without request metadata')
