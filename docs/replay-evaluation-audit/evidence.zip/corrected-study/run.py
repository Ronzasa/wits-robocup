"""Corrected-roster, frozen independent feature comparison and one validation."""
from datetime import datetime,timezone
import importlib.util,json,random,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path[:0]=['/workspace/work/exploit-lab/student-sdk','/workspace/work/replay-finishing-handoffs/tools/benchmarks']
from benchmark import aggregate,points
from soccer.validate import validate
spec=importlib.util.spec_from_file_location('roster_driver','/workspace/work/replay-default-roster-20261025/run.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)


def play(label,source,opponent,style,seed,side,kick,reg):
    result,telemetry,roster=driver.native_match(source,opponent,seed,side,kick,reg)
    return dict(source=label,opponent_name=style,opponent=opponent,seed=seed,
                candidate_slot=side,candidate_takes_kickoff=kick,result=result,
                telemetry=telemetry,initial_roster=roster)


def main():
    reg=json.loads((ROOT/'registration.json').read_text())
    (ROOT/'metadata.json').write_text(json.dumps(dict(started_utc=datetime.now(timezone.utc).isoformat(),
        registration_sha256=driver.digest(ROOT/'registration.json'),runner_sha256=driver.digest(__file__),
        driver_sha256=driver.digest('/workspace/work/replay-default-roster-20261025/run.py')),indent=2))
    for item in [*reg['sources'].values(),*reg['opponents'].values()]:assert driver.digest(item['path'])==item['sha256']
    for label in ('edge-contact','team8-unlocked'):
        report=validate(reg['sources'][label]['path'],ticks=400,deadline_ms=20.)
        data=dict(ok=report.ok,errors=report.errors,warnings=report.warnings,stats=report.stats)
        (ROOT/f'{label}-intake.json').write_text(json.dumps(data,indent=2))
        print('INTAKE',label,data,flush=True)
        if report.errors:raise RuntimeError('Intake error: '+label)
    rng=random.Random(reg['order_seed'])
    combos=[(seed,side,kick) for seed in reg['development_seeds'] for side in (0,1) for kick in (True,False)]
    rng.shuffle(combos);raw={name:[] for name in reg['sources']}
    with (ROOT/'development.jsonl').open('x') as f:
        for index,(seed,side,kick) in enumerate(combos):
            order=list(raw);rng.shuffle(order)
            for label in order:
                row=play(label,reg['sources'][label]['path'],reg['opponents']['team8']['path'],'team8',seed,side,kick,reg)
                raw[label].append(row);f.write(json.dumps(row)+'\n');f.flush()
            if (index+1)%4==0:print('CORRECTED-DEVELOPMENT',index+1,'/32', {n:sum(points(r) for r in rs) for n,rs in raw.items()},flush=True)
    stats={name:aggregate(rows) for name,rows in raw.items()};eligible=[]
    for name,s in stats.items():
        mirror=aggregate([dict(r,candidate_slot=1-r['candidate_slot']) for r in raw[name]])
        s['opponent_points']=mirror['points']
        s['extra_misses_per1000']=(s['policy_timeouts']-mirror['policy_timeouts'])*1000/32
        if s['policy_errors']==0 and s['points']>mirror['points'] and s['extra_misses_per1000']<=2:
            eligible.append(name)
    winner=sorted(eligible,key=lambda n:(-stats[n]['points'],-stats[n]['goal_difference'],stats[n]['decision_mean_ms'],n))[0] if eligible else None
    selection=dict(development=stats,selected=winner,selection_uses_only_development=True,promotion=False)
    (ROOT/'selection.json').write_text(json.dumps(selection,indent=2))
    print('SELECTED',winner,flush=True)
    if winner is None:return
    sources={'candidate':reg['sources'][winner],'team8':reg['opponents']['team8']}
    rows={name:[] for name in sources}
    combos=[(style,seed,side,kick) for style in reg['opponents'] for seed in reg['validation_seeds'] for side in (0,1) for kick in (True,False)]
    rng.shuffle(combos)
    with (ROOT/'validation.jsonl').open('x') as f:
        for index,(style,seed,side,kick) in enumerate(combos):
            order=list(sources)
            if index%2:order.reverse()
            for label in order:
                row=play(label,sources[label]['path'],reg['opponents'][style]['path'],style,seed,side,kick,reg)
                rows[label].append(row);f.write(json.dumps(row)+'\n');f.flush()
            if (index+1)%16==0:print('CORRECTED-VALIDATION',index+1,'/160',{n:sum(points(r) for r in rs) for n,rs in rows.items()},flush=True)
    pooled={name:aggregate(rs) for name,rs in rows.items()}
    paired=driver.compare(rows['candidate'],rows['team8'],reg['bootstrap_seed'])
    extra=(pooled['candidate']['policy_timeouts']-pooled['team8']['policy_timeouts'])*1000/160
    gates=dict(positive_paired_points_lower_bound=paired['paired_seed_bootstrap_95'][0]>0,
        zero_policy_errors=pooled['candidate']['policy_errors']==0,additional_raw_misses_per1000_at_most2=extra<=2.)
    final=dict(selected=winner,sources=sources,summary=pooled,paired=paired,
        additional_raw_misses_per1000=extra,gates=gates,passes_all=all(gates.values()),
        by_opponent={style:{n:aggregate([r for r in rs if r['opponent_name']==style]) for n,rs in rows.items()} for style in reg['opponents']},
        finished_utc=datetime.now(timezone.utc).isoformat(),promotion=False)
    for item in [*reg['sources'].values(),*reg['opponents'].values()]:assert driver.digest(item['path'])==item['sha256']
    (ROOT/'validation-summary.json').write_text(json.dumps(final,indent=2)+'\n')
    print('FINAL',json.dumps(final),flush=True)


if __name__=='__main__':main()
