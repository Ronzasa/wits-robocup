"""Functional first-divergence trace on an exposed development fixture only."""
from collections import deque
import importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path[:0]=['/workspace/work/exploit-lab/student-sdk','/workspace/work/replay-finishing-handoffs/tools/benchmarks']
from soccer import runner
from soccer.helpers import load_controller
from benchmark import points
spec=importlib.util.spec_from_file_location('default_roster_driver','/workspace/work/replay-default-roster-20261025/run.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)


def commands(action):
    return {str(i):dict(movement=list(p.movement),kick_direction=None if p.kick_direction is None else list(p.kick_direction),kick_power=p.kick_power) for i,p in action.players.items()}


def main():
    reg=json.loads((ROOT/'registration.json').read_text())
    rows=[json.loads(x) for x in (ROOT/'development.jsonl').read_text().splitlines()]
    keyed={(r['source'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff']):r for r in rows}
    chosen=next(r for r in rows if r['source']=='full-v2' and points(keyed[('no-retention',r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])])>points(r))
    shadow=load_controller(reg['sources']['no-retention']['path']);shadow.reset(chosen['seed'])
    original=runner._decide;counter=0;found=None;history=deque(maxlen=6)
    def measured(controller,obs):
        nonlocal counter,found
        slot=counter%2;counter+=1
        answer=original(controller,obs)
        if slot==chosen['candidate_slot'] and found is None and answer[2] is None:
            alternative=shadow.act(obs)
            same=commands(answer[0])==commands(alternative)
            history.append(dict(tick=obs.tick,same_commands=same,
                full_chaser=controller._chaser,without_plan_chaser=shadow._chaser,
                full_carry_plan=controller._carry_plan,without_plan_carry=shadow._carry_plan))
            if not same:
                found=dict(tick=obs.tick,score=obs.score,ball_position=obs.ball.position,
                    ball_velocity=obs.ball.velocity,history=list(history),
                    players=[dict(id=p.id,position=p.position,velocity=p.velocity,cooldown=p.kick_cooldown_ticks,can_kick=obs.can_kick(p.id)) for p in obs.my_players],
                    full_commands=commands(answer[0]),without_plan_commands=commands(alternative))
        return answer
    runner._decide=measured
    try:
        result,_,_=driver.native_match(reg['sources']['full-v2']['path'],reg['opponents']['team8']['path'],
            chosen['seed'],chosen['candidate_slot'],chosen['candidate_takes_kickoff'],reg)
    finally:runner._decide=original
    report=dict(scope='Exposed development fixture, two policy states receiving identical native observations. Their movement/kick commands agree until the recorded first difference. Shadow computation occurs outside native timed calls. This diagnostic is not a validation fixture or timing benchmark.',
        seed=chosen['seed'],candidate_slot=chosen['candidate_slot'],candidate_takes_kickoff=chosen['candidate_takes_kickoff'],
        first_divergence=found,native_result=result)
    (ROOT/'self-reception-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(found),flush=True)


if __name__=='__main__':main()
