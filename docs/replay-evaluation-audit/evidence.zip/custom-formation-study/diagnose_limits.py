"""One native, same-state functional diagnostic; not a validation result."""
import copy,json,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import play_match,runner
from soccer.helpers import load_controller


def commands(action):
    return {str(pid):dict(movement=list(p.movement),
                         kick_direction=None if p.kick_direction is None else list(p.kick_direction),
                         kick_power=p.kick_power)
            for pid,p in action.players.items()}


def main():
    reg=json.loads((ROOT/'registration.json').read_text())
    rows=[json.loads(x) for x in (ROOT/'development.jsonl').read_text().splitlines()]
    by={(r['source'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff']):r for r in rows}
    source=next(r for r in rows if r['source']=='full-v2' and
        (lambda q:q['result']['score'][q['candidate_slot']]-q['result']['score'][1-q['candidate_slot']])(
            by[('no-work-caps',r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])])>
        r['result']['score'][r['candidate_slot']]-r['result']['score'][1-r['candidate_slot']])
    side=source['candidate_slot'];old=runner._decide;counter=0;found=None
    shadow=load_controller(reg['sources']['no-work-caps']['path'])
    def measured(controller,obs):
        nonlocal counter,found
        slot=counter%2;counter+=1
        # _x_prepare replaces _x_obs with this tick's public observation
        # before it is used. The native observation cannot be deep-copied.
        state=(copy.deepcopy({k:v for k,v in controller.__dict__.items() if k!='_x_obs'})
               if slot==side and found is None else None)
        answer=old(controller,obs)
        if state is not None and answer[2] is None:
            shadow.__dict__=state
            alternative=shadow.act(obs)
            if commands(answer[0])!=commands(alternative):
                found=dict(tick=obs.tick,ball_position=obs.ball.position,
                    ball_velocity=obs.ball.velocity,score=obs.score,
                    full_v2=commands(answer[0]),without_caps=commands(alternative),
                    remaining_budgets=controller._work,
                    full_unknown=controller._work_unknown,
                    touch_evaluations_left=controller._touch_left,
                    full_pass_plan=controller._pass_plan,
                    uncapped_pass_plan=shadow._pass_plan,
                    full_carry_plan=controller._carry_plan,
                    uncapped_carry_plan=shadow._carry_plan)
        return answer
    paths=[reg['sources']['full-v2']['path'],reg['opponents']['team8']['path']]
    if side:paths.reverse()
    runner._decide=measured
    try:
        outcome=play_match(*paths,seed=source['seed'],kickoff_team=side if source['candidate_takes_kickoff'] else 1-side,
            config_path=reg['config_path'],max_ticks=2400,per_decision_timeout_ms=20.,match_id='limits-mechanism-diagnostic')
    finally:runner._decide=old
    record=dict(scope='Functional diagnostic on an exposed development fixture. Shadow calculations and state copies occur outside the official timed call. This is not a performance benchmark, qualification fixture or replacement result.',
        seed=source['seed'],candidate_slot=side,candidate_takes_kickoff=source['candidate_takes_kickoff'],
        first_different_command=found,result=outcome.result)
    (ROOT/'limits-diagnostic.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record['first_different_command']),flush=True)


if __name__=='__main__':main()
