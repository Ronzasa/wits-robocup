"""Interleaved native ablations. No source tuning or raw result replacement."""
from collections import defaultdict
from datetime import datetime,timezone
import hashlib,json,random,sys,time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path[:0]=['/workspace/work/exploit-lab/student-sdk','/workspace/work/replay-finishing-handoffs/tools/benchmarks']
from soccer import play_match,runner
from soccer.validate import validate
from benchmark import aggregate,points,candidate_score


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compare(a,b,rng_seed):
    keyed=lambda rows:{(r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff']):r for r in rows}
    aa,bb=keyed(a),keyed(b)
    assert aa.keys()==bb.keys()
    blocks=defaultdict(list)
    for key,row in aa.items():blocks[row['seed']].append(points(row)-points(bb[key]))
    means=[sum(values)/len(values) for values in blocks.values()]
    rng=random.Random(rng_seed)
    boot=sorted(sum(rng.choices(means,k=len(means)))/len(means) for _ in range(10000))
    return dict(points_difference_per_match=sum(means)/len(means),paired_seed_bootstrap_95=[boot[249],boot[9749]],seed_blocks=len(means))


def fixture(source,opponent,seed,side,kick,reg,label,opponent_name):
    paths=[source,opponent]
    if side:paths.reverse()
    telemetry=dict(first_goal=None,old_lock_ticks=0,recovery_ticks=0,carry_ticks=0,slow=[])
    old=runner._decide;counter=0
    def measured(controller,obs):
        nonlocal counter
        slot=counter%2;counter+=1
        result=old(controller,obs)
        if slot==side:
            if telemetry['first_goal'] is None and sum(obs.score):
                telemetry['first_goal']='candidate' if obs.score[0]>obs.score[1] else 'opponent'
            telemetry['recovery_ticks']+=getattr(controller,'_recovery_guard',None) is not None
            telemetry['carry_ticks']+=getattr(controller,'_carry_plan',None) is not None
        elif opponent_name=='team8':
            telemetry['old_lock_ticks']+=(obs.score[0]>obs.score[1])
        if result[1]>20 or result[2] is not None:
            telemetry['slow'].append(dict(side=slot,tick=obs.tick,elapsed_ms=result[1],error=result[2]))
        return result
    runner._decide=measured
    try:
        outcome=play_match(*paths,seed=seed,kickoff_team=side if kick else 1-side,
            config_path=reg['config_path'],max_ticks=2400,per_decision_timeout_ms=20.,
            match_id=f'{label}-{opponent_name}-{seed}-{side}-{int(kick)}')
    finally:runner._decide=old
    result=outcome.result
    assert result['engine_version']==reg['engine_version'] and result['config_hash']==reg['config_hash']
    assert not result.get('platform_error')
    return dict(source=label,opponent=opponent,opponent_name=opponent_name,seed=seed,
        candidate_slot=side,candidate_takes_kickoff=kick,result=result,telemetry=telemetry)


def summary(rows):
    result=aggregate(rows)
    result['completed_full_matches']=sum(r['result']['ticks']==2400 and r['result']['terminal_reason']=='time_limit' for r in rows)
    result['first_goal_candidate']=sum(r['telemetry']['first_goal']=='candidate' for r in rows)
    result['first_goal_opponent']=sum(r['telemetry']['first_goal']=='opponent' for r in rows)
    result['old_lock_ticks']=sum(r['telemetry']['old_lock_ticks'] for r in rows)
    return result


def main():
    reg=json.loads((ROOT/'registration.json').read_text())
    started=datetime.now(timezone.utc).isoformat()
    for item in [*reg['sources'].values(),*reg['opponents'].values()]:assert digest(item['path'])==item['sha256']
    for label,spec in reg['sources'].items():
        report=validate(spec['path'],ticks=400,deadline_ms=20.)
        data=dict(ok=report.ok,errors=report.errors,warnings=report.warnings,stats=report.stats)
        (ROOT/f'{label}-intake.json').write_text(json.dumps(data,indent=2))
        print('INTAKE',label,data,flush=True)
        if report.errors:raise RuntimeError('Source intake errors: '+label)
    combinations=[(seed,side,kick) for seed in reg['development_seeds'] for side in (0,1) for kick in (True,False)]
    rng=random.Random(reg['source_order_seed']);rng.shuffle(combinations)
    raw={name:[] for name in reg['sources']}
    with (ROOT/'development.jsonl').open('x') as handle:
        for index,(seed,side,kick) in enumerate(combinations):
            order=list(raw);rng.shuffle(order)
            for label in order:
                row=fixture(reg['sources'][label]['path'],reg['opponents']['team8']['path'],seed,side,kick,reg,label,'team8')
                raw[label].append(row);handle.write(json.dumps(row)+'\n');handle.flush()
            if (index+1)%4==0:
                print('DEVELOPMENT',index+1,'/32 paired fixtures', {name:sum(points(r) for r in rows) for name,rows in raw.items()},flush=True)
    summaries={name:summary(rows) for name,rows in raw.items()}
    eligible=[]
    for name,s in summaries.items():
        mirrors=[dict(r,candidate_slot=1-r['candidate_slot']) for r in raw[name]]
        opponent=aggregate(mirrors)
        excess=(s['policy_timeouts']-opponent['policy_timeouts'])*1000/len(raw[name])
        s['opponent_points']=opponent['points']
        s['extra_misses_per1000']=excess
        s['paired_vs_full_v2']=compare(raw[name],raw['full-v2'],reg['bootstrap']['seed'])
        if name!='full-v2' and s['policy_errors']==0 and excess<=2.:
            eligible.append(name)
    winner=(sorted(eligible,key=lambda n:(-summaries[n]['points'],-summaries[n]['goal_difference'],summaries[n]['decision_mean_ms'],n))[0] if eligible else None)
    selection=dict(started_utc=started,development=summaries,selected=winner,
        scope='Selection uses exposed development seeds only; prior full-v2 failure remains retained.',promotion=False)
    (ROOT/'selection.json').write_text(json.dumps(selection,indent=2))
    print('SELECTION',json.dumps(selection),flush=True)
    if winner is None:return
    # The source choice is now frozen; do not use validation to select again.
    sources={winner:reg['sources'][winner],'team8':reg['opponents']['team8']}
    for name in sources:
        path=ROOT/'validation'/name;path.mkdir(parents=True,exist_ok=True)
    checks={name:[] for name in sources}
    combinations=[(style,seed,side,kick) for style in reg['opponents'] for seed in reg['validation_seeds'] for side in (0,1) for kick in (True,False)]
    rng.shuffle(combinations)
    with (ROOT/'validation.jsonl').open('x') as handle:
        for index,(style,seed,side,kick) in enumerate(combinations):
            order=list(sources)
            if index%2:order.reverse()
            for label in order:
                row=fixture(sources[label]['path'],reg['opponents'][style]['path'],seed,side,kick,reg,label,style)
                checks[label].append(row);handle.write(json.dumps(row)+'\n');handle.flush()
            if (index+1)%16==0:print('VALIDATION',index+1,'/160 pairs',{n:sum(points(r) for r in rs) for n,rs in checks.items()},flush=True)
    final={name:summary(rows) for name,rows in checks.items()}
    paired=compare(checks[winner],checks['team8'],reg['bootstrap']['seed'])
    delta=(final[winner]['policy_timeouts']-final['team8']['policy_timeouts'])*1000/len(checks[winner])
    gates=dict(positive_paired_points_lower_bound=paired['paired_seed_bootstrap_95'][0]>0,
               zero_policy_errors=final[winner]['policy_errors']==0,
               additional_raw_misses_per1000_at_most2=delta<=2.)
    result=dict(selected=winner,sources=sources,summary=final,paired=paired,
        by_opponent={style:{label:aggregate([r for r in rows if r['opponent_name']==style]) for label,rows in checks.items()} for style in reg['opponents']},
        additional_raw_misses_per1000=delta,gates=gates,passes_all=all(gates.values()),
        finished_utc=datetime.now(timezone.utc).isoformat(),promotion=False)
    for item in [*reg['sources'].values(),*reg['opponents'].values()]:assert digest(item['path'])==item['sha256']
    (ROOT/'validation-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print('FINAL',json.dumps(result),flush=True)


if __name__=='__main__':main()
