"""Replay captured legal actions through the public native API, with default rosters."""
import json,math,sys
from pathlib import Path
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv,TeamAction,PlayerAction

ROOT=Path(__file__).resolve().parent
HAR=Path('/workspace/work/har-review-20261025/replays')


def main():
    results=[]
    for path in sorted(HAR.glob('*.json')):
        d=json.loads(path.read_text());header=d['header'];frames=d['frames']
        max_ball=0.;max_player=0.;first=None;sample_count=0
        with SoccerEnv(config_path='/workspace/work/exploit-lab/configs/default.toml',max_ticks=2400) as env:
            observations=env.reset(seed=header['seed'],kickoff_team=header['kickoff_team'])
            for tick in range(2400):
                commands={}
                for side,key in ((0,'team_a'),(1,'team_b')):
                    sign=1 if side==0 else -1
                    action=TeamAction()
                    for local in range(5):
                        raw=frames[tick+1]['players'][side*5+local]['action']
                        if raw is None:
                            action.set(local,PlayerAction())
                            continue
                        move=tuple(sign*raw['movement'][q] for q in ('x','y'))
                        kick=raw.get('kick_direction')
                        direction=None if kick is None else tuple(sign*kick[q] for q in ('x','y'))
                        action.set(local,PlayerAction(movement=move,kick_direction=direction,kick_power=raw.get('kick_power',0.)))
                    commands[key]=action
                observations,_=env.step(commands)
                obs=observations['team_a'];expected=frames[tick+1]
                eb=expected['ball_position'];ev=expected['ball_velocity']
                ball_error=max(abs(obs.ball.position[0]-eb['x']),abs(obs.ball.position[1]-eb['y']),
                               abs(obs.ball.velocity[0]-ev['x']),abs(obs.ball.velocity[1]-ev['y']))
                players=list(obs.my_players)+list(obs.opponents)
                player_error=max(max(abs(p.position[0]-q['position']['x']),abs(p.position[1]-q['position']['y']),
                                     abs(p.velocity[0]-q['velocity']['x']),abs(p.velocity[1]-q['velocity']['y']))
                                 for p,q in zip(players,expected['players']))
                max_ball=max(max_ball,ball_error);max_player=max(max_player,player_error);sample_count+=1
                if first is None and max(ball_error,player_error)>.003:
                    first=dict(tick=tick+1,ball_error=ball_error,player_error=player_error)
                if env.finished:break
            record=dict(replay=path.name,seed=header['seed'],steps=sample_count,
                        max_ball_state_error=max_ball,max_player_state_error=max_player,
                        first_over_tolerance=first,replayed_score=env.result()['score'],
                        captured_score=frames[-1]['score'])
        results.append(record);print(json.dumps(record),flush=True)
    (ROOT/'replay-parity.json').write_text(json.dumps(results,indent=2)+'\n')


if __name__=='__main__':main()
