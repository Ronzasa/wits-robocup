"""Official public native API, matching the default rosters captured in the HAR.

The decision/failure loop matches soccer.runner.play_match; the optional
custom-formation hook is intentionally not used, as verified against replays.
"""
from collections import defaultdict
from datetime import datetime,timezone
import hashlib,json,random,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path[:0]=['/workspace/work/exploit-lab/student-sdk','/workspace/work/replay-finishing-handoffs/tools/benchmarks']
from soccer import SoccerEnv,TeamController,runner
from soccer.helpers import load_controller
from benchmark import aggregate,points


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def native_match(candidate,opponent,seed,side,kick,reg):
    paths=[candidate,opponent]
    if side:paths.reverse()
    controllers=[load_controller(p) for p in paths]
    kickoff=side if kick else 1-side
    telemetry=dict(first_goal=None,slow=[])
    with SoccerEnv(config_path=reg['config_path'],max_ticks=2400,per_decision_timeout_ms=20.,
                   team_ids=('policy_a','policy_b')) as env:
        for c in controllers:c.reset(seed)
        observations=env.reset(seed=seed,kickoff_team=kickoff)
        initial_roster=[list(p.position) for p in list(observations['team_a'].my_players)+list(observations['team_a'].opponents)]
        previous=[TeamController.idle(observations[key]) for key in ('team_a','team_b')]
        while not env.finished:
            actions={}
            for slot,key in ((0,'team_a'),(1,'team_b')):
                obs=observations[key]
                action,elapsed,error=runner._decide(controllers[slot],obs)
                if slot==side and telemetry['first_goal'] is None and sum(obs.score):
                    telemetry['first_goal']='candidate' if obs.score[0]>obs.score[1] else 'opponent'
                if error is None:previous[slot]=action
                else:action=previous[slot]
                if elapsed>20. or error is not None:
                    telemetry['slow'].append(dict(side=slot,tick=obs.tick,elapsed_ms=elapsed,error=error))
                env.record_decision(slot,elapsed,error)
                actions[key]=action
            if env.finished:break
            observations,_=env.step(actions)
        result=env.result()
    assert result['engine_version']==reg['engine_version'] and result['config_hash']==reg['config_hash']
    assert not result.get('platform_error')
    return result,telemetry,initial_roster


def compare(a,b,seed):
    key=lambda r:(r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])
    aa={key(r):r for r in a};bb={key(r):r for r in b}
    assert aa.keys()==bb.keys()
    groups=defaultdict(list)
    for k,r in aa.items():groups[r['seed']].append(points(r)-points(bb[k]))
    means=[sum(v)/len(v) for v in groups.values()]
    rng=random.Random(seed)
    boot=sorted(sum(rng.choices(means,k=len(means)))/len(means) for _ in range(10000))
    return dict(points_difference_per_match=sum(means)/len(means),
                paired_seed_bootstrap_95=[boot[249],boot[9749]],seed_blocks=len(means))


def main():
    reg=json.loads((ROOT/'registration.json').read_text())
    for spec in [*reg['sources'].values(),*reg['opponents'].values()]:assert digest(spec['path'])==spec['sha256']
    combinations=[(style,seed,side,kick) for style in reg['opponents'] for seed in reg['seeds'] for side in (0,1) for kick in (True,False)]
    rng=random.Random(reg['fixture_order_seed']);rng.shuffle(combinations)
    rows={name:[] for name in reg['sources']}
    metadata=dict(started_utc=datetime.now(timezone.utc).isoformat(),
                  registration_sha256=digest(ROOT/'registration.json'),runner_sha256=digest(__file__))
    (ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2))
    with (ROOT/'matches.jsonl').open('x') as handle:
        for index,(style,seed,side,kick) in enumerate(combinations):
            order=list(rows)
            if index%2:order.reverse()
            for name in order:
                result,telemetry,roster=native_match(reg['sources'][name]['path'],reg['opponents'][style]['path'],seed,side,kick,reg)
                row=dict(source=name,opponent_name=style,opponent=reg['opponents'][style]['path'],
                         seed=seed,candidate_slot=side,candidate_takes_kickoff=kick,
                         result=result,telemetry=telemetry,initial_roster=roster)
                rows[name].append(row);handle.write(json.dumps(row)+'\n');handle.flush()
            if (index+1)%16==0:print('DEFAULT-ROSTER',index+1,'/160 pairs',{n:sum(points(r) for r in rs) for n,rs in rows.items()},flush=True)
    assert all(len(rs)==160 for rs in rows.values())
    pooled={name:aggregate(rs) for name,rs in rows.items()}
    paired=compare(rows['candidate'],rows['team8'],reg['bootstrap_seed'])
    extra=(pooled['candidate']['policy_timeouts']-pooled['team8']['policy_timeouts'])*1000/160
    gates=dict(positive_paired_points_lower_bound=paired['paired_seed_bootstrap_95'][0]>0,
               zero_policy_errors=pooled['candidate']['policy_errors']==0,
               additional_raw_misses_per1000_at_most2=extra<=2.)
    final=dict(scope=reg['scope'],formation=reg['formation'],summary=pooled,paired=paired,
               additional_raw_misses_per1000=extra,gates=gates,passes_all=all(gates.values()),
               by_opponent={style:{name:aggregate([r for r in rs if r['opponent_name']==style]) for name,rs in rows.items()} for style in reg['opponents']},
               completed_full_matches={name:sum(r['result']['ticks']==2400 and r['result']['terminal_reason']=='time_limit' for r in rs) for name,rs in rows.items()},promotion=False)
    for spec in [*reg['sources'].values(),*reg['opponents'].values()]:assert digest(spec['path'])==spec['sha256']
    (ROOT/'summary.json').write_text(json.dumps(final,indent=2)+'\n')
    metadata['finished_utc']=datetime.now(timezone.utc).isoformat()
    (ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print('FINAL',json.dumps(final),flush=True)


if __name__=='__main__':main()
