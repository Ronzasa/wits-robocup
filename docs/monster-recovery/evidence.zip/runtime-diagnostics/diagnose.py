"""Bounded native repeats; passive selected-decision wall/thread CPU/profiling.

Copies the frozen default-roster decision/failure loop, calls the actual SDK
runner._decide unchanged, and preserves the20ms native accounting. cProfile
runs only on a designated diagnostic decision, never as tournament evidence.
No GC callbacks/control, affinity, sleep or deadline/timer alterations.
"""
import cProfile,hashlib,json,pstats,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv,TeamController,runner
from soccer.helpers import load_controller
REG=json.loads((ROOT/'structural-field/registration.json').read_text())
OUT=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def safe(v):
 if v is None or isinstance(v,(str,int,float,bool)):return v
 if isinstance(v,(tuple,list)):return [safe(x) for x in v]
 if isinstance(v,dict):return {str(k):safe(x) for k,x in v.items()}
 return repr(v)
def snapshot(c,obs):
 helpers={'wrapper':c,'fallback':getattr(c,'_fallback',None),'specialist':getattr(c,'_specialist',None)}
 fields=('_active','_wall_confirmed','_wall_ticks','_ready','_last_score','_receive_plan','_receive_aim','_relay_receive','_x_reception','_bank_receive','_chaser','_x_rush','_x_power_state','_runtime_path','_siege_obs')
 state={}
 for name,obj in helpers.items():
  if obj is None:continue
  state[name]={k:safe(getattr(obj,k,None)) for k in fields if k not in ('_runtime_path','_siege_obs')}
  state[name]['runtime_path_samples']=len(getattr(obj,'_runtime_path',None) or ())
  state[name]['siege_obs_tick']=getattr(getattr(obj,'_siege_obs',None),'tick',None)
 return dict(tick=obs.tick,score=obs.score,ball=dict(position=obs.ball.position,velocity=obs.ball.velocity,last_touch=obs.ball.last_touch,controlling_team=obs.ball.controlling_team),players=[dict(id=p.id,position=p.position,velocity=p.velocity,cooldown=p.kick_cooldown_ticks,can_kick=obs.can_kick(p.id)) for p in obs.my_players],controller=state)
def run(source,selected_tick,profiled,repeat):
 a=REG['sources'][source];b=REG['opponents']['milla-stress']
 for i in (a,b):assert digest(i['path'])==i['sha256']
 controllers=[load_controller(i['path']) for i in (a,b)]
 seed=3260277102;side=0;kickoff=1;slow=[];selected=None
 with SoccerEnv(config_path=REG['config_path'],max_ticks=2400,per_decision_timeout_ms=20.,team_ids=('policy_a','policy_b')) as env:
  for c in controllers:c.reset(seed)
  obs=env.reset(seed=seed,kickoff_team=kickoff)
  previous=[TeamController.idle(obs[k]) for k in ('team_a','team_b')]
  while not env.finished:
   actions={}
   for slot,key in enumerate(('team_a','team_b')):
    ob=obs[key];is_selected=slot==side and ob.tick==selected_tick
    if is_selected:
     before=snapshot(controllers[slot],ob);prof=cProfile.Profile() if profiled else None
     if prof:prof.enable()
     wall0=time.perf_counter_ns();cpu0=time.thread_time_ns()
    action,elapsed,error=runner._decide(controllers[slot],ob)
    if is_selected:
     cpu1=time.thread_time_ns();wall1=time.perf_counter_ns()
     if prof:prof.disable()
     selected=dict(before=before,after=snapshot(controllers[slot],ob),sdk_elapsed_ms=elapsed,error=error,outer_wall_ms=(wall1-wall0)/1e6,outer_thread_cpu_ms=(cpu1-cpu0)/1e6,debug=safe(getattr(action,'debug',None)))
     if prof:
      path=OUT/f'{source}-repeat{repeat}.pstats';prof.dump_stats(str(path));stats=pstats.Stats(prof)
      rows=[]
      for (file,line,function),(cc,nc,tt,ct,callers) in stats.stats.items():rows.append(dict(file=file,line=line,function=function,primitive_calls=cc,calls=nc,self_seconds=tt,cumulative_seconds=ct))
      selected['profile_functions']=sorted(rows,key=lambda r:-r['cumulative_seconds'])[:40]
      selected['profile_path']=path.name
    if error is None:previous[slot]=action
    else:action=previous[slot]
    if elapsed>20. or error is not None:slow.append(dict(side=slot,tick=ob.tick,elapsed_ms=elapsed,error=error))
    env.record_decision(slot,elapsed,error);actions[key]=action
   if env.finished:break
   obs,_=env.step(actions)
  result=env.result()
 row=dict(source=source,seed=seed,candidate_side=side,candidate_takes_kickoff=False,selected_tick=selected_tick,profiled=profiled,source_sha256=a['sha256'],opponent_sha256=b['sha256'],scope='diagnostic rerun; not additional qualification',selected=selected,slow=slow,result=result)
 path=OUT/f'{source}-repeat{repeat}.json'
 with path.open('x') as f:json.dump(row,f,indent=2)
 print(source,'profiled',profiled,'selected',None if selected is None else {k:selected[k] for k in ('sdk_elapsed_ms','outer_wall_ms','outer_thread_cpu_ms','error','debug')},'slow',slow,flush=True)
 return row

def main():
 rows=[run('nearpost',1777,profiled,i+1) for i,profiled in enumerate((False,True))]
 summary=dict(scope='two posthoc diagnostic repeats, not qualification; original27.5908ms failure retained',harness_sha256=digest(__file__),reruns=[dict(profiled=r['profiled'],selected=r['selected'],slow=r['slow'],score=r['result']['score']) for r in rows],cause='Unresolved: short repeats cannot establish the cause of the original stall.')
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
if __name__=='__main__':main()
