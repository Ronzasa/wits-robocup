"""Independent structural hypotheses. Frozen originals are never overwritten."""
from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/work/replay-finishing-handoffs/experiments/monster-13/uploaded/team.py')
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '1bf09f5fcab940eae8f387ef36030d302dfe9e52aa6ae0fe82f48742ea6e85b7'
base = raw.decode().replace('\r\n', '\n')

replacement = '''    def shell_act(self, obs, protected):
        """Independent reduced-cover experiment, using public observations only."""
        ball = (*obs.ball.position, *obs.ball.velocity)
        bx, by, vx, vy = ball
        if self.FIXED_OUTLET and self.outlet_side is None and bx<self.left+25 and abs(by)>3:
            self.outlet_side = 1 if by>0 else -1
        release_side = self.outlet_side if self.outlet_side is not None else (1 if by>=0 else -1)
        friends = [(p.id, *p.position, *p.velocity, p.kick_cooldown_ticks) for p in obs.my_players]
        opponents = [(p.id, *p.position, *p.velocity, p.kick_cooldown_ticks) for p in obs.opponents]
        covers = {0: 4.6, 1: 0.0, 3: -4.6} if self.HOME_COVERS==3 else {0: 3.4, 3: -3.4}
        runners = [p for p in friends if p[0] not in covers]
        path = self.path(*ball)
        races = {p[0]: self.race(p, path) for p in runners}
        chaser = min(runners, key=lambda p: races[p[0]][0]-(0.07 if p[0]==self.previous_chaser else 0))
        self.previous_chaser = chaser[0]
        carrier = min((p for p in runners if obs.can_kick(p[0])),
                      key=lambda p: math.hypot(p[1]-bx,p[2]-by), default=None)
        if carrier is not None:
            chaser = carrier
        targets = {chaser[0]: self.bound(*races[chaser[0]][1])}
        support = sorted((p for p in runners if p[0]!=chaser[0]),key=lambda p:p[2])
        for index,p in enumerate(support):
            side = (-release_side if len(support)==1 else (-1 if index==0 else 1))
            if bx<self.left+20:
                targets[p[0]] = self.bound(-16.0,side*17.0)
            else:
                targets[p[0]] = self.bound(bx+7.0,by*0.2+side*11.0)
        depth = self.LOCK_DEPTH if obs.score[0]>obs.score[1] else self.SHELL_DEPTH
        wall = sum(q[1]>self.right-3.5 and abs(q[2])<self.goal+1 for q in opponents)>=4
        outlet = max(runners,key=lambda p:p[1]-0.1*abs(p[2]-release_side*22.0))
        actions = TeamAction(debug={"text": "MONSTER reduced-cover experiment"})
        for p in friends:
            i = p[0]
            aim = (self.left+depth,covers[i]) if i in covers else targets[i]
            if self.ADAPTIVE_POSTS and bx<self.left+12 and abs(by)>4.0 and i==(0 if by>0 else 3):
                side = 1 if by>0 else -1
                aim = (max(self.left+self.pr+0.02,min(self.left+depth,bx-0.6)),
                       side*clip(abs(by),5.4,self.goal+2.5))
            movement = self.move(p,aim)
            kick = None
            if carrier is not None and i==carrier[0] and not protected:
                movement = self.move(p,(bx+0.3,by))
                stage = (self.right+1,(1 if by>=0 else -1)*(self.goal+1.3)) if wall else (self.right,0)
                best = self.duel(p,ball,opponents,movement)
                if best is None:
                    best = self.shot(p,ball,opponents,movement,wall)
                if best is None:
                    best = self.touch(p,ball,opponents,stage)
                if best:
                    _,kick,movement,_ = best
            elif i in covers and not protected and obs.can_kick(i):
                ux,uy = unit(max(-4.0,outlet[1]+5)-bx,release_side*22.0-by)
                kick = ((ux,uy),1.0)
            if protected and i not in covers and math.hypot(p[1],p[2])<self.circle+4:
                ux,uy = unit(p[1],p[2])
                movement = self.move(p,(ux*(self.circle+2.5),uy*(self.circle+2.5)))
            if kick:
                actions.kick(i,kick[0],kick[1],movement=movement)
            else:
                actions.move(i,movement)
        return actions

'''
manifest = {}
for name in ('baseline','open-play','three-cover','two-cover','adaptive'):
    if name=='baseline':
        data = raw
    elif name=='adaptive':
        data = Path('/workspace/work/div6-leader-20261026/opponents/champion-current/team.py').read_bytes()
    else:
        text = base.replace("version = 'v25-fast-post'",f"version = 'recovery-{name}-dev1'")
        if name=='open-play':
            text = text.replace('    SHELL = True\n','    SHELL = False\n')
        else:
            start,end = text.index('    def shell_act('),text.index('    def act(')
            text = text[:start]+replacement+text[end:]
            text = text.replace('    PRESSERS = 2\n',f'    PRESSERS = 2\n    HOME_COVERS = {3 if name=="three-cover" else 2}\n')
        data = text.encode()
    out = ROOT/'candidates'/name/'team.py'
    out.parent.mkdir(parents=True,exist_ok=True)
    assert not out.exists()
    out.write_bytes(data)
    manifest[name] = dict(path=str(out),sha256=hashlib.sha256(data).hexdigest())
(ROOT/'candidates.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
