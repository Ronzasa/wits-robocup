"""Restore the proven team12 decision engine, explicitly preserving its behavior.

This is the existing competition reference under a recovery submission name,
not another tactical challenger selected using qualification data.
"""
import ast
import hashlib
import json
from pathlib import Path

R=Path(__file__).resolve().parent
P=Path('/workspace/work/replay-finishing-handoffs')
source=(R/'candidates/adaptive/team.py').read_text()
assert hashlib.sha256(source.encode()).hexdigest()=='27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce'
before=ast.parse(source)
c=next(n for n in before.body if isinstance(n,ast.ClassDef) and n.name=='AdaptiveChampion')
for n in c.body:
    if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('name','version'):
        key=n.targets[0].id
        value='MONSTER Recovery - restored TITAN engine' if key=='name' else 'restore-team12-1.0'
        line=''.join(source.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
        source=source.replace(line,'    '+key+' = '+repr(value)+'\n',1)
source='"""Recovery submission: frozen TITAN Adaptive Counter decision engine.\n\nOnly the submission name/version changes. No experimental keeper or cover\nchanges are added. The original MONSTER13 and reference remain unchanged.\n"""\n'+source
after=ast.parse(source)
def behavior(tree):
    out=[]
    for c in tree.body:
        if not isinstance(c,ast.ClassDef):continue
        out.append((c.name,[ast.dump(n) for n in c.body if not (c.name=='AdaptiveChampion' and isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('name','version'))]))
    return out
assert behavior(before)==behavior(after)
# No decision code reads the metadata fields changed above.
assert not any(isinstance(n,ast.Attribute) and n.attr in ('name','version') for c in before.body if isinstance(c,ast.ClassDef) for n in ast.walk(c) if isinstance(n,ast.Attribute))
p=P/'experiments/monster-recovery/restored/team.py'
p.parent.mkdir(exist_ok=True)
p.write_text(source)
assert p.stat().st_size<262144
(R/'restoration-manifest.json').write_text(json.dumps(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),reference_sha256='27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce',bytes=p.stat().st_size,all_decision_methods_and_tactical_constants_equal=True,metadata_not_read_by_decision_code=True,scope='Behavior-identical copy of existing competition reference, not a new tactical challenger or promotion'),indent=2)+'\n')
print('Restored reference engine',p.stat().st_size,'bytes')
