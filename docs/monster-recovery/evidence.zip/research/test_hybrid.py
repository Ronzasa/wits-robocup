"""Mode-switch regressions, public observations only; no match outcomes asserted."""
import ast
import unittest
from pathlib import Path
from types import SimpleNamespace as N
from soccer import TeamAction, PlayerAction
from soccer.helpers import load_controller
import test_recovery as tr
R = tr.R

class Hybrid(tr.Recovery):
    def hybrid(self, remaining=19., score=(1,0), pending=False, kicking=False, control=1):
        c=load_controller(str(R/'candidates/late-cover/team.py'))
        o=self.obs(bx=-20.,score=score);o.time_remaining=remaining;o.ball.controlling_team=control
        a=TeamAction({i:PlayerAction(movement=(0.,0.)) for i in range(5)})
        if kicking:a.kick(4,(1.,0.),1.)
        fallback=N(_receive_plan=(2,4,o.tick+10) if pending else None,_relay_receive=None,_x_reception=None)
        c._attack=N(_fallback=fallback,_specialist=N(_receive_plan=None),act=lambda obs:a)
        return c,o,a

    def test_normal_play_is_exact_reference(self):
        c,o,a=self.hybrid(remaining=70.)
        self.assertIs(c.act(o),a)
        self.assertFalse(c._covering)

    def test_late_lead_only_enters_cover(self):
        c,o,a=self.hybrid()
        result=c.act(o)
        self.assertTrue(c._covering)
        self.assertEqual(result.debug['text'],'MONSTER four-cover counter')
        self.assertEqual(set(result.players),set(range(5)))

    def test_never_discards_reception_or_live_kick(self):
        for kw in ({'pending':True},{'kicking':True},{'control':0}):
            c,o,a=self.hybrid(**kw)
            self.assertIs(c.act(o),a)
            self.assertFalse(c._covering)

    def test_recovers_attack_when_lead_lost(self):
        c,o,a=self.hybrid();c.act(o);self.assertTrue(c._covering)
        o.score=(1,1);self.assertIs(c.act(o),a);self.assertFalse(c._covering)

    def test_specialist_reception_preserved(self):
        c,o,a=self.hybrid()
        c._attack._specialist._receive_plan=(2,3,o.tick+20)
        self.assertIs(c.act(o),a)
        self.assertFalse(c._covering)

    def test_embedded_physics_and_reference_methods_unchanged(self):
        def classes(path):
            return {c.name:c for c in ast.parse(path.read_text()).body if isinstance(c,ast.ClassDef)}
        original=classes(R/'candidates/adaptive/team.py')
        candidate=classes(R/'candidates/late-cover/team.py')
        for name,c in original.items():
            other='_AdaptiveReference' if name=='AdaptiveChampion' else name
            methods=lambda x:{n.name:ast.dump(n) for n in x.body if isinstance(n,ast.FunctionDef)}
            self.assertEqual(methods(c),methods(candidate[other]))
        original=classes(R/'candidates/baseline/team.py')['Monster']
        before={n.name:ast.dump(n) for n in original.body if isinstance(n,ast.FunctionDef)}
        for n in candidate['_MonsterCover'].body:
            if isinstance(n,ast.FunctionDef):self.assertEqual(before[n.name],ast.dump(n))
        self.assertLess((R/'candidates/late-cover/team.py').stat().st_size,256*1024)

if __name__=='__main__':unittest.main()
