"""Re-run a registered panel after extracting evidence.zip.

Supply a complete repository and the installed official native SDK. Source
files are located by frozen SHA256, never by a controller's display name.
The only registration changes are local source/config paths and scope.
"""
import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,required=True)
    p.add_argument('--evidence',type=Path,required=True)
    p.add_argument('--cohort',choices=['screen','structural-field','qualification'],required=True)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    original=args.evidence/args.cohort/'registration.json'
    reg=json.loads(original.read_text())
    files={hashlib.sha256(f.read_bytes()).hexdigest():f.resolve() for f in args.evidence.rglob('*.py')}
    for group in ('sources','opponents'):
        for item in reg[group].values():
            item['path']=str(files[item['sha256']])
    reg['config_path']=str(args.repo.resolve()/'configs/default.toml')
    reg['scope']='Reproduction of '+reg['scope']
    args.out.mkdir()
    (args.out/'registration.json').write_text(json.dumps(reg,indent=2)+'\n')
    source=(args.evidence/'research/batch.py').read_text()
    # Relocate the original driver's import root. The policy, loop and deadline
    # remain identical; retain both driver hashes in reproduction metadata.
    old="REPO=Path('/workspace/work/replay-finishing-handoffs')"
    assert old in source
    source=source.replace(old,'REPO=Path('+repr(str(args.repo.resolve()))+')',1)
    target=args.out/'relocated-batch.py'
    target.write_text(source)
    (args.out/'reproduction-provenance.json').write_text(json.dumps(dict(
        original_registration_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
        original_harness_sha256=hashlib.sha256((args.evidence/'research/batch.py').read_bytes()).hexdigest(),
        relocated_harness_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
        changes='Source/config paths only; simulator, SDK, policies, seeds, sides, kickoff, accounting and20ms unchanged.'),indent=2)+'\n')
    subprocess.run([sys.executable,str(target),str(args.out.resolve())],check=True)

if __name__=='__main__':main()
