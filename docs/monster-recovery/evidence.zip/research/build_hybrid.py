"""Compose frozen public-observation policies without altering their physics."""
import ast
import hashlib
import json
from pathlib import Path

R=Path(__file__).resolve().parent
source=(R/'candidates/adaptive/team.py').read_text()
assert hashlib.sha256(source.encode()).hexdigest()=='27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce'
reference=ast.parse(source)
last=next(c for c in reference.body if isinstance(c,ast.ClassDef) and c.name=='AdaptiveChampion')
last.name='_AdaptiveReference'
last.bases=[]
monster=ast.parse((R/'candidates/baseline/team.py').read_text())
core=next(c for c in monster.body if isinstance(c,ast.ClassDef))
core.name='_MonsterCover'
core.bases=[]
core.body=[n for n in core.body if not isinstance(n,ast.FunctionDef) or n.name not in ('initial_formation','passing','lock','act')]
wrapper='''
class MonsterRecovery(TeamController):
    name = 'MONSTER Recovery'
    version = 'adaptive-late-cover-dev1'

    def __init__(self):
        self._attack = _AdaptiveReference()
        self._cover = _MonsterCover()
        self.reset(0)

    def reset(self, seed):
        self._attack.reset(seed)
        self._cover.reset(seed)
        self._covering = False
        self._last_score = None
        self._restart_until = -1
        self._restart_owner = None

    def initial_formation(self, field):
        return self._attack.initial_formation(field)

    def act(self, obs):
        deadline = perf_counter()+0.007
        score = tuple(obs.score)
        if score != self._last_score:
            self._restart_until = obs.tick + int(3*obs.field.simulation_hz)
            self._restart_owner = obs.ball.controlling_team
            self._last_score = score
        if math.hypot(*obs.ball.position)>0.5 or math.hypot(*obs.ball.velocity)>0.1:
            self._restart_until = -1
        protected = obs.tick<self._restart_until and self._restart_owner==1
        eligible = score[0]>score[1] and obs.time_remaining<=20.0 and not protected
        if self._covering and not eligible:
            self._covering = False
        if not self._covering:
            actions = self._attack.act(obs)
            fallback = self._attack._fallback
            specialist = self._attack._specialist
            plans = (fallback._receive_plan,fallback._relay_receive,fallback._x_reception,
                     specialist._receive_plan)
            pending = any(plan is not None and plan[2]>=obs.tick for plan in plans)
            kicking = any(action.kick_direction is not None for action in actions.players.values())
            # Do not discard a launched reception or the current possession action.
            if not eligible or pending or kicking or obs.ball.controlling_team==0:
                return actions
            self._covering = True
        if not self._cover.ready:
            self._cover.setup(obs.field)
        self._cover.deadline = deadline
        return self._cover.shell_act(obs,protected)
'''
helpers=[n for n in monster.body if isinstance(n,ast.FunctionDef)]
tree=ast.Module(body=reference.body+[ast.ImportFrom(module='time',names=[ast.alias(name='perf_counter')],level=0)]+helpers+[core]+ast.parse(wrapper).body,type_ignores=[])
out=ast.unparse(ast.fix_missing_locations(tree))+'\n'
p=R/'candidates/late-cover/team.py';p.parent.mkdir(exist_ok=True)
assert not p.exists()
p.write_text(out)
assert p.stat().st_size<256*1024
assert sum(isinstance(n,ast.ClassDef) and any(isinstance(b,ast.Name) and b.id=='TeamController' for b in n.bases) for n in tree.body)==1
(R/'hybrid-manifest.json').write_text(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Frozen team12 adaptive public policy plus original Monster cover only when leading inside last20s; no physics changes'),indent=2)+'\n')
print('Created',p.stat().st_size,'bytes')
