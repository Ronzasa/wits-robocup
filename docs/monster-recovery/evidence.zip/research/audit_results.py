"""Independent raw-data audit; fixed seed blocks, no qualification tuning."""
import hashlib
import json
import random
import sys
from collections import defaultdict
from pathlib import Path

R=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/work/replay-finishing-handoffs/tools/benchmarks')
from benchmark import aggregate,points

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name):
    p=R/name
    reg=json.loads((p/'registration.json').read_text())
    rows=[json.loads(s) for s in (p/'matches.jsonl').read_text().splitlines()]
    metadata=json.loads((p/'metadata.json').read_text())
    assert metadata['registration_sha256']==digest(p/'registration.json')
    assert metadata['harness_sha256']==digest(R/'batch.py')
    assert metadata['driver_sha256']==digest('/workspace/work/replay-finishing-handoffs/tools/benchmarks/default_roster.py')
    expected={(n,o,seed,side,kick) for n in reg['sources'] for o in reg['opponents'] for seed in reg['seeds'] for side in (0,1) for kick in (True,False)}
    actual=set()
    for row in rows:
        key=(row['source'],row['opponent_name'],row['seed'],row['candidate_slot'],row['candidate_takes_kickoff'])
        assert key in expected and key not in actual,key
        actual.add(key)
        result=row['result']
        assert result['ticks']==2400 and result['terminal_reason']=='time_limit'
        assert result['engine_version']==reg['engine_version'] and result['config_hash']==reg['config_hash']
        assert result['kickoff_team']==(row['candidate_slot'] if row['candidate_takes_kickoff'] else 1-row['candidate_slot'])
        for side in (0,1):
            stats=result['stats'][side]
            raw=[s for s in row['telemetry']['slow'] if s['side']==side and s['elapsed_ms']>20.]
            assert len(raw)==stats['policy_timeouts'],(key,side,'raw-timeout accounting')
            failures=[s for s in row['telemetry']['slow'] if s['side']==side and s['error'] is not None]
            assert len(failures)==stats['policy_errors'],(key,side,'raw-exception accounting')
    assert actual==expected,(name,len(actual),len(expected))
    for item in list(reg['sources'].values())+list(reg['opponents'].values()):assert digest(item['path'])==item['sha256']
    return reg,rows

def comparison(rows,source,reference):
    key=lambda r:(r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])
    a={key(r):r for r in rows if r['source']==source}
    b={key(r):r for r in rows if r['source']==reference}
    assert set(a)==set(b)
    blocks=defaultdict(list)
    for k,row in a.items():blocks[row['seed']].append(points(row)-points(b[k]))
    means=[sum(v)/len(v) for _,v in sorted(blocks.items())]
    rng=random.Random(4127068007)
    samples=sorted(sum(rng.choices(means,k=len(means)))/len(means) for _ in range(20000))
    aa=aggregate(list(a.values()));bb=aggregate(list(b.values()))
    per_style={op:sum(points(v)-points(b[k]) for k,v in a.items() if v['opponent_name']==op)/sum(v['opponent_name']==op for v in a.values()) for op in sorted({r['opponent_name'] for r in a.values()})}
    return dict(points_difference_per_fixture=(aa['points']-bb['points'])/len(a),seed_block_95=[samples[500],samples[19499]],additional_raw_misses_per1000=(aa['policy_timeouts']-bb['policy_timeouts'])*1000/len(a),per_style_difference_ppf=per_style)

def main():
    cohorts={n:load(n) for n in ('screen','structural-field','qualification')}
    reg,rows=cohorts['qualification']
    summary={n:aggregate([r for r in rows if r['source']==n]) for n in reg['sources']}
    paired={n:comparison(rows,'challenger',n) for n in ('baseline','adaptive')}
    cumulative=defaultdict(list)
    reliability=[]
    for cohort,(_,rs) in cohorts.items():
        for row in rs:
            label=row['source']
            if label=='nearpost':label='challenger'
            if label in ('baseline','adaptive','challenger'):cumulative[label].append(row)
            for slot,s in enumerate(row['result']['stats']):
                for event in row['telemetry']['slow']:
                    if event['side']==slot:
                        reliability.append(dict(cohort=cohort,source=row['source'],opponent=row['opponent_name'],seed=row['seed'],candidate_side=row['candidate_slot'],kickoff=row['candidate_takes_kickoff'],role='source' if slot==row['candidate_slot'] else 'opponent',**event))
    cum={n:dict(fixtures=len(rs),raw_misses=sum(r['result']['stats'][r['candidate_slot']]['policy_timeouts'] for r in rs),exceptions=sum(r['result']['stats'][r['candidate_slot']]['policy_errors'] for r in rs)) for n,rs in cumulative.items()}
    cumdiff={n:1000*(cum['challenger']['raw_misses']/cum['challenger']['fixtures']-cum[n]['raw_misses']/cum[n]['fixtures']) for n in ('baseline','adaptive')}
    intake=json.loads((R/'finalist-intake.json').read_text())
    gates=dict(positive_points_lower_vs_both=all(v['seed_block_95'][0]>0 for v in paired.values()),zero_exceptions=summary['challenger']['policy_errors']==0 and cum['challenger']['exceptions']==0,qualification_raw_miss_rate=all(v['additional_raw_misses_per1000']<=2 for v in paired.values()),cumulative_raw_miss_rate=all(v<=2 for v in cumdiff.values()),style_gate=all(min(v['per_style_difference_ppf'].values())>=-.25 for v in paired.values()),official_intake=intake['ok'],code_limit=Path(reg['sources']['challenger']['path']).stat().st_size<=262144)
    output=dict(cohort_sizes={n:len(v[1]) for n,v in cohorts.items()},qualification_summary=summary,paired_vs_references=paired,reference_restoration_vs_monster=comparison(rows,'adaptive','baseline'),cumulative_reliability=cum,cumulative_additional_raw_misses_per1000=cumdiff,all_slow_events=reliability,gates=gates,all_gates_pass=all(gates.values()),promote=False,scope='No active files or protected branches changed; statistical selection uses development only, qualification frozen before first fixture.')
    (R/'final-audit.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))

if __name__=='__main__':main()
