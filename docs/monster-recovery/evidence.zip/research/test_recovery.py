"""Bounded action and isolation regressions; synthetic states are not match evidence."""
import ast
import math
import unittest
from pathlib import Path
from types import SimpleNamespace as N
from soccer import SoccerEnv
from soccer.helpers import load_controller

R = Path(__file__).resolve().parent

class Recovery(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with SoccerEnv() as env:
            cls.field = env.field

    def controller(self, name):
        c = load_controller(str(R/'candidates'/name/'team.py'))
        c.reset(1)
        c.setup(self.field)
        return c

    def obs(self, bx=0., by=0., ready=(), score=(0,0)):
        def p(i,x,y):
            return N(id=i,position=(x,y),velocity=(0.,0.),kick_cooldown_ticks=0)
        return N(field=self.field,tick=200,score=score,
                 my_players=[p(0,-48.8,5.4),p(1,-48.8,-1.8),p(2,-15.,-10.),p(3,-48.8,-5.4),p(4,bx-1.,by)],
                 opponents=[p(i+5,x,y) for i,(x,y) in enumerate([(48.,0.),(10.,-5.),(10.,5.),(20.,12.),(20.,-12.)])],
                 ball=N(position=(bx,by),velocity=(0.,0.),controlling_team=0,last_touch=None),
                 can_kick=lambda i:i in ready)

    def test_original_is_unchanged(self):
        import hashlib
        self.assertEqual(hashlib.sha256((R/'candidates/baseline/team.py').read_bytes()).hexdigest(),
                         '1bf09f5fcab940eae8f387ef36030d302dfe9e52aa6ae0fe82f48742ea6e85b7')

    def test_only_formation_policy_changes(self):
        def methods(name):
            tree = ast.parse((R/'candidates'/name/'team.py').read_text())
            cls = next(n for n in tree.body if isinstance(n,ast.ClassDef))
            return {n.name:ast.dump(n) for n in cls.body if isinstance(n,ast.FunctionDef)}
        before = methods('baseline')
        for name in ('open-play','two-cover','three-cover'):
            for key,value in methods(name).items():
                if name!='open-play' and key=='shell_act':
                    continue
                self.assertEqual(before[key],value,(name,key))

    def test_all_actions_are_bounded_and_complete(self):
        for name in ('open-play','three-cover','two-cover'):
            for bx,by in ((-48.,0.),(-20.,-26.),(0.,0.),(25.,12.),(48.,6.)):
                action = self.controller(name).act(self.obs(bx,by))
                self.assertEqual(set(action.players),set(range(5)))
                for p in action.players.values():
                    self.assertTrue(all(math.isfinite(v) for v in p.movement))
                    self.assertLessEqual(math.hypot(*p.movement),1.000001)

    def test_enemy_restart_never_kicks(self):
        for name in ('two-cover','three-cover'):
            obs = self.obs(ready=range(5));obs.ball.controlling_team=1
            result = self.controller(name).act(obs)
            self.assertTrue(all(p.kick_direction is None for p in result.players.values()))

    def test_only_one_attacking_carrier_kicks(self):
        for name in ('two-cover','three-cover'):
            c=self.controller(name);obs=self.obs(bx=25.,ready=(2,4))
            a=c.shell_act(obs,False)
            self.assertIsNotNone(a.players[4].kick_direction)
            self.assertIsNone(a.players[2].kick_direction)

    def test_reduced_cover_has_real_forward_support(self):
        obs=self.obs(bx=10.)
        c=self.controller('three-cover');a=c.shell_act(obs,False)
        self.assertGreater(a.players[2].movement[0],0.)
        b=self.controller('baseline').shell_act(obs,False)
        self.assertLess(b.players[2].movement[0],0.)
        # The primary goal-line players continue to guard both posts.
        self.assertEqual(a.players[0].movement[0],b.players[0].movement[0])
        self.assertEqual(a.players[3].movement[0],b.players[3].movement[0])

    def test_reset_clears_match_state(self):
        c=self.controller('two-cover');c.shell_act(self.obs(-40.,12.),False)
        self.assertIsNotNone(c.outlet_side)
        c.reset(2)
        self.assertIsNone(c.outlet_side)
        self.assertIsNone(c.previous_chaser)

if __name__=='__main__':
    unittest.main()
