"""Shadow the frozen reference on identical public native observations.

Behavior regression only. Shadow timings are not tournament reliability data.
The real native match retains official20ms enforcement and default rosters.
"""
import hashlib
import json
from pathlib import Path
from soccer import SoccerEnv,TeamController,runner
from soccer.helpers import load_controller

R=Path(__file__).resolve().parent
P=Path('/workspace/work/replay-finishing-handoffs')
reference=P/'experiments/monster-recovery/reference/team.py'
restore=P/'experiments/monster-recovery/restored/team.py'
rows=[]
for op in ('v10-compact','v10-press'):
    opponent=Path('/workspace/work/div6-leader-20261026/opponents')/op/'team.py'
    for seed in (4127069101,4127069102):
        for side in (0,1):
            for own_kickoff in (True,False):
                paths=[reference,opponent]
                if side:paths.reverse()
                controllers=[load_controller(str(p)) for p in paths]
                shadow=load_controller(str(restore))
                for c in controllers+[shadow]:c.reset(seed)
                count=0
                with SoccerEnv(config_path=str(P/'configs/default.toml'),max_ticks=2400,per_decision_timeout_ms=20.) as env:
                    obs=env.reset(seed=seed,kickoff_team=side if own_kickoff else 1-side)
                    previous=[TeamController.idle(obs[k]) for k in ('team_a','team_b')]
                    while not env.finished:
                        actions={}
                        for slot,key in enumerate(('team_a','team_b')):
                            a,elapsed,error=runner._decide(controllers[slot],obs[key])
                            if slot==side:
                                b,shadow_elapsed,shadow_error=runner._decide(shadow,obs[key])
                                assert error is None and shadow_error is None,(seed,op,side,obs[key].tick,error,shadow_error)
                                encode=lambda a:{pid:v.as_dict() for pid,v in a.players.items()}
                                assert encode(a)==encode(b),(seed,op,side,own_kickoff,obs[key].tick)
                                count+=1
                            if error is None:previous[slot]=a
                            else:a=previous[slot]
                            env.record_decision(slot,elapsed,error)
                            actions[key]=a
                        if env.finished:break
                        obs,_=env.step(actions)
                    result=env.result()
                rows.append(dict(opponent=op,seed=seed,side=side,own_kickoff=own_kickoff,identical_decisions=count,result=result))
                print('identical',len(rows),op,seed,side,own_kickoff,count,flush=True)
report=dict(scope='16 native behavior regressions, not qualification or independent strength estimates',source_sha256=hashlib.sha256(restore.read_bytes()).hexdigest(),reference_sha256=hashlib.sha256(reference.read_bytes()).hexdigest(),fixtures=len(rows),identical_decisions=sum(r['identical_decisions'] for r in rows),identical_player_commands=sum(r['identical_decisions'] for r in rows)*5,all_equal=True,rows=rows)
(R/'restore-equivalence.json').write_text(json.dumps(report,indent=2)+'\n')
