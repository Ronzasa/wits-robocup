"""Generate the decision report from audited native results, never hand totals."""
import json
from pathlib import Path

R=Path(__file__).resolve().parent
P=Path('/workspace/work/replay-finishing-handoffs')
report=json.loads((R/'final-audit.json').read_text())
screen=json.loads((R/'screen/summary.json').read_text())
dev=json.loads((R/'structural-field/summary.json').read_text())
q=report['qualification_summary']
fmt=lambda n:f"{n:,}"
rows=lambda summary:'\n'.join(f"| {name} | {s['matches']} | {s['points']} | {s['wins']}–{s['draws']}–{s['losses']} | {s['goals_for']}–{s['goals_against']} | {s['policy_errors']} | {s['policy_timeouts']} | {s['decision_mean_ms']:.3f} / {s['decision_max_ms']:.3f} |" for name,s in summary.items())
tablehead='| Controller | Matches | Points | W–D–L | Goals for–against | Exceptions | Raw deadline misses | Mean / max ms |\n|---|---:|---:|---|---|---:|---:|---|'
comparisons='\n'.join(f"| challenger − {ref} | {v['points_difference_per_fixture']:+.4f} | [{v['seed_block_95'][0]:+.4f}, {v['seed_block_95'][1]:+.4f}] | {v['additional_raw_misses_per1000']:+.3f} |" for ref,v in report['paired_vs_references'].items())
styles='\n'.join(f"| {op} | {report['paired_vs_references']['baseline']['per_style_difference_ppf'][op]:+.4f} | {report['paired_vs_references']['adaptive']['per_style_difference_ppf'][op]:+.4f} |" for op in sorted(report['paired_vs_references']['baseline']['per_style_difference_ppf']))
gates='\n'.join(f"- {key}: **{'PASS' if value else 'FAIL'}**" for key,value in report['gates'].items())
verdict='The repair passes every registered local gate. It is a candidate for user approval; no active champion is promoted.' if report['all_gates_pass'] else 'The repair fails one or more registered gates and is not an accepted upgrade. Do not promote it.'
restore=report['reference_restoration_vs_monster']
equivalence=json.loads((R/'restore-equivalence.json').read_text())
recommendation='The experimental repair is eligible for user review.' if report['all_gates_pass'] else '**Use [restored/team.py](../../experiments/monster-recovery/restored/team.py) for the recovery.** It restores the frozen team12 reference engine, with only the display name/version and explanatory header changed. It introduces no unproven tactical changes and claims no improvement beyond that reference.'
text=f'''# MONSTER Recovery: leaderboard diagnosis and native qualification

{verdict}

{recommendation}

The user reports that MONSTER performs worse than team12. They tentatively identified `sandbox-champion-hunt` as team12 ("i think so"). This study therefore uses that branch's frozen controller as the **provisional** team12 reference. The archive does not contain a team12 source file or a submission source hash, so the identity cannot be established from the archive alone.

`main`, `sandbox-champion-hunt`, `my-team/team.py`, archived champions, and the original uploaded MONSTER remain unchanged. All work belongs to experimental branch `monster-recovery`.

## Evidence supplied by the user

`download.zip` contains a HAR named `download.devtools`, with a team statistics response and no match replays. Only a selected own-team summary is published. HAR requests, headers, cookies, credentials, HTML and the full team response remain excluded.

The snapshot reports rank168/270, division9, 951points from1012games (248W–207D–557L), 1005–1420goals, zero exceptions and15timeouts. Completed passes rank247, shots218, territory261 and blocks3. Entrant version1 is not a controller hash. These cumulative statistics do not establish attribution of every event to MONSTER13.

MONSTER sets `SHELL=True` and `SHELL_RELEASE=False`. Its `act()` therefore bypasses normal multi-player attacking and reception logic in favor of four home coverers and one outlet. Being good at blocks is not sufficient to win. The earlier review also found the uploaded MONSTER weaker over a broad opponent panel: see [the original review](../monster-13/README.md).

## Independent structural tests

Two new development seeds, four opponents, both sides and both kickoff arrangements:160full native fixtures,32per controller. No tactical variants were combined.

{tablehead}
{rows(screen['summary'])}

`open-play` only disables MONSTER's shell. `three-cover` and `two-cover` independently release extra runners, retain MONSTER's original touch, shot, duel and movement physics, and allow only one attacking carrier to kick. All three lost points and were rejected. Removing the cover does not make the isolated attack engine as strong as team12.

## Broader development and frozen selection

Two further exposed development seeds, eight opponents, all four side/kickoff arrangements:256full fixtures,64per source.

{tablehead}
{rows(dev['summary'])}

`late-cover` embeds frozen team12 normal play and original MONSTER cover. It switches only while leading inside the final20s, defers active receptions, existing kicks and friendly control, and returns to attack if the lead disappears. It scored98vs99for team12 and was rejected. It retains one SDK subclass and stays below the256KiB limit. Two initial adapter prototypes failed public intake because of missing helper/state names; both failures and corrected sources are retained. They were fixed before any tournament. The corrected adapter passed intake but was still rejected on competitive results.

`nearpost` reuses an independently screened keeper package from the previous division6 replay investigation. Its components were separately tested there before combination; they are not newly isolated causal tests in this study. It preserves team12 attacking code while removing the automatic five-player wall after falling two goals behind, guarding contested keeper clearances with contact-aware checks/braking, and positioning the keeper earlier at the near post. Historical component evidence remains in [the previous evidence archive](../monster-13/evidence.zip).

The selected development source scored118points vs99for team12 and80for MONSTER. Its name/version metadata was updated for the frozen candidate; every method AST is identical to the tested development parent. Source and selection are recorded in `finalist-manifest.json` and `qualification-plan.json`. This is a team12-based repair, not a claim that freeing MONSTER's runners solved its attack.

One development decision exceeded20ms:27.590792ms at tick1777, seed3260277102, against the Milla stress surrogate, side0 with opposing kickoff. Two diagnostic native repeats did not reproduce the stall:1.513178ms unprofiled (thread CPU1.515293ms),4.563952ms with profiling. The original event remains counted. Its cause is unresolved; clean repeats do not prove an environmental cause. Diagnostic profiles never contribute qualification timing evidence.

## Untouched qualification

The candidate and both references were frozen before the first fixture. Sixteen untouched seeds4127068101–4127068116; nine opponents; both sides and kickoff arrangements; **1728full fixtures,576per source**. The panel includes original MONSTER, provisional team12, v10, v9.1, v10-counter, v10-press, v10-compact, strong-replay, and the explicitly approximate Milla-stress surrogate. It does not contain the actual Milla controller. No qualification results were used to retune or select another challenger, and there was no optional extension or early stop.

{tablehead}
{rows(q)}

The repair scored 1,239 goals versus the reference's 729, but conceded 697 versus 640 and won 315 matches versus 323. The extra goals did not increase league points. Its qualification timing was clean, while the reference recorded one raw 21.980773 ms miss. The recovery file's own public intake had zero exceptions and zero deadline misses; the reference's benchmark miss remains part of its evidence.

The columns above are separate controllers against identical common fixtures. They are not complementary head-to-head totals. Confidence intervals below resample complete seed blocks (20,000draws, fixed RNG). Fixtures with the same seed are not counted as independent samples.

| Paired comparison | Points difference per fixture | Seed-block95% interval | Additional raw misses/1000fixtures |
|---|---:|---|---:|
{comparisons}

The frozen team12 reference versus MONSTER itself has a paired difference of **{restore['points_difference_per_fixture']:+.4f}points/fixture**,95% interval **[{restore['seed_block_95'][0]:+.4f}, {restore['seed_block_95'][1]:+.4f}]**. Retaining or returning to this reference is a choice of existing control, not selection of another experimental challenger using qualification data.

| Opponent | Challenger − MONSTER points/fixture | Challenger − team12 points/fixture |
|---|---:|---:|
{styles}

The registered gates require a positive paired95% lower bound against **both** references, zero exceptions, no more than two additional raw misses/1000fixtures in both qualification and cumulative current-study exact-behavior exposure, no opponent-style decline greater than0.25points/fixture against either reference, successful official intake and the256KiB code limit.

{gates}

Cumulative raw accounting includes development and qualification, including the original27.59ms event. See `results/final-audit.json` for every slow event on either side and the exact denominators. Failed adapter prototypes and instrumented diagnostic repeats are explicitly separate from frozen-policy tournament reliability.

## Reproduction and constraints

The restored submission was prepared as a behavior-identical copy of the existing control, not selected as another tactical challenger. Its method and tactical-constant ASTs match the reference exactly, and decision code does not read the changed name/version. In16additional native behavior-regression fixtures, it issued **{equivalence['identical_decisions']:,}identical team decisions / {equivalence['identical_player_commands']:,}identical player commands** on the same public observations, across both sides/kickoffs, two fresh seeds and two opponents. This is an equivalence check, not another strength or timing qualification; the reference's tournament numbers are not counted twice. Its own final file also passes official intake.

Every research fixture uses the official native engine0.1.0, config372990895c7eca2a,2400ticks and unchanged20ms enforcement. Exactly one timed worker runs at a time. There are no simulator edits, hidden-state inputs, deadline changes, GC/affinity tricks or opponent changes. Default rosters match the previously supplied course replays. Optional custom formation hooks are exercised separately by official intake; default-roster tournament findings do not establish identical outcomes under all formation profiles.

The candidate is [experiments/monster-recovery/challenger/team.py](../../experiments/monster-recovery/challenger/team.py). It is experimental and has not replaced the active submission. The frozen provisional team12 source is [reference/team.py](../../experiments/monster-recovery/reference/team.py).

The evidence archive includes registrations, frozen sources, raw native rows, summaries, action/AST regressions, intake reports, timing diagnostics and the independent audit. Extract it and use a complete course repository/SDK:

```sh
PYTHONPATH=/path/to/student-sdk python research/reproduce.py \\
  --repo /path/to/wits-robocup --evidence . \\
  --cohort qualification --out /tmp/monster-recovery-reproduction
```

This reconstructs the registered panel by SHA256. Only local paths are relocated. All seeds, policies, official timing and fixtures stay fixed. Hardware scheduling can change wall times; raw misses from this study remain in the archive.
'''
replacements={
 'rank168/270':'rank 168/270','division9':'division 9','951points from1012games':'951 points from 1,012 games',
 '1005–1420goals':'1,005–1,420 goals','and15timeouts':'and 15 timeouts','rank247':'rank 247',
 'shots218':'shots 218','territory261':'territory 261','blocks3':'blocks 3','version1':'version 1',
 'arrangements:160full native fixtures,32per controller':'arrangements: 160 full native fixtures, 32 per controller',
 'arrangements:256full fixtures,64per source':'arrangements: 256 full fixtures, 64 per source',
 'final20s':'final 20 seconds','scored98vs99for':'scored 98 versus 99 for','the256KiB':'the 256 KiB',
 'division6':'division 6','scored118points vs99for team12 and80for':'scored 118 points versus 99 for team12 and 80 for',
 'exceeded20ms:27.590792ms at tick1777, seed3260277102':'exceeded 20 ms: 27.590792 ms at tick 1777, seed 3260277102',
 'side0':'side 0','stall:1.513178ms':'stall: 1.513178 ms','CPU1.515293ms),4.563952ms':'CPU 1.515293 ms), 4.563952 ms',
 'seeds4127068101':'seeds 4127068101','**1728full fixtures,576per source**':'**1,728 full fixtures, 576 per source**',
 '20,000draws':'20,000 draws','Seed-block95%':'Seed-block 95%','misses/1000fixtures':'misses/1,000 fixtures',
 'points/fixture**,95%':' points/fixture**, 95%','paired95%':'paired 95%',
 'than0.25points/fixture':'than 0.25 points/fixture','original27.59ms':'original 27.59 ms',
 'In16additional':'In 16 additional','38,400identical':'38,400 identical','192,000identical':'192,000 identical',
 'engine0.1.0, config372990895c7eca2a,2400ticks and unchanged20ms':'engine 0.1.0, config 372990895c7eca2a, 2,400 ticks and unchanged 20 ms',
 'current-study exact-behavior exposure':'all current-study runs using the same decision code',
}
for before,after in replacements.items():text=text.replace(before,after)
out=P/'docs/monster-recovery';out.mkdir(parents=True,exist_ok=True)
(out/'README.md').write_text(text)
index=P/'experiments/monster-recovery/README.md'
index.write_text('''# MONSTER Recovery files

'''+recommendation+'''

- `restored/team.py`: restores the existing team12 reference decision engine under a recovery name; no new tactical behavior.
- `reference/team.py`: byte-for-byte frozen `sandbox-champion-hunt` reference, provisionally identified by the user as team12.
- `challenger/team.py`: independently qualified keeper-repair experiment; see the gate decision before using it.
- `rejected/late-cover/team.py`: rejected late-cover combination.

Full native results and decision: [report](../../docs/monster-recovery/README.md).
''')
print('Generated',out/'README.md')
