"""Publish an allowlisted, checksummed archive. Never include HAR metadata."""
import hashlib
import json
import zipfile
from pathlib import Path

R=Path(__file__).resolve().parent
P=Path('/workspace/work/replay-finishing-handoffs')
OUT=P/'docs/monster-recovery'
OUT.mkdir(parents=True,exist_ok=True)
items={}
def add(p,name=None):
    p=Path(p)
    assert p.is_file(),p
    n=name or p.relative_to(R).as_posix()
    assert not any(bad in n.lower() for bad in ('private','download.devtools','download.zip','.har','__pycache__','.pyc'))
    assert n not in items,n
    items[n]=p.read_bytes()

for name in ['batch.py','register.py','build.py','build_hybrid.py','build_restore.py','verify_restore.py','test_recovery.py','test_hybrid.py','audit_results.py','make_report.py','package_evidence.py','reproduce.py']:
    add(R/name,'research/'+name)
for name in ['candidates.json','hybrid-manifest.json','finalist-manifest.json','restoration-manifest.json','restore-equivalence.json','restore-equivalence.log','restored-intake.json','submission-review.json','qualification-plan.json','leaderboard-summary.json','final-audit.json','protected-sources.json','regressions.log','regressions-final.log','hybrid-regressions.log','keeper-regressions.json','late-cover-intake-failed.json','late-cover-intake-failed-v2.json','late-cover-intake.json','nearpost-intake.json','finalist-intake.json','late-cover-draft.py','late-cover-intake-failed.py','late-cover-intake-failed-v2.py']:
    add(R/name)
for root in ['candidates','opponents']:
    for path in sorted((R/root).rglob('team.py')):add(path)
for cohort in ['screen','structural-field','qualification']:
    for name in ['registration.json','metadata.json','matches.jsonl','summary.json','run.log']:add(R/cohort/name)
    sources=json.loads((R/cohort/'registration.json').read_text())['opponents']
    for name,item in sources.items():
        key='opponents/'+name+'/team.py'
        if key in items:
            assert hashlib.sha256(items[key]).hexdigest()==item['sha256']
        else:add(item['path'],key)
for path in sorted((R/'runtime-diagnostics').iterdir()):
    if path.suffix in ('.py','.json','.log','.pstats'):add(path)
add(P/'experiments/monster-recovery/challenger/team.py','finalist/team.py')
add(P/'experiments/monster-recovery/restored/team.py','restored/team.py')
manifest={n:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for n,data in sorted(items.items())}
items['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=OUT/'evidence.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(items.items()):z.writestr(name,data)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(items)
    for name,entry in manifest.items():
        b=z.read(name)
        assert len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256']
outer=dict(archive='evidence.zip',bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),payload_files=len(manifest),files=manifest,excluded=['uploaded archive and raw HAR','request headers/cookies/URLs/HTML','full team response','Python caches','unrelated work'])
(OUT/'evidence-manifest.json').write_text(json.dumps(outer,indent=2)+'\n')
results=OUT/'results';results.mkdir(exist_ok=True)
for name,path in [('final-audit.json',R/'final-audit.json'),('leaderboard-summary.json',R/'leaderboard-summary.json'),('qualification-plan.json',R/'qualification-plan.json'),('finalist-intake.json',R/'finalist-intake.json'),('restored-intake.json',R/'restored-intake.json'),('restore-equivalence.json',R/'restore-equivalence.json'),('timing-diagnostics.json',R/'runtime-diagnostics/summary.json')]:
    (results/name).write_bytes(path.read_bytes())
for cohort in ['screen','structural-field','qualification']:
    (results/(cohort+'.json')).write_bytes((R/cohort/'summary.json').read_bytes())
print(json.dumps({k:outer[k] for k in ['bytes','sha256','payload_files']},indent=2))
