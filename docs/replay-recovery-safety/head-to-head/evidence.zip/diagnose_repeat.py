"""Exact native timing repeat; never substitutes for a scheduled raw result."""
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parent
sys.path[:0]=['/workspace/work/exploit-lab/student-sdk',
              '/workspace/work/replay-finishing-handoffs/tools/benchmarks']
from soccer import runner
from benchmark import run_fixture

reg=json.loads((ROOT/'registration.json').read_text())
rows=[json.loads(x) for x in (ROOT/'matches.jsonl').read_text().splitlines()]
output=[]
for original_row in rows:
    if not original_row['slow_decisions']:
        continue
    fixture={k:original_row[k] for k in ('seed','candidate_slot','candidate_takes_kickoff')}
    fixture.update(team=reg['sources']['new']['path'],
                   opponent=reg['sources']['team8']['path'],
                   config_path=reg['config_path'],config_hash=reg['config_hash'],
                   split='diagnostic-repeat-only')
    source=runner._decide
    counter=0
    target_ticks={x['tick'] for x in original_row['slow_decisions']}
    measurements=[]
    def measured(controller,obs):
        global counter
        slot=counter%2;counter+=1
        before=time.thread_time_ns()
        answer=source(controller,obs)
        cpu_ms=(time.thread_time_ns()-before)/1e6
        if answer[1]>20 or (slot==fixture['candidate_slot'] and obs.tick in target_ticks):
            measurements.append(dict(team='new' if slot==fixture['candidate_slot'] else 'team8',
                                     tick=obs.tick,wall_ms=answer[1],thread_cpu_ms=cpu_ms,error=answer[2]))
        return answer
    runner._decide=measured
    try:
        repeat=run_fixture(fixture)
    finally:
        runner._decide=source
    output.append(dict(original_fixture_id=original_row['fixture_id'],
                       scope='Diagnostic only; original match, score and raw deadline miss stay counted.',
                       repeated_match=repeat,timing=measurements))
(ROOT/'timing-repeat.json').write_text(json.dumps(output,indent=2)+'\n')
for item in output:
    r=item['repeated_match'];s=r['candidate_slot']
    print(json.dumps(dict(seed=r['seed'],score=r['result']['score'],
                         new_misses=r['result']['stats'][s]['policy_timeouts'],
                         old_misses=r['result']['stats'][1-s]['policy_timeouts'],
                         timing=item['timing'])),flush=True)
