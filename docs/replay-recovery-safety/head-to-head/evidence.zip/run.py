"""Frozen serial head-to-head matches through the unmodified official SDK."""
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path[:0] = ['/workspace/work/exploit-lab/student-sdk',
                '/workspace/work/replay-finishing-handoffs/tools/benchmarks']
from soccer import SoccerEnv, play_match, runner
from soccer.validate import validate
from benchmark import aggregate, candidate_score, points


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cpu_stat():
    path=Path('/sys/fs/cgroup/cpu.stat')
    return dict(line.split() for line in path.read_text().splitlines()) if path.exists() else {}


def quantile(values,fraction):
    return values[int((len(values)-1)*fraction)] if values else None


def main():
    registration=json.loads((ROOT/'registration.json').read_text())
    for source in registration['sources'].values():
        assert digest(source['path'])==source['sha256']
    with SoccerEnv(config_path=registration['config_path']) as env:
        assert env.engine_version==registration['engine_version']
        assert env.config_hash==registration['config_hash']
    metadata=dict(started_utc=datetime.now(timezone.utc).isoformat(),
                  registration_sha256=digest(ROOT/'registration.json'),
                  runner_sha256=digest(__file__),cpu_start=cpu_stat(),
                  decision_observer='Records the official returned elapsed time outside the timed act() call. Actions and native timing records are unchanged.')
    (ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2))
    for label,source in registration['sources'].items():
        report=validate(source['path'],ticks=400,deadline_ms=20.0)
        result=dict(ok=report.ok,errors=report.errors,warnings=report.warnings,
                    stats=report.stats,controller=report.controller)
        (ROOT/f'{label}-intake.json').write_text(json.dumps(result,indent=2))
        print('INTAKE',label,json.dumps(result),flush=True)
        if not report.ok:
            raise RuntimeError('Official intake failed; raw intake retained: '+label)
    sources=registration['sources']
    rows=[]
    timing={'new':[],'team8':[]}
    original=runner._decide
    with (ROOT/'matches.jsonl').open('x') as stream:
        for index,fixture in enumerate(registration['fixtures']):
            side=fixture['candidate_slot']
            kickoff=side if fixture['candidate_takes_kickoff'] else 1-side
            paths=[sources['new']['path'],sources['team8']['path']]
            if side: paths.reverse()
            counter=0
            slow=[]
            decisions={'new':[],'team8':[]}
            telemetry={'recovery_ticks':0,'carry_plan_ticks':0}

            def measured(controller,obs):
                nonlocal counter
                slot=counter%2
                counter+=1
                label='new' if slot==side else 'team8'
                result=original(controller,obs)
                _,elapsed,error=result
                decisions[label].append(elapsed)
                if elapsed>20 or error is not None:
                    slow.append(dict(team=label,tick=obs.tick,elapsed_ms=elapsed,error=error))
                if label=='new':
                    telemetry['recovery_ticks']+=getattr(controller,'_recovery_guard',None) is not None
                    telemetry['carry_plan_ticks']+=getattr(controller,'_carry_plan',None) is not None
                return result

            runner._decide=measured
            started=time.perf_counter()
            cpu_before=cpu_stat()
            try:
                outcome=play_match(paths[0],paths[1],seed=fixture['seed'],
                    kickoff_team=kickoff,config_path=registration['config_path'],
                    max_ticks=2400,per_decision_timeout_ms=20.0,
                    match_id=f"v2-vs-team8-{fixture['seed']}-side{side}-kick{int(fixture['candidate_takes_kickoff'])}")
            finally:
                runner._decide=original
            result=outcome.result
            for label,values in decisions.items(): timing[label].extend(values)
            row=dict(fixture_id=result.get('match_id',str(index)),
                     split='frozen-head-to-head',opponent=sources['team8']['path'],
                     **fixture,result=result,slow_decisions=slow,
                     wall_seconds=time.perf_counter()-started,
                     cpu_before=cpu_before,cpu_after=cpu_stat(),telemetry=telemetry)
            rows.append(row)
            stream.write(json.dumps(row)+'\n');stream.flush()
            assert result['engine_version']==registration['engine_version']
            assert result['config_hash']==registration['config_hash']
            assert not result.get('platform_error')
            a,b=candidate_score(row)
            own=result['stats'][side];other=result['stats'][1-side]
            print(f"MATCH {index+1}/64 seed={fixture['seed']} side={side} kickoff={fixture['candidate_takes_kickoff']} score={a}-{b} errors={own.get('policy_errors',0)}/{other.get('policy_errors',0)} misses={own.get('policy_timeouts',0)}/{other.get('policy_timeouts',0)}",flush=True)
    assert len(rows)==registration['expected_fixtures']
    for source in sources.values(): assert digest(source['path'])==source['sha256']
    mirrored=[dict(row,candidate_slot=1-row['candidate_slot']) for row in rows]
    new,old=aggregate(rows),aggregate(mirrored)
    blocks=defaultdict(list)
    for row,mirror in zip(rows,mirrored):
        blocks[row['seed']].append(points(row)-points(mirror))
    means=[sum(values)/len(values) for values in blocks.values()]
    rng=random.Random(registration['statistics']['bootstrap_seed'])
    boot=sorted(sum(rng.choices(means,k=len(means)))/len(means)
                for _ in range(registration['statistics']['bootstrap_samples']))
    ci=[quantile(boot,.025),quantile(boot,.975)]
    distributions={}
    for label,values in timing.items():
        values.sort()
        distributions[label]=dict(count=len(values),p50_ms=quantile(values,.5),
            p95_ms=quantile(values,.95),p99_ms=quantile(values,.99),
            p999_ms=quantile(values,.999),max_ms=max(values),
            raw_over_20ms=sum(v>20 for v in values))
    summary=dict(scope=registration['scope'],new=new,team8=old,
        paired_points_difference_per_match=(new['points']-old['points'])/len(rows),
        paired_seed_bootstrap_95=ci,
        positive_win_evidence=new['points']>old['points'] and ci[0]>0,
        additional_raw_misses_per_1000=(new['policy_timeouts']-old['policy_timeouts'])*1000/len(rows),
        decision_distributions=distributions,
        by_side={str(s):aggregate([r for r in rows if r['candidate_slot']==s]) for s in (0,1)},
        by_kickoff={str(k):aggregate([r for r in rows if r['candidate_takes_kickoff']==k]) for k in (True,False)},
        completed_full_matches=sum(r['result']['ticks']==2400 and r['result']['terminal_reason']=='time_limit' for r in rows),
        promotion=False)
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    metadata.update(finished_utc=datetime.now(timezone.utc).isoformat(),cpu_finish=cpu_stat())
    (ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print('SUMMARY',json.dumps(summary),flush=True)


if __name__=='__main__':
    main()
