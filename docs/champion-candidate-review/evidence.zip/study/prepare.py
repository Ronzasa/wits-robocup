"""Freeze the upload and two independent, review-only changes."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/workspace/work/replay-finishing-handoffs')
source=Path('/workspace/attachments/1c93cd1f-7a5f-4181-83c4-502e26666c35/champion_candidate.py').read_text()
assert hashlib.sha256(source.encode()).hexdigest()=='7708f5d3b10202092f1fce73abfc61a5d7a61d91326d95d69cec872d4c7ba758'
new_method='''    def _wall_break(self, obs, actions):
        # Optional wall pressure must not undo an executed kick, an active
        # reception, or the normal chaser/cover assignments.
        if (self._receive_plan is not None or self._x_reception is not None
                or obs.ball.controlling_team == 1
                or any(a.kick_direction is not None for a in actions.players.values())):
            return
        gx = obs.opponent_goal[0]
        field = obs.field
        r = field.player_radius
        wall = [q for q in obs.opponents
                if abs(q.position[0] - gx) <= 3.0 and abs(q.position[1]) <= 9.0]
        bx, by = obs.ball.position
        if len(wall) < 4 or bx < 0.0:
            return
        hw = field.goal_width * 0.5
        br = field.ball_radius
        ys = sorted(q.position[1] for q in wall)
        gaps = []
        lo = -hw
        for y in ys + [hw + r]:
            hi = min(y - r, hw)
            if hi > lo:
                gaps.append((hi - lo, (lo + hi) * 0.5))
            lo = max(lo, y + r)
        if not gaps:
            return
        width, cy = max(gaps)
        friends = sorted(obs.my_players, key=lambda q: q.id)
        if width >= 2.0 * br + 0.25 and bx > gx - 40.0:
            vx, vy = obs.ball.velocity
            opponents = [(q.id, *q.position, *q.velocity) for q in obs.opponents]
            for p in friends[1:]:
                if not obs.can_kick(p.id):
                    continue
                # Reuse existing momentum/contact, drag, goal-plane and
                # defender checks instead of treating direction as velocity.
                option = self._shot_option((p.id, *p.position, *p.velocity),
                                           bx, by, vx, vy, opponents, cy)
                if option is not None:
                    _, kick, movement, _ = option
                    actions.set(p.id, PlayerAction(movement=movement,
                                kick_direction=kick[0], kick_power=kick[1]))
                    return
        outfield = friends[1:]
        if len(outfield) < 2:
            return
        chaser = min(outfield, key=lambda q:
                     math.hypot(q.position[0] - bx, q.position[1] - by))
        protected = {0, self._chaser, self._shape_cover_id, chaser.id}
        protected.update(p.id for p in outfield if obs.can_kick(p.id))
        pushers = [p for p in outfield if p.id not in protected]
        targets = sorted(wall, key=lambda q: abs(q.position[1] - cy))[:len(pushers)]
        pushers.sort(key=lambda q: q.position[1])
        targets.sort(key=lambda q: q.position[1])
        for p, q in zip(pushers, targets):
            dx, dy = q.position[0] - p.position[0], q.position[1] - p.position[1]
            d = math.hypot(dx, dy)
            if d > 1e-6:
                actions.set(p.id, PlayerAction(movement=(dx / d, dy / d)))

'''
a=source.index('    def _wall_break(');b=source.index('    def _lock_wall(',a)
variants={'uploaded':source,
          'no-trailing-wall':source.replace('    TRAIL_WALL = 2\n','    TRAIL_WALL = 0\n'),
          'guarded-wall-break':source[:a]+new_method+source[b:]}
items={}
for label,text in variants.items():
 p=repo/'experiments/champion-candidate-review'/label/'team.py'
 p.parent.mkdir(parents=True,exist_ok=True)
 assert not p.exists()
 p.write_text(text)
 items[label]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
opponents=json.loads(Path('/workspace/work/replay-corrected-isolation-20261025/registration.json').read_text())['opponents']
reg=dict(sources=items,opponents=opponents,seeds=[3104278101,3104278102,3104278103,3104278104],
         config_path=str(repo/'configs/default.toml'),config_hash='372990895c7eca2a',engine_version='0.1.0',
         max_ticks=2400,deadline_ms=20.,workers=1,formation='Public native defaults; captured replay roster regression verified',
         purpose='Development-only review of the new upload. Do not select or promote a champion using this cohort.',
         schedule='Each of three independent sources against five fixed common opponents, all four side/kickoff combinations, four unused seeds: 240 matches.',
         order_seed=3104278105,bootstrap_seed=3104278106,promotion=False)
(root/'registration.json').write_text(json.dumps(reg,indent=2)+'\n')
print(json.dumps(items,indent=2))
