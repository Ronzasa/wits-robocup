"""Fixed development-only review. Never promotes or changes controller files."""
from collections import defaultdict
from datetime import datetime,timezone
import hashlib,json,random,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/work/replay-finishing-handoffs')
sys.path.insert(0,str(REPO/'tools/benchmarks'))
from benchmark import aggregate,points
from default_roster import native_match
from soccer.validate import validate

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def paired(rows,baseline,seed):
    key=lambda r:(r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])
    a={key(r):r for r in rows};b={key(r):r for r in baseline}
    assert a.keys()==b.keys()
    blocks=defaultdict(list)
    for k,r in a.items():blocks[r['seed']].append(points(r)-points(b[k]))
    means=[sum(ds)/len(ds) for _,ds in sorted(blocks.items())]
    rng=random.Random(seed)
    draws=sorted(sum(rng.choices(means,k=len(means)))/len(means) for _ in range(10000))
    return dict(points_difference_per_fixture=sum(means)/len(means),
                paired_seed_block_bootstrap_95=[draws[250],draws[9749]],
                independent_seed_blocks=len(blocks),development_only=True)

def main():
    reg=json.loads((ROOT/'registration.json').read_text())
    for item in [*reg['sources'].values(),*reg['opponents'].values()]:assert digest(item['path'])==item['sha256']
    metadata=dict(started_utc=datetime.now(timezone.utc).isoformat(),runner_sha256=digest(__file__),registration_sha256=digest(ROOT/'registration.json'),native_driver_sha256=digest(REPO/'tools/benchmarks/default_roster.py'))
    (ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    for label,item in reg['sources'].items():
        report=validate(item['path'],ticks=400,deadline_ms=20.)
        data=dict(ok=report.ok,errors=report.errors,warnings=report.warnings,stats=report.stats)
        (ROOT/f'{label}-intake.json').write_text(json.dumps(data,indent=2)+'\n')
        print('INTAKE',label,json.dumps(data),flush=True)
        if report.errors:raise RuntimeError('Intake failure: '+label)
    rng=random.Random(reg['order_seed'])
    fixtures=[(style,seed,side,kick) for style in reg['opponents'] for seed in reg['seeds'] for side in (0,1) for kick in (False,True)]
    rng.shuffle(fixtures)
    rows={name:[] for name in reg['sources']}
    with (ROOT/'matches.jsonl').open('x') as f:
        for index,(style,seed,side,kick) in enumerate(fixtures):
            labels=list(rows);rng.shuffle(labels)
            for label in labels:
                result,telemetry,roster=native_match(reg['sources'][label]['path'],reg['opponents'][style]['path'],seed,side,kick,reg)
                row=dict(source=label,opponent_name=style,seed=seed,candidate_slot=side,candidate_takes_kickoff=kick,result=result,telemetry=telemetry,initial_roster=roster)
                rows[label].append(row);f.write(json.dumps(row)+'\n');f.flush()
            if (index+1)%5==0:print('DEVELOPMENT',index+1,'/80', {n:sum(points(r) for r in rs) for n,rs in rows.items()},flush=True)
    summary={n:aggregate(rs) for n,rs in rows.items()}
    comparisons={n:paired(rs,rows['uploaded'],reg['bootstrap_seed']) for n,rs in rows.items() if n!='uploaded'}
    for n,s in summary.items():
        if n!='uploaded':comparisons[n]['additional_raw_misses_per1000']=(s['policy_timeouts']-summary['uploaded']['policy_timeouts'])*1000/s['matches']
    final=dict(summary=summary,paired_vs_upload=comparisons,
               by_opponent={style:{n:aggregate([r for r in rs if r['opponent_name']==style]) for n,rs in rows.items()} for style in reg['opponents']},
               finished_utc=datetime.now(timezone.utc).isoformat(),promotion=False,development_only=True)
    for item in [*reg['sources'].values(),*reg['opponents'].values()]:assert digest(item['path'])==item['sha256']
    (ROOT/'summary.json').write_text(json.dumps(final,indent=2)+'\n')
    print('FINAL',json.dumps(dict(summary=summary,paired=comparisons)),flush=True)

if __name__=='__main__':main()
