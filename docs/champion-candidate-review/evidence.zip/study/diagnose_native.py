"""Functional examples from native observations, separate from timed evaluation.

Wrap only the uploaded controller for before/after action inspection. Opponents,
engine and physics are unchanged. These reruns never replace scheduled results.
"""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/work/replay-finishing-handoffs')
sys.path.insert(0,str(REPO/'tools/benchmarks'))
from soccer import SoccerEnv
from soccer.helpers import load_controller

def physical(r):
 s=r['result']['stats'][r['candidate_slot']]
 return [s.get(k) for k in ('shots','passes_attempted','turnovers','controlled_ticks','dribble_distance')]

def run(row,reg):
 paths=[reg['sources']['uploaded']['path'],reg['opponents'][row['opponent_name']]['path']]
 side=row['candidate_slot']
 if side:paths.reverse()
 controllers=[load_controller(p) for p in paths]
 c=controllers[side]
 events=[];counts=dict(trailing_wall_ticks=0,wall_action_changes=0,receiver_overrides=0,cover_overrides=0,cancelled_kicks=0)
 wall=c._wall_break
 def inspect_wall(obs,actions):
  before={i:a.as_dict() for i,a in actions.players.items()}
  receive=c._receive_plan;cover=c._shape_cover_id
  wall(obs,actions)
  after={i:a.as_dict() for i,a in actions.players.items()}
  changed=[i for i in before if before[i]!=after[i]]
  if not changed:return
  counts['wall_action_changes']+=1
  receiver=receive[0] if receive is not None else None
  if receiver in changed:counts['receiver_overrides']+=1
  if cover in changed:counts['cover_overrides']+=1
  cancelled=[i for i in changed if 'kick_direction' in before[i] and 'kick_direction' not in after[i]]
  counts['cancelled_kicks']+=len(cancelled)
  if len(events)<8 and (receiver in changed or cover in changed or cancelled):
   events.append(dict(tick=obs.tick,score=list(obs.score),ball=dict(position=list(obs.ball.position),velocity=list(obs.ball.velocity)),receive_plan=receive,cover=cover,changed=changed,cancelled=cancelled,before=before,after=after))
 c._wall_break=inspect_wall
 with SoccerEnv(config_path=reg['config_path'],max_ticks=2400,per_decision_timeout_ms=20.,team_ids=('policy_a','policy_b')) as env:
  for controller in controllers:controller.reset(row['seed'])
  observations=env.reset(seed=row['seed'],kickoff_team=side if row['candidate_takes_kickoff'] else 1-side)
  while not env.finished:
   obs=observations['team_a' if side==0 else 'team_b']
   if obs.score[1]-obs.score[0]>=c.TRAIL_WALL:counts['trailing_wall_ticks']+=1
   actions={key:controllers[i].act(observations[key]) for i,key in enumerate(('team_a','team_b'))}
   observations,_=env.step(actions)
  result=env.result()
 return dict(fixture={k:row[k] for k in ('opponent_name','seed','candidate_slot','candidate_takes_kickoff')},counts=counts,examples=events,score=result['score'],ticks=result['ticks'],separate_functional_rerun=True,timings_not_evaluated=True)

def main():
 reg=json.loads((ROOT/'registration.json').read_text())
 groups={}
 for line in (ROOT/'matches.jsonl').read_text().splitlines():
  r=json.loads(line);key=(r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])
  groups.setdefault(key,{})[r['source']]=r
 chosen=[]
 for variant in ('guarded-wall-break','no-trailing-wall'):
  group=next((g for g in groups.values() if 'uploaded' in g and variant in g and physical(g['uploaded'])!=physical(g[variant])),None)
  if group is not None and group['uploaded'] not in chosen:chosen.append(group['uploaded'])
 result=[run(row,reg) for row in chosen]
 (ROOT/'native-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps([{'fixture':r['fixture'],'counts':r['counts'],'examples':len(r['examples'])} for r in result],indent=2))

if __name__=='__main__':main()
