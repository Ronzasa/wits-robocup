"""Score-aware Pep--Klopp hybrid using canonical public observations.

A stable marker shadows the opposition striker. Receiver-led short links can
prepare a third-player run; Pele finishes centrally and the midfielder tests
reachable long shots. Predicted wall rebounds coordinate a collector and outlet.
At a lead of two or more, every player guards the goal; a verified saved-shot
rebound may release two players while three retain cover. The keeper tracks
shots while the shield forms. Legal acceleration and kick impulse stay fixed.

The retained physics planner evaluates drag, wall restitution, first body
contact, momentum and interception races. No seeds, opponent names or hidden
engine state select tactics. These are bounded predictions, not guaranteed saves.
"""
import math

from soccer import PlayerAction, TeamAction, TeamController


def _clip(value, low, high):
    return low if value < low else high if value > high else value


def _unit(x, y):
    length = math.hypot(x, y)
    if length < 1e-8:
        return 0.0, 0.0
    return x / length, y / length


class Guardiola2011(TeamController):
    name = "Pep Guardiola + Jurgen Klopp Hybrid"
    version = "8.0-hybrid-shield-tiki"
    SHIELD_SHAPE = 'flat'
    MARK_DISTANCE = 3.0
    TIKI_WEIGHT = 0.3
    STRIKER_MARK = True
    SCORE_SHIELD = True
    REBOUND_COUNTER = True
    TIKI_TAKA = True
    SECOND_BALL = True
    MIDFIELD_SHOT = True
    PELE_FINISH = True
    LINK_MARGIN = 0.10
    SHOT_MARGIN = -0.04
    OPTION_SWITCH_MARGIN = 0.15
    BANK_LAUNCH_BUDGET = 12
    COVER_SHAPE = True
    KEEPER_PRIORITY = True
    KEEPER_RECOVERY = True
    WALL_PASSING = True
    BANK_MARGIN = 0.12
    MARK_HANDOFF = True
    TRANSITION_SECONDS = 1.5
    TRANSITION_LEAD = 2.0
    TRANSITION_GAIN = 4.0
    TRANSITION_ROOM = 1.2
    TRANSITION_MARGIN = 0.06
    COUNTERPRESS_SECONDS = 1.0
    COUNTERPRESS_RACE_MARGIN = 0.10
    PLAYER_ROLES = {
        0: "Oliver Kahn | goalkeeper",
        1: "Beckenbauer | libero",
        2: "Gerrard | long-range midfielder",
        3: "Messi | creator",
        4: "Pele | central finisher",
    }
    DRIBBLE_SPEED = 8.0
    SHOOT_RANGE = 34.0
    PASSING = True
    PREDICTIVE_KEEPER = True
    SAFE_RECYCLE = True

    def __init__(self):
        self.reset(0)

    def reset(self, seed):
        # The supplied seed is deliberately unused.
        self._enemy_cooldowns = {}
        self._mark_assignments = {}
        self._bank_plan = None
        self._bank_receive = None
        self._cover_id = None
        self._cover_secure_since = None
        self._ready = False
        self._tactics_reset()
        self._restart_until = -1
        self._restart_owner = None
        self._chaser = -1
        self._last_score = None
        self._touch_movement = None
        self._pass_plan = None
        self._receive_plan = None
        self._transition_owner = None
        self._transition_until = -1
        self._transition_last_touch = None
        self._transition_holder = None
        self._transition_score = None
        self._transition_tick = None
        self._transition_active = False
        self._press_until = -1
        self._press_origin = None
        self._press_contact_owner = None
        self._press_last_ball_touch = None
        self._press_last_ball_holder = None
        self._press_own_contact_tick = -100000

    def initial_formation(self, field):
        w, h = field.width, field.height
        circle = field.centre_circle_radius
        return [
            (field.my_goal[0] + 3.0, 0.0),
            (-0.26 * w, 0.0),
            (-0.15 * w, -0.13 * h),
            (-0.15 * w, 0.20 * h),
            (-circle - 1.8, 0.0),
        ]

    def _setup(self, field):
        self._dt = 1.0 / field.simulation_hz
        self._hz = field.simulation_hz
        self._speed = field.max_speed
        self._acc = field.acceleration * self._dt
        self._friction = field.ball_friction
        self._log_friction = math.log(self._friction)
        self._impulse = field.kick_impulse
        self._range = field.kick_range
        self._eta_range = self._range * 0.8
        self._left = field.my_goal[0]
        self._right = field.opponent_goal[0]
        self._half_height = field.height * 0.5
        self._mouth = max(0.0, field.goal_width * 0.5 - 0.6)
        self._circle = field.centre_circle_radius
        self._ball_radius = field.ball_radius
        self._player_radius = field.player_radius
        self._contact = field.player_radius + field.ball_radius
        # Public course profile: player damping, wall restitution, ball cap.
        self._damping = 0.9
        self._wall = 0.75
        self._ball_cap = 30.0
        # Closed-form displacements for collision-free forecast samples.
        self._drag = tuple(self._friction ** tick for tick in range(81))
        self._roll = tuple(self._dt * (1.0 - drag) / (1.0 - self._friction)
                           for drag in self._drag)
        self._forecast_steps = tuple((tick * self._dt, self._roll[tick])
                                    for tick in (0, 2, 4, 6, 9, 12, 16, 20, 25, 31, 38, 47, 58, 70, 80))
        self._reach_table = tuple(
            (self._dt*self._damping*(1.0-self._damping**n)/(1.0-self._damping),
             self._dt*self._acc/(1.0-self._damping)*(n-self._damping*(1.0-self._damping**n)/(1.0-self._damping)))
            for n in range(83))
        self._ready = True

    def _target(self, x, y):
        return (_clip(x, self._left + 2.0, self._right - 2.0),
                _clip(y, -self._half_height + 2.0, self._half_height - 2.0))

    def _move(self, p, target, friends=()):
        dx, dy = target[0] - p[1], target[1] - p[2]
        gap = math.hypot(dx, dy)
        # Reuse exactly the norm that _unit would calculate again.
        if gap < 1e-8:
            ux, uy = 0.0, 0.0
        else:
            ux, uy = dx / gap, dy / gap
        for other in friends:
            if other[0] == p[0]:
                continue
            sx, sy = p[1] - other[1], p[2] - other[2]
            d = math.hypot(sx, sy)
            if 0.01 < d < 3.0:
                force = (3.0 - d) * 0.22 / d
                ux += sx * force
                uy += sy * force
        ux, uy = _unit(ux, uy)
        desired = min(self._speed, gap * 5.0)
        ax = (ux * desired - p[3] * self._damping) / self._acc
        ay = (uy * desired - p[4] * self._damping) / self._acc
        length = math.hypot(ax, ay)
        if length > 1.0:
            return ax / length, ay / length
        return ax, ay

    def _eta(self, p, x, y):
        dx, dy = x - p[1], y - p[2]
        d = math.hypot(dx, dy)
        if d < 1e-6:
            return 0.0
        speed_towards = (dx * p[3] + dy * p[4]) / d
        sideways = abs(dx * p[4] - dy * p[3]) / d
        startup = max(0.0, 1.0 - speed_towards / self._speed) * 0.30
        return max(0.0, d - self._eta_range) / self._speed + startup + sideways * 0.025

    def _crossing_ticks(self, position, velocity, bound):
        if abs(velocity) < 1e-9:
            return 81
        distance = bound - position if velocity > 0.0 else position + bound
        fraction = 1.0 - max(0.0, distance) * (1.0 - self._friction) / (abs(velocity) * self._dt)
        if fraction <= 0.0:
            return 81
        # Boundaries reflect only after crossing, not merely touching.
        return max(1, int(math.log(fraction) / self._log_friction) + 1)

    def _trajectory(self, bx, by, vx, vy):
        radius = 0.45
        xwall, ywall = self._right - radius, self._half_height - radius
        reach = self._forecast_steps[-1][1]
        if abs(bx + vx * reach) < xwall and abs(by + vy * reach) < ywall:
            return [(t, bx + vx * distance, by + vy * distance)
                    for t, distance in self._forecast_steps]
        # Advance analytically between the few wall contacts. Each contact
        # uses the same discrete overshoot/reflection as the stepped model.
        samples = [(0.0, bx, by)]
        elapsed = 0
        hit = min(self._crossing_ticks(bx, vx, xwall),
                  self._crossing_ticks(by, vy, ywall))
        for wanted in (2, 4, 6, 9, 12, 16, 20, 25, 31, 38, 47, 58, 70, 80):
            while hit <= wanted:
                steps = hit - elapsed
                scale = self._roll[steps]
                bx += vx * scale
                by += vy * scale
                if by > ywall:
                    by = ywall * 2.0 - by
                    vy = -abs(vy) * self._wall
                elif by < -ywall:
                    by = -ywall * 2.0 - by
                    vy = abs(vy) * self._wall
                if abs(bx) > xwall:
                    if abs(by) <= self._mouth + 0.6:
                        samples.append((hit * self._dt, _clip(bx, -xwall, xwall), by))
                        return samples
                    if bx > xwall:
                        bx = xwall * 2.0 - bx
                        vx = -abs(vx) * self._wall
                    else:
                        bx = -xwall * 2.0 - bx
                        vx = abs(vx) * self._wall
                drag = self._drag[steps]
                vx *= drag
                vy *= drag
                elapsed = hit
                hit = elapsed + min(self._crossing_ticks(bx, vx, xwall),
                                    self._crossing_ticks(by, vy, ywall))
            scale = self._roll[wanted - elapsed]
            samples.append((wanted * self._dt, bx + vx * scale, by + vy * scale))
        return samples

    def _intercept(self,p,samples):
        _,px,py,pvx,pvy=p
        best=None
        for t,x,y in samples:
            dx,dy=x-px,y-py
            d=math.hypot(dx,dy)
            n=max(0,int(round(t*self._hz)))
            if n==0:
                feasible=d<=self._eta_range
            else:
                coast,reach=self._reach_table[n]
                feasible=(d<=self._speed*t+self._eta_range and
                          math.hypot(dx-pvx*coast,dy-pvy*coast)<=reach+self._eta_range)
            if feasible:
                return t,(x,y)
            cost=self._eta(p,x,y)+t*.12
            if best is None or cost<best[0]:best=(cost,(x,y))
        return best

    def _closest_eta(self, players, target):
        # Strict comparison preserves min's first-player tie breaking.
        best = None
        best_eta = None
        x, y = target
        for p in players:
            eta = self._eta(p, x, y)
            if best is None or eta < best_eta:
                best, best_eta = p, eta
        return best

    def _role_closest_eta(self, players, target, cover=False):
        # Roles settle close races; distance still controls assignments.
        # The largest preference is only 0.09 seconds, so the libero can
        # step out while another nearby player provides defensive cover.
        best = None
        best_eta = None
        x, y = target
        for p in players:
            eta = self._eta(p, x, y)
            if p[0] == 1:  # Beckenbauer: cover or goal-side marking.
                eta -= 0.09 if cover else 0.045
            elif p[0] == 2:  # Iniesta: retain the next defensive option.
                eta -= 0.045 if cover else 0.025
            if best is None or eta < best_eta:
                best, best_eta = p, eta
        return best

    def _role_support(self, p, bx, by, lane):
        # Start with the existing forward support shape, then adjust a few
        # units for each role. Neither defender is anchored far from play.
        if p[0] == 1:
            return self._target(bx + 6.0, by * 0.2 + lane * 0.5)
        if p[0] == 2:
            return self._target(bx + 7.0, by * 0.2 + lane * 0.7)
        if p[0] == 3:
            return self._target(bx + 10.0, by * 0.2 + lane * 0.8)
        if p[0] == 4:
            return self._target(bx + 15.0, by * 0.2 + lane * 0.3)
        return self._target(bx + 12.0, by * 0.2 + lane)

    def _flight(self, distance, speed):
        if speed <= 0.01:
            return 20.0
        fraction = 1.0 - distance * (1.0 - self._friction) / (speed * self._dt)
        if fraction <= 0.001:
            return 20.0
        return max(0.0, math.log(fraction) / self._log_friction * self._dt)

    def _kick_to_velocity(self, vx, vy, tx, ty):
        dx, dy = tx - vx, ty - vy
        length = math.hypot(dx, dy)
        if length < 0.03:
            return None
        power = min(1.0, length / self._impulse)
        return (dx / length, dy / length), power

    def _shot_velocity(self, bx, by, vx, vy, target_y):
        ux, uy = _unit(self._right - bx, target_y - by)
        along = vx * ux + vy * uy
        perpendicular_sq = max(0.0, vx * vx + vy * vy - along * along)
        if perpendicular_sq >= self._impulse * self._impulse:
            return None
        speed = min(self._ball_cap, along + math.sqrt(self._impulse ** 2 - perpendicular_sq))
        if speed < 9.0:
            return None
        return ux * speed, uy * speed, speed

    def _pass_velocity(self, bx, by, vx, vy, tx, ty):
        # A kick adds at most one impulse: evaluate the trajectory that is
        # actually achievable, including the ball's existing sideways speed.
        ux, uy = _unit(tx - bx, ty - by)
        along = vx * ux + vy * uy
        sideways_sq = max(0.0, vx * vx + vy * vy - along * along)
        if sideways_sq >= self._impulse * self._impulse:
            return None
        reach = math.sqrt(self._impulse * self._impulse - sideways_sq)
        speed = _clip(24.0, max(0.0, along - reach), min(self._ball_cap, along + reach))
        if speed < 9.0:
            return None
        return ux * speed, uy * speed, speed

    def _lane(self, bx, by, tx, ty, speed, opponents):
        dx, dy = tx - bx, ty - by
        length = math.hypot(dx, dy)
        if length < 0.1:
            return -10.0
        ux, uy = dx / length, dy / length
        room = 12.0
        for p in opponents:
            along = (p[1] - bx) * ux + (p[2] - by) * uy
            if along < -1.0 or along > length + 1.5:
                continue
            t = self._flight(max(0.0, along), speed)
            lead = min(0.65, t)
            x, y = p[1] + p[3] * lead, p[2] + p[4] * lead
            along = _clip((x - bx) * ux + (y - by) * uy, 0.0, length)
            lateral = math.hypot(x - bx - along * ux, y - by - along * uy)
            needed = self._contact + min(3.5, t * 1.2)
            room = min(room, lateral - needed)
        return room

    def _transition_observe(self, obs, protected, friends, opponents, race_info=None):
        # Persist only a directly observed touch/control, never the nearest
        # runner or phase label. A loose ball alone cannot invent a regain.
        score = tuple(obs.score)
        reset = (self._transition_score is not None and score != self._transition_score)
        reset = reset or (self._transition_tick is not None and obs.tick <= self._transition_tick)
        self._transition_score = score
        self._transition_tick = obs.tick
        last_touch = obs.ball.last_touch
        if reset or protected:
            self._transition_owner = None
            self._transition_until = -1
            self._transition_last_touch = last_touch
            self._transition_holder = obs.ball.controlling_player
            self._transition_active = False
            return
        ours = {p[0] for p in friends}
        theirs = {p[0] for p in opponents}
        # controlling_player describes a player actually at the ball. The
        # public last_touch can additionally identify a touch between ticks.
        holder = obs.ball.controlling_player
        changed_touch = (last_touch != self._transition_last_touch
                         and (last_touch in ours or last_touch in theirs))
        changed_holder = (holder != self._transition_holder
                          and (holder in ours or holder in theirs))
        direct = last_touch if changed_touch else holder if changed_holder else None
        self._transition_last_touch = last_touch
        self._transition_holder = holder
        owner = 0 if direct in ours else 1 if direct in theirs else None
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        if race_info is None:
            samples = self._trajectory(bx, by, vx, vy)
            our_race = min((self._intercept(p,samples)[0] for p in friends if p[0]!=0),default=100.0)
            their_race = min((self._intercept(p,samples)[0] for p in opponents),default=100.0)
        else:
            our_race,their_race=race_info
        pressure = min((math.hypot(p[1]-bx, p[2]-by) for p in opponents), default=100.0)
        favorable = (bx > self._left + 12.0 and pressure >= 3.2
                     and our_race + 0.10 < their_race)
        if owner is not None:
            if owner == 0 and self._transition_owner == 1:
                self._transition_until = (obs.tick + int(self.TRANSITION_SECONDS * self._hz)
                                          if favorable else -1)
            elif owner == 1:
                self._transition_until = -1
            self._transition_owner = owner
        self._transition_active = (favorable and self._transition_owner == 0
                                   and obs.tick <= self._transition_until)

    def _transition_support(self, bx, by, friends, opponents, chaser_id, targets):
        if not self._transition_active:
            return
        available = [p for p in friends if p[0] not in (0, chaser_id)]
        if len(available) < 2:
            return
        # Keep the existing cover and support shape. Only the highest runner
        # receives a small diagonal cue while the regain advantage is clear.
        cover = min(available, key=lambda p: targets[p[0]][0])
        runners = [p for p in available if p[0] != cover[0]]
        runner = max(runners, key=lambda p: p[1] + (2.0 if p[0] == 4 else 0.0))
        tx, ty = targets[runner[0]]
        nearest = min(opponents, key=lambda p: math.hypot(p[1]-tx,p[2]-ty), default=None)
        side = (1.0 if ty >= by else -1.0) if nearest is None else (1.0 if ty >= nearest[2] else -1.0)
        targets[runner[0]] = self._target(tx + 3.0, ty + side * 4.0)

    def _transition_release(self, p, bx, by, vx, vy, friends, opponents):
        if not self._transition_active:
            return None
        # This hook runs only after the complete existing escape/finishing
        # decisions have declined; safe quick links cannot suppress them.
        movement = self._move(p, target if p[0] in self._guard_ids else (bx + 0.3, by))
        best = None
        for receiver in friends:
            if receiver[0] in (0, p[0]):
                continue
            # Try a direct vertical link and a short diagonal into the
            # receiver's running lane, never an unassigned long clearance.
            for extra in (0.0, self.TRANSITION_LEAD):
                tx, ty = receiver[1] + extra, receiver[2]
                for _ in range(2):
                    velocity = self._pass_velocity(bx, by, vx, vy, tx, ty)
                    if velocity is None:
                        break
                    flight = self._flight(math.hypot(tx-bx, ty-by), velocity[2])
                    lead = min(0.9, flight)
                    tx, ty = self._target(receiver[1] + receiver[3] * lead * 0.8 + extra,
                                          receiver[2] + receiver[4] * lead * 0.8)
                if velocity is None:
                    continue
                gain, gap = tx - bx, math.hypot(tx-bx, ty-by)
                if gain < self.TRANSITION_GAIN or not 5.0 < gap < 31.0:
                    continue
                velocity = self._pass_velocity(bx, by, vx, vy, tx, ty)
                if velocity is None:
                    continue
                room = self._lane(bx, by, tx, ty, velocity[2], opponents)
                if room < self.TRANSITION_ROOM:
                    continue
                kick = self._kick_to_velocity(vx, vy, velocity[0], velocity[1])
                if kick is None:
                    continue
                sx, sy = self._requested_velocity(vx, vy, kick)
                launch = self._carrier_contact(p, bx, by, sx, sy, movement)
                if launch is None or launch[2] < 5.0 or math.hypot(launch[2], launch[3]) < 10.5:
                    continue
                trajectory = self._trajectory(*launch)
                arrival, contact = self._intercept(receiver, trajectory)
                enemy_arrival = min((self._intercept(o, trajectory)[0] for o in opponents), default=100.0)
                if arrival > 1.7 or arrival + self.TRANSITION_MARGIN > enemy_arrival:
                    continue
                # An endpoint must be both progressive and reachable by the
                # named receiver; lane openness alone cannot qualify a pass.
                if contact[0] < bx + self.TRANSITION_GAIN:
                    continue
                receiver_room = min((math.hypot(contact[0]-o[1]-o[3]*min(arrival,0.5),
                                               contact[1]-o[2]-o[4]*min(arrival,0.5))
                                     for o in opponents), default=100.0)
                if receiver_room < 3.0:
                    continue
                score = (contact[0]-bx)*0.08 + min(room,6.0)*0.15 - arrival*0.20
                score += min(receiver_room,8.0)*0.04 - abs(contact[1])*0.006
                if best is None or score > best[0]:
                    best = score, kick, receiver[0], contact
        if best is None:
            return None
        self._pass_plan = (best[2], *best[3])
        return best[1]

    def _original_choose_kick(self, p, bx, by, vx, vy, friends, opponents):
        release = self._escape_release(p,bx,by,vx,vy,opponents)
        if release is not None:
            return release
        goal_distance = math.hypot(self._right - bx, by)
        finisher = p[0] in (3, 4)
        best_shot = None
        for fraction in (-1.0, -0.75, -0.5, 0.0, 0.5, 0.75, 1.0):
            y = self._mouth * fraction
            velocity = self._shot_velocity(bx, by, vx, vy, y)
            if velocity is None:
                continue
            sx, sy, speed = velocity
            room = self._lane(bx, by, self._right, y, speed, opponents)
            if finisher:
                # Rank only eligible Messi/Ronaldo aims. A blocked near aim
                # must not hide a clear far aim, and drag must allow the ball
                # to reach this actual point on the goal line.
                distance = math.hypot(self._right - bx, y - by)
                flight = self._flight(distance, speed)
                if flight >= 20.0:
                    continue
                ordinary = ((goal_distance < self.SHOOT_RANGE and room > 0.0)
                            or (goal_distance < 15.0 and room > -2.0))
                # Only an already fast ball permits the modest extension.
                # It must reach an open aim quickly with useful speed left.
                extended = (goal_distance < 38.0 and speed >= 24.0
                            and flight <= 2.0 and room > 1.75
                            and speed * self._friction ** (flight * self._hz) >= 12.0)
                if not (ordinary or extended):
                    continue
            score = room - abs(y - by) * 0.025
            if best_shot is None or score > best_shot[0]:
                best_shot = (score, room, sx, sy)
        if best_shot is not None:
            _, room, sx, sy = best_shot
            if finisher or (goal_distance < self.SHOOT_RANGE and room > 0.0) or (goal_distance < 15.0 and room > -2.0):
                return self._kick_to_velocity(vx, vy, sx, sy)

        transition = self._transition_release(p,bx,by,vx,vy,friends,opponents)
        if transition is not None:
            return transition
        pressure = min((math.hypot(o[1] - bx, o[2] - by) for o in opponents), default=100.0)
        best_pass = None
        best_break = None
        if self.PASSING:
            for receiver in friends:
                if receiver[0] in (p[0], 0):
                    continue
                gain = receiver[1] - bx
                recycle = gain < 3.0 and p[0] != 0
                if recycle and (not self.SAFE_RECYCLE or pressure >= 3.5 or
                                gain < -8.0 or receiver[1] < self._left + 15.0):
                    continue
                tx, ty = receiver[1], receiver[2]
                velocity = None
                for _ in range(2):
                    velocity = self._pass_velocity(bx, by, vx, vy, tx, ty)
                    if velocity is None:
                        break
                    t = min(1.6, self._flight(math.hypot(tx - bx, ty - by), velocity[2]))
                    tx, ty = self._target(receiver[1] + receiver[3] * t * 0.8,
                                          receiver[2] + receiver[4] * t * 0.8)
                if velocity is None:
                    continue
                gap = math.hypot(tx - bx, ty - by)
                if not 5.0 < gap < 35.0:
                    continue
                velocity = self._pass_velocity(bx, by, vx, vy, tx, ty)
                if velocity is None:
                    continue
                room = self._lane(bx, by, tx, ty, velocity[2], opponents)
                if room < 0.5:
                    continue
                if recycle:
                    outlet_pressure = min((math.hypot(tx - o[1] - o[3] * 0.4,
                                                     ty - o[2] - o[4] * 0.4)
                                           for o in opponents), default=100.0)
                    # Recycling must release pressure, rather than merely
                    # inflate possession or invite danger beside our keeper.
                    if outlet_pressure < max(4.5, pressure + 1.0):
                        continue
                receiver_space = min((math.hypot(tx - o[1] - o[3] * 0.4,
                                                  ty - o[2] - o[4] * 0.4)
                                      for o in opponents), default=100.0)
                # These are decision preferences, not player stat bonuses.
                # Every role retains the same achievable-velocity, lane and
                # pressured-recycle requirements above.
                if p[0] == 1:       # Beckenbauer: composed progression.
                    score = (tx - bx) * 0.045 + min(room, 6.0) * 0.20 - gap * 0.023
                elif p[0] == 2:     # Iniesta: short, safe progressive links.
                    score = (tx - bx) * 0.05 + min(room, 6.0) * 0.20 - gap * 0.024
                elif p[0] == 3:     # Messi: progressive links to the striker.
                    score = (tx - bx) * 0.065 + min(room, 6.0) * 0.16 - gap * 0.02
                    if receiver[0] == 4 and gain >= 6.0 and abs(ty) < self._half_height * 0.5:
                        score += 0.10
                elif p[0] == 4:     # Ronaldo Nazario: face the opponent goal.
                    score = (tx - bx) * 0.07 + min(room, 6.0) * 0.16 - gap * 0.02
                else:
                    score = (tx - bx) * 0.05 + min(room, 6.0) * 0.16 - gap * 0.02
                candidate = (score, velocity[0], velocity[1], receiver[0], tx, ty)
                if best_pass is None or score > best_pass[0]:
                    best_pass = candidate
                if (gain >= 8.0 and gap >= 9.0 and room >= 1.75
                        and receiver_space >= 4.5 and bx < 32.0
                        and (best_break is None or score > best_break[0])):
                    best_break = candidate
            chosen = best_pass if (pressure < 4.5 or p[0] == 0) else best_break
            if chosen is not None:
                # Ronaldo can advance through a genuinely clear central
                # corridor. A viable clear shot has already taken priority.
                # Keep the safe outlet when the carry would meet a defender.
                if (p[0] == 4 and bx > 5.0 and goal_distance > 15.0
                        and abs(by) < self._half_height * 0.5 and pressure >= 6.5):
                    cx, cy, tx, ty, clearance = self._carry_velocity(p, bx, by, pressure, opponents)
                    if (tx - bx >= 3.5 and clearance >= 5.0
                            and self._lane(bx, by, tx, ty, math.hypot(cx, cy), opponents) > 1.0):
                        return self._kick_to_velocity(vx, vy, cx, cy)
                self._pass_plan = (chosen[3], chosen[4], chosen[5])
                return self._kick_to_velocity(vx, vy, chosen[1], chosen[2])

        if p[0] == 0:
            # Clear laterally out of danger when no safe outlet is available.
            side = -1.0 if by > 0.0 else 1.0
            ux, uy = _unit(1.0, side * 0.6)
            return self._kick_to_velocity(vx, vy, ux * 22.0, uy * 22.0)

        cx, cy, _, _, _ = self._carry_velocity(p, bx, by, pressure, opponents)
        return self._kick_to_velocity(vx, vy, cx, cy)

    def _carry_velocity(self, p, bx, by, pressure, opponents):
        # Messi uses a shorter control horizon under pressure. Open-field
        # touches retain the team's existing speed, and no role exceeds it.
        close_control = p[0] == 3 and pressure < 4.5
        lookahead = 3.5 if close_control else 5.0
        touch_speed = min(self.DRIBBLE_SPEED, 7.0) if close_control else self.DRIBBLE_SPEED
        forward_weight = 0.70 if p[0] == 4 else 0.45
        centre_weight = 0.06 if p[0] in (3, 4) else 0.04
        best = None
        goal_ux, goal_uy = _unit(self._right - bx, -by)
        for dx, dy in ((goal_ux, goal_uy), (1.0, 0.0), (0.85, 0.53), (0.85, -0.53)):
            tx, ty = self._target(bx + dx * lookahead, by + dy * lookahead)
            clearance = min((math.hypot(tx - o[1] - o[3] * 0.2,
                                        ty - o[2] - o[4] * 0.2) for o in opponents), default=15.0)
            score = min(clearance, 10.0) + (tx - bx) * forward_weight - abs(ty) * centre_weight
            if best is None or score > best[0]:
                best = (score, dx, dy, tx, ty, clearance)
        return best[1] * touch_speed, best[2] * touch_speed, best[3], best[4], best[5]

    def _requested_velocity(self, vx, vy, kick):
        direction, power = kick
        sx = vx + direction[0] * power * self._impulse
        sy = vy + direction[1] * power * self._impulse
        speed = math.hypot(sx, sy)
        if speed > self._ball_cap:
            sx *= self._ball_cap / speed
            sy *= self._ball_cap / speed
        return sx, sy

    def _carrier_contact(self, p, bx, by, sx, sy, movement):
        # One free movement step, then just the carrier's first ball contact.
        pvx = p[3] * self._damping + movement[0] * self._acc
        pvy = p[4] * self._damping + movement[1] * self._acc
        speed = math.hypot(pvx, pvy)
        if speed > self._speed:
            pvx *= self._speed / speed
            pvy *= self._speed / speed
        px, py = p[1] + pvx * self._dt, p[2] + pvy * self._dt
        if math.hypot(px - bx, py - by) >= self._range - 0.18:
            return None
        x, y = bx + sx * self._dt, by + sy * self._dt
        sx *= self._friction
        sy *= self._friction
        rx, ry = x - px, y - py
        gap = math.hypot(rx, ry)
        if 1e-8 < gap < self._contact:
            nx, ny = rx / gap, ry / gap
            x, y = px + nx * self._contact, py + ny * self._contact
            closing = (sx - pvx) * nx + (sy - pvy) * ny
            if closing < 0.0:
                # Documented ground player/ball restitution is 0.25.
                impulse = -1.25 * closing
                sx += impulse * nx
                sy += impulse * ny
        return x, y, sx, sy

    def _legacy_choose_kick(self, p, bx, by, vx, vy, friends, opponents):
        self._touch_movement = None
        kick = self._original_choose_kick(p, bx, by, vx, vy, friends, opponents)
        if (kick is None or bx >= 0.0 or bx <= self._left + 3.0
                or abs(by) >= self._half_height - 3.0):
            return kick
        sx, sy = self._requested_velocity(vx, vy, kick)
        if sx <= 2.0:
            return kick
        movement = self._move(p, target if p[0] in self._guard_ids else (bx + 0.3, by))
        original = self._carrier_contact(p, bx, by, sx, sy, movement)
        if original is None or original[2] >= -2.0:
            return kick

        # Retain the exact kick if braking or moving away prevents its return.
        brake_x = -p[3] * self._damping / self._acc
        brake_y = -p[4] * self._damping / self._acc
        brake_length = math.hypot(brake_x, brake_y)
        if brake_length > 1.0:
            brake_x /= brake_length
            brake_y /= brake_length
        away = _unit(p[1] - bx, p[2] - by)
        for alternative in ((brake_x, brake_y), away):
            outcome = self._carrier_contact(p, bx, by, sx, sy, alternative)
            if outcome is not None and outcome[2] >= -2.0:
                self._touch_movement = alternative
                return kick

        # Try the smallest requested rotation first. Re-evaluate the capped
        # actual impulse instead of assuming the rotated velocity is feasible.
        for degrees in (30.0, -30.0, 60.0, -60.0):
            angle = math.radians(degrees)
            cosine, sine = math.cos(angle), math.sin(angle)
            tx, ty = sx * cosine - sy * sine, sx * sine + sy * cosine
            alternative = self._kick_to_velocity(vx, vy, tx, ty)
            if alternative is None:
                continue
            ax, ay = self._requested_velocity(vx, vy, alternative)
            outcome = self._carrier_contact(p, bx, by, ax, ay, movement)
            if ax > 2.0 and outcome is not None and outcome[2] >= -2.0:
                return alternative
        return kick


    def _escape_release(self, p, bx, by, vx, vy, opponents):
        if p[0] == 0 or bx > 2.0:
            return None
        pressure=min((math.hypot(o[1]-bx,o[2]-by) for o in opponents),default=100.0)
        if pressure>=4.0:
            return None
        best=None
        for width in (-16.0,-8.0,0.0,8.0,16.0):
            tx,ty=self._target(bx+28.0,by*0.3+width)
            ux,uy=_unit(tx-bx,ty-by)
            along=vx*ux+vy*uy
            side=max(0.0,vx*vx+vy*vy-along*along)
            if side>=self._impulse**2:
                continue
            speed=min(28.0,along+math.sqrt(self._impulse**2-side))
            if speed<14.0:
                continue
            room=self._lane(bx,by,tx,ty,speed,opponents)
            score=room-abs(ty)*0.025
            if best is None or score>best[0]:
                best=score,self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
        return None if best is None else best[1]


    def _endpoint_controlled_touch(self, p, bx, by, vx, vy, opponents):
        # Evaluate reachable short touches after our own body contact. The
        # final point is a collection opportunity, not a possession claim.
        base_angle = math.atan2(-by, self._right - bx)
        original_distance = math.hypot(self._right - bx, by)
        best = None
        for angle_offset in (0.0, -0.45, 0.45, -0.9, 0.9, -1.35, 1.35):
            angle = base_angle + angle_offset
            ux, uy = math.cos(angle), math.sin(angle)
            for speed in (6.0, 9.0):
                kick = self._kick_to_velocity(vx, vy, ux*speed, uy*speed)
                if kick is None:
                    continue
                sx, sy = self._requested_velocity(vx, vy, kick)
                movement = self._move(p, self._target(bx+ux*3.0, by+uy*3.0))
                contact = self._carrier_contact(p, bx, by, sx, sy, movement)
                if contact is None:
                    continue
                x, y, rx, ry = contact
                horizon = 0.30
                drag = self._friction**(horizon*self._hz)
                scale = self._dt*(1.0-drag)/(1.0-self._friction)
                tx, ty = x+rx*scale, y+ry*scale
                if abs(ty) > self._half_height-1.5 or tx < self._left+3.0:
                    continue
                own_eta = self._eta(p, tx, ty)
                enemy_eta = min((self._eta(o, tx, ty) for o in opponents),default=10.0)
                clearance = min((math.hypot(tx-o[1]-o[3]*0.22,
                                            ty-o[2]-o[4]*0.22)
                                 for o in opponents),default=15.0)
                progress = original_distance-math.hypot(self._right-tx, ty)
                retain = _clip(enemy_eta-own_eta, -1.0, 1.0)
                score = (progress*0.85 + min(clearance,8.0)*0.45
                         + retain*3.5 - max(0.0,own_eta-0.5)*4.0)
                if rx < -2.0 and bx < 0.0:
                    score -= 5.0
                if best is None or score > best[0]:
                    best = score, kick, movement
        return best

    def _legacy_policy_kick(self, p, bx, by, vx, vy, friends, opponents):
        self._bank_plan = None
        self._pass_plan = None
        kick = self._legacy_choose_kick(p,bx,by,vx,vy,friends,opponents)
        if kick is None:
            return kick
        sx, sy = self._requested_velocity(vx,vy,kick)
        is_shot = (bx > self._right-self.SHOOT_RANGE-4.0 and sx > 1.0
                   and abs(by + sy*(self._right-bx)/sx) <= self._mouth + 0.2)
        direct_safe = False
        if self._pass_plan is not None:
            recipient = next((q for q in friends if q[0]==self._pass_plan[0]),None)
            move = self._touch_movement or self._move(p,(bx+0.3,by))
            launch = self._carrier_contact(p,bx,by,sx,sy,move)
            if recipient is not None and launch is not None:
                path = self._trajectory(*launch)
                own = self._intercept(recipient,path)[0]
                enemy = min((self._intercept(o,path)[0] for o in opponents),default=100.0)
                direct_safe = own+0.12<enemy
        if self.WALL_PASSING and not direct_safe and not is_shot:
            bank = self._bank_release(p,bx,by,vx,vy,friends,opponents)
            if bank is not None:
                self._touch_movement = bank[2]
                self._pass_plan = bank[3]
                self._bank_plan = bank[3]
                return bank[1]
        if p[0] == 0:
            return kick
        if math.hypot(sx,sy) > 10.5:
            return kick
        planned = self._controlled_touch(p,bx,by,vx,vy,opponents)
        if planned is not None:
            self._touch_movement = planned[2]
            return planned[1]
        return kick

    def _touch_path(self, p, bx, by, vx, vy, kick, movement, opponents):
        sx,sy = self._requested_velocity(vx,vy,kick)
        contact = self._carrier_contact(p,bx,by,sx,sy,movement)
        if contact is None:
            return None
        x,y,sx,sy = contact
        pvx=p[3]*self._damping+movement[0]*self._acc
        pvy=p[4]*self._damping+movement[1]*self._acc
        player_speed=math.hypot(pvx,pvy)
        if player_speed>self._speed:
            pvx*=self._speed/player_speed
            pvy*=self._speed/player_speed
        px,py=p[1]+pvx*self._dt,p[2]+pvy*self._dt
        initial_distance=math.hypot(self._right-bx,by)
        margin=4.0
        recapture=None
        cooldowns=getattr(self,'_enemy_cooldowns',{})
        for tick in range(1,12):
            elapsed=tick*self._dt
            if abs(y)>self._half_height-1.0 or x<self._left+2.0:
                return None
            # Evaluate the complete path, not just the endpoint beyond a
            # blocker. Public cooldowns distinguish an available tackle.
            steps=tick+1
            coast=self._dt*self._damping*(1.0-self._damping**steps)/(1.0-self._damping)
            reach=(self._dt*self._acc/(1.0-self._damping)
                   *(steps-self._damping*(1.0-self._damping**steps)/(1.0-self._damping)))
            for enemy in opponents:
                if cooldowns.get(enemy[0],0)>tick:
                    continue
                cx=enemy[1]+enemy[3]*coast
                cy=enemy[2]+enemy[4]*coast
                # Any legal acceleration sequence lies inside this reachable
                # disc. This includes immediate short tackles without the
                # generic ETA estimator's artificial startup delay.
                remaining=math.hypot(x-cx,y-cy)-reach-self._range
                margin=min(margin,remaining/self._speed)
            gap=math.hypot(x-px,y-py)
            if tick>=5 and gap<self._range-0.15:
                recapture=elapsed
                break
            if tick==11:
                break
            # Simulate the carrier's receding chase and every subsequent
            # body collision until their next legal touch is available.
            player=(p[0],px,py,pvx,pvy)
            chase=self._target(x+sx*0.15,y+sy*0.15)
            move=self._move(player,chase)
            pvx=pvx*self._damping+move[0]*self._acc
            pvy=pvy*self._damping+move[1]*self._acc
            player_speed=math.hypot(pvx,pvy)
            if player_speed>self._speed:
                pvx*=self._speed/player_speed
                pvy*=self._speed/player_speed
            px+=pvx*self._dt
            py+=pvy*self._dt
            x+=sx*self._dt
            y+=sy*self._dt
            sx*=self._friction
            sy*=self._friction
            dx,dy=x-px,y-py
            gap=math.hypot(dx,dy)
            if 1e-8<gap<self._contact:
                nx,ny=dx/gap,dy/gap
                x,y=px+nx*self._contact,py+ny*self._contact
                closing=(sx-pvx)*nx+(sy-pvy)*ny
                if closing<0.0:
                    sx-=1.25*closing*nx
                    sy-=1.25*closing*ny
        if recapture is None:
            recapture=0.55+self._eta((p[0],px,py,pvx,pvy),x,y)
        progress=initial_distance-math.hypot(self._right-x,y)
        clearance=min((math.hypot(x-q[1]-q[3]*0.25,y-q[2]-q[4]*0.25)
                       for q in opponents),default=15.0)
        score=(progress*0.85+min(clearance,8.0)*0.25
               +_clip(margin,-0.6,0.6)*8.0-max(0.0,recapture-0.25)*8.0)
        return score,margin,recapture

    def _controlled_touch(self,p,bx,by,vx,vy,opponents):
        original=self._endpoint_controlled_touch(p,bx,by,vx,vy,opponents)
        pressure=min((math.hypot(q[1]-bx,q[2]-by) for q in opponents),default=100.0)
        if original is None or pressure>=5.5:
            return original
        original_path=self._touch_path(p,bx,by,vx,vy,original[1],original[2],opponents)
        # Open short touches preserve the established attack. Only a path
        # with a possible tackle before collection triggers a new search.
        if original_path is not None and original_path[1]>=0.10:
            return original
        best=None
        if original_path is not None:
            best=(original_path[0],original[1],original[2],original_path[1])
        base_angle=math.atan2(-by,self._right-bx)
        for offset in (0.0,-0.6,0.6,-1.2,1.2,-1.8,1.8):
            angle=base_angle+offset
            ux,uy=math.cos(angle),math.sin(angle)
            for speed in (5.0,8.0):
                kick=self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
                if kick is None:
                    continue
                move=self._move(p,self._target(bx+ux*3.0,by+uy*3.0))
                path=self._touch_path(p,bx,by,vx,vy,kick,move,opponents)
                if path is None or path[2]>0.70:
                    continue
                if best is None or path[0]>best[0]:
                    best=(path[0],kick,move,path[1])
        if best is not None:
            return best[:3]
        return original


    def _keeper_reaches(self, keeper, bx, by, vx, vy, target, chase, cooldown):
        px,py,pvx,pvy=keeper[1:]
        for tick in range(1,27):
            previous_scale=self._roll[tick-1]
            old_x,old_y=bx+vx*previous_scale,by+vy*previous_scale
            aim=self._target(old_x,old_y) if chase else target
            before=math.hypot(px-old_x,py-old_y)
            movement=self._move((keeper[0],px,py,pvx,pvy),aim)
            pvx=pvx*self._damping+movement[0]*self._acc
            pvy=pvy*self._damping+movement[1]*self._acc
            speed=math.hypot(pvx,pvy)
            if speed>self._speed:
                pvx*=self._speed/speed;pvy*=self._speed/speed
            px+=pvx*self._dt;py+=pvy*self._dt
            if (cooldown<tick and before<=self._range
                    and math.hypot(px-old_x,py-old_y)<self._range-0.18):
                return True
            scale=self._roll[tick]
            x,y=bx+vx*scale,by+vy*scale
            if x<self._left+self._ball_radius:
                return False
            if math.hypot(px-x,py-y)<=self._contact:
                return True
        return False

    def _choose_marker(self, free, target, threat_id, tick):
        marker=self._role_closest_eta(free,target)
        self._mark_assignments[threat_id]=(marker[0],tick+int(0.3*self._hz))
        return marker


    def _retain_mark(self, obs, friends, opponents, chaser, targets):
        ours={p[0] for p in friends}
        if obs.ball.controlling_player in ours or obs.ball.last_touch in ours:
            return
        bx,by=obs.ball.position
        candidates=[]
        for threat in opponents[1:]:
            old=self._mark_assignments.get(threat[0])
            if (old is None or obs.tick>old[1] or threat[1]>=min(8.0,bx-1.0)
                    or abs(threat[2])>24.0):
                continue
            marker=next((p for p in friends[1:] if p[0]==old[0] and p[0]!=chaser[0]),None)
            if (marker is not None and marker[1]<=threat[1]+0.5
                    and math.hypot(marker[1]-threat[1],marker[2]-threat[2])<6.0):
                candidates.append((threat[1]+abs(threat[2])*0.25,threat,marker))
        if candidates:
            _,threat,marker=min(candidates,key=lambda item:item[0])
            ux,uy=_unit(self._left-threat[1],-threat[2])
            targets[marker[0]]=self._target(threat[1]+ux*3.0,threat[2]+uy*3.0)

    def _cover_shape(self, obs, friends, opponents, chaser, races, enemy_eta, targets):
        bx,by=obs.ball.position
        ours={p[0] for p in friends}
        secure=(obs.ball.controlling_player in ours
                or (obs.ball.last_touch in ours and races[chaser[0]][0]+0.16<enemy_eta))
        pressure=min((math.hypot(o[1]-bx,o[2]-by) for o in opponents),default=100.0)
        if secure or abs(by)<12.0 or pressure>5.0:
            return
        guard_id=self._shape_cover_id
        if guard_id is None or guard_id==chaser[0]:
            return
        # Move only the actual cover assignment: the deepest target may be
        # a separate runner's marker, who must retain that responsibility.
        old=targets[guard_id]
        fraction=_clip((old[0]-self._left)/max(3.0,bx-self._left),0.0,1.0)
        targets[guard_id]=self._target(old[0],by*fraction)


    def _bank_path(self, bx, by, vx, vy):
        # Dense, bounded public-physics forecast. Timing includes the first
        # carrier-contact tick; only side-wall, one-bounce routes qualify.
        wall = self._half_height - self._ball_radius
        samples = [(self._dt, bx, by)]
        bounce = None
        for tick in range(2, 51):
            bx += vx * self._dt
            by += vy * self._dt
            if abs(by) > wall:
                if bounce is not None:
                    break
                side = 1.0 if by > 0.0 else -1.0
                by = side * wall * 2.0 - by
                vy = -side * abs(vy) * self._wall
                bounce = tick * self._dt
            vx *= self._friction
            vy *= self._friction
            if bx <= self._left + self._ball_radius or bx >= self._right - self._ball_radius:
                break
            if tick % 2 == 0 or (bounce is not None and abs(tick*self._dt-bounce) < 1e-8):
                samples.append((tick*self._dt, bx, by))
        return samples, bounce

    def _bank_release(self, p, bx, by, vx, vy, friends, opponents):
        # A blocked direct link may have a safe route through the side wall.
        # Preserve finishing and direct passes; never bank blindly into space.
        if bx > 18.0 or bx < self._left + 10.0 or abs(by) < 9.0:
            return None
        wall = (self._half_height - self._ball_radius) * (1.0 if by >= 0.0 else -1.0)
        normal_move = self._move(p, (bx + 0.3, by))
        brake = _unit(-p[3], -p[4])
        best = None
        direct_cache = {}
        used = 0
        candidates = [(receiver, offset) for receiver in friends[1:] for offset in (0.0, 7.0, 13.0)]
        for receiver, wall_lead in candidates:
            if receiver[0] == p[0] or receiver[1] < bx + 5.0:
                continue
            # A wall route has a cost: an already open direct pass wins.
            if receiver[0] not in direct_cache:
                direct = self._pass_velocity(bx,by,vx,vy,receiver[1],receiver[2])
                safe = False
                if direct is not None:
                    direct_path=self._trajectory(bx,by,direct[0],direct[1])
                    own=self._intercept(receiver,direct_path)[0]
                    enemy=min((self._intercept(o,direct_path)[0] for o in opponents),default=100.0)
                    safe=(own+0.18<enemy and self._lane(bx,by,receiver[1],receiver[2],direct[2],opponents)>1.5)
                direct_cache[receiver[0]]=safe
            if direct_cache[receiver[0]]:
                continue
            for extra in (0.0, 3.0):
                lateral = (1.0 if by>=0.0 else -1.0)*wall_lead
                tx, ty = self._target(receiver[1] + extra, receiver[2] + lateral)
                velocity = None
                for _ in range(2):
                    # Normal speed is reduced by wall restitution. A plain
                    # mirror image assumes an elastic wall and undershoots.
                    virtual_y = wall + (wall - ty) / self._wall
                    velocity = self._pass_velocity(bx, by, vx, vy, tx, virtual_y)
                    if velocity is None or velocity[0] < 4.0:
                        break
                    along_distance = (tx-bx) * velocity[2] / velocity[0]
                    flight = self._flight(along_distance, velocity[2])
                    lead = min(1.1, flight)
                    tx, ty = self._target(receiver[1] + receiver[3]*lead*0.8 + extra,
                                          receiver[2] + receiver[4]*lead*0.8 + lateral)
                if velocity is None or velocity[0] < 4.0:
                    continue
                virtual_y = wall + (wall - ty) / self._wall
                velocity = self._pass_velocity(bx, by, vx, vy, tx, virtual_y)
                if velocity is None:
                    continue
                kick = self._kick_to_velocity(vx, vy, velocity[0], velocity[1])
                if kick is None:
                    continue
                previous_launch = None
                for movement in (normal_move, brake):
                    sx, sy = self._requested_velocity(vx, vy, kick)
                    launch = self._carrier_contact(p, bx, by, sx, sy, movement)
                    if (launch is None or launch[2]<=4.0 or launch[3]*wall<=0.0
                            or abs(launch[1])>self._half_height-self._ball_radius):
                        continue
                    if launch == previous_launch:
                        continue
                    previous_launch=launch
                    if self.BANK_LAUNCH_BUDGET and used>=self.BANK_LAUNCH_BUDGET:
                        return best
                    used+=1
                    path, bounce = self._bank_path(*launch)
                    if bounce is None or bounce > 1.2:
                        continue
                    after = [s for s in path if s[0] >= bounce + self._dt]
                    contact = None
                    for t, x, y in after:
                        if t > 2.2:
                            break
                        if self._eta(receiver, x, y) <= t + 0.03:
                            contact = t, x, y
                            break
                    if contact is None or contact[1] < bx + 5.0:
                        continue
                    arrival, x, y = contact
                    if abs(y) > self._half_height - 2.0:
                        continue
                    relevant = [s for s in path if s[0] <= arrival + 0.16]
                    enemy = 100.0
                    for t, x0, y0 in relevant:
                        if t<=0.35:
                            steps=max(1,int(round(t*self._hz)))
                            decay=self._damping**steps
                            coast=self._dt*self._damping*(1.0-decay)/(1.0-self._damping)
                            reach=self._dt*self._acc/(1.0-self._damping)*(steps-self._damping*(1.0-decay)/(1.0-self._damping))
                        for opponent in opponents:
                            reachable = self._eta(opponent,x0,y0) <= t+0.03
                            if t<=0.35:
                                # Bodies still obstruct a pass on cooldown.
                                ex=opponent[1]+opponent[3]*coast
                                ey=opponent[2]+opponent[4]*coast
                                radius=(self._range if self._enemy_cooldowns.get(opponent[0],0)<=steps else self._contact)
                                reachable = reachable or math.hypot(x0-ex,y0-ey)<=reach+radius
                            if reachable:
                                enemy=t
                                break
                        if enemy<100.0:
                            break
                    if arrival+self.BANK_MARGIN>enemy:
                        continue
                    # Reject an early teammate obstruction as well as an
                    # opponent interception on either leg of the rebound.
                    blocked = False
                    for t, x0, y0 in relevant:
                        if t > arrival - 0.10:
                            continue
                        for other in friends[1:]:
                            if other[0] == receiver[0] or (other[0] == p[0] and t<0.30):
                                continue
                            if self._eta(other, x0, y0) <= t - 0.05:
                                blocked = True
                                break
                        if blocked:
                            break
                    if blocked:
                        continue
                    score = (x-bx)*0.07 + min(enemy-arrival, 0.8)*1.5 - arrival*0.30
                    if best is None or score > best[0]:
                        best = score, kick, movement, (receiver[0], x, y)
        return best

    def _counterpress_targets(self, obs, bx, by, vx, vy, outfield,
                              opponents, races, chaser, enemy_eta, protected, baseline_targets):
        """Brief Klopp transition trap, then the established Pep positions.

        A new opposing touch after our actual contact starts the timer. A
        loose ball retaining its old controlling_team never starts a press.
        Public canonical player ids identify the side that actually touched.
        """
        own_ids = {p[0] for p in outfield}
        own_ids.add(0)
        enemy_ids = {p[0] for p in opponents}
        touch = obs.ball.last_touch
        holder = obs.ball.controlling_player
        touch_changed = touch is not None and touch != self._press_last_ball_touch
        holder_changed = holder is not None and holder != self._press_last_ball_holder
        # A newly observed physical touch is newer evidence than a player
        # remaining within control range. Preserve that edge if they conflict.
        actual = touch if touch_changed else holder if holder_changed else None
        owner = 0 if actual in own_ids else 1 if actual in enemy_ids else None
        if owner == 0:
            self._press_own_contact_tick = obs.tick
            self._press_until = -1
        elif (owner == 1 and self._press_contact_owner == 0
              and obs.tick - self._press_own_contact_tick <= int(2.5 * self._hz)
              and not protected and bx >= 0.0):
            self._press_until = obs.tick + int(self.COUNTERPRESS_SECONDS * self._hz)
            self._press_origin = (bx, by)
        if owner is not None:
            self._press_contact_owner = owner
        elif holder in own_ids and self._press_contact_owner == 0:
            # A continuous own hold keeps recent-contact evidence fresh but
            # cannot overwrite a newer opposing touch or restart the timer.
            self._press_own_contact_tick = obs.tick
        self._press_last_ball_touch = touch
        self._press_last_ball_holder = holder
        if protected or obs.tick >= self._press_until or self._press_origin is None:
            return None

        # Abandon a broken trap before it pulls the back line toward a
        # completed counterattack. The original interception still applies.
        origin_x, origin_y = self._press_origin
        nearest = races[chaser[0]][0]
        local = sum(math.hypot(p[1] - bx, p[2] - by) < 16.0 for p in outfield)
        escaped = (bx < 0.0 or math.hypot(vx, vy) > 12.0 or bx < origin_x - 7.0
                   or math.hypot(bx - origin_x, by - origin_y) > 15.0
                   or nearest > enemy_eta + self.COUNTERPRESS_RACE_MARGIN
                   or local < 2
                   or (vx < -13.0 and abs(by) < self._mouth + 5.0))
        if escaped:
            self._press_until = -1
            return None

        targets = {chaser[0]: self._target(*races[chaser[0]][1])}
        available = [p for p in outfield if p[0] != chaser[0]]
        if len(available) < 2:
            return None
        # Keep the established deepest target and every other support run.
        # This loss-only variation adds one nearby exit-lane screen rather
        # than replacing the existing defensive or attacking structure.
        reserve = min(available, key=lambda p: baseline_targets[p[0]][0])
        available = [p for p in available if p[0] != reserve[0]]
        outlets = [o for o in opponents
                   if o[1] < bx + 1.0
                   and 4.0 < math.hypot(o[1] - bx, o[2] - by) < 27.0]
        if outlets:
            outlet = min(outlets, key=lambda o:
                         self._eta(chaser, o[1], o[2]) * 0.35
                         + math.hypot(o[1] - bx, o[2] - by) * 0.03
                         + (o[1] - bx) * 0.025)
            ux, uy = _unit(outlet[1] - bx, outlet[2] - by)
            screen = self._target(bx + ux * 4.0, by + uy * 4.0)
        else:
            screen = self._target(bx - 3.8, by * 0.65)
        second = self._closest_eta(available, screen)
        # Both pressure players must already be close enough to contribute
        # inside this one-second phase; the baseline retains its shape if not.
        if (self._eta(second, *screen) > 0.55
                or math.hypot(chaser[1] - bx, chaser[2] - by) > 8.0):
            return None
        targets[second[0]] = screen
        return targets

    def act(self, obs):
        if not self._ready:
            self._setup(obs.field)
            self._restart_until = obs.tick + int(3.0 * self._hz)
            self._restart_owner = obs.ball.controlling_team
        # A changed public score identifies a goal without copying or
        # scanning event payloads in the decision loop.
        score = obs.score
        if self._last_score is not None and score != self._last_score:
            self._restart_until = obs.tick + int(3.0 * self._hz)
            self._restart_owner = 0 if score[1] > self._last_score[1] else 1
            self._chaser = -1
            self._receive_plan = None
            self._bank_receive = None
            self._cover_id = None
            self._mark_assignments = {}
            self._press_until = -1
            self._press_origin = None
            self._press_contact_owner = None
            self._press_own_contact_tick = -100000
            self._press_last_ball_touch = None
            self._press_last_ball_holder = None
        self._last_score = score
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        if math.hypot(bx, by) > 0.7 or math.hypot(vx, vy) > 0.15:
            self._restart_until = -1
        protected = (obs.tick < self._restart_until and self._restart_owner == 1)
        friends = [(p.id, *p.position, *p.velocity) for p in obs.my_players]
        opponents = [(p.id, *p.position, *p.velocity) for p in obs.opponents]
        self._enemy_cooldowns = {p.id:p.kick_cooldown_ticks for p in obs.opponents}
        self._tactics_observe(obs, friends, opponents)
        actions = TeamAction(debug={"roles": self.PLAYER_ROLES})
        if not friends:
            return actions
        keeper = friends[0]
        outfield = friends[1:] or friends
        samples = self._trajectory(bx, by, vx, vy)
        races = {}
        chaser = None
        chaser_eta = None
        previous = None
        for p in outfield:
            race = self._intercept(p, samples)
            races[p[0]] = race
            if chaser is None or race[0] < chaser_eta:
                chaser, chaser_eta = p, race[0]
            if p[0] == self._chaser:
                previous = p
        if previous is not None and races[previous[0]][0] < races[chaser[0]][0] + 0.12:
            chaser = previous
        self._chaser = chaser[0]
        enemy_eta = None
        for o in opponents:
            eta = self._intercept(o, samples)[0]
            if enemy_eta is None or eta < enemy_eta:
                enemy_eta = eta
        if enemy_eta is None:
            enemy_eta = 100.0
        self._transition_observe(obs,protected,friends,opponents,
            (min((v[0] for k,v in races.items() if k!=0),default=100.0),enemy_eta))
        attack = races[chaser[0]][0] <= enemy_eta + 0.12

        keeper_x = self._left + 2.2
        keeper_y = by * 2.2 / max(3.0, bx - self._left)
        # Stay central while a slow approach can still be redirected. Commit
        # only after a fast, near-term shot reveals its actual goal-line path.
        if (self.PREDICTIVE_KEEPER and vx < -8.0
                and math.hypot(vx, vy) >= 12.0 and bx > keeper_x):
            time_to_line = (keeper_x - bx) / vx
            if 0.0 < time_to_line < 1.25:
                keeper_y = by + vy * time_to_line
        keeper_target = (keeper_x, _clip(keeper_y, -self._mouth, self._mouth))
        sweep = bx < self._left+10.0 and self._eta(keeper,bx,by)<races[chaser[0]][0]*0.85
        if sweep and abs(by)>self._mouth+1.0:
            # Wide collection is useful only with a clear first arrival.
            # Do not drag the keeper along its own fast outgoing clearance.
            ours=self._eta(keeper,bx,by)
            theirs=min((self._eta(o,bx,by) for o in opponents),default=100.0)
            away=(obs.ball.last_touch==keeper[0] and vx>6.0
                  and (bx-keeper[1])*vx+(by-keeper[2])*vy>0.0)
            sweep=(not away and ours<=1.10 and ours+0.20<theirs)
        if self.KEEPER_PRIORITY and self.PREDICTIVE_KEEPER and vx<-8.0 and math.hypot(vx,vy)>=12.0 and bx>keeper_x:
            flight=(keeper_x-bx)/vx
            if 0.0<flight<0.55:
                goal_y=by+vy*(self._left+self._ball_radius-bx)/vx
                opposite=(keeper_target[1]-keeper[2])*(by-keeper[2])<0.0
                if abs(goal_y)<=self._mouth+0.6 and opposite:
                    cooldown=obs.my_players[0].kick_cooldown_ticks
                    line=self._keeper_reaches(keeper,bx,by,vx,vy,keeper_target,False,cooldown)
                    rush=self._keeper_reaches(keeper,bx,by,vx,vy,keeper_target,True,cooldown)
                    if line and not rush:
                        sweep=False
        if self.KEEPER_RECOVERY:
            outgoing=(obs.ball.last_touch==keeper[0] and vx>10.0
                      and self._receive_plan is not None and self._receive_plan[1]==keeper[0]
                      and math.hypot(bx-keeper[1],by-keeper[2])>self._range+0.3)
            if outgoing:
                receiver_id=self._receive_plan[0]
                receiver=next((p for p in outfield if p[0]==receiver_id),None)
                safe=(receiver is not None and races[receiver_id][0]+0.12<enemy_eta)
                if safe:
                    sweep=False
        if sweep:
            keeper_target=self._target(bx,by)

        targets = {keeper[0]: keeper_target, chaser[0]: self._target(*races[chaser[0]][1])}
        free = [p for p in outfield if p[0] != chaser[0]]
        self._shape_cover_id = None
        if free:
            cover_target = self._target(min(28.0, bx - 2.0),
                                        _clip(by, -self._half_height + 2.0, self._half_height - 2.0))
            cover = self._role_closest_eta(free, cover_target, cover=True)
            if cover[0] == 1:
                cover_target = self._target(min(28.0, bx - 3.5), cover_target[1])
            elif cover[0] == 2:
                cover_target = self._target(min(28.0, bx - 2.75), cover_target[1])
            targets[cover[0]] = cover_target
            self._shape_cover_id = cover[0]
            free = [p for p in free if p[0] != cover[0]]
        if attack:
            spread = max(7.0, 15.0 - max(0.0, bx - 20.0) * 0.35)
            free.sort(key=lambda p: p[2])
            for index, p in enumerate(free):
                lane = 0.0 if len(free) == 1 else -spread + 2.0 * spread * index / (len(free) - 1)
                targets[p[0]] = self._role_support(p, bx, by, lane)
        else:
            threats = sorted(opponents, key=lambda p: p[1] + abs(p[2]) * 0.2)
            for threat in threats:
                if not free:
                    break
                if math.hypot(threat[1] - bx, threat[2] - by) < 3.5:
                    continue
                ux, uy = _unit(self._left - threat[1], -threat[2])
                target = self._target(threat[1] + ux * 3.0, threat[2] + uy * 3.0)
                marker = (self._choose_marker(free,target,threat[0],obs.tick)
                          if self.MARK_HANDOFF else self._role_closest_eta(free,target))
                targets[marker[0]] = target
                free = [p for p in free if p[0] != marker[0]]
            for p in free:
                targets[p[0]] = self._target(bx - 9.0, p[2] * 0.5)

        self._transition_support(bx, by, friends, opponents, chaser[0], targets)
        actions.debug["text"] = ("Klopp quick transition" if self._transition_active
                                  else "Pep positional control")
        press_targets = self._counterpress_targets(
            obs, bx, by, vx, vy, outfield, opponents,
            races, chaser, enemy_eta, protected, targets)
        if press_targets is not None:
            targets.update(press_targets)
            actions.debug["text"] = "Klopp brief counterpress; Pep cover"

        receive_target = None
        if self._receive_plan is not None:
            recipient, passer, expiry = self._receive_plan
            recipient_player = next((p for p in outfield if p[0] == recipient), None)
            if (recipient_player is None or obs.tick > expiry
                    or obs.ball.last_touch not in (None, passer)
                    or math.hypot(vx, vy) < (5.0 if self.TIKI_TAKA else 9.0)):
                self._receive_plan = None
                self._bank_receive = None
            else:
                race = races[recipient]
                bank = self._bank_receive
                if bank is not None and bank[0]==recipient and bank[1]==passer:
                    targets[recipient] = self._target(*bank[2])
                elif race[0] <= races[chaser[0]][0]+0.25 and race[0] <= enemy_eta+0.15:
                    targets[recipient] = self._target(*race[1])

        if (self.MARK_HANDOFF and attack and not protected
                and enemy_eta<races[chaser[0]][0]+0.10):
            self._retain_mark(obs,friends,opponents,chaser,targets)
        if self.COVER_SHAPE and not protected:
            self._cover_shape(obs, friends, opponents, chaser, races, enemy_eta, targets)

        self._tactics_targets(obs, friends, opponents, chaser, races, enemy_eta, targets, protected)
        actions.debug["text"] = self._tactical_mode

        carrier = None
        carrier_gap = None
        for p in friends:
            if obs.can_kick(p[0]):
                gap = math.hypot(p[1] - bx, p[2] - by)
                if carrier is None or gap < carrier_gap:
                    carrier, carrier_gap = p, gap
        launched_pass = None
        for p in friends:
            target = targets.get(p[0], (p[1], p[2]))
            if protected and math.hypot(p[1], p[2]) < self._circle + 5.0:
                ux, uy = _unit(p[1], p[2])
                target = (ux * (self._circle + 3.0), uy * (self._circle + 3.0))
            kick = None
            if carrier is not None and p[0] == carrier[0] and not protected:
                # The carrier's original general movement was immediately
                # replaced; _move is pure, so calculate only the used value.
                movement = self._move(p, target if p[0] in self._guard_ids else (bx + 0.3, by))
                nx = p[3] * self._damping + movement[0] * self._acc
                ny = p[4] * self._damping + movement[1] * self._acc
                speed = math.hypot(nx, ny)
                if speed > self._speed:
                    nx *= self._speed / speed
                    ny *= self._speed / speed
                # The engine moves players before checking kick range.
                distance_next = math.hypot(p[1] + nx * self._dt - bx,
                                           p[2] + ny * self._dt - by)
                if distance_next < self._range - 0.18:
                    kick = self._choose_kick(p, bx, by, vx, vy, friends, opponents)
                    if self._touch_movement is not None:
                        movement = self._touch_movement
                    self._receive_plan = None
                    self._bank_receive = None
                    if kick is not None and self._bank_plan is not None:
                        recipient,x,y=self._bank_plan
                        launched_pass=recipient,(x,y)
                        self._receive_plan=(recipient,p[0],obs.tick+int(2.6*self._hz))
                        self._bank_receive=(recipient,p[0],(x,y))
                    if kick is not None and self._pass_plan is not None and self._bank_plan is None:
                        recipient = self._pass_plan[0]
                        sx, sy = self._requested_velocity(vx, vy, kick)
                        launch = self._carrier_contact(p, bx, by, sx, sy, movement)
                        if launch is not None and math.hypot(launch[2], launch[3]) > (7.0 if self.TIKI_TAKA else 10.5):
                            # Correct for our own body contact, including a kick
                            # changed by the pre-existing own-half return guard.
                            trajectory = self._trajectory(*launch)
                            receiver = next((q for q in outfield if q[0] == recipient), None)
                            if receiver is not None:
                                receiver_race = self._intercept(receiver, trajectory)
                                nearest = min(self._intercept(q, trajectory)[0] for q in outfield)
                                enemy_race = min((self._intercept(q, trajectory)[0] for q in opponents),default=100.0)
                                if receiver_race[0] <= nearest+0.25 and receiver_race[0] <= enemy_race+0.15:
                                    launched_pass = recipient, receiver_race[1]
                                    self._receive_plan = (recipient,p[0],obs.tick+int(2.6*self._hz))
            else:
                movement = self._move(p, target, friends if p[0] != chaser[0] and p[0] != 0 and p[0] not in self._guard_ids else ())
            if kick is None:
                actions.set(p[0], PlayerAction(movement=movement))
            else:
                actions.set(p[0], PlayerAction(movement=movement,
                                               kick_direction=kick[0],
                                               kick_power=kick[1]))
        if launched_pass is not None:
            recipient, target = launched_pass
            receiver = next(p for p in outfield if p[0] == recipient)
            actions.set(recipient,PlayerAction(movement=self._move(receiver,self._target(*target))))
        return actions

    def _option_path(self, launch):
        # Launch already includes the first movement/contact tick.
        return [(t+self._dt,x,y) for t,x,y in self._trajectory(*launch)]

    def _early_body_margin(self, path, opponents, until):
        margin = 2.0
        for t,x,y in path:
            if t>min(until,0.55):
                break
            n=max(1,int(round(t*self._hz)))
            decay=self._damping**n
            coast=self._dt*self._damping*(1.0-decay)/(1.0-self._damping)
            reach=self._dt*self._acc/(1.0-self._damping)*(n-self._damping*(1.0-decay)/(1.0-self._damping))
            for q in opponents:
                radius=self._range if self._enemy_cooldowns.get(q[0],0)<=n else self._contact
                gap=math.hypot(x-q[1]-q[3]*coast,y-q[2]-q[4]*coast)
                margin=min(margin,(gap-reach-radius)/self._speed)
        return margin

    def _link_option(self,p,bx,by,vx,vy,receiver,opponents,tx,ty,speed):
        ux,uy=_unit(tx-bx,ty-by)
        kick=self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
        if kick is None:
            return None
        movement=self._move(p,(bx+0.3,by))
        sx,sy=self._requested_velocity(vx,vy,kick)
        launch=self._carrier_contact(p,bx,by,sx,sy,movement)
        if launch is None:
            return None
        path=self._option_path(launch)
        arrival,point=self._intercept(receiver,path)
        if arrival>1.8 or point[0]<self._left+9.0 or math.hypot(point[0]-bx,point[1]-by)<(3.0 if self.TIKI_TAKA else 4.0):
            return None
        enemy=min((self._intercept(q,path)[0] for q in opponents),default=100.0)
        margin=enemy-arrival
        if margin<self.LINK_MARGIN or self._early_body_margin(path,opponents,arrival)<-0.04:
            return None
        progress=math.hypot(self._right-bx,by)-math.hypot(self._right-point[0],point[1])
        space=min((math.hypot(point[0]-q[1]-q[3]*min(arrival,.5),point[1]-q[2]-q[4]*min(arrival,.5)) for q in opponents),default=20.0)
        score=0.9+progress*.15+min(margin,.8)*3.0+min(space,9.0)*.10-arrival*.7
        if abs(point[1])<12.0 and point[0]>self._right-27.0:
            score+=1.0
        if p[0]==0 or bx<self._left+17.0:
            score+=.7
        return score,kick,movement,(receiver[0],point[0],point[1])

    def _v7_search_links(self,p,bx,by,vx,vy,friends,opponents):
        best=None
        for q in friends:
            if q[0] in (p[0],0):
                continue
            gap=math.hypot(q[1]-bx,q[2]-by)
            if not 4.0<gap<39.0:
                continue
            # Different powers let a nearby receiver collect the pass rather
            # than treating every link as a 24-unit/s clearance.
            for speed in (14.0,20.0,26.0):
                lead=min(.9,self._flight(gap,speed))
                tx,ty=self._target(q[1]+q[3]*lead*.8,q[2]+q[4]*lead*.8)
                option=self._link_option(p,bx,by,vx,vy,q,opponents,tx,ty,speed)
                if option is not None and (best is None or option[0]>best[0]):
                    best=option
        return best

    def _goal_path(self,launch):
        x,y,vx,vy=launch
        path=[(self._dt,x,y)]
        wall=self._half_height-self._ball_radius
        goal=self._right-self._ball_radius
        for tick in range(2,61):
            oldx,oldy=x,y
            x+=vx*self._dt;y+=vy*self._dt
            if abs(y)>wall:
                side=1.0 if y>0.0 else -1.0
                y=side*wall*2.0-y;vy=-side*abs(vy)*self._wall
            if x>=goal and vx>0.0:
                fraction=(goal-oldx)/max(1e-9,x-oldx)
                gy=oldy+(y-oldy)*fraction
                if abs(gy)>self._mouth+.15:
                    return None
                time=(tick-1+fraction)*self._dt
                path.append((time,goal,gy))
                return path,(time,gy,math.hypot(vx,vy))
            if x<=self._left+self._ball_radius:
                return None
            vx*=self._friction;vy*=self._friction
            if tick%2==0:
                path.append((tick*self._dt,x,y))
        return None

    def _shot_option(self,p,bx,by,vx,vy,opponents,target_y,bank=False):
        if bank:
            wall=(self._half_height-self._ball_radius)*(1.0 if by>=0.0 else -1.0)
            aim_y=wall+(wall-target_y)/self._wall
        else:
            aim_y=target_y
        ux,uy=_unit(self._right-bx,aim_y-by)
        along=vx*ux+vy*uy
        sideways=max(0.0,vx*vx+vy*vy-along*along)
        if sideways>=self._impulse*self._impulse:
            return None
        speed=min(self._ball_cap,along+math.sqrt(self._impulse*self._impulse-sideways))
        kick=self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
        if kick is None:
            return None
        movement=self._move(p,(bx+.3,by))
        sx,sy=self._requested_velocity(vx,vy,kick)
        launch=self._carrier_contact(p,bx,by,sx,sy,movement)
        if launch is None:
            return None
        forecast=self._goal_path(launch)
        if forecast is None:
            return None
        path,(flight,gy,end_speed)=forecast
        if flight>2.5 or end_speed<6.0:
            return None
        margin=min((self._eta(q,x,y)-t for t,x,y in path for q in opponents),default=1.0)
        body=self._early_body_margin(path,opponents,flight)
        if margin<self.SHOT_MARGIN or body<-.06:
            return None
        score=6.0+min(margin,.5)*4.0-flight*.7+min(end_speed,20.0)*.03
        return score,kick,movement,None

    def _before_endwall(self,p,bx,by,vx,vy,friends,opponents):
        fallback=self._legacy_policy_kick(p,bx,by,vx,vy,friends,opponents)
        pressure=min((math.hypot(q[1]-bx,q[2]-by) for q in opponents),default=100.0)
        fallback_plan=self._pass_plan
        fallback_bank=self._bank_plan
        fallback_move=self._touch_movement
        best=None
        # Clear, reachable shots retain priority over sideways retention.
        if bx>self._right-40.0:
            for y in (-5.7,-3.0,0.0,3.0,5.7):
                option=self._shot_option(p,bx,by,vx,vy,opponents,y)
                if option is not None and (best is None or option[0]>best[0]):
                    best=option
        link=self._search_links(p,bx,by,vx,vy,friends,opponents)
        if link is not None and (best is None or link[0]>best[0]):
            best=link
        # Rate the existing action too; a search is not permission to replace
        # a productive shot or carry with an arbitrary pass.
        old_score=-2.0
        if fallback is not None:
            sx,sy=self._requested_velocity(vx,vy,fallback)
            move=fallback_move or self._move(p,(bx+.3,by))
            launch=self._carrier_contact(p,bx,by,sx,sy,move)
            goal=self._goal_path(launch) if launch is not None and sx>0.0 else None
            if goal is not None:
                path,(flight,gy,end_speed)=goal
                margin=min((self._eta(q,x,y)-t for t,x,y in path for q in opponents),default=1.0)
                old_score=6.0+min(margin,.5)*4.0-flight*.7+min(end_speed,20.0)*.03
            elif fallback_plan is not None:
                receiver=next((q for q in friends if q[0]==fallback_plan[0]),None)
                if receiver is not None:
                    rated=self._link_option(p,bx,by,vx,vy,receiver,opponents,fallback_plan[1],fallback_plan[2],math.hypot(sx,sy))
                    old_score=rated[0] if rated is not None else -.5
            elif math.hypot(sx,sy)<=10.5:
                path=self._touch_path(p,bx,by,vx,vy,fallback,move,opponents)
                old_score=path[0]*.55 if path is not None else -2.0
        if best is not None and best[0]>old_score+self.OPTION_SWITCH_MARGIN:
            self._touch_movement=best[2]
            self._pass_plan=best[3]
            self._bank_plan=None
            return best[1]
        self._pass_plan=fallback_plan
        self._bank_plan=fallback_bank
        self._touch_movement=fallback_move
        return fallback

    def _endwall_link(self,p,bx,by,vx,vy,friends,opponents):
        if bx<15.0 or abs(by)<8.0 or p[0]==0:
            return None
        wall=self._right-self._ball_radius
        movement=self._move(p,(bx+.3,by))
        best=None
        for q in friends[1:]:
            if q[0]==p[0] or q[1]<max(bx+2.0,self._right-24.0):
                continue
            for extra in (-4.0,0.0,4.0):
                tx,ty=self._target(q[1]+q[3]*.4,q[2]+q[4]*.4+extra)
                virtual=wall+(wall-tx)/self._wall
                ux,uy=_unit(virtual-bx,ty-by)
                along=vx*ux+vy*uy
                sideways=max(0.0,vx*vx+vy*vy-along*along)
                if sideways>=self._impulse*self._impulse:
                    continue
                speed=min(self._ball_cap,along+math.sqrt(self._impulse*self._impulse-sideways))
                kick=self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
                if kick is None:continue
                sx,sy=self._requested_velocity(vx,vy,kick)
                launch=self._carrier_contact(p,bx,by,sx,sy,movement)
                if launch is None or launch[2]<6.0:continue
                n=self._crossing_ticks(launch[0],launch[2],wall)
                if n>32:continue
                hit_y=launch[1]+launch[3]*self._roll[n]
                if not self._mouth+1.1<abs(hit_y)<self._half_height-1.0:
                    continue
                path=self._option_path(launch)
                post=[sample for sample in path if sample[0]>(n+1)*self._dt]
                if not post:continue
                arrival,point=self._intercept(q,post)
                if arrival>2.4 or point[0]<self._right-25.0:continue
                enemy=min((self._intercept(o,path)[0] for o in opponents),default=100.0)
                margin=enemy-arrival
                if margin<.12 or self._early_body_margin(path,opponents,arrival)<-.04:
                    continue
                progress=math.hypot(self._right-bx,by)-math.hypot(self._right-point[0],point[1])
                space=min((math.hypot(point[0]-o[1],point[1]-o[2]) for o in opponents),default=20.0)
                score=.9+progress*.15+min(margin,.8)*3.0+min(space,9.0)*.10-arrival*.7
                if point[0]>self._right-20.0 and abs(point[1])<12.0:score+=1.0
                if best is None or score>best[0]:
                    best=score,kick,movement,(q[0],point[0],point[1])
        return best

    def _v7_choose_kick(self,p,bx,by,vx,vy,friends,opponents):
        fallback=self._before_endwall(p,bx,by,vx,vy,friends,opponents)
        if fallback is None or bx<15.0 or abs(by)<8.0:
            return fallback
        sx,sy=self._requested_velocity(vx,vy,fallback)
        move=self._touch_movement or self._move(p,(bx+.3,by))
        launch=self._carrier_contact(p,bx,by,sx,sy,move)
        if launch is not None:
            goal=self._goal_path(launch)
            if goal is not None:
                path,_=goal
                margin=min((self._eta(q,x,y)-t for t,x,y in path for q in opponents),default=1.0)
                if margin>=-.04:return fallback
        option=self._endwall_link(p,bx,by,vx,vy,friends,opponents)
        if option is None:return fallback
        score=-2.0
        if self._pass_plan is not None:
            q=next((q for q in friends if q[0]==self._pass_plan[0]),None)
            rated=self._link_option(p,bx,by,vx,vy,q,opponents,self._pass_plan[1],self._pass_plan[2],math.hypot(sx,sy)) if q else None
            if rated is not None:score=rated[0]
        elif math.hypot(sx,sy)<=10.5:
            rated=self._touch_path(p,bx,by,vx,vy,fallback,move,opponents)
            if rated is not None:score=rated[0]*.55
        if option[0]>score+.2:
            self._touch_movement=option[2]
            self._pass_plan=option[3];self._bank_plan=option[3]
            return option[1]
        return fallback

    def _tactics_reset(self):
        self._tactic_score = None
        self._tactic_tick = -1
        self._threat_scores = {}
        self._striker_id = None
        self._striker_marker = None
        self._incoming_until = -1
        self._rebound_until = -1
        self._previous_touch = None
        self._previous_ball_vx = 0.0
        self._break_until = -1
        self._break_start = -1
        self._break_origin = 0.0
        self._break_ids = ()
        self._guard_ids = ()
        self._shield_active = False
        self._tactical_mode = "balanced"
        self._tiki_outlet = None
        self._tiki_next = None
        self._last_link = None
        self._tactical_targets = {}
        self._midfield_shot = False
        self._bounce_plan = None

    def _tactics_observe(self, obs, friends, opponents):
        # Score changes clear plans from the previous restart. Only an observed
        # incoming opponent shot can arm a subsequent rebound counter.
        tick = obs.tick
        score = tuple(obs.score)
        if self._tactic_score is not None and score != self._tactic_score:
            self._incoming_until = self._rebound_until = self._break_until = -1
            self._break_ids = ()
            self._tiki_outlet = None
            self._last_link = None
            self._previous_touch = None
            self._previous_ball_vx = 0.0
        self._tactic_score = score
        self._tactic_tick = tick
        self._shield_active = self.SCORE_SHIELD and score[0] - score[1] >= 2
        if not self._shield_active:
            self._break_until = -1
            self._break_ids = ()
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        ours = {p[0] for p in friends}
        theirs = {p[0] for p in opponents}
        touch = obs.ball.last_touch
        if tick % max(1, int(self._hz)) == 0:
            self._threat_scores = {key: value * .90 for key, value in self._threat_scores.items() if key in theirs}
        goal_bound = (vx < -6.0 and bx < self._left + 40.0
                      and abs(by + vy * (self._left + self._ball_radius - bx) / vx) < self._mouth + 1.2)
        if goal_bound and (touch in theirs or tick <= self._incoming_until):
            self._incoming_until = tick + int(1.5 * self._hz)
            if touch in theirs and touch != self._previous_touch:
                self._threat_scores[touch] = min(8.0, self._threat_scores.get(touch, 0.0) + 2.0)
        own_save = touch in ours and touch != self._previous_touch
        reversed_shot = self._previous_ball_vx < -2.0 and vx > 2.0
        if (tick <= self._incoming_until and bx < self._left + 28.0
                and (own_save or reversed_shot)):
            self._rebound_until = tick + int(1.4 * self._hz)
        if touch in theirs and touch != self._previous_touch:
            self._rebound_until = -1
            self._tiki_outlet = None
            if not goal_bound:
                self._break_until = -1
        self._previous_touch = touch
        self._previous_ball_vx = vx
        self._midfield_shot = False

    def _own_secure(self, obs, friends, chaser, races, enemy_eta):
        ours = {p[0] for p in friends}
        holder = obs.ball.controlling_player
        if holder is not None:
            return holder in ours
        return obs.ball.last_touch in ours and races[chaser[0]][0] + .18 < enemy_eta

    def _shadow_striker(self, obs, friends, opponents, chaser, races, enemy_eta, targets):
        if not self.STRIKER_MARK or len(opponents) < 2:
            self._striker_marker = None
            return
        bx, by = obs.ball.position
        candidates = opponents[1:]
        def threat(q):
            return -q[1] - abs(q[2]) * .18 + min(6.0, self._threat_scores.get(q[0], 0.0)) * 2.0
        striker = max(candidates, key=threat)
        old = next((q for q in candidates if q[0] == self._striker_id), None)
        if old is not None and threat(old) + 2.5 >= threat(striker):
            striker = old
        self._striker_id = striker[0]
        ux, uy = _unit(self._left - striker[1], -striker[2])
        target = self._target(striker[1] + ux * self.MARK_DISTANCE,
                              striker[2] + uy * self.MARK_DISTANCE)
        free = [p for p in friends[1:] if p[0] != chaser[0]]
        if not free:
            self._striker_marker = None
            return
        secure = self._own_secure(obs, friends, chaser, races, enemy_eta)
        cover = next((p for p in free if p[0] == self._shape_cover_id), None)
        if secure and cover is not None:
            marker = cover
            target = self._target(min(target[0], bx - 2.5), target[1])
        else:
            prior = self._mark_assignments.get(striker[0])
            marker = next((p for p in free if prior is not None and p[0] == prior[0]), None)
            best = self._closest_eta(free, target)
            if marker is None or self._eta(marker, *target) > self._eta(best, *target) + .35:
                marker = best
        self._striker_marker = marker[0]
        targets[marker[0]] = target
        self._mark_assignments[striker[0]] = (marker[0], obs.tick + int(.6 * self._hz))

    def _wall_collection(self, obs, friends, opponents, chaser, races, enemy_eta, targets):
        self._bounce_plan = None
        if not self.SECOND_BALL:
            return
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        hit_x = self._crossing_ticks(bx, vx, self._right - self._ball_radius)
        hit_y = self._crossing_ticks(by, vy, self._half_height - self._ball_radius)
        hit = min(hit_x, hit_y)
        # A ball entering either goal does not rebound off an end wall.
        if hit_x <= hit_y and abs(vx) > 1e-9:
            end_x = self._right - self._ball_radius if vx > 0.0 else self._left + self._ball_radius
            goal_y = by + vy * (end_x - bx) / vx
            if abs(goal_y) <= self._mouth + .6:
                return
        bounce_time = hit * self._dt
        if hit > int(1.1 * self._hz) or races[chaser[0]][0] < bounce_time - .1:
            return
        path = self._trajectory(bx, by, vx, vy)
        after = [s for s in path if s[0] >= bounce_time]
        if not after:
            return
        options = [(self._intercept(p, after), p) for p in friends[1:]]
        race, collector = min(options, key=lambda item: item[0][0])
        enemy = min((self._intercept(q, after)[0] for q in opponents), default=100.0)
        if race[0] + .14 >= enemy or race[0] > 1.8:
            return
        if collector[0] in (self._striker_marker, self._shape_cover_id):
            return
        targets[collector[0]] = self._target(*race[1])
        free = [p for p in friends[1:] if p[0] not in (collector[0], self._shape_cover_id, self._striker_marker)]
        if free:
            side = 1.0 if race[1][1] >= 0.0 else -1.0
            outlet_target = self._target(race[1][0] + 6.0, race[1][1] - side * 7.0)
            outlet = self._closest_eta(free, outlet_target)
            targets[outlet[0]] = outlet_target
            self._bounce_plan = (collector[0], outlet[0], race[1])

    def _rebound_break(self, obs, friends, opponents, races, enemy_eta, protected):
        # Releasing two is conditional on first arrival, possession and a
        # recoverable forward route; losing the race immediately restores cover.
        tick = obs.tick
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        full_races = dict(races)
        full_races[friends[0][0]] = self._intercept(friends[0], self._trajectory(bx, by, vx, vy))
        collector = min(friends, key=lambda p: full_races[p[0]][0])
        ours = full_races[collector[0]][0]
        own_ids = {p[0] for p in friends}
        holder = obs.ball.controlling_player
        secure = holder in own_ids or (obs.ball.last_touch in own_ids and ours + .18 < enemy_eta)
        if protected or (holder is not None and holder not in own_ids) or enemy_eta + .10 < ours:
            self._break_until = -1
            self._break_ids = ()
            return ()
        if tick < self._break_until:
            if secure and bx > self._break_origin + 6.0 and tick < self._break_start + int(6.0 * self._hz):
                self._break_until = max(self._break_until, tick + int(.8 * self._hz))
            return self._break_ids
        self._break_ids = ()
        ready = obs.can_kick(collector[0])
        if (not self.REBOUND_COUNTER or protected or tick > self._rebound_until
                or ours + .15 >= enemy_eta or ours > 1.25
                or (vx <= 1.5 and not (ready and math.hypot(vx, vy) < 9.0))):
            return ()
        tx, ty = self._target(bx + 10.0, by * .7)
        clear = self._lane(bx, by, tx, ty, 10.0, opponents) >= 1.2
        if ready:
            touch = self._controlled_touch(collector, bx, by, vx, vy, opponents)
            good_touch = False
            if touch is not None:
                rated = self._touch_path(collector, bx, by, vx, vy, touch[1], touch[2], opponents)
                good_touch = rated is not None and rated[1] >= .10 and rated[2] <= .7
            link = self._search_links(collector, bx, by, vx, vy, friends, opponents)
            clear = clear and (good_touch or (link is not None and link[3][1] >= bx + 4.0))
        if not clear:
            return ()
        free = [p for p in friends[1:] if p[0] != collector[0]]
        if not free:
            return ()
        side = 1.0 if by >= 0.0 else -1.0
        outlet = self._closest_eta(free, self._target(tx + 3.0, ty - side * 6.0))
        self._break_ids = (collector[0], outlet[0])
        self._break_start = tick
        self._break_until = tick + int(2.5 * self._hz)
        self._break_origin = bx
        return self._break_ids

    def _shield_positions(self, players, targets):
        if not players:
            return
        x = self._left + self._player_radius + .05
        span = self._mouth - .8
        keeper = next((p for p in players if p[0] == 0), None)
        others = sorted((p for p in players if p[0] != 0), key=lambda p: p[2])
        if self.SHIELD_SHAPE == "flat" or len(players) < 5:
            if keeper is not None:
                targets[keeper[0]] = (x, 0.0)
                ys = (-span, -span * .5, span * .5, span) if len(others) == 4 else (-span * .8, span * .8) if len(others) == 2 else tuple(-span + 2.0 * span * i / max(1, len(others)-1) for i in range(len(others)))
            else:
                ys = tuple(-span * .8 + 1.6 * span * i / max(1, len(others)-1) for i in range(len(others)))
            for p, y in zip(others, ys):
                targets[p[0]] = (x, y)
        else:
            targets[keeper[0] if keeper is not None else players[0][0]] = (x, 0.0)
            for p, slot in zip(others, ((x, -4.6), (self._left+4.5, -2.3),
                                        (self._left+4.5, 2.3), (x, 4.6))):
                targets[p[0]] = slot

    def _tactics_targets(self, obs, friends, opponents, chaser, races, enemy_eta, targets, protected):
        # The score shield has final priority over pressing, marking and runs.
        bx, by = obs.ball.position
        self._guard_ids = ()
        self._tactical_mode = "balanced; shadow striker"
        if self._shield_active:
            active = self._rebound_break(obs, friends, opponents, races, enemy_eta, protected)
            guards = [p for p in friends if p[0] not in active]
            self._guard_ids = tuple(p[0] for p in guards)
            tracking_target = targets.get(0)
            self._shield_positions(guards, targets)
            # Until the wall is in position, retain the keeper's shot tracking.
            # A counter's three guards also leave gaps requiring a mobile keeper.
            forming = len(guards) < 5 or any(math.hypot(p[1]-targets[p[0]][0], p[2]-targets[p[0]][1]) > 2.0 for p in guards if p[0] != 0)
            if 0 in self._guard_ids and forming and tracking_target is not None:
                y = tracking_target[1]
                if tracking_target[0] > self._left + 5.0:
                    y = by * 2.2 / max(3.0, bx-self._left)
                targets[0] = (self._left+self._player_radius+.05, _clip(y, -self._mouth, self._mouth))
            if active:
                samples = self._trajectory(bx, by, *obs.ball.velocity)
                collector = next(p for p in friends if p[0] == active[0])
                point = self._intercept(collector, samples)[1]
                targets[active[0]] = self._target(*point)
                side = 1.0 if by >= 0.0 else -1.0
                targets[active[1]] = self._target(point[0] + 7.0, point[1] - side * 6.0)
                self._tactical_mode = "rebound counter; three goal guards"
            else:
                self._tactical_mode = "two-goal lead; five goal guards"
            self._tactical_targets = dict(targets)
            return
        if protected:
            self._tactical_targets = dict(targets)
            return
        self._shadow_striker(obs, friends, opponents, chaser, races, enemy_eta, targets)
        self._wall_collection(obs, friends, opponents, chaser, races, enemy_eta, targets)
        secure = self._own_secure(obs, friends, chaser, races, enemy_eta)
        if self.TIKI_TAKA and self._tiki_outlet is not None:
            passer, receiver, third, tx, ty, expiry = self._tiki_outlet
            if obs.tick > expiry or obs.ball.last_touch not in (None, passer, receiver):
                self._tiki_outlet = None
            elif secure and third not in (chaser[0], self._shape_cover_id, self._striker_marker):
                targets[third] = self._target(tx, ty)
        receiving = self._receive_plan is not None and self._receive_plan[0] == 4
        if (self.PELE_FINISH and secure and bx > 10.0 and not receiving
                and 4 not in (chaser[0], self._shape_cover_id, self._striker_marker)):
            tx = _clip(bx + 8.0, 22.0, self._right - 5.0)
            choices = [(self._lane(bx, by, tx, y, 18.0, opponents)
                        + min((math.hypot(tx-q[1], y-q[2]) for q in opponents), default=15.0)*.15, y)
                       for y in (-4.5, 4.5)]
            quality, ty = max(choices)
            if quality > 1.0:
                targets[4] = self._target(tx, ty)
        self._tactical_targets = dict(targets)

    def _third_man(self, p, option, friends, opponents):
        receiver, x, y = option[3]
        best = None
        for q in friends:
            if q[0] in (0, p[0], receiver, self._shape_cover_id, self._striker_marker):
                continue
            tx, ty = self._target(q[1] + q[3]*.4 + 2.0, q[2] + q[4]*.4)
            gap = math.hypot(tx-x, ty-y)
            if tx < x+3.0 or not 4.0 < gap < 20.0:
                continue
            room = self._lane(x, y, tx, ty, 18.0, opponents)
            if room < 1.0:
                continue
            score = min(room, 4.0)*.2 + min(tx-x, 12.0)*.025
            if best is None or score > best[0]:
                best = score, q[0], tx, ty
        return best

    def _search_links(self, p, bx, by, vx, vy, friends, opponents):
        best = self._v7_search_links(p, bx, by, vx, vy, friends, opponents)
        self._tiki_next = None
        if not self.TIKI_TAKA or p[0] == 0:
            return best
        for q in friends:
            if q[0] in (p[0], 0) or not 3.5 < math.hypot(q[1]-bx, q[2]-by) < 15.0:
                continue
            for speed in (12.0, 16.0):
                lead = min(.7, self._flight(math.hypot(q[1]-bx, q[2]-by), speed))
                tx, ty = self._target(q[1]+q[3]*lead*.8, q[2]+q[4]*lead*.8)
                option = self._link_option(p, bx, by, vx, vy, q, opponents, tx, ty, speed)
                if option is None:
                    continue
                third = self._third_man(p, option, friends, opponents)
                boost = min(1.0, third[0]) * self.TIKI_WEIGHT if third is not None else 0.0
                if self._last_link is not None:
                    passer, receiver, tick = self._last_link
                    if p[0] == receiver and q[0] == passer and self._tactic_tick-tick < self._hz:
                        boost -= .65
                candidate = (option[0]+boost, *option[1:])
                if best is None or candidate[0] > best[0]:
                    best = candidate
                    self._tiki_next = (q[0], *third[1:]) if third is not None else None
        return best

    def _guard_clearance(self, p, bx, by, vx, vy, opponents):
        self._pass_plan = self._bank_plan = None
        hold = self._move(p, self._tactical_targets.get(p[0], (p[1], p[2])))
        self._touch_movement = hold
        best = None
        for angle in (-.95, -.5, 0.0, .5, .95):
            kick = ((math.cos(angle), math.sin(angle)), 1.0)
            sx, sy = self._requested_velocity(vx, vy, kick)
            launch = self._carrier_contact(p, bx, by, sx, sy, hold)
            if launch is None or launch[2] <= 1.0:
                continue
            tx, ty = self._target(launch[0]+launch[2]*.35, launch[1]+launch[3]*.35)
            room = self._lane(launch[0], launch[1], tx, ty, math.hypot(launch[2], launch[3]), opponents)
            score = launch[2] + min(room, 8.0)*.5 - abs(launch[3])*.05
            if best is None or score > best[0]:
                best = score, kick
        return best[1] if best is not None else None

    def _special_finish(self, p, bx, by, vx, vy, opponents):
        # Long shots must reach the actual goal with speed and interception
        # margin. Role names never grant extra movement speed or kick power.
        distance = math.hypot(self._right-bx, by)
        midfielder = self.MIDFIELD_SHOT and p[0] == 2 and 24.0 < distance < 52.0
        pele = self.PELE_FINISH and p[0] == 4 and distance < 25.0
        if not midfielder and not pele:
            return None
        best = None
        for y in (-5.8, -3.5, 0.0, 3.5, 5.8):
            option = self._shot_option(p, bx, by, vx, vy, opponents, y)
            if option is None:
                continue
            sx, sy = self._requested_velocity(vx, vy, option[1])
            launch = self._carrier_contact(p, bx, by, sx, sy, option[2])
            forecast = self._goal_path(launch) if launch is not None else None
            if forecast is None:
                continue
            path, (flight, gy, end_speed) = forecast
            margin = min((self._eta(q,x,y)-t for t,x,y in path for q in opponents), default=1.0)
            if midfielder and (margin < .08 or end_speed < 11.0):
                continue
            if best is None or option[0] > best[0]:
                best = option
        return best

    def _choose_kick(self, p, bx, by, vx, vy, friends, opponents):
        if self._shield_active and p[0] not in self._break_ids:
            return self._guard_clearance(p, bx, by, vx, vy, opponents)
        planning = [q for q in friends if q[0] in self._break_ids] if self._shield_active else friends
        fallback = self._v7_choose_kick(p, bx, by, vx, vy, planning, opponents)
        special = self._special_finish(p, bx, by, vx, vy, opponents)
        if special is not None:
            old_score = -100.0
            if fallback is not None:
                sx, sy = self._requested_velocity(vx, vy, fallback)
                movement = self._touch_movement or self._move(p, (bx+.3, by))
                launch = self._carrier_contact(p, bx, by, sx, sy, movement)
                forecast = self._goal_path(launch) if launch is not None else None
                if forecast is not None:
                    path, (flight, gy, speed) = forecast
                    margin = min((self._eta(q,x,y)-t for t,x,y in path for q in opponents), default=1.0)
                    old_score = 6.0+min(margin,.5)*4.0-flight*.7+min(speed,20.0)*.03
            if special[0] > old_score+.10:
                self._touch_movement = special[2]
                self._pass_plan = self._bank_plan = None
                self._midfield_shot = p[0] == 2
                return special[1]
        if fallback is not None and self._pass_plan is not None:
            receiver = self._pass_plan[0]
            self._last_link = (p[0], receiver, self._tactic_tick)
            if self._tiki_next is not None and self._tiki_next[0] == receiver:
                _, third, tx, ty = self._tiki_next
                self._tiki_outlet = (p[0], receiver, third, tx, ty, self._tactic_tick+int(1.2*self._hz))
        return fallback
