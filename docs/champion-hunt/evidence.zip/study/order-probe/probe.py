"""Public-API native kick-order diagnostic, separate from timed fixtures.

No simulator/SDK edits, private state, formation changes, or state injection.
The environment starts with the normal roster. Every setup transition is an
ordinary movement action derived from public observations. Failed setups are
saved and reported, never replaced by an injected state.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
import sys


SDK = Path('/workspace/work/exploit-lab/student-sdk')
CONFIG = Path('/workspace/work/replay-finishing-handoffs/configs/default.toml')
FORBIDDEN_SEEDS = range(3249063101, 3249063133)
PAIR_TARGETS = ((-1.8, -1.2), (-1.8, 1.2))
SINGLE_TARGET = (0.0, 2.1)


def norm(v):
    return math.hypot(*v)


def sub(a, b):
    return a[0] - b[0], a[1] - b[1]


def distance(a, b):
    return norm(sub(a, b))


def clamp_norm(v, maximum=1.0):
    length = norm(v)
    return v if length <= maximum else (v[0] * maximum / length, v[1] * maximum / length)


def json_safe(value):
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def infer_frames(observations):
    """Infer each public frame from views of identical opponent players.

    World means the team_a public frame; no authoritative state is consulted.
    The team_b transform is verified on every initial roster coordinate.
    """
    a, b = observations['team_a'], observations['team_b']
    count = len(a.my_players)
    world_opponents = {p.id - count: p for p in a.opponents}
    options = []
    for sx, sy in itertools.product((-1, 1), repeat=2):
        error = max(distance(world_opponents[p.id].position,
                             (sx * p.position[0], sy * p.position[1]))
                    for p in b.my_players)
        options.append((error, sx, sy))
    error, sx, sy = min(options)
    if error > 1e-5:
        raise RuntimeError('public player frames do not match a diagonal reflection')
    return ((1, 1), (sx, sy)), error


def world_pair(value, frame):
    return value[0] * frame[0], value[1] * frame[1]


def player_world(player, frame):
    return dict(id=player.id, position=list(world_pair(player.position, frame)),
                velocity=list(world_pair(player.velocity, frame)),
                cooldown=player.kick_cooldown_ticks,
                has_control=player.has_control)


def snapshot(observations, frames, phase, actions=None):
    a = observations['team_a']
    teams = []
    for side, key in enumerate(('team_a', 'team_b')):
        obs = observations[key]
        rows = []
        for p in obs.my_players:
            row = player_world(p, frames[side])
            row['can_kick'] = obs.can_kick(p.id)
            if actions is not None:
                raw = actions[key][p.id]
                row['action'] = json_safe(raw)
                row['movement_world'] = list(world_pair(raw['movement'], frames[side]))
                if 'kick_direction' in raw:
                    row['kick_direction_world'] = list(world_pair(raw['kick_direction'], frames[side]))
            rows.append(row)
        teams.append(dict(side=obs.side, players=rows))
    return dict(tick=a.tick, phase=phase, score=list(a.score),
                ball=dict(position=list(a.ball.position), velocity=list(a.ball.velocity),
                          controlling_team=a.ball.controlling_team,
                          controlling_player=a.ball.controlling_player,
                          last_touch=a.ball.last_touch),
                teams=teams,
                events_team_a=json_safe(list(a.events)),
                events_team_b=json_safe(list(observations['team_b'].events)))


def assign_players(observations, frames, pair_team):
    assigned = {}
    pair = observations[('team_a', 'team_b')[pair_team]]
    candidates = list(pair.my_players)
    best = min(itertools.permutations(candidates, 2),
               key=lambda ps: sum(distance(world_pair(p.position, frames[pair_team]), target)
                                  for p, target in zip(ps, PAIR_TARGETS)))
    for player, target in zip(best, PAIR_TARGETS):
        assigned[pair_team, player.id] = target
    single_team = 1 - pair_team
    single = observations[('team_a', 'team_b')[single_team]]
    player = min(single.my_players,
                 key=lambda p: distance(world_pair(p.position, frames[single_team]), SINGLE_TARGET))
    assigned[single_team, player.id] = SINGLE_TARGET
    return assigned


def route_outer(position, target):
    """Reach a radial staging point without crossing the stationary ball.

    A blocked direct segment is replaced by a short arc waypoint at radius
    8.5. All navigation and collision consequences remain native.
    """
    delta = sub(target, position)
    length2 = delta[0] ** 2 + delta[1] ** 2
    if length2 < 1e-12:
        return target
    t = max(0.0, min(1.0, -(position[0] * delta[0] + position[1] * delta[1]) / length2))
    closest = (position[0] + t * delta[0], position[1] + t * delta[1])
    if norm(closest) >= 6.0:
        return target
    angle = math.atan2(position[1], position[0])
    wanted = math.atan2(target[1], target[0])
    turn = (wanted - angle + math.pi) % (2 * math.pi) - math.pi
    next_angle = angle + max(-0.32, min(0.32, turn))
    return 8.5 * math.cos(next_angle), 8.5 * math.sin(next_angle)


def pd_movement(position, velocity, target, acceleration):
    delta = sub(target, position)
    return clamp_norm(((6.0 * delta[0] - 5.0 * velocity[0]) / acceleration,
                       (6.0 * delta[1] - 5.0 * velocity[1]) / acceleration))


def make_actions(observations, frames, assigned, phase, pair_team, payload_order):
    by_team = {}
    for side, key in enumerate(('team_a', 'team_b')):
        obs = observations[key]
        actions = {}
        for p in obs.my_players:
            position = world_pair(p.position, frames[side])
            velocity = world_pair(p.velocity, frames[side])
            if phase in ('warm', 'kick', 'after'):
                movement = (0.0, 0.0)
            else:
                if (side, p.id) in assigned:
                    target = assigned[side, p.id]
                    if phase in ('park', 'outer'):
                        target = (target[0] * 4, target[1] * 4)
                        target = route_outer(position, target)
                    if phase == 'park':
                        target = position
                else:
                    target = (-28.0 if side == 0 else 28.0, -22.0 + 11.0 * p.id)
                movement = pd_movement(position, velocity, target, obs.field.acceleration)
            row = dict(movement=world_pair(movement, frames[side]))
            if phase == 'kick' and (side, p.id) in assigned:
                direction = (1.0, 0.0) if side == pair_team else (-1.0, 0.0)
                row.update(kick_direction=world_pair(direction, frames[side]), kick_power=1.0)
            actions[p.id] = row
        by_team[key] = actions
    return {key: by_team[key] for key in (('team_a', 'team_b') if payload_order == 'ab'
                                         else ('team_b', 'team_a'))}


def target_status(observations, frames, assigned, phase):
    errors, speeds = [], []
    for side, key in enumerate(('team_a', 'team_b')):
        for p in observations[key].my_players:
            position = world_pair(p.position, frames[side])
            if (side, p.id) in assigned:
                if phase == 'park':
                    continue
                target = assigned[side, p.id]
                if phase == 'outer':
                    target = target[0] * 4, target[1] * 4
            else:
                target = (-28.0 if side == 0 else 28.0, -22.0 + 11.0 * p.id)
            errors.append(distance(position, target))
            speeds.append(norm(world_pair(p.velocity, frames[side])))
    return dict(max_target_error=max(errors), max_player_speed=max(speeds))


def validate_setup(observations, frames, assigned, pair_team):
    a = observations['team_a']
    players = []
    ready = True
    for side, key in enumerate(('team_a', 'team_b')):
        obs = observations[key]
        for p in obs.my_players:
            position = world_pair(p.position, frames[side])
            players.append((side, p.id, position))
            if (side, p.id) in assigned:
                ready = ready and obs.can_kick(p.id)
    minimum_player_separation = min(distance(p[2], q[2])
                                    for p, q in itertools.combinations(players, 2))
    minimum_ball_separation = min(distance(p[2], a.ball.position) for p in players)
    # Both candidate post-integration positions must avoid every player body.
    # This is a diagnostic geometry guard, not a substitute native simulation.
    candidate_positions = ((a.ball.position[0] + 8.0 / a.field.simulation_hz, a.ball.position[1]),
                           (a.ball.position[0] + 22.0 / a.field.simulation_hz, a.ball.position[1]))
    minimum_candidate_ball_separation = min(distance(p[2], b)
                                            for p in players for b in candidate_positions)
    status = target_status(observations, frames, assigned, 'inner')
    ok = (a.tick > 60 and norm(a.ball.position) < 1e-7 and norm(a.ball.velocity) < 1e-7
          and status['max_target_error'] < 0.003 and status['max_player_speed'] < 0.003
          and ready and minimum_player_separation > 2.002
          and minimum_ball_separation > a.field.player_radius + a.field.ball_radius + 0.001
          and minimum_candidate_ball_separation > a.field.player_radius + a.field.ball_radius + 0.001)
    return dict(ok=ok, ready=ready, **status,
                minimum_player_separation=minimum_player_separation,
                minimum_ball_separation=minimum_ball_separation,
                minimum_candidate_ball_separation=minimum_candidate_ball_separation,
                pair_team=pair_team)


def predict_velocity(pre_velocity, pair_team, first_team, impulse, max_speed, friction):
    velocity = tuple(pre_velocity)
    sequence = []
    for side in (first_team, 1 - first_team):
        for _ in range(2 if side == pair_team else 1):
            direction = 1.0 if side == pair_team else -1.0
            velocity = clamp_norm((velocity[0] + direction * impulse, velocity[1]), max_speed)
            sequence.append(dict(team=side, velocity=list(velocity)))
    return dict(before_drag=velocity, after_drag=(velocity[0] * friction, velocity[1] * friction),
                sequence=sequence)


def run_probe(seed, pair_team, kickoff_team, payload_order, setup_ticks, after_ticks):
    # Import only while explicitly running a probe, so --help/static compilation
    # need not even load the native module.
    sys.path.insert(0, str(SDK))
    from soccer import SoccerEnv

    output = dict(seed=seed, pair_team=pair_team, kickoff_team=kickoff_team,
                  payload_order=payload_order, status='setup_failed',
                  scope='untimed public-API functional diagnostic; not a competition fixture',
                  trace=[])
    with SoccerEnv(config_path=str(CONFIG)) as env:
        observations = env.reset(seed=seed, kickoff_team=kickoff_team)
        frames, frame_error = infer_frames(observations)
        assigned = assign_players(observations, frames, pair_team)
        config = env.config()
        output.update(config_hash=env.config_hash, engine_version=env.engine_version,
                      effective_config=json_safe(config), frames=frames,
                      frame_error=frame_error,
                      assignments=[dict(team=side, player=pid, target=target)
                                   for (side, pid), target in sorted(assigned.items())])
        phase, settled = 'warm', 0
        for _ in range(setup_ticks):
            a = observations['team_a']
            if norm(a.ball.position) > 1e-7 or norm(a.ball.velocity) > 1e-7:
                output['setup_failure_reason'] = 'ordinary setup movements disturbed the ball'
                break
            if phase == 'warm' and a.tick >= 70:
                phase = 'park'
            if phase in ('park', 'outer', 'inner'):
                status = target_status(observations, frames, assigned, phase)
                tolerance = 0.003 if phase == 'inner' else 0.05
                speed_tolerance = 0.003 if phase == 'inner' else 0.03
                settled = settled + 1 if (status['max_target_error'] < tolerance
                                           and status['max_player_speed'] < speed_tolerance) else 0
                if settled >= 5:
                    if phase == 'park':
                        phase, settled = 'outer', 0
                    elif phase == 'outer':
                        phase, settled = 'inner', 0
                    else:
                        geometry = validate_setup(observations, frames, assigned, pair_team)
                        if geometry['ok']:
                            output['setup_validation'] = geometry
                            phase = 'kick'
            actions = make_actions(observations, frames, assigned, phase, pair_team, payload_order)
            output['trace'].append(snapshot(observations, frames, phase, actions))
            if phase == 'kick':
                output['pre'] = snapshot(observations, frames, phase, actions)
                predictions = {str(first): predict_velocity(a.ball.velocity, pair_team, first,
                                                            a.field.kick_impulse,
                                                            float(config['ball']['max_speed']),
                                                            a.field.ball_friction)
                               for first in (0, 1)}
                observations, _ = env.step(actions)
                post = snapshot(observations, frames, 'post')
                output['post'] = post
                output['predictions_by_first_team'] = predictions
                errors = {first: distance(post['ball']['velocity'], prediction['after_drag'])
                          for first, prediction in predictions.items()}
                output['velocity_errors_by_first_team'] = errors
                kicks = [e for e in post['events_team_a'] if e.get('kind') == 'kick']
                rejected = [e for e in post['events_team_a'] if e.get('kind') == 'kick_rejected']
                output['native_kick_events'] = kicks
                output['native_rejections'] = rejected
                best = min(errors, key=errors.get)
                fits = len(kicks) == 3 and not rejected and errors[best] < 0.001
                output['status'] = 'order_observed' if fits else 'ambiguous_native_outcome'
                output['first_team'] = int(best) if fits else None
                output['trace'].append(post)
                for _ in range(after_ticks):
                    actions = make_actions(observations, frames, assigned, 'after', pair_team, payload_order)
                    observations, _ = env.step(actions)
                    output['trace'].append(snapshot(observations, frames, 'after', actions))
                break
            observations, _ = env.step(actions)
            if env.finished:
                break
        if output['status'] == 'setup_failed':
            output.setdefault('setup_failure_reason', 'setup did not satisfy the public geometry checks within its tick limit')
            output['failed_setup_final'] = snapshot(observations, frames, phase)
            output['setup_validation'] = validate_setup(observations, frames, assigned, pair_team)
        output['result_at_close'] = json_safe(env.result())
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seeds', type=int, nargs='+', default=[3249065101, 3249065102, 3249065103])
    parser.add_argument('--pair-teams', type=int, nargs='+', choices=(0, 1), default=[0, 1])
    parser.add_argument('--kickoff-teams', type=int, nargs='+', choices=(0, 1), default=[0, 1])
    parser.add_argument('--payload-orders', nargs='+', choices=('ab', 'ba'), default=['ab'])
    parser.add_argument('--setup-ticks', type=int, default=1200)
    parser.add_argument('--after-ticks', type=int, default=2)
    parser.add_argument('--out', type=Path, default=Path(__file__).with_name('results.json'))
    args = parser.parse_args()
    if any(seed in FORBIDDEN_SEEDS for seed in args.seeds):
        parser.error('qualification seeds 3249063101-3249063132 are forbidden')
    rows = []
    for seed, pair_team, kickoff_team, payload_order in itertools.product(
            args.seeds, args.pair_teams, args.kickoff_teams, args.payload_orders):
        row = run_probe(seed, pair_team, kickoff_team, payload_order, args.setup_ticks, args.after_ticks)
        rows.append(row)
        args.out.write_text(json.dumps(rows, indent=2) + '\n')
        print(json.dumps({k: row.get(k) for k in ('seed', 'pair_team', 'kickoff_team', 'payload_order',
                                                   'status', 'first_team', 'setup_validation',
                                                   'velocity_errors_by_first_team')}), flush=True)
    orders = sorted({r['first_team'] for r in rows if r['status'] == 'order_observed'})
    print(json.dumps(dict(probes=len(rows), observed=sum(r['status'] == 'order_observed' for r in rows),
                          distinct_first_teams=orders, out=str(args.out))), flush=True)


if __name__ == '__main__':
    main()
