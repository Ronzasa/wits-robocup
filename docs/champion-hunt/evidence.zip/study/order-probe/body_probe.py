"""Two public ordinary-movement probes of native player/ball body order."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
import sys

from probe import (CONFIG, SDK, FORBIDDEN_SEEDS, distance, infer_frames,
                   json_safe, make_actions, norm, snapshot, target_status,
                   world_pair)


def body_sequence(ball_position, ball_velocity, players, order, radius, restitution):
    position, velocity = tuple(ball_position), tuple(ball_velocity)
    steps = []
    for side in order:
        player = players[side]
        delta = (position[0] - player['position'][0], position[1] - player['position'][1])
        separation = norm(delta)
        if separation >= radius:
            steps.append(dict(team=side, contact=False, position=position, velocity=velocity))
            continue
        if separation < 1e-12:
            raise RuntimeError('degenerate body normal; no fabricated resolution')
        normal = delta[0] / separation, delta[1] / separation
        position = (player['position'][0] + normal[0] * radius,
                    player['position'][1] + normal[1] * radius)
        relative = (velocity[0] - player['velocity'][0], velocity[1] - player['velocity'][1])
        closing = relative[0] * normal[0] + relative[1] * normal[1]
        if closing < 0:
            velocity = (velocity[0] - (1.0 + restitution) * closing * normal[0],
                        velocity[1] - (1.0 + restitution) * closing * normal[1])
        steps.append(dict(team=side, contact=True, normal=normal, closing=closing,
                          position=position, velocity=velocity))
    return dict(position=position, velocity=velocity, steps=steps)


def run(seed, left_team, setup_ticks):
    sys.path.insert(0, str(SDK))
    from soccer import SoccerEnv

    row = dict(seed=seed, left_team=left_team, kickoff_team=0,
               scope='untimed public ordinary-movement body-order diagnostic',
               status='setup_failed', trace=[])
    with SoccerEnv(config_path=str(CONFIG)) as env:
        observations = env.reset(seed=seed, kickoff_team=0)
        frames, frame_error = infer_frames(observations)
        assigned = {}
        for side, key in enumerate(('team_a', 'team_b')):
            target = (-1.6 if side == left_team else 1.6, 0.0)
            p = min(observations[key].my_players,
                    key=lambda p: distance(world_pair(p.position, frames[side]), target))
            assigned[side, p.id] = target
        config = env.config()
        row.update(config_hash=env.config_hash, engine_version=env.engine_version,
                   effective_config=json_safe(config), frames=frames, frame_error=frame_error,
                   assignments=[dict(team=s, player=p, target=t) for (s, p), t in sorted(assigned.items())])
        phase, settled = 'warm', 0
        for _ in range(setup_ticks):
            a = observations['team_a']
            if norm(a.ball.position) > 1e-7 or norm(a.ball.velocity) > 1e-7:
                row['setup_failure_reason'] = 'ordinary setup movements disturbed the stationary ball'
                break
            if phase == 'warm' and a.tick >= 70:
                phase = 'park'
            if phase in ('park', 'outer', 'inner'):
                status = target_status(observations, frames, assigned, phase)
                tolerance = 0.0002 if phase == 'inner' else 0.05
                speed_tolerance = 0.0002 if phase == 'inner' else 0.03
                settled = settled + 1 if (status['max_target_error'] < tolerance
                                           and status['max_player_speed'] < speed_tolerance) else 0
                if settled >= 5:
                    if phase == 'park':
                        phase, settled = 'outer', 0
                    elif phase == 'outer':
                        phase, settled = 'inner', 0
                    else:
                        row['setup_validation'] = status
                        phase = 'push'
            if phase == 'push':
                break
            actions = make_actions(observations, frames, assigned, phase, 0, 'ab')
            row['trace'].append(snapshot(observations, frames, phase, actions))
            observations, _ = env.step(actions)
        if phase != 'push':
            row.setdefault('setup_failure_reason', 'setup did not naturally settle within its tick limit')
            row['final'] = snapshot(observations, frames, phase)
            return row

        row['settled'] = snapshot(observations, frames, 'settled')
        for push_frame in range(1, 5):
            actions = make_actions(observations, frames, assigned, 'after', 0, 'ab')
            for (side, pid), target in assigned.items():
                direction = (1.0 if side == left_team else -1.0, 0.0)
                actions[('team_a', 'team_b')[side]][pid] = dict(movement=world_pair(direction, frames[side]))
            before = snapshot(observations, frames, 'push', actions)
            row['trace'].append(before)
            observations, _ = env.step(actions)
            after = snapshot(observations, frames, 'push_result')
            row['trace'].append(after)
            a = observations['team_a']
            radius = a.field.player_radius + a.field.ball_radius
            free_position = (before['ball']['position'][0] + before['ball']['velocity'][0] / a.field.simulation_hz,
                             before['ball']['position'][1] + before['ball']['velocity'][1] / a.field.simulation_hz)
            free_velocity = (before['ball']['velocity'][0] * a.field.ball_friction,
                             before['ball']['velocity'][1] * a.field.ball_friction)
            selected = {side: next(p for p in after['teams'][side]['players'] if p['id'] == pid)
                        for (side, pid) in assigned}
            contacts = {side: distance(p['position'], free_position) < radius
                        for side, p in selected.items()}
            minimum_player_separation = min(distance(p['position'], q['position'])
                                            for p, q in itertools.combinations(
                                                [p for t in after['teams'] for p in t['players']], 2))
            if norm(after['ball']['velocity']) > 1e-7 or distance(after['ball']['position'], free_position) > 1e-7:
                row.update(first_contact_push_frame=push_frame, pre=before, post=after,
                           free_position=free_position, free_velocity=free_velocity,
                           free_ball_inside_selected=contacts,
                           minimum_player_separation=minimum_player_separation)
                models = {str(first): body_sequence(free_position, free_velocity, selected,
                                                    (first, 1 - first), radius,
                                                    float(config['ball']['player_restitution']))
                          for first in (0, 1)}
                errors = {first: dict(position=distance(m['position'], after['ball']['position']),
                                       velocity=distance(m['velocity'], after['ball']['velocity']),
                                       velocity_if_post_drag=distance(
                                           (m['velocity'][0] * a.field.ball_friction,
                                            m['velocity'][1] * a.field.ball_friction),
                                           after['ball']['velocity']))
                          for first, m in models.items()}
                row.update(predictions_by_first_team=models, errors_by_first_team=errors)
                best = min(errors, key=lambda k: errors[k]['position'])
                proof = (all(contacts.values()) and minimum_player_separation > 2.0
                         and norm(before['ball']['position']) < 1e-7
                         and norm(before['ball']['velocity']) < 1e-7
                         and errors[best]['position'] < 0.0001
                         and min(errors[best]['velocity'], errors[best]['velocity_if_post_drag']) < 0.0001)
                row['status'] = 'body_order_observed' if proof else 'ambiguous_first_contact'
                row['first_team'] = int(best) if proof else None
                break
        else:
            row['status'] = 'no_contact_within_four_push_frames'
            row['final'] = snapshot(observations, frames, 'final')
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seed', type=int, default=3249065101)
    parser.add_argument('--setup-ticks', type=int, default=1200)
    parser.add_argument('--out', type=Path, default=Path(__file__).with_name('body-both.json'))
    args = parser.parse_args()
    if args.seed in FORBIDDEN_SEEDS:
        parser.error('qualification seeds are forbidden')
    rows = []
    for left_team in (0, 1):
        row = run(args.seed, left_team, args.setup_ticks)
        rows.append(row)
        args.out.write_text(json.dumps(rows, indent=2) + '\n')
        print(json.dumps({k: row.get(k) for k in ('left_team', 'status', 'first_team',
                                                   'first_contact_push_frame', 'setup_validation',
                                                   'free_ball_inside_selected', 'minimum_player_separation',
                                                   'errors_by_first_team')}), flush=True)


if __name__ == '__main__':
    main()
