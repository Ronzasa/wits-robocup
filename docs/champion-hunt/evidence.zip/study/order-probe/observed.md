Observed native result
======================

After the parent explicitly paused tournament timings, the two authorized
smoke probes ran in 0.44 seconds on non-qualification seed **3249065101** with
kickoff team 0. The parent was told native work was finished before timings
resumed. No additional native probes have run.

Both ordinary-movement setups succeeded with the default roster and unchanged
course profile, config hash `372990895c7eca2a`, engine `0.1.0`. The initial
public views verified team B's frame transform as `(-x, -y)`.

| Pair's global team | Kick tick | Pre ball x/vx | Post ball x | Post ball vx | Matching application order |
| --- | ---: | --- | ---: | ---: | --- |
| 0 | 571 | 0 / 0 | 0.400000006 | 7.880000114 | team 0 pair, then team 1 single |
| 1 | 585 | 0 / 0 | 1.100000024 | 21.670000076 | team 0 single, then team 1 pair |

The velocity residual against team-0-first was 0 and 2.38e-7 respectively. The
team-1-first model missed by approximately 13.79 in both cases. Native event
lists independently reported `0,0,1` and `0,1,1`; all three kicks were accepted,
with no kick rejection. Every kicker's public cooldown changed from 0 to 4.

All three reported `can_kick=True` before the simultaneous actions. Maximum
target error was 0.002402 and maximum speed was 0.002380. Actual minimum player
separation exceeded 2.01467; actual ball-to-player distance exceeded 2.10231.
The tighter of the two candidate ball endpoint clearances exceeded 2.14003,
well beyond the combined body radius 1.45. The ball remained exactly stationary
at the center throughout setup.

The full public states, all player movements/cooldowns, pre/post snapshots and
native events are preserved in `smoke-both.json`. These two reversed-role cases
establish team 0 before team 1 for the observed seed/profile. Other seeds,
kickoff ownership, and reversed action-map insertion have not yet been run;
the harness supports them for a later timing pause.

Practical controller use: in the controller's canonical coordinates, simulate
own legal kicks before predicted opponent kicks when public `obs.side == 0`,
and predicted opponent kicks before own kicks when `obs.side == 1`. Apply the
30 speed cap after each kick, then native movement/drag. This can change which
power/direction or same-frame multi-kick is best. Opponent intent must still be
predicted from public information; ordering does not expose its simultaneous
action. Any competition implementation remains one TeamController using math
and the SDK within 256 KB and 20 ms.
