Observed native body order
==========================

The parent explicitly paused timing and authorized these two tiny cases.
Both ran in 0.47 seconds, after which the parent was told to resume timing.
They use non-qualification seed **3249065101**, native engine `0.1.0`, frozen
course configuration `372990895c7eca2a`, normal reset/default rosters, public
observations, and ordinary movements only. The earlier kick evidence remains
unchanged. These body probes contain no kick actions or state injection.

One player from each global team settled at world x = ±1.6, y = 0. Unused
players parked far away. Maximum setup error was 0.000160 and speed 0.000159.
Three frames of opposed unit movement then brought both player discs into
contact with the ball on the same first-contact frame.

| Global team 0 location | Contact tick | Pre player x | Post player x | Post ball x | Post ball vx |
| --- | ---: | --- | --- | ---: | ---: |
| Left | 620 | ±1.455146074 | ±1.319640279 | −0.130359769 | −4.234555244 |
| Right | 709 | ±1.455146074 | ±1.319640279 | +0.130359769 | +4.234555244 |

Immediately before each contact frame, the ball position and velocity were
exactly zero. Both updated player centers lay inside contact distance 1.45 of
the free-flight ball, while their mutual separation remained 2.639280558, so
no player/player collision affected the result. Their updated x speeds were
±2.710115433.

Resolving **global team 0 then global team 1** matched both cases:

- Ball position error: 5.96e-8.
- Ball velocity error: 1.19e-7.
- Reversed body order missed position by 0.260719478 and velocity by 8.469110608.

The model places the ball at body radius 1.45 along the contact normal and,
for negative relative closing speed, subtracts `1.25 * closing * normal` from
ball velocity. The resulting contact velocity matches the native observation
directly. Applying an additional drag after contact would miss velocity by
0.063518151; native drag precedes these body resolutions.

Thus both global kick ordering and global body ordering are team 0 before
team 1 in the observed profile. An order-aware canonical forecaster can use
own-team-first for public `obs.side == 0` and opponent-team-first for
`obs.side == 1` for both operations. These probes do not establish within-team
player traversal order.

Full public setup/action traces, first-contact snapshots, and both exact
resolution models: `body-both.json`. Reproducible harness: `body_probe.py`.
