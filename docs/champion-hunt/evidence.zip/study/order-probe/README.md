Public native kick-order probe
=============================

This is an untimed functional diagnostic, separate from the candidate/opponent
fixtures. It uses the complete student SDK and frozen course config, default
initial rosters, normal reset/step calls, and legal movement/kick actions only.
It does not load the frozen opponent or competition candidate. Neither the SDK
nor physics nor hidden state is modified. There are no formation hooks.

Do not run this while the parent is recording one-worker tournament timings.
The parent will explicitly authorize a pause before a native probe is run.

The script waits until tick 70, parks unused players, routes the selected
players around the stationary ball, and uses public-position/velocity PD
movement to settle two players at world `(-1.8, -1.2)` / `(-1.8, 1.2)` and one
at `(0, 2.1)`. World here is team A's public observation frame. Team B's
coordinate transform is inferred and verified from the two public roster
views, including its y convention.

All three must be ready, within 0.003 of target and below 0.003 speed. The ball
must remain centered and stationary. Actual player separation must exceed
2.002, and both candidate ball endpoints must clear every player body. The
probe records a failed setup if ordinary movements disturb the ball or cannot
meet the checks; it never fabricates a replacement state.

On one frame, the pair kicks world +x at full power and the single kicks -x.
Pair-then-single predicts `0 -> 22 -> 30 -> 8`, or post-drag velocity **7.88**.
Single-then-pair predicts `0 -> -22 -> 0 -> 22`, or **21.67**. Ball velocity
determines the inferred order; native kick event order is supporting evidence.
The JSON includes every setup frame's public positions, velocities, cooldowns,
`can_kick` values, movements, and both sides' events, plus pre/post snapshots,
predicted cap sequences, native kick events, rejections, and effective config.

First run one small setup smoke probe:

```sh
python order-probe/probe.py --seeds 3249065101 --pair-teams 0 --kickoff-teams 0 --out order-probe/smoke.json
```

Then reverse pair ownership, kickoff ownership, and input-map insertion order
on three non-qualification seeds (24 probes):

```sh
python order-probe/probe.py --seeds 3249065101 3249065102 3249065103 --payload-orders ab ba --out order-probe/reversed.json
```

Qualification seeds 3249063101–3249063132 are rejected by the CLI. Static setup
was syntax checked without importing or stepping the native engine.

If global team ordering is observed consistently, a competition controller may
read public `obs.side` to select the corresponding cap sequence. It still has
to predict the opponent's simultaneous kick intent using public state and the
opponent policy's behavior. A useful counter can compare candidate legal kicks
under that predicted sequence, including own same-frame multi-kicks, rather
than treating all impulses as an unordered sum. This diagnostic itself is a
stdlib harness; a competition submission remains one TeamController using
math and the SDK, within 256 KB and 20 ms.
