"""Untimed shared-observation native decision parity, not deadline qualification."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv
from soccer.helpers import load_controller
paths={'frozen-slow':ROOT/'final-development-sources/bait-slow/team.py',
       'wall-cache':ROOT/'agent-cache/cache-only/team.py',
       'touch-table':ROOT/'agent-cache/touch-table-only/team.py',
       'combined':ROOT/'agent-cache/cache-all/team.py'}
records=[]
for side in (0,1):
 for kick in (False,True):
  seed=3249061101
  variants={n:load_controller(str(p)) for n,p in paths.items()}
  opponent=load_controller(str(ROOT/'opponent/team.py'))
  for c in [*variants.values(),opponent]:c.reset(seed)
  compared={n:0 for n in paths if n!='frozen-slow'}
  first_difference=None
  with SoccerEnv(config_path='/workspace/work/replay-finishing-handoffs/configs/default.toml',max_ticks=2400,per_decision_timeout_ms=20.,team_ids=('policy_a','policy_b')) as env:
   obs=env.reset(seed=seed,kickoff_team=side if kick else 1-side)
   while not env.finished:
    key='team_a' if side==0 else 'team_b';other='team_b' if side==0 else 'team_a'
    outputs={n:c.act(obs[key]) for n,c in variants.items()}
    baseline={i:a.as_dict() for i,a in outputs['frozen-slow'].players.items()}
    for n,a in outputs.items():
     if n=='frozen-slow':continue
     compared[n]+=1
     actual={i:p.as_dict() for i,p in a.players.items()}
     if baseline!=actual and first_difference is None:
      first_difference=dict(tick=obs[key].tick,variant=n,baseline=baseline,actual=actual)
    if first_difference is not None:break
    actions={key:outputs['frozen-slow'],other:opponent.act(obs[other])}
    obs,_=env.step(actions)
   result=env.result()
  records.append(dict(seed=seed,candidate_side=side,candidate_takes_kickoff=kick,comparisons=compared,first_difference=first_difference,ticks=result['ticks'],score=result['score']))
  print('PARITY',side,kick,compared,'difference',first_difference is not None,flush=True)
  if first_difference is not None:break
report=dict(scope='Four untimed native shared-input matches; no decision timings recorded. Does not replace scheduled outcomes or raw misses.',sources={n:dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for n,p in paths.items()},fixtures=records,all_equal=all(r['first_difference'] is None and r['ticks']==2400 for r in records),original_raw_miss_ms=22.3811920004664)
(ROOT/'native-cache-parity.json').write_text(json.dumps(report,indent=2)+'\n')
assert len(records)==4 and report['all_equal'],report
