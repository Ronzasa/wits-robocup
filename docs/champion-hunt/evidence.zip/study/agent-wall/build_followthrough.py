import ast,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
s=(root/'v10-boundary-crossing/team.py').read_text()
s=s.replace('version = "v10-boundary-crossing-v1"','version = "v10-wall-followthrough-v1"')
s=s.replace('        self._receive_aim = None\n','        self._receive_aim = None\n        self._siege_follow = None\n',1)
s=s.replace('        return self._opening_act(obs)\n','        self._siege_follow=None\n        return self._opening_act(obs)\n',1)
s=s.replace('if best is None or score>best[0]:best=(score,kick)\n        return None if best is None else best[1]\n\n    def _siege_clearance_path',
'''if best is None or score>best[0]:best=(score,kick,outcomes)
        if best is None:
            return None
        self._siege_follow=(p[0],obs.tick,tuple(obs.score),[o[2] for o in best[2]])
        return best[1]

    def _siege_clearance_path''')
s=s.replace('        assists=0\n        for n in range(1,13):','        assists=0\n        trace=[]\n        for n in range(1,13):')
s=s.replace('            if x>self._right and abs(y)<=self._goal_half:return n,assists\n',
'''            trace.append((x,y,vx,vy,*own))
            if x>self._right and abs(y)<=self._goal_half:return n,assists,trace
''')
s=s.replace('        carrier=min(outfield,key=lambda p:self._intercept(p,path)[0])\n',
'''        carrier=min(outfield,key=lambda p:self._intercept(p,path)[0])
        following=False
        plan=self._siege_follow
        if plan is not None:
            pid,start,score,hypotheses=plan
            elapsed=obs.tick-start
            tracked=next((q for q in outfield if q[0]==pid),None)
            if tracked is not None and tuple(obs.score)==score and elapsed>0:
                valid=[]
                for states in hypotheses:
                    if elapsed<=len(states):
                        st=states[elapsed-1]
                        ball_error=math.hypot(bx-st[0],by-st[1])
                        player_error=math.hypot(tracked[1]-st[4],tracked[2]-st[5])
                        velocity_error=math.hypot(vx-st[2],vy-st[3])
                        if ball_error<=.60 and player_error<=.60 and velocity_error<=6.:
                            valid.append(states)
                if valid:
                    self._siege_follow=(pid,start,score,valid)
                    carrier=tracked
                    following=True
                else:
                    self._siege_follow=None
            else:
                self._siege_follow=None
''')
s=s.replace('''                if obs.can_kick(p[0]):
                    movement=self._move(p,(bx+ax*.8,by+ay*.8))
''','''                if following:
                    # Execute exactly the pursuit predicted in the selected
                    # flight. Expire immediately when public states diverge.
                    movement=self._move(p,(bx+vx*.1,by+vy*.1))
                elif obs.can_kick(p[0]):
                    movement=self._move(p,(bx+ax*.8,by+ay*.8))
''')
ast.parse(s)
p=root/'v10-wall-followthrough/team.py';p.write_text(s)
assert 'best=(score,kick,outcomes)' in s
assert 'return n,assists,trace' in s
assert 'elif obs.can_kick(p[0])' in s
print(len(s.encode()),hashlib.sha256(p.read_bytes()).hexdigest())
