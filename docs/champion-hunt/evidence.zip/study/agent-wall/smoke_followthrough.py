import json,math,sys,hashlib
from pathlib import Path
from types import SimpleNamespace as NS
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv
from soccer.helpers import load_controller
root=Path(__file__).resolve().parent
p=root/'v10-wall-followthrough/team.py';c=load_controller(str(p))
with SoccerEnv(config_path='/workspace/work/exploit-lab/configs/default.toml') as e:
 f=e.field;c.act(e.reset(seed=3249061101)['team_a'])
def state(bx,by,vx,tick=100):
 ps=[NS(id=0,position=(-48.8,0.),velocity=(0.,0.),kick_cooldown_ticks=0),NS(id=1,position=(20.,-6.),velocity=(0.,0.),kick_cooldown_ticks=0),NS(id=2,position=(30.,6.),velocity=(0.,0.),kick_cooldown_ticks=0),NS(id=3,position=(bx-1.,by+.6*(1 if by>=0 else -1)),velocity=(8.,0.),kick_cooldown_ticks=0),NS(id=4,position=(35.,0.),velocity=(0.,0.),kick_cooldown_ticks=0)]
 enemies=[NS(id=5+i,position=(48.8,y),velocity=(0.,0.),kick_cooldown_ticks=0) for i,y in enumerate((5.6,2.8,0.,-2.8,-5.6))]
 return NS(field=f,opponent_goal=f.opponent_goal,my_goal=f.my_goal,tick=tick,score=(0,1),time_remaining=.8,my_players=ps,opponents=enemies,ball=NS(position=(bx,by),velocity=(vx,0.),controlling_team=0),can_kick=lambda i:math.hypot(ps[i].position[0]-bx,ps[i].position[1]-by)<=f.kick_range)
results=[]
for bx,by,vx in [(25.,0.,0.),(48.9,7.9,10.5),(48.9,-7.9,10.5)]:
 c.reset(0);obs=state(bx,by,vx);a=c.act(obs)
 assert set(a.players)==set(range(5))
 assert all(math.isfinite(v) for p in a.players.values() for v in p.movement)
 results.append(dict(state=[bx,by,vx],plan_generated=c._siege_follow is not None))
# Explicitly exercise matched follow-through, role commitment, zero new kick,
# and cancellation on a public-state deviation, independently of goal ranking.
c.reset(0);c._setup(f);obs=state(48.,7.9,8.,101)
tracked=obs.my_players[3]
expected=(48.,7.9,8.,0.,*tracked.position,*tracked.velocity)
c._siege_follow=(3,100,(0,1),[[expected,expected]])
a=c.act(obs);assert c._siege_follow is not None;assert a.players[3].kick_direction is None
expectedmove=c._move((3,*tracked.position,*tracked.velocity),(48.+8.*.1,7.9))
assert tuple(a.players[3].movement)==expectedmove
obs.ball.position=(40.,7.9);obs.tick=102
a=c.act(obs);assert c._siege_follow is None
out=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),fullact_states=results,matching_plan_followed=True,new_kick_suppressed=True,diverged_plan_cancelled=True,scope='Synthetic full act +one native kickoff observation, no native matches')
(root/'followthrough-smoke.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
