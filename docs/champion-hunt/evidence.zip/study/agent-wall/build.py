import ast
from pathlib import Path
root=Path(__file__).resolve().parent
source=Path('/workspace/work/replay-finishing-handoffs/experiments/champion-candidate-review/uploaded/team.py').read_text()
methods='''    def act(self, obs):
        wall=[q for q in obs.opponents if q.position[0]>obs.opponent_goal[0]-3.0 and abs(q.position[1])<9.0]
        if len(wall)>=4:
            if not self._ready:
                self._setup(obs.field)
                self._restart_until=obs.tick+int(3.0*self._hz)
                self._restart_owner=obs.ball.controlling_team
            return self._siege_act(obs,wall)
        return self._act_normal(obs)

    def _siege_goal(self,p,bx,by,vx,vy,movement,opponents):
        # Explicit public holding-wall forecast. This deliberately does not
        # replace the ordinary shot/interception model against moving teams.
        if bx<self._right-8.0 or abs(by)<self._goal_half+.5:
            return None
        side=1.0 if by>0 else -1.0
        best=None
        for gy in (self._goal_half-.02,self._goal_half-.18,self._goal_half-.45):
            for ex in (.03,.20,.45):
                ux,uy=_unit(self._right+ex-bx,side*gy-by)
                along=vx*ux+vy*uy
                perpendicular=max(0.,vx*vx+vy*vy-along*along)
                if perpendicular>=self._impulse*self._impulse:
                    continue
                speed=min(self._ball_cap,along+math.sqrt(self._impulse*self._impulse-perpendicular))
                if speed<8.:
                    continue
                kick=self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
                if kick is None:
                    continue
                launch=self._carrier_contact(p,bx,by,*self._requested_velocity(vx,vy,kick),movement)
                if launch is None:
                    continue
                x,y,sx,sy=launch
                oldx,oldy=bx,by
                valid=True
                for n in range(1,8):
                    elapsed=n*self._dt
                    # Frozen goal-wall opponents correct toward their public
                    # equally spaced slots. Predict one capped movement law.
                    for q in opponents:
                        coast=self._dt*self._damping*(1.-self._damping**n)/(1.-self._damping)
                        qx=q.position[0]+q.velocity[0]*coast
                        qy=q.position[1]+q.velocity[1]*coast
                        if (q.kick_cooldown_ticks<=n and math.hypot(oldx-qx,oldy-qy)<self._range+.015):
                            valid=False;break
                        if math.hypot(x-qx,y-qy)<self._contact+.015:
                            valid=False;break
                    if not valid:
                        break
                    if x>self._right and abs(y)<=self._goal_half:
                        score=10.-elapsed+min(1.,abs(y))*0.02
                        if best is None or score>best[0]:best=(score,kick)
                        break
                    if x>self._right-self._ball_radius and abs(y)>self._goal_half:
                        break
                    oldx,oldy=x,y
                    x+=sx*self._dt;y+=sy*self._dt
                    sx*=self._friction;sy*=self._friction
        return None if best is None else best[1]

    def _siege_act(self,obs,wall):
        bx,by=obs.ball.position
        vx,vy=obs.ball.velocity
        friends=[(p.id,*p.position,*p.velocity) for p in obs.my_players]
        outfield=friends[1:]
        path=self._trajectory(bx,by,vx,vy)
        carrier=min(outfield,key=lambda p:self._intercept(p,path)[0])
        self._receive_plan=self._receive_aim=self._bank_receive=None
        self._relay_receive=self._x_reception=None
        side=1.0 if by>=0. else -1.0
        if bx<self._right-14.:
            stage=(self._right-7.,side*(self._goal_half+1.2))
        else:
            stage=(self._right+4.,side*(self._goal_half+.90))
        ax,ay=_unit(stage[0]-bx,stage[1]-by)
        desired_speed=10.5
        if bx>self._right-12.:
            # Keep forward momentum for a one-step diagonal endpoint shot.
            tx,ty=10.5,_clip((side*(self._goal_half+.90)-by)*5.,-4.,4.)
        else:
            tx,ty=ax*desired_speed,ay*desired_speed
        actions=TeamAction(debug={'text':'Corner endpoint siege'})
        free=[p for p in outfield if p[0]!=carrier[0]]
        free.sort(key=lambda p:p[2])
        targets={}
        # A retrieval net collects the opponent's predictable straight
        # clearances without crowding the corner carrier.
        for index,p in enumerate(free):
            targets[p[0]]=(min(34.,max(0.,bx-12.)),(-7.,0.,7.)[index])
        if self.SIEGE_PRESS:
            # A separate variant adds two lateral compression contacts on
            # the opposite edge; never crosses the selected shot corridor.
            chosen=sorted(wall,key=lambda q:side*q.position[1])[:2]
            for p,q in zip(free,chosen):
                targets[p[0]]=(self._right+.3,q.position[1]-side*1.8)
        gx=self._left+1.3
        gy=_clip(by*.35,-self._goal_half+1.,self._goal_half-1.)
        if vx<-.2:
            ticks=self._crossing_ticks(bx,vx,-gx)
            if ticks is not None and 0<=ticks<80:
                gy=_clip(by+vy*self._roll[min(80,max(0,int(ticks)))],-self._goal_half+.4,self._goal_half-.4)
        targets[0]=(gx,gy)
        for p in friends:
            if p[0]==carrier[0]:
                target=self._intercept(p,path)[1]
                movement=self._move(p,self._target(*target))
                kick=None
                if obs.can_kick(p[0]):
                    movement=self._move(p,(bx+ax*.8,by+ay*.8))
                    kick=self._siege_goal(p,bx,by,vx,vy,movement,wall)
                    if kick is None:
                        kick=self._kick_to_velocity(vx,vy,tx,ty)
                    px=p[3]*self._damping+movement[0]*self._acc
                    py=p[4]*self._damping+movement[1]*self._acc
                    length=math.hypot(px,py)
                    if length>self._speed:px*=self._speed/length;py*=self._speed/length
                    if math.hypot(p[1]+px*self._dt-bx,p[2]+py*self._dt-by)>self._range-.025:
                        kick=None
                if kick is None:actions.set(p[0],PlayerAction(movement=movement))
                else:actions.set(p[0],PlayerAction(movement=movement,kick_direction=kick[0],kick_power=kick[1]))
            else:
                movement=self._move(p,targets.get(p[0],p[1:3]))
                if p[0]==0 and obs.can_kick(p[0]):
                    actions.set(p[0],PlayerAction(movement=movement,kick_direction=(1.,0.),kick_power=1.))
                else:
                    actions.set(p[0],PlayerAction(movement=movement))
        return actions

'''
a=source.index('    def act(self, obs):');b=source.index('    def _wall_break(',a)
for name,press in [('corner-route',False),('corner-press',True)]:
 s=source[:a]+methods+source[b:]
 s=s.replace('    LOCK_LEAD = 1\n','    LOCK_LEAD = 0\n').replace('    TRAIL_WALL = 2\n','    TRAIL_WALL = 0\n')
 s=s.replace('    WALL_BREAK = 1\n','    WALL_BREAK = 0\n    SIEGE_PRESS = '+str(press)+'\n')
 s=s.replace('version = "replay-finishing-handoffs-v1"','version = "'+name+'-v1"')
 ast.parse(s)
 (root/name/'team.py').write_text(s)
 print(name,len(s.encode()))
