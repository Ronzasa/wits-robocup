import ast,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'v10-corner-route-v2/team.py').read_text()
methods='''    def _siege_goal(self,p,bx,by,vx,vy,movement,opponents):
        # Target-specific counter: predict the holding wall's actual steering,
        # ready +x-canonical clearances, and ball/body restitution. Enemy kicks
        # can help the ball enter their goal, so do not reject them outright.
        if bx<self._right-12. or abs(by)<self._goal_half-.5:
            return None
        obs=self._siege_obs
        opponents=obs.opponents
        qstates=[(q.id,*q.position,*q.velocity) for q in opponents]
        frames=[qstates]
        count=len(qstates)
        for n in range(1,13):
            moved=[]
            for index,q in enumerate(frames[-1]):
                tx=self._right-obs.field.player_radius-.2
                ty=-(index-(count-1)*.5)*2.8
                dx,dy=tx-q[1],ty-q[2]
                distance=math.hypot(dx,dy)
                scale=min(1.,distance/1.5)/distance if distance>1e-8 else 0.
                qvx=q[3]*self._damping+dx*scale*self._acc
                qvy=q[4]*self._damping+dy*scale*self._acc
                speed=math.hypot(qvx,qvy)
                if speed>self._speed:qvx*=self._speed/speed;qvy*=self._speed/speed
                moved.append((q[0],_clip(q[1]+qvx*self._dt,self._left+1.,self._right-1.),
                              _clip(q[2]+qvy*self._dt,-self._half_height+1.,self._half_height-1.),qvx,qvy))
            frames.append(moved)
        side=1. if by>=0. else -1.
        best=None
        for gy in (self._goal_half-.02,self._goal_half-.30,self._goal_half-.7):
            for ex in (.10,.50,1.0):
                ux,uy=_unit(self._right+ex-bx,side*gy-by)
                along=vx*ux+vy*uy
                lateral=max(0.,vx*vx+vy*vy-along*along)
                if lateral>=self._impulse*self._impulse:continue
                cap=min(self._ball_cap,along+math.sqrt(self._impulse*self._impulse-lateral))
                for ratio in (1.,.88):
                    kick=self._kick_to_velocity(vx,vy,ux*cap*ratio,uy*cap*ratio)
                    if kick is None:continue
                    outcomes=[self._siege_clearance_path(p,(bx,by,vx,vy),movement,kick,frames,order)
                              for order in (False,True)]
                    if any(outcome is None for outcome in outcomes):continue
                    latest=max(outcome[0] for outcome in outcomes)
                    assisted=min(outcome[1] for outcome in outcomes)
                    score=15.-latest*.2+assisted*.03
                    if best is None or score>best[0]:best=(score,kick)
        return None if best is None else best[1]

    def _siege_clearance_path(self,p,ball,movement,kick,frames,enemy_first):
        x,y,vx,vy=ball
        obs=self._siege_obs
        cooldowns=[q.kick_cooldown_ticks for q in obs.opponents]
        own=[p[1],p[2],p[3],p[4]]
        assists=0
        for n in range(1,13):
            before=frames[n-1];after=frames[n]
            intents=[i for i,q in enumerate(before)
                     if cooldowns[i]==0 and (x-q[1])**2+(y-q[2])**2<=self._range*self._range]
            move=movement if n==1 else self._move((p[0],*own),(x+vx*.1,y+vy*.1))
            own[2]=own[2]*self._damping+move[0]*self._acc
            own[3]=own[3]*self._damping+move[1]*self._acc
            speed=math.hypot(own[2],own[3])
            if speed>self._speed:own[2]*=self._speed/speed;own[3]*=self._speed/speed
            own[0]=_clip(own[0]+own[2]*self._dt,self._left+1.,self._right-1.)
            own[1]=_clip(own[1]+own[3]*self._dt,-self._half_height+1.,self._half_height-1.)
            if n==1 and (x-own[0])**2+(y-own[1])**2>self._range*self._range:return None
            kicks=[]
            for index in intents:
                q=after[index]
                if (x-q[1])**2+(y-q[2])**2<=self._range*self._range:
                    kicks.append((-self._impulse,0.))
                    cooldowns[index]=5;assists+=1
            own_kick=(kick[0][0]*self._impulse*kick[1],kick[0][1]*self._impulse*kick[1])
            if n==1:
                if enemy_first:kicks.append(own_kick)
                else:kicks.insert(0,own_kick)
            for dx,dy in kicks:
                vx+=dx;vy+=dy
                speed=math.hypot(vx,vy)
                if speed>self._ball_cap:vx*=self._ball_cap/speed;vy*=self._ball_cap/speed
            x+=vx*self._dt;y+=vy*self._dt
            vx*=self._friction;vy*=self._friction
            wall=self._half_height-self._ball_radius
            if abs(y)>wall:
                sign=1. if y>0. else -1.
                y=sign*2.*wall-y;vy=-sign*abs(vy)*self._wall
            xwall=self._right-self._ball_radius
            if abs(x)>xwall and abs(y)>self._goal_half:
                sign=1. if x>0. else -1.
                x=sign*2.*xwall-x;vx=-sign*abs(vx)*self._wall
            # Predict all current friendly bodies; unrelated future steering
            # and player/player collisions remain unmodelled uncertainty.
            bodies=[]
            for friend in obs.my_players:
                if friend.id==p[0]:bodies.append(tuple(own))
                else:
                    coast=self._dt*self._damping*(1.-self._damping**n)/(1.-self._damping)
                    bodies.append((friend.position[0]+friend.velocity[0]*coast,
                                   friend.position[1]+friend.velocity[1]*coast,
                                   friend.velocity[0]*self._damping**n,friend.velocity[1]*self._damping**n))
            enemy_bodies=[q[1:] for q in after]
            if enemy_first:bodies=enemy_bodies+bodies
            else:bodies+=enemy_bodies
            for px,py,pvx,pvy in bodies:
                dx,dy=x-px,y-py
                gap=math.hypot(dx,dy)
                if 1e-8<gap<self._contact:
                    nx,ny=dx/gap,dy/gap
                    x,y=px+nx*self._contact,py+ny*self._contact
                    closing=(vx-pvx)*nx+(vy-pvy)*ny
                    if closing<0.:
                        vx-=1.25*closing*nx;vy-=1.25*closing*ny
            if x>self._right and abs(y)<=self._goal_half:return n,assists
            if x<self._left and abs(y)<=self._goal_half:return None
            cooldowns=[max(0,c-1) for c in cooldowns]
        return None

'''
a=source.index('    def _siege_goal(');b=source.index('    def _siege_act(',a)
s=source[:a]+methods+source[b:]
s=s.replace('    def _siege_act(self,obs,wall):\n','    def _siege_act(self,obs,wall):\n        self._siege_obs=obs\n')
s=s.replace('version = "v10-corner-route-v2"','version = "v10-clearance-goal-v1"')
ast.parse(s)
p=root/'v10-clearance-goal/team.py';p.write_text(s)
print(len(s.encode()),hashlib.sha256(p.read_bytes()).hexdigest())
