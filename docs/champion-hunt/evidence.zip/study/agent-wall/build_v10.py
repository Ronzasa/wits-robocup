import ast
from pathlib import Path
root=Path(__file__).resolve().parent
base=Path('/workspace/work/replay-finishing-handoffs/champions/v10.0/team.py').read_text()
base=base.replace('    def act(self, obs):','    def _opening_act(self, obs):',1)
base=base.replace('    FIRST_TOUCH = False\n','    FIRST_TOUCH = False\n    SIEGE_PRESS = False\n')
for src,name in [('corner-route','v10-corner-route'),('diagonal-corner','v10-diagonal-corner')]:
 s=(root/src/'team.py').read_text();lines=s.splitlines(True);t=ast.parse(s)
 cls=next(n for n in t.body if isinstance(n,ast.ClassDef))
 methods=[]
 for n in cls.body:
  if isinstance(n,ast.FunctionDef) and n.name in ('act','_siege_goal','_siege_act'):
   methods.append(''.join(lines[n.lineno-1:n.end_lineno]))
 extra='\n\n'+'\n\n'.join(methods)+'\n'
 extra=extra.replace('return self._act_normal(obs)','return self._opening_act(obs)')
 new=base+extra
 new=new.replace('version = "10.0-titan10b-r"','version = "'+name+'-v1"')
 ast.parse(new)
 (root/name).mkdir(exist_ok=True)
 (root/name/'team.py').write_text(new)
 print(name,len(new.encode()))
