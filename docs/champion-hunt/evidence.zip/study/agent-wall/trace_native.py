"""Two separate untimed native public-observation functional diagnostics.
No SDK/simulator/opponent changes; no formation hooks; results never replace scheduled fixtures.
"""
import json,sys
from pathlib import Path
from collections import Counter
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv
from soccer.helpers import load_controller
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/work/champion-hunt-20261025')

def run(kickoff):
 side=1;seed=3249061101
 paths=[str(BASE/'opponent/team.py'),str(BASE/'screen-new2/sources/corner-route/team.py')]
 cs=[load_controller(p) for p in paths];c=cs[side]
 counts=Counter();proposals=[];states=[];events=[];pending=[]
 original_goal=c._siege_goal
 def goal(p,bx,by,vx,vy,movement,opponents):
  counts['siege_goal_calls']+=1
  answer=original_goal(p,bx,by,vx,vy,movement,opponents)
  row=dict(tick=now['tick'],score=now['score'],carrier=p,ball=[bx,by,vx,vy],movement=movement,kick=answer,opponents_supplied=len(opponents),cooldowns=now['cooldowns'])
  if answer is not None:counts['siege_goal_proposals']+=1;pending.append(now['tick'])
  if bx>40 and 7.1<abs(by)<12.5:proposals.append(row)
  return answer
 c._siege_goal=goal
 with SoccerEnv(config_path='/workspace/work/replay-finishing-handoffs/configs/default.toml',max_ticks=2400,per_decision_timeout_ms=20.,team_ids=('policy_a','policy_b')) as env:
  for controller in cs:controller.reset(seed)
  obs=env.reset(seed=seed,kickoff_team=side if kickoff else 1-side)
  initial=[list(p.position) for p in obs['team_a'].my_players+obs['team_a'].opponents]
  while not env.finished:
   me=obs['team_b'];now=dict(tick=me.tick,score=list(me.score),cooldowns={p.id:p.kick_cooldown_ticks for p in me.my_players})
   wall=[q for q in me.opponents if q.position[0]>47 and abs(q.position[1])<9]
   if len(wall)>=4:
    counts['wall_ticks']+=1
    bx,by=me.ball.position
    if bx>45 and 7.1<abs(by)<12.5:
     counts['corner_window_ticks']+=1
     ready=[p.id for p in me.my_players if me.can_kick(p.id)]
     if ready:counts['corner_window_ready_ticks']+=1
     if len(states)<400:states.append(dict(tick=me.tick,score=list(me.score),ball=[*me.ball.position,*me.ball.velocity],players=[dict(id=p.id,position=list(p.position),velocity=list(p.velocity),cooldown=p.kick_cooldown_ticks) for p in me.my_players],ready=ready))
   for event in me.events:
    if event.get('kind') in ('kick','goal'):
     e=dict(event);e['observation_tick']=me.tick
     if event.get('kind')=='goal':counts['observed_goal_events']+=1
     if pending and me.tick-pending[-1]<=1:e['after_siege_proposal_tick']=pending[-1]
     events.append(e)
   actions={'team_a':cs[0].act(obs['team_a']),'team_b':c.act(me)}
   obs,_=env.step(actions)
  result=env.result()
 return dict(fixture=dict(seed=seed,candidate_side=side,candidate_kickoff=kickoff),counts=dict(counts),initial_roster=initial,score=result['score'],native_stats=result['stats'],corner_calls=proposals,corner_states=states,events=events,scope='untimed functional rerun, public native defaults; not qualification; no recorded decision timing')

out=[run(False),run(True)]
(ROOT/'native-corner-traces.json').write_text(json.dumps(out,indent=2)+'\n')
for r in out:print(json.dumps(dict(fixture=r['fixture'],counts=r['counts'],score=r['score'],call_examples=len(r['corner_calls']),state_examples=len(r['corner_states']),events=len(r['events']))))
