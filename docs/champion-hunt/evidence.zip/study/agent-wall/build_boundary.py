import ast,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'v10-clearance-goal/team.py').read_text()
start=source.index('            wall=self._half_height-self._ball_radius\n',source.index('    def _siege_clearance_path('))
end=source.index('            # Predict all current friendly bodies;',start)
old_boundary=source[start:end]
source=source[:start]+source[end:]
source=source.replace('            x+=vx*self._dt;y+=vy*self._dt\n','            previous_x,previous_y=x,y\n            x+=vx*self._dt;y+=vy*self._dt\n')
new_boundary='''            # Native traces leave body overlap created by a wall reflection:
            # resolve ball/player contacts before the boundary response.
            wall=self._half_height-self._ball_radius
            if abs(y)>wall:
                sign=1. if y>0. else -1.
                y=sign*2.*wall-y;vy=-sign*abs(vy)*self._wall
            xwall=self._right-self._ball_radius
            if abs(x)>xwall:
                sign=1. if x>0. else -1.
                if self.SIEGE_CROSSING:
                    crossing_y=y
                    if abs(previous_x)<=xwall and abs(x-previous_x)>1e-9:
                        fraction=(sign*xwall-previous_x)/(x-previous_x)
                        crossing_y=previous_y+(y-previous_y)*fraction
                    blocked=abs(y)>self._goal_half or abs(crossing_y)>self._goal_half
                else:
                    # Conservative aperture guard matching currently observed
                    # outside->inside and inside->outside native reflections.
                    blocked=max(abs(previous_y),abs(y))>self._goal_half
                if blocked:
                    x=sign*2.*xwall-x;vx=-sign*abs(vx)*self._wall
'''
source=source.replace('            if x>self._right and abs(y)<=self._goal_half:return n,assists\n',new_boundary+'            if x>self._right and abs(y)<=self._goal_half:return n,assists\n')
for name,crossing,bank in [('v10-boundary-union',False,False),('v10-boundary-crossing',True,False),('v10-bank-pressure',True,True)]:
 s=source.replace('    SIEGE_PRESS = False\n','    SIEGE_PRESS = False\n    SIEGE_CROSSING = '+str(crossing)+'\n')
 s=s.replace('version = "v10-clearance-goal-v1"','version = "'+name+'-v1"')
 if bank:s=s.replace('for gy in (self._goal_half-.02,self._goal_half-.30,self._goal_half-.7):','for gy in (self._goal_half-.02,self._goal_half-.30,self._goal_half-.7,self._goal_half+.25,self._goal_half+.65):')
 ast.parse(s);p=root/name/'team.py';p.parent.mkdir(exist_ok=True);p.write_text(s)
 print(name,len(s.encode()),hashlib.sha256(p.read_bytes()).hexdigest())
