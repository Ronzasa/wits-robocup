# Wall attack experiments

No champion, opponent, native engine, SDK, config, or repository main file is modified by this agent. All candidate files are single-file math+soccer controllers. Parent runs native qualification centrally.

## Candidates

- `corner-route`: uploaded v1 normal opening, own lead/trailing walls disabled. At >=4 opponents occupying their goal, a single carrier routes the ball wide and near the post, while three outfielders collect predictable straight clearances. A finite, momentum-aware near-post endpoint goal search uses the actual requested impulse and own first contact.
- `corner-press`: same with two opposite-edge compression players. Failed to outperform the simpler route in first screen.
- `diagonal-corner`: wider y~14 approach and 27 finite launch phases with 40-step static-wall forecasts. Attempts to exploit the endpoint collision geometry before reaching the tiny x~49 corner window.
- `v10-corner-route`, `v10-diagonal-corner`: FIRST transplants are invalid; missing `_goal_half` in the v10 setup caused native policy exceptions. Preserve their failures, do not submit them.
- `v10-corner-route-v2`, `v10-diagonal-corner-v2`: corrected v10 setup includes `_goal_half`. Complete synthetic act smoke tests and one native kickoff observation passed; native match decisions are parent's evidence.
- `v10-clearance-goal`: predicts all five known holding-wall players' normalized/throttled position corrections, per-player cooldown and straight clearance impulses. It does not discard enemy kicks: those can create own goals through residual momentum and body restitution. Eighteen finite launches, twelve ticks and two first-action/body orders. Friendly future role changes and player/player collisions are not fully modeled; accept only as a target-specific candidate ranking model, not a physical guarantee. Synthetic full-act smoke cost about1.6–2.7ms on four states, not native deadline qualification.

## Functional native evidence

`trace_native.py` ran TWO full matches without native timing reporting, only for public-observation/action inspection. Default native rosters; fixed uploaded opponent. Scores match scheduled matches exactly:

- seed3249061101, candidate side1, opponent kickoff: 0–1; 603 settled-wall ticks, 141 corner-window ticks, 21 ready-window ticks, 4 modeled scoring proposals, all4 actual native kick events, zero candidate goals.
- same seed/side, candidate kickoff: 4–1; 1,377 wall ticks, 136 corner-window ticks, 19 ready-window ticks, 6 modeled scoring proposals, all6 actual native kick events.

The four goals in the latter game are NOT all corner goals. Own player goals occur at152 and555. Own keeper own goal338 concedes. Opponent keeper own goals811 and1249 score. The opponent trailing wall begins after811 (3–1); only the fourth goal occurs during that settled-wall period. A corner proposal at1243 precedes that goal; this is temporal association, not proven causal attribution.

The original static/coasting goal forecast has false positives. For example, loss tick2101's proposal executes but does not score before an opponent kick next tick. The two-match trace's selected corner-state filter omits post-proposal states once |ball.y|<7.1, so it cannot diagnose the exact boundary/body discrepancy. `trace_native_v2.py` is PREPARED BUT NOT RUN; it captures all opponent states and next three observations per proposal. Parent must coordinate any execution away from timed cohorts.

The old goal model's comments about predicting wall slot correction were inaccurate: it only coasts observed velocities. The new clearance-goal model implements the actual normalized restore command, while still leaving noted future-contact uncertainty. Only actual native goals/results should decide acceptance.

## Later source variants and verified physics findings

- `v10-clearance-score-sync`: one-line `_last_score=obs.score` update in wall mode. A synthetic sequence shows incorrect restart ownership without it, but normal default-roster goal resets normally run the opening controller before the wall reforms. Therefore the synthetic sequence does not establish a reachable native bug or explain repeated equalizers. Parent is screening it as a control only.
- `v10-boundary-union`: unchanged launch set and clearance model, but ball/body contacts precede boundary reflection, and endwall aperture uses conservative pre/post vertical guard.
- `v10-boundary-crossing`: same physics-order correction, but aperture check interpolates vertical position at the inner endwall crossing and also checks the final endpoint. This is a separate hypothesis from pre/post union.
- `v10-bank-pressure`: crossing model plus two explicit outside-mouth bank targets; still simulates the rebound, next clearance and body contact instead of rejecting wall returns. Thirty bounded launches instead of eighteen; synthetic full-act cost about4.8–5.4ms, not native deadline qualification.

Native v2 followups prove first static goal model false positives through endwall reflection. `boundary-order-cases.json` extracts ten position/velocity reflections matching a full-step x mirror to5e-5, including nine resulting positions that overlap a wall player's contact radius. Since the native state retains those overlaps, ball/body contacts precede the endwall reflection, not follow it. The current strong `v10-clearance-goal` ranking model had that order reversed; frozen source was retained and the corrected ordering is isolated in new variants.

The archive's sixteen accepted inside-to-inside near-post goals have ball-center|y|>6.55, disproving a universal ball-radius inset as the explanation for corner failures. Both pre/post-union and inner-wall-interpolated+post checks fit the currently observed failures and successes. The exact aperture implementation is not uniquely established; do not claim a fully reverse-engineered x-before-y engine order. Three offline regression checks pass in `test_boundary_reference.py`.

Parent's central 32-development-game expansion of `v10-clearance-goal` reports12W16D4L, goals83–53, zero errors/deadline misses, with38 opponent own goals and2 own own-goals. This identifies a real target-specific mechanism and many draws, not a qualified dominant challenger. Parent owns all match statistics and promotion decisions.
