import ast,hashlib,json,sys,math
from pathlib import Path
from types import SimpleNamespace as NS
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv
from soccer.helpers import load_controller
root=Path(__file__).resolve().parent
results=[]
for old,new in [('v10-corner-route','v10-corner-route-v2'),('v10-diagonal-corner','v10-diagonal-corner-v2')]:
 s=(root/old/'team.py').read_text()
 s=s.replace('        self._half_height = field.height * 0.5\n','        self._half_height = field.height * 0.5\n        self._goal_half = field.goal_width * 0.5\n')
 s=s.replace('version = "'+old+'-v1"','version = "'+new+'"')
 ast.parse(s);target=root/new/'team.py';target.write_text(s)
 c=load_controller(str(target))
 with SoccerEnv(config_path='/workspace/work/exploit-lab/configs/default.toml') as e:
  native=e.reset(seed=3249061101);f=e.field
  c.act(native['team_a'])
 for bx,by,vx in [(25.,0.,0.),(48.9,7.9,10.5),(48.9,-7.9,10.5)]:
  c.reset(0);c._setup(f)
  ps=[NS(id=0,position=(-48.8,0.),velocity=(0.,0.),kick_cooldown_ticks=0),NS(id=1,position=(20.,-6.),velocity=(0.,0.),kick_cooldown_ticks=0),NS(id=2,position=(30.,6.),velocity=(0.,0.),kick_cooldown_ticks=0),NS(id=3,position=(bx-1.,by+.6*(1 if by>=0 else -1)),velocity=(8.,0.),kick_cooldown_ticks=0),NS(id=4,position=(35.,0.),velocity=(0.,0.),kick_cooldown_ticks=0)]
  enemies=[NS(id=5+i,position=(48.8,y),velocity=(0.,0.),kick_cooldown_ticks=0) for i,y in enumerate((5.6,2.8,0.,-2.8,-5.6))]
  obs=NS(field=f,opponent_goal=f.opponent_goal,my_goal=f.my_goal,tick=100,score=(0,1),time_remaining=.8,my_players=ps,opponents=enemies,ball=NS(position=(bx,by),velocity=(vx,0.),controlling_team=0),can_kick=lambda i:math.hypot(ps[i].position[0]-bx,ps[i].position[1]-by)<=f.kick_range)
  a=c.act(obs);assert set(a.players)==set(range(5));assert all(math.isfinite(v) for p in a.players.values() for v in p.movement)
 results.append(dict(path=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),tests=['one native kickoff observation','synthetic fullact ball25,0','synthetic fullact positive corner','synthetic fullact negative corner'],passed=True))
(root/'v10-v2-smoke.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
