import ast
from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'corner-route/team.py').read_text()
method='''    def _siege_goal(self,p,bx,by,vx,vy,movement,opponents):
        # A settled wall holds its slots. Search finite launch phases so the
        # final pre-goal sample is outside every kicker and the next endpoint
        # crosses the goal plane inside the post. No interpolated goal credit.
        if bx<self._right-22.0 or abs(by)<self._goal_half+.5:
            return None
        side=1.0 if by>0 else -1.0
        best=None
        for gy in (self._goal_half-.02,self._goal_half-.18,self._goal_half-.45):
            for ex in (.03,.20,.45):
                ux,uy=_unit(self._right+ex-bx,side*gy-by)
                along=vx*ux+vy*uy
                perpendicular=max(0.,vx*vx+vy*vy-along*along)
                if perpendicular>=self._impulse*self._impulse:
                    continue
                cap=min(self._ball_cap,along+math.sqrt(self._impulse*self._impulse-perpendicular))
                for ratio in (1.0,.94,.88):
                    speed=cap*ratio
                    if speed<8.:
                        continue
                    kick=self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
                    if kick is None:
                        continue
                    launch=self._carrier_contact(p,bx,by,*self._requested_velocity(vx,vy,kick),movement)
                    if launch is None:
                        continue
                    x,y,sx,sy=launch
                    oldx,oldy=bx,by
                    valid=True
                    for n in range(1,41):
                        coast=self._dt*self._damping*(1.-self._damping**n)/(1.-self._damping)
                        for q in opponents:
                            qx=q.position[0]+q.velocity[0]*coast
                            qy=q.position[1]+q.velocity[1]*coast
                            if q.kick_cooldown_ticks<=n and (oldx-qx)**2+(oldy-qy)**2<(self._range+.02)**2:
                                valid=False;break
                            if (x-qx)**2+(y-qy)**2<(self._contact+.02)**2:
                                valid=False;break
                        if not valid:
                            break
                        if x>self._right and abs(y)<=self._goal_half:
                            score=10.-n*self._dt+math.hypot(sx,sy)*.002
                            if best is None or score>best[0]:best=(score,kick)
                            break
                        if x>self._right-self._ball_radius and abs(y)>self._goal_half:
                            break
                        oldx,oldy=x,y
                        x+=sx*self._dt;y+=sy*self._dt
                        sx*=self._friction;sy*=self._friction
        return None if best is None else best[1]

'''
a=source.index('    def _siege_goal(');b=source.index('    def _siege_act(',a)
s=source[:a]+method+source[b:]
s=s.replace('version = "corner-route-v1"','version = "diagonal-corner-v1"')
s=s.replace("side*(self._goal_half+1.2)","side*(self._goal_half+7.)")
s=s.replace("side*(self._goal_half+.90)","side*(self._goal_half+(.90 if bx>self._right-5. else 7.))")
ast.parse(s)
(root/'diagonal-corner/team.py').write_text(s)
print(len(s.encode()))
