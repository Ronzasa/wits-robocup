"""Regression checks of observed public native boundary cases, no engine calls."""
import json,math,unittest
from pathlib import Path
DATA=json.loads((Path(__file__).with_name('boundary-order-cases.json')).read_text())

def step(before,crossing):
 x,y,vx,vy=before;xx=x+vx*.05;yy=y+vy*.05
 if abs(xx)>49.55:
  if crossing:
   hit_y=yy
   if abs(x)<=49.55:hit_y=y+(yy-y)*(math.copysign(49.55,xx)-x)/(xx-x)
   blocked=abs(yy)>7. or abs(hit_y)>7.
  else:blocked=max(abs(y),abs(yy))>7.
  if blocked:xx=math.copysign(99.1,xx)-xx;vx=-math.copysign(abs(vx)*.75,xx if xx>49.55 else 1.)
 return xx,yy,vx*.985,vy*.985

class BoundaryEvidence(unittest.TestCase):
 def test_both_candidate_aperture_hypotheses_match_observed_reflections(self):
  self.assertGreaterEqual(len(DATA['reflections']),8)
  for case in DATA['reflections']:
   for cross in (False,True):
    with self.subTest(tick=case['step_tick'],cross=cross):
     actual=step(case['before'],cross)
     for a,b in zip(actual,case['native_after']):self.assertAlmostEqual(a,b,delta=5e-5)
 def test_native_inside_nearpost_goals_disprove_ball_radius_inset(self):
  self.assertGreaterEqual(len(DATA['accepted_nearpost_goals']),8)
  for case in DATA['accepted_nearpost_goals']:
   self.assertTrue(case['native_goal'])
   self.assertGreater(abs(case['before'][1]),6.55)
   for cross in (False,True):
    x,y,_,_=step(case['before'],cross)
    self.assertGreater(x,50.)
    self.assertLessEqual(abs(y),7.)
 def test_native_reflection_can_create_body_overlap_without_same_step_resolution(self):
  overlaps=[x for x in DATA['reflections'] if x['overlaps_after_reflection']]
  self.assertGreaterEqual(len(overlaps),3)
  for case in overlaps:self.assertTrue(any(q['distance']<1.45 for q in case['overlaps_after_reflection']))

if __name__=='__main__':unittest.main()
