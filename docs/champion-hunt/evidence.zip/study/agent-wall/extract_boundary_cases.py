"""Extract observed physics regressions; no engine execution or hidden state."""
import hashlib,json,math
from pathlib import Path
root=Path(__file__).resolve().parent
trace=root/'native-corner-traces-v2.json';games=json.loads(trace.read_text())
cases=[]
for game in games:
 for row in game['corner_calls']:
  if row['kick'] is None:continue
  prior=row['ball'];first=True
  for follow in (f for f in game['proposal_followups'] if f['proposal_tick']==row['tick']):
   x,y,vx,vy=prior
   if first:
    direction,power=row['kick'];vx+=22.*direction[0]*power;vy+=22.*direction[1]*power
    speed=math.hypot(vx,vy)
    if speed>30.:vx*=30./speed;vy*=30./speed
   elif any(e['kind']=='kick' for e in follow['events']):break
   raw=[x+vx*.05,y+vy*.05]
   actual=follow['ball']
   expected=[99.1-raw[0],raw[1],-vx*.985*.75,vy*.985]
   error=max(abs(a-b) for a,b in zip(expected,actual))
   if raw[0]>49.55 and error<5e-5:
    crossing_y=y+(raw[1]-y)*(49.55-x)/(raw[0]-x) if x<=49.55 else raw[1]
    overlaps=[dict(id=q['id'],distance=math.hypot(actual[0]-q['position'][0],actual[1]-q['position'][1])) for q in follow['opponents'] if math.hypot(actual[0]-q['position'][0],actual[1]-q['position'][1])<1.45]
    cases.append(dict(fixture=game['fixture'],proposal_tick=row['tick'],step_tick=follow['tick'],before=[x,y,vx,vy],unbounded_endpoint=raw,native_after=actual,native_reflection_error=error,inner_wall_cross_y=crossing_y,overlaps_after_reflection=overlaps,native_goal=False))
   prior=actual;first=False
positive=[]
for name in ('edge-finishing-native.json','edge-finishing-native-advanced.json'):
 path=Path('/workspace/work/top-two-json-20261025')/name
 for p in json.loads(path.read_text())['native_probes']:
  if p['native_goal'] and abs(p['nominal_target_y_at_x50'])>=6.8:
   positive.append(dict(source=name,side=p['side'],before=p['before_goal'],native_goal=True,nominal_goal_y=p['nominal_target_y_at_x50']))
result=dict(scope='Public native observations. Reflection coordinate/velocity fits full-step endwall mirror. Supports body-before-boundary; aperture crossing vs pre/post guard not uniquely established. Inside->inside positive goals disprove universal0.45mouthinset.',trace_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),reflections=cases,accepted_nearpost_goals=positive)
(root/'boundary-order-cases.json').write_text(json.dumps(result,indent=2)+'\n')
print('Native exact free-flight reflections',len(cases),'nativegoals outsideinset',len(positive),'nativeoverlaps-afterreflection',sum(bool(c['overlaps_after_reflection']) for c in cases))
