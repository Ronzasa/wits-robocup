"""Frozen adaptive matches with read-only post-match controller-mode telemetry.

Only this harness's bound loader reference is wrapped; the SDK, policies and
native decision/failure loop are unchanged. Mode reads occur after the match.
"""
import argparse,hashlib,json,random,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/work/replay-finishing-handoffs')
sys.path.insert(0,str(REPO/'tools/benchmarks'))
from benchmark import aggregate,points
import default_roster as driver
from batch import compare

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def observed_match(candidate,opponent,seed,side,kick,reg):
    saved=driver.load_controller
    objects=[]
    def capture(path):
        controller=saved(path);objects.append(controller);return controller
    driver.load_controller=capture
    try:
        result,telemetry,roster=driver.native_match(candidate,opponent,seed,side,kick,reg)
    finally:
        driver.load_controller=saved
    c=objects[side]
    telemetry['adaptive']=dict(active_at_end=getattr(c,'_active',None),
        wall_confirmed=getattr(c,'_wall_confirmed',None),
        wall_confirmation_tick=getattr(c,'_wall_last_tick',None),
        last_fit_count=getattr(c,'_wall_ticks',None))
    return result,telemetry,roster

def main(folder):
 folder=Path(folder);reg=json.loads((folder/'registration.json').read_text())
 for item in [*reg['candidates'].values(),reg['opponent']]:assert digest(item['path'])==item['sha256']
 (folder/'metadata.json').write_text(json.dumps(dict(started=datetime.now(timezone.utc).isoformat(),registration_sha256=digest(folder/'registration.json'),harness_sha256=digest(__file__),native_driver_sha256=digest(driver.__file__),mode_observer='own harness loader wrapper, fields read only after native result'),indent=2)+'\n')
 rng=random.Random(reg['order_seed']);fixtures=[(seed,side,kick) for seed in reg['seeds'] for side in (0,1) for kick in (True,False)];rng.shuffle(fixtures)
 rows={n:[] for n in reg['candidates']}
 with (folder/'matches.jsonl').open('x') as f:
  for index,(seed,side,kick) in enumerate(fixtures):
   labels=list(rows);rng.shuffle(labels)
   for n in labels:
    result,telemetry,roster=observed_match(reg['candidates'][n]['path'],reg['opponent']['path'],seed,side,kick,reg)
    row=dict(source=n,opponent_name='frozen-upload',seed=seed,candidate_slot=side,candidate_takes_kickoff=kick,result=result,telemetry=telemetry,initial_roster=roster)
    rows[n].append(row);f.write(json.dumps(row)+'\n');f.flush()
   print('ADAPTIVE',index+1,'/',len(fixtures),{n:sum(points(r) for r in rs) for n,rs in rows.items()},flush=True)
 summaries={n:aggregate(rs) for n,rs in rows.items()}
 for n,s in summaries.items():
  s.update(compare(rows[n]));mirror=aggregate([dict(r,candidate_slot=1-r['candidate_slot']) for r in rows[n]])
  s.update(opponent_points=mirror['points'],opponent_errors=mirror['policy_errors'],opponent_raw_misses=mirror['policy_timeouts'],additional_raw_misses_per1000=(s['policy_timeouts']-mirror['policy_timeouts'])*1000/s['matches'],incomplete_fixtures=sum(r['result']['ticks']!=2400 or r['result']['terminal_reason']!='time_limit' for r in rows[n]),specialist_activated_matches=sum(r['telemetry']['adaptive']['active_at_end'] is True for r in rows[n]))
 for item in [*reg['candidates'].values(),reg['opponent']]:assert digest(item['path'])==item['sha256']
 report=dict(summaries=summaries,split=reg['split'],promotion=False,finished=datetime.now(timezone.utc).isoformat())
 (folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL',json.dumps(summaries),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder');main(p.parse_args().folder)
