Exactly two separate native diagnostic reproductions completed on 2026-10-25. They are not qualification evidence. The scheduled 22.3811920004664 ms timeout at tick 1175 remains counted.

Fixture: seed 3249061103, candidate slot 1, candidate kickoff false. Candidate SHA-256 `9d40fad4bc049e205f3131b591b5a14f4e99d6d2f02ebe6f8a754ea83e3b7fdd`; frozen opponent SHA-256 `7708f5d3b10202092f1fce73abfc61a5d7a61d91326d95d69cec872d4c7ba758`. Hashes were checked before and after each run. Config, native default roster, 2400 ticks and normal 20 ms deadline match the scheduled fixture. The original official `default_roster.native_match` driver, original `runner._decide`, and native decision/failure handling were retained. No policy, SDK, physics, formation, GC-control, timer, or affinity changes were made.

Both reproductions completed 2400 ticks, scored [0, 1] (candidate won), and recorded zero timeouts for either side. The original scheduled fixture also scored [0, 1]. Full public positions, velocities, cooldowns and controller-owned state at ticks 1173–1177 are in the JSON artifacts. Pre-decision state at tick 1175 matches between these two reproductions. The diagnostic wrapper observes state outside the timed call; its timing and passive GC callback are additional instrumentation.

Plain reproduction timing, milliseconds:

| Tick | Official `_decide` wall | Observer wall | Thread CPU |
|---|---:|---:|---:|
| 1173 | 0.079400 | 0.080572 | 0.080079 |
| 1174 | 0.092320 | 0.094834 | 0.093329 |
| 1175 | 1.280306 | 1.282179 | 1.281466 |
| 1176 | 1.145692 | 1.147535 | 1.146795 |
| 1177 | 0.094833 | 0.096106 | 0.095402 |

The plain reproduction's largest candidate decision was 3.452872 ms at tick 1080. Tick 1175 has only 0.000713 ms observer wall minus thread CPU; no sizable stall was witnessed there.

Actual mode at tick 1175 is opening: score 0–0, enemy-wall count 1, bait ineligible, and debug text `Pep positional control`. Ball position is (33.44396209716797, 0.16993185877799988), velocity is (4.30472469329834, -8.64366340637207), and only player 2 can kick. `_receive_plan` and `_pass_plan` remain None. cProfile confirms `act → _bait_counter_act → _opening_act → _choose_kick → _before_endwall`. There are no `_siege_goal` or `_siege_clearance_path` calls at this tick, so the independent wall-body forecast optimization does not target this witnessed workload.

The second run profiled only candidate tick 1175. Its official decision wall was 3.717090 ms, observer wall 3.724782 ms and thread CPU 3.721834 ms. Profiling overhead makes this unsuitable for timing qualification. The profile recorded 10810 function calls. Relevant inclusive costs:

| Function | Calls | Cumulative ms |
|---|---:|---:|
| `_controlled_touch` | 1 | 1.382441 |
| `_touch_path` | 16 | 1.019879 |
| `_search_links` | 1 | 0.890927 |
| `_link_option` | 6 | 0.864897 |
| `_shot_option` | 5 | 0.787551 |
| `_pass_race` | 6 | 0.691165 |
| `_runtime_intercept` | 30 | 0.360763 |

Inclusive costs overlap. These are witnessed local costs, not an explanation for the earlier timeout. Identical redundant computations were not established, and no policy optimization was made.

A passive `gc.callbacks` observer recorded collection generation, wall/thread CPU duration, collected counts, and active decision/tick without disabling or forcing collection. Neither reproduction collected at candidate tick 1175 or ticks 1173–1177. The largest observed collection was 1.1111 ms during loading outside a decision. This does not identify or exclude GC as a cause in the original run; instrumentation itself changes allocation schedules.

The original 22.381192 ms decision has no thread CPU or GC measurement. Its cause remains unresolved. Clean repeats do not establish an environmental cause or remove the raw miss. No further native loops ran after these two, and no future qualification seeds were accessed.

Artifacts: `diagnose.py`; `measure.json` and `profile.json` (full results, original scheduled row, per-decision timing, public/controller state, passive GC events); `profile.pstats`; and `profile.profile.txt`.
