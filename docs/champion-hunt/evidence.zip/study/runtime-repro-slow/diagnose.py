"""Two explicitly authorized native diagnostics, never qualification evidence.

Uses the unmodified official default-roster fixture loop and _decide. An
external observer measures wall/thread CPU; optional cProfile affects tick1175.
The normal 20ms deadline and native decision/failure handling stay enabled.
"""
import argparse
import cProfile
import hashlib
import gc
import io
import json
from pathlib import Path
import pstats
import sys
import time

SDK = Path('/workspace/work/exploit-lab/student-sdk')
ROOT = Path('/workspace/work/champion-hunt-20261025')
BENCH = Path('/workspace/work/replay-finishing-handoffs/tools/benchmarks')
sys.path.insert(0, str(SDK))
sys.path.insert(0, str(BENCH))
from soccer import runner
from default_roster import native_match

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def own_state(controller):
    keys = ('_bait_plan_score', '_bait_wall_ids', '_receive_plan', '_ready',
            '_restart_until', '_restart_owner', '_bank_receive', '_receive_aim',
            '_chaser', '_pass_plan', '_transition_active', '_runtime_queries')
    return {key: (len(getattr(controller,key)) if key == '_runtime_queries'
                  else getattr(controller,key,None)) for key in keys}

def snapshot(controller, obs):
    wall = sum(q.position[0] > obs.opponent_goal[0]-3.0 and
               abs(q.position[1]) < 9.0 for q in obs.opponents)
    lead = obs.score[0] - obs.score[1]
    eligible = lead == 1 or (lead == 0 and obs.score[0] > 0)
    player = lambda p: dict(id=p.id, position=p.position, velocity=p.velocity,
                           cooldown=p.kick_cooldown_ticks)
    return dict(tick=obs.tick, score=obs.score,
                ball=dict(position=obs.ball.position, velocity=obs.ball.velocity,
                          controlling_team=obs.ball.controlling_team),
                my_players=[player(p) for p in obs.my_players],
                opponents=[player(p) for p in obs.opponents],
                can_kick=[p.id for p in obs.my_players if obs.can_kick(p.id)],
                enemy_wall=wall, bait_eligible=eligible,
                base_mode='siege' if wall >= 4 else 'opening',
                own_state=own_state(controller))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('mode', choices=('measure','profile'))
    args=parser.parse_args()
    destination=Path(__file__).parent / (args.mode+'.json')
    if destination.exists():
        raise SystemExit('Refusing to replace diagnostic evidence')
    reg=json.loads((ROOT/'final-development/registration.json').read_text())
    candidate=ROOT/'final-development-sources/bait-slow/team.py'
    opponent=ROOT/'opponent/team.py'
    assert digest(candidate) == reg['candidates']['bait-slow']['sha256']
    assert digest(opponent) == reg['opponent']['sha256']
    original_row=next(json.loads(line) for line in
                      (ROOT/'final-development/matches.jsonl').read_text().splitlines()
                      if (lambda r: r['source']=='bait-slow' and
                          r['seed']==3249061103 and r['candidate_slot']==1 and
                          not r['candidate_takes_kickoff'])(json.loads(line)))
    records=[]
    profiles=[]
    original_decide=runner._decide
    candidate_controller=[None]
    observed_calls=[0]
    current_call=dict(tick=None,candidate=False,phase='outside_decision')
    gc_events=[]
    gc_starts={}
    def record_gc(phase,info):
        generation=info['generation']
        if phase=='start':
            gc_starts[generation]=(time.perf_counter_ns(),time.thread_time_ns(),dict(current_call))
        elif phase=='stop' and generation in gc_starts:
            wall,cpu,call=gc_starts.pop(generation)
            gc_events.append(dict(generation=generation,observer_wall_ms=(time.perf_counter_ns()-wall)/1e6,
                                  observer_thread_cpu_ms=(time.thread_time_ns()-cpu)/1e6,
                                  collected=info['collected'],uncollectable=info['uncollectable'],**call))
    def observed_decide(controller,obs):
        if candidate_controller[0] is None:
            if observed_calls[0]==0:
                observed_calls[0]+=1
                current_call.update(tick=obs.tick,candidate=False,phase='decision')
                try:
                    return original_decide(controller,obs)
                finally:
                    current_call['phase']='outside_decision'
            candidate_controller[0]=controller
        if controller is not candidate_controller[0]:
            current_call.update(tick=obs.tick,candidate=False,phase='decision')
            try:
                return original_decide(controller,obs)
            finally:
                current_call['phase']='outside_decision'
        current_call.update(tick=obs.tick,candidate=True,phase='outside_decision')
        capture=1173 <= obs.tick <= 1177
        before=snapshot(controller,obs) if capture else None
        prof=cProfile.Profile() if args.mode=='profile' and obs.tick==1175 else None
        if prof is not None:
            prof.enable()
        current_call['phase']='decision'
        wall_start=time.perf_counter_ns()
        cpu_start=time.thread_time_ns()
        answer=original_decide(controller,obs)
        cpu_end=time.thread_time_ns()
        wall_end=time.perf_counter_ns()
        current_call['phase']='outside_decision'
        if prof is not None:
            prof.disable()
            profiles.append(prof)
        action,official_ms,error=answer
        row=dict(tick=obs.tick,official_elapsed_ms=official_ms,
                 observer_wall_ms=(wall_end-wall_start)/1e6,
                 observer_thread_cpu_ms=(cpu_end-cpu_start)/1e6,
                 error=error,profiled=prof is not None)
        if capture:
            row['before']=before
            row['after_own_state']=own_state(controller)
            row['action_debug']=getattr(action,'debug',None)
            row['bait_overlay_allowed_after_core']=(before['bait_eligible'] and
                 before['enemy_wall']<4 and getattr(controller,'_receive_plan',None) is None)
        records.append(row)
        return answer
    runner._decide=observed_decide
    gc.callbacks.append(record_gc)
    try:
        result,telemetry,roster=native_match(str(candidate),str(opponent),
                                           3249061103,1,False,reg)
    finally:
        runner._decide=original_decide
        gc.callbacks.remove(record_gc)
    hashes=dict(candidate_sha256=digest(candidate),opponent_sha256=digest(opponent),
                harness_sha256=digest(__file__),driver_sha256=digest(BENCH/'default_roster.py'),
                sdk_runner_sha256=digest(SDK/'soccer/runner.py'))
    assert hashes['candidate_sha256']==reg['candidates']['bait-slow']['sha256']
    assert hashes['opponent_sha256']==reg['opponent']['sha256']
    output=dict(scope='separate native diagnostic; not qualification; original miss retained',
                mode=args.mode,seed=3249061103,candidate_slot=1,candidate_takes_kickoff=False,
                formation='native defaults; no initial_formation hooks',
                normal_deadline_ms=20,hashes=hashes,result=result,telemetry=telemetry,
                initial_roster=roster,original_scheduled_row=original_row,decisions=records,gc_events=gc_events)
    if profiles:
        profile_path=destination.with_suffix('.pstats')
        profiles[0].dump_stats(str(profile_path))
        stream=io.StringIO()
        stats=pstats.Stats(profiles[0],stream=stream)
        stats.sort_stats('cumulative').print_stats(60)
        destination.with_suffix('.profile.txt').write_text(stream.getvalue())
        output['profile_functions']=[dict(file=k[0],line=k[1],function=k[2],
                                         primitive_calls=v[0],total_calls=v[1],
                                         self_seconds=v[2],cumulative_seconds=v[3])
                                     for k,v in stats.stats.items()]
    destination.write_text(json.dumps(output,indent=2,default=repr)+'\n')
    print(json.dumps(dict(mode=args.mode,score=result['score'],ticks=result['ticks'],
                          candidate_timeouts=result['stats'][1]['policy_timeouts'],
                          opponent_timeouts=result['stats'][0]['policy_timeouts'],
                          window=[{k:v for k,v in r.items() if k not in
                                  ('before','after_own_state','action_debug')}
                                  for r in records if 1173<=r['tick']<=1177],
                          output=str(destination)),indent=2))

if __name__=='__main__':
    main()
