from pathlib import Path
import ast,hashlib,json
root=Path(__file__).resolve().parent
base=Path('/workspace/work/replay-finishing-handoffs/champions/v10.0/team.py').read_text()
anchor='''        if self.KEEPER_PRIORITY and self.PREDICTIVE_KEEPER and vx<-8.0'''
assert base.count(anchor)==1
sweep=base.replace(anchor,'''        # A central collection race can be lost before a visible shot exists.
        # Keep the normal line rather than rushing an opponent who arrives first.
        if sweep and not self._hunt_sweep_safe(keeper,bx,by,opponents):
            sweep=False
''' + anchor)
sweep+='''
    def _hunt_sweep_safe(self,keeper,bx,by,opponents):
        ours=self._eta(keeper,bx,by)
        theirs=min((self._eta(q,bx,by) for q in opponents),default=100.)
        return ours+.18<theirs
'''
assert base.count('keeper_x = self._left + 2.2')==1
assert base.count('keeper_y = by * 2.2 / max(3.0, bx - self._left)')==1
deep=base.replace('keeper_x = self._left + 2.2','keeper_x = self._left + 1.25').replace('keeper_y = by * 2.2 / max(3.0, bx - self._left)','keeper_y = by * 1.25 / max(3.0, bx - self._left)')
a=base.index('    def _cover_shape(');b=base.index('    def _bank_path(',a)
cover=base[a:b]
assert 'if secure or abs(by)<12.0 or pressure>5.0:' in cover
cover=cover.replace('if secure or abs(by)<12.0 or pressure>5.0:','if secure or pressure>5.0 or (abs(by)<12.0 and bx>=-10.0):')
assert 'if guard_id is None or guard_id==chaser[0]:' in cover
cover=cover.replace('if guard_id is None or guard_id==chaser[0]:','if (guard_id is None or guard_id==chaser[0]\n                or (self._receive_plan is not None and self._receive_plan[0]==guard_id)):')
central=base[:a]+cover+base[b:]
variants={'sweep-race-v10':sweep,'deep-line-v10':deep,'central-cover-v10':central}
manifest={}
for label,text in variants.items():
 text=text.replace('version = "10.0-titan10b-r"',f'version = "hunt-{label}"')
 ast.parse(text)
 p=root/label/'team.py';p.parent.mkdir(exist_ok=True);p.write_text(text)
 manifest[label]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':len(p.read_bytes())}
(root/'opening-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
