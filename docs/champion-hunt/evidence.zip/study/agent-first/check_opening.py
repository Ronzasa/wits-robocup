"""Reproduce the completed opening microchecks; not a native match benchmark."""
from pathlib import Path
from types import SimpleNamespace as NS
from soccer import SoccerEnv
from soccer.helpers import load_controller
ROOT=Path(__file__).resolve().parent
with SoccerEnv(config_path='/workspace/work/replay-finishing-handoffs/configs/default.toml') as env:
    field=env.field
    c=load_controller(str(ROOT/'sweep-race-v10/team.py'));c._setup(field)
    assert not c._hunt_sweep_safe((0,-47.8,0.,0.,0.),-43.,0.,[(5,-43.2,0.,0.,0.)])
    assert c._hunt_sweep_safe((0,-47.8,0.,0.,0.),-43.,0.,[(5,-20.,0.,0.,0.)])
    c=load_controller(str(ROOT/'central-cover-v10/team.py'));c._setup(field);c._shape_cover_id=1
    obs=NS(ball=NS(position=(-25.,8.),controlling_player=6,last_touch=6))
    friends=[(0,-48.,0.,0.,0.),(1,-28.,8.,0.,0.),(2,-26.,8.,0.,0.)]
    enemies=[(6,-24.,8.,0.,0.)]
    targets={1:(-28.,8.)}
    c._cover_shape(obs,friends,enemies,friends[2],{2:(.5,(-25.,8.))},.3,targets)
    assert abs(targets[1][1]-7.04)<1e-8
    c._receive_plan=(1,2,100);targets={1:(-28.,8.)}
    c._cover_shape(obs,friends,enemies,friends[2],{2:(.5,(-25.,8.))},.3,targets)
    assert targets[1]==(-28.,8.)
    obs=env.reset(seed=99,kickoff_team=1)['team_a']
    c=load_controller(str(ROOT/'deep-line-v10/team.py'))
    targets=[];old=c._move
    def inspect(p,target,friends=()):
        if p[0]==0:targets.append(target)
        return old(p,target,friends)
    c._move=inspect
    c.act(obs)
    assert any(abs(t[0]-(-48.75))<1e-8 for t in targets)
print('Opening microchecks passed; no complete native match was run.')
