from pathlib import Path
import ast,json,hashlib
root=Path(__file__).resolve().parent
uploaded=Path('/workspace/work/replay-finishing-handoffs/experiments/champion-candidate-review/uploaded/team.py').read_text()
helper='''
    def _hunt_edge_ready(self,p,bx,by,friends,opponents,movement=None):
        # A command is legal after movement, not just at observation time.
        # Only nominate new edge contacts with zero observed cooldown and
        # collision-free space for every other player's full next-step reach.
        if self._friend_cooldowns.get(p[0],1)!=0:return False
        if math.hypot(p[1]-bx,p[2]-by)>self._range+self._speed*self._dt:return False
        if movement is None:movement=self._move(p,(bx+.3,by))
        vx=p[3]*self._damping+movement[0]*self._acc
        vy=p[4]*self._damping+movement[1]*self._acc
        speed=math.hypot(vx,vy)
        if speed>self._speed:vx*=self._speed/speed;vy*=self._speed/speed
        x,y=p[1]+vx*self._dt,p[2]+vy*self._dt
        if abs(x)>=self._right-1.0 or abs(y)>=self._half_height-1.0:return False
        if math.hypot(x-bx,y-by)>=self._range-.03:return False
        safe=2.0+self._speed*self._dt+.05
        for q in friends:
            if q[0]!=p[0] and math.hypot(x-q[1],y-q[2])<safe:return False
        for q in opponents:
            if math.hypot(x-q[1],y-q[2])<safe:return False
        return True
'''
manifest={}
for label,source in [('edge-v1',uploaded),('edge-v10',Path('/workspace/work/replay-finishing-handoffs/champions/v10.0/team.py').read_text())]:
 source=source.replace('    LOCK_LEAD = 1\n','    LOCK_LEAD = 0\n').replace('    TRAIL_WALL = 2\n','    TRAIL_WALL = 0\n').replace('    WALL_BREAK = 1\n','    WALL_BREAK = 0\n')
 source=source.replace('if math.hypot(px - bx, py - by) >= self._range - 0.18:', 'if math.hypot(px - bx, py - by) >= self._range - 0.03:').replace('if distance_next < self._range - 0.18:', 'if distance_next < self._range - 0.03:')
 old='''        for p in friends:
            if obs.can_kick(p[0]):
                gap = math.hypot(p[1] - bx, p[2] - by)
'''
 new='''        for p in friends:
            if obs.can_kick(p[0]) or self._hunt_edge_ready(p,bx,by,friends,opponents):
                gap = math.hypot(p[1] - bx, p[2] - by)
'''
 assert source.count(old)==1,(label,source.count(old))
 source=source.replace(old,new)
 old='''                    if self._touch_movement is not None:
                        movement = self._touch_movement
                    self._receive_plan = None
'''
 new='''                    if self._touch_movement is not None:
                        movement = self._touch_movement
                    # New edge nominations are checked again against the
                    # movement actually chosen by the pass/touch/shot policy.
                    if not obs.can_kick(p[0]) and not self._hunt_edge_ready(p,bx,by,friends,opponents,movement):
                        kick = None
                    self._receive_plan = None
'''
 assert source.count(old)==1,(label,source.count(old))
 source=source.replace(old,new)+helper
 source=source.replace('version = "replay-finishing-handoffs-v1"',f'version = "hunt-{label}"').replace('version = "10.0-titan10b-r"',f'version = "hunt-{label}"')
 ast.parse(source)
 p=root/label/'team.py';p.parent.mkdir(exist_ok=True);p.write_text(source)
 manifest[label]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':len(p.read_bytes())}
(root/'edge-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
