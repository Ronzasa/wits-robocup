from pathlib import Path
import ast,hashlib,json
root=Path(__file__).resolve().parent
s=Path('/workspace/work/replay-finishing-handoffs/experiments/champion-candidate-review/uploaded/team.py').read_text()
s=s.replace('    LOCK_LEAD = 1\n','    LOCK_LEAD = 0\n').replace('    TRAIL_WALL = 2\n','    TRAIL_WALL = 0\n').replace('    WALL_BREAK = 1\n','    WALL_BREAK = 0\n')
s=s.replace('self._range - 0.18','self._range - 0.03').replace('self._range-0.18','self._range-0.03')
# Independent baseline: remove elaborate relay but retain verified ordinary passing.
a=s.index('    def _cooldown_handoff(');b=s.index('    def _choose_kick(',a)
simple=s[:a]+'''    def _cooldown_handoff(self,p,bx,by,vx,vy,friends,opponents,pressure):
        return None

'''+s[b:]
extra='''
    def _hunt_lane(self,p,bx,by,vx,vy,opponents,aim,bank=False):
        if bank:
            wall=(self._half_height-self._ball_radius)*(1.0 if by>=0.0 else -1.0)
            aim=wall+(wall-aim)/self._wall
        ux,uy=_unit(self._right-bx,aim-by)
        along=vx*ux+vy*uy
        perp=max(0.,vx*vx+vy*vy-along*along)
        if perp>=self._impulse*self._impulse:return None
        speed=min(self._ball_cap,along+math.sqrt(self._impulse*self._impulse-perp))
        if speed<12.:return None
        kick=self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
        if kick is None:return None
        move=self._move(p,(bx+.3,by))
        launch=self._carrier_contact(p,bx,by,*self._requested_velocity(vx,vy,kick),move)
        if launch is None:return None
        goal=self._goal_path(launch)
        if goal is None:return None
        path,(flight,gy,end_speed)=goal
        if flight>2.6 or end_speed<5.0:return None
        if self._shot_contact_margin(bx,by,launch,opponents,min(flight,.15))<-.02:return None
        states=[list(q) for q in opponents]
        ready=[self._enemy_cooldowns.get(q[0],0) for q in opponents]
        # No hidden observations: wall identity follows the public goal-line pattern.
        wall_mode=sum(q[1]>self._right-3.0 and abs(q[2])<9.0 for q in opponents)>=4
        x,y,sx,sy=launch
        oldx,oldy,oldvx,oldvy=bx,by,vx,vy
        margin=10.0
        count=min(52,max(1,int(math.ceil(flight*self._hz))))
        for n in range(1,count+1):
            if n>1:
                x+=sx*self._dt;y+=sy*self._dt
            bound=self._half_height-self._ball_radius
            if abs(y)>bound:
                side=1. if y>0 else -1.
                y=side*bound*2.-y;sy=-side*abs(sy)*self._wall
            for i,q in enumerate(states):
                if wall_mode:
                    tx=self._right-1.2
                    ty=(7-q[0])*2.8
                elif q[0]==opponents[0][0]:
                    tx=self._right-2.2
                    ty=oldy*2.2/max(3.,self._right-oldx)
                    if oldvx>8. and math.hypot(oldvx,oldvy)>=12.:
                        cross=(tx-oldx)/oldvx
                        if 0.<cross<1.25:ty=oldy+oldvy*cross
                    ty=_clip(ty,-self._mouth,self._mouth)
                else:
                    tx,ty=oldx,oldy
                mx,my=self._move(q,(tx,ty))
                q[3]=q[3]*self._damping+mx*self._acc
                q[4]=q[4]*self._damping+my*self._acc
                norm=math.hypot(q[3],q[4])
                if norm>self._speed:q[3]*=self._speed/norm;q[4]*=self._speed/norm
                q[1]=_clip(q[1]+q[3]*self._dt,self._left+1.,self._right-1.)
                q[2]=_clip(q[2]+q[4]*self._dt,-self._half_height+1.,self._half_height-1.)
                body=math.hypot(x-q[1],y-q[2])-self._contact
                if body<.05:return None
                if ready[i]<=n-1:
                    grab=math.hypot(oldx-q[1],oldy-q[2])-self._range
                    if grab<.06:return None
                    margin=min(margin,grab)
                margin=min(margin,body)
            if n>1:sx*=self._friction;sy*=self._friction
            oldx,oldy,oldvx,oldvy=x,y,sx,sy
        return 10.+min(margin,3.)-flight*.6+end_speed*.02,kick,move

    def _choose_kick(self,p,bx,by,vx,vy,friends,opponents):
        if p[0]!=0 and bx>6.0:
            best=None
            for aim in (-self._post_aim,-5.2,-2.5,0.,2.5,5.2,self._post_aim):
                option=self._hunt_lane(p,bx,by,vx,vy,opponents,aim)
                if option is not None and (best is None or option[0]>best[0]):best=option
            if HUNT_BANK and bx>20.0 and abs(by)>8.0:
                for aim in (-self._post_aim,0.,self._post_aim):
                    option=self._hunt_lane(p,bx,by,vx,vy,opponents,aim,True)
                    if option is not None and (best is None or option[0]>best[0]):best=option
            if best is not None:
                self._touch_movement=best[2]
                self._pass_plan=self._bank_plan=None
                self._relay_proposal=self._relay_fallback=None
                self._x_proposal=self._x_reception=None
                return best[1]
        return self._hunt_previous_kick(p,bx,by,vx,vy,friends,opponents)
'''
# Rename only the final ordinary dispatch, not lower-level policies.
base=s.replace('    def _choose_kick(self,p,bx,by,vx,vy,friends,opponents):','    def _hunt_previous_kick(self,p,bx,by,vx,vy,friends,opponents):')
variants={'direct-no-relay':simple,'rollout-shot':base+extra.replace('HUNT_BANK','False'),'rollout-bank':base+extra.replace('HUNT_BANK','True')}
manifest={}
for name,text in variants.items():
 text=text.replace('version = "replay-finishing-handoffs-v1"','version = "hunt-first-'+name+'"')
 ast.parse(text)
 p=root/name/'team.py';p.parent.mkdir(exist_ok=True);p.write_text(text)
 manifest[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':len(p.read_bytes())}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
