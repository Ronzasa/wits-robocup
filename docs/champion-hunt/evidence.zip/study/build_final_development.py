import ast,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
base=(ROOT/'agent-clearance/clearance-counter-scored-tie-bait/team.py').read_text()
items={}
def freeze(name,text):
 ast.parse(text)
 p=ROOT/'final-development-sources'/name/'team.py';p.parent.mkdir(parents=True,exist_ok=True)
 assert not p.exists();p.write_text(text)
 items[name]=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
# Isolate known fixed-course kick/body sequence; unknown side retains both.
text=base.replace('        self._ready = False\n','        self._ready = False\n        self._siege_first_order = None\n',1)
text=text.replace('        obs=self._siege_obs\n        opponents=obs.opponents\n','        obs=self._siege_obs\n        orders=(False,True) if self._siege_first_order is None else (self._siege_first_order,)\n        opponents=obs.opponents\n',1)
text=text.replace('                              for order in (False,True)]\n','                              for order in orders]\n',1)
text=text.replace('        self._siege_obs=obs\n','        self._siege_obs=obs\n        side=getattr(obs,"side",None)\n        self._siege_first_order=False if side==0 else True if side==1 else None\n',1)
assert text!=base and 'for order in orders' in text
freeze('bait-order',text)
# One carry-speed parameter, leaving the goal solver and bait unchanged.
node=next(n for n in ast.walk(ast.parse(base)) if isinstance(n,ast.FunctionDef) and n.name=='_siege_act')
method=''.join(base.splitlines(True)[node.lineno-1:node.end_lineno])
assert '10.5' in method
freeze('bait-slow',base.replace(method,method.replace('10.5','7.5')))
# Selective extra chase only in the weak normal phase; never dismantle bait.
pack=(ROOT/'parent-selective-pack/team.py').read_text()
node=next(n for n in ast.walk(ast.parse(pack)) if isinstance(n,ast.FunctionDef) and n.name=='act')
method=''.join(pack.splitlines(True)[node.lineno-1:node.end_lineno])
method=method.replace('self._press_original_act(obs)','self._selective_original_act(obs)')
method=method.replace('        bx,by=obs.ball.position\n','        lead=obs.score[0]-obs.score[1]\n        if lead==1 or lead==0 and obs.score[0]>0:\n            return actions\n        bx,by=obs.ball.position\n',1)
text=base.replace('    def act(self, obs):','    def _selective_original_act(self, obs):',1)+'\n'+method+'\n'
freeze('bait-selective',text)
(ROOT/'final-development-sources/manifest.json').write_text(json.dumps(items,indent=2)+'\n')
print('Final three isolated descendants frozen. Selection uses league points and reliability on all8 development seeds.')
