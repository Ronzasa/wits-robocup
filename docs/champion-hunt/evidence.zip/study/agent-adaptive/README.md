The frozen candidate is `v3/team.py:AdaptiveChampion`.

SHA-256: `36024c0458babd2f543ae495ef9ab433eef5625340bb0fb0df5444beca4e79ca`

Source size: 238151 bytes, below the 262144-byte limit. Its only imports are
math and the official soccer SDK. It defines one SDK controller and embeds
the hash-pinned uploaded fallback and specialist as plain helper classes.
Build-time AST checks preserve their complete bodies after docstring/comment
removal, class renaming, and removal of the SDK base. Shared `_clip`/`_unit`
functions are AST-identical in both original sources.

The gate recognizes four of the five frozen enemy slots, including keeper
ID 5 at y=5.6, for six consecutive public observation ticks. Inactive actions
are returned directly from the fallback. After confirmation it calls the
fallback first and preserves its selected kick or same-score, unexpired
receive contract. It then resets and switches to the specialist on the
current observation and latches until reset. It seeds the specialist's last
score from the current public observation before that first act, allowing
the first post-siege goal to initialize opponent kickoff protection.
The specialist never acts
before switching. Intake formation always delegates to the fallback.

All 18 synthetic tests pass, including 38 exact inactive action comparisons,
three contract types, expiry/score boundaries, kick deferral, detector false
positives and sequence breaks, reset/latch/call counts, and full specialist
actions in both corners at goal widths 14 and 18. The full actual-helper
0–1 wall activation to 1–1 equalizer regression confirms the opponent's
60-tick kickoff protection and outward movement; the frozen v2 fails the
same causal check. The independent audit also passes. No native matches or
qualification seeds were used by this agent.

Reproduce the static build check and synthetic tests:

```sh
python /workspace/work/champion-hunt-20261025/agent-adaptive/v3/build_adaptive.py --check
python /workspace/work/champion-hunt-20261025/agent-adaptive/v3/test_adaptive.py
```

The root-level team/build/manifest/test files retain the earlier working
revision (SHA `2df5a7ca434379e46d08bc1e34048ecc3838a5fd9ed90d20b41fdc2f045c2189`)
as superseded evidence. Revision 2 fixes receive-plan starvation caused by
expired fields that the fallback's early wall branch can retain. The frozen
v2 artifacts are also preserved. Revision 3 adds only the public score
bootstrap and version metadata; the complete frozen helpers remain exact.
No frozen input, main source, champion source, SDK, or opponent source was
edited.
