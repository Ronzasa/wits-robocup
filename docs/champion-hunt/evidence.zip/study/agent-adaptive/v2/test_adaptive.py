"""Synthetic public-observation regression checks; never runs native matches."""
import ast
import importlib.util
import math
from pathlib import Path
import sys
from types import SimpleNamespace as N
import unittest


HERE = Path(__file__).resolve().parent
SDK = Path('/workspace/wits-robocup/student-sdk')
sys.path.insert(0, str(SDK))
from soccer import PlayerAction, TeamAction, TeamController


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


candidate = load(HERE / 'team.py', 'adaptive_under_test')
frozen_fallback = load('/workspace/work/champion-hunt-20261025/opponent/team.py', 'frozen_fallback_reference')
frozen_specialist = load(
    '/workspace/work/replay-finishing-handoffs/experiments/champion-hunt/team.py',
    'frozen_specialist_reference',
)


def field(goal_width=14.0):
    return N(width=100.0, height=60.0, my_goal=(-50.0, 0.0),
             opponent_goal=(50.0, 0.0), simulation_hz=20.0,
             max_speed=8.0, acceleration=20.0, ball_friction=0.985,
             kick_impulse=22.0, kick_range=2.2, goal_width=goal_width,
             centre_circle_radius=8.0, ball_radius=0.45, player_radius=1.0)


def player(pid, pos, vel=(0.0, 0.0), cooldown=0):
    return N(id=pid, position=pos, velocity=vel, kick_cooldown_ticks=cooldown,
             has_control=False, facing=(1.0, 0.0))


def observation(tick, wall=False, side=1, ball=None, score=(0, 0),
                can_kick=(), goal_width=14.0):
    f = field(goal_width)
    mine = [player(i, p) for i, p in enumerate(
        [(-47.0, 0.0), (-8.0, 0.0), (10.0, -8.0), (0.5, 0.0), (14.0, 8.0)])]
    if wall:
        enemies = [player(i, (48.8, (7 - i) * 2.8)) for i in range(5, 10)]
    else:
        enemies = [player(i + 5, p) for i, p in enumerate(
            [(47.0, 0.0), (24.0, 20.0), (28.0, -20.0), (35.0, 12.0), (36.0, -12.0)])]
    if ball is None:
        ball = (6.0, side * 4.0, 3.0, side * -1.0)
    bx, by, vx, vy = ball
    b = N(position=(bx, by), velocity=(vx, vy), controlling_player=None,
          controlling_team=None, last_touch=None)
    return N(tick=tick, max_ticks=2400, time_remaining=(2400 - tick) / 2400,
             score=score, field=f, my_goal=f.my_goal, opponent_goal=f.opponent_goal,
             my_players=mine, opponents=enemies, ball=b, team=0, side=0,
             phase='ATTACK', events=[], can_kick=lambda pid: pid in can_kick)


def snapshot(action):
    return ({pid: (tuple(a.movement), None if a.kick_direction is None
                   else tuple(a.kick_direction), a.kick_power)
             for pid, a in action.players.items()}, action.debug)


def assert_valid(test, action):
    test.assertEqual(set(action.players), set(range(5)))
    for a in action.players.values():
        test.assertTrue(all(math.isfinite(v) for v in a.movement))
        test.assertLessEqual(math.hypot(*a.movement), 1.00000001)
        test.assertGreaterEqual(a.kick_power, 0.0)
        test.assertLessEqual(a.kick_power, 1.0)
        if a.kick_direction is not None:
            test.assertTrue(all(math.isfinite(v) for v in a.kick_direction))


def marker_action(value, kick=False):
    return TeamAction({i: PlayerAction(movement=(value, 0.0),
                                     kick_direction=(1.0, 0.0) if kick and i == 4 else None,
                                     kick_power=1.0 if kick and i == 4 else 0.0)
                       for i in range(5)}, debug={'text': str(value)})


class SpyPolicy:
    def __init__(self, value):
        self.value = value
        self.calls = []
        self.resets = []
        self.hook = None
        self._receive_plan = None
        self._relay_receive = None
        self._x_reception = None
        self._last_score = None

    def reset(self, seed):
        self.resets.append(seed)
        self._receive_plan = self._relay_receive = self._x_reception = None
        self._last_score = None

    def act(self, obs):
        self.calls.append(obs.tick)
        self._last_score = tuple(obs.score)
        if self.hook is not None:
            return self.hook(obs)
        return marker_action(self.value)

    def initial_formation(self, f):
        return [(self.value, f.goal_width)] * 5


def spied():
    c = candidate.AdaptiveChampion()
    c._fallback = SpyPolicy(0.25)
    c._specialist = SpyPolicy(0.75)
    c.reset(123456)
    return c


class AdaptiveTests(unittest.TestCase):
    def test_source_contract(self):
        source = (HERE / 'team.py').read_bytes()
        self.assertLessEqual(len(source), 256 * 1024)
        tree = ast.parse(source)
        for node in tree.body:
            if isinstance(node, ast.Import):
                self.assertEqual([a.name for a in node.names], ['math'])
            if isinstance(node, ast.ImportFrom):
                self.assertEqual(node.module, 'soccer')
        classes = [v for v in vars(candidate).values()
                   if isinstance(v, type) and v.__module__ == candidate.__name__
                   and issubclass(v, TeamController)]
        self.assertEqual(classes, [candidate.AdaptiveChampion])
        self.assertFalse(issubclass(candidate._FallbackPolicy, TeamController))
        self.assertFalse(issubclass(candidate._SpecialistPolicy, TeamController))

    def test_initial_formation_exact(self):
        c = candidate.AdaptiveChampion()
        reference = frozen_fallback.Guardiola2011()
        for width in (14.0, 18.0):
            self.assertEqual(c.initial_formation(field(width)),
                             reference.initial_formation(field(width)))
        spy = spied()
        self.assertEqual(spy.initial_formation(field()), [(0.25, 14.0)] * 5)

    def test_inactive_full_actions_equal_original(self):
        c = candidate.AdaptiveChampion()
        reference = frozen_fallback.Guardiola2011()
        c.reset(700)
        reference.reset(700)
        for tick in range(18):
            score = (0, 0) if tick < 6 else (1, 0) if tick < 12 else (0, 1)
            ball = (1.0 + tick * 0.7, (-1) ** tick * 4.0, 3.0, 0.5)
            obs = observation(tick + 200, ball=ball, score=score)
            actual = c.act(obs)
            expected = reference.act(obs)
            self.assertEqual(snapshot(actual), snapshot(expected), tick)
            self.assertFalse(c._active)
            assert_valid(self, actual)

    def test_inactive_full_kicks_and_receive_plan_equal_original(self):
        kicks = 0
        contracts = 0
        for kicker, ball, score in (
                (3, (1.0, 0.0, 0.0, 0.0), (0, 0)),
                (4, (14.5, 8.0, 0.0, 0.0), (0, 0)),
                (4, (14.5, 8.0, 2.0, -1.0), (0, 1)),
                (4, (14.5, 8.0, -1.0, 2.0), (1, 0)),
                (0, (-46.5, 0.0, 0.0, 0.0), (0, 0))):
            c = candidate.AdaptiveChampion()
            reference = frozen_fallback.Guardiola2011()
            c.reset(701)
            reference.reset(701)
            for tick in range(200, 204):
                obs = observation(tick, ball=ball, score=score, can_kick=(kicker,))
                obs.ball.controlling_player = kicker
                obs.ball.controlling_team = 0
                obs.ball.last_touch = kicker
                actual = c.act(obs)
                expected = reference.act(obs)
                self.assertEqual(snapshot(actual), snapshot(expected), (kicker, score, tick))
                self.assertFalse(c._active)
                assert_valid(self, actual)
                kicks += sum(a.kick_direction is not None for a in actual.players.values())
                contracts += c._fallback._receive_plan is not None
        self.assertGreater(kicks, 0)
        self.assertGreater(contracts, 0)

    def test_six_ticks_then_one_caller_and_latch(self):
        c = spied()
        for tick in range(5):
            actual = c.act(observation(tick, wall=True))
            self.assertEqual(snapshot(actual), snapshot(marker_action(0.25)))
            self.assertFalse(c._active)
        self.assertEqual(c._specialist.calls, [])
        actual = c.act(observation(5, wall=True))
        self.assertTrue(c._active)
        self.assertEqual(snapshot(actual), snapshot(marker_action(0.75)))
        self.assertEqual(c._fallback.calls, list(range(6)))
        self.assertEqual(c._specialist.calls, [5])
        self.assertEqual(c._specialist.resets, [123456, 123456])
        c.act(observation(6, wall=False))
        self.assertTrue(c._active)
        self.assertEqual(c._fallback.calls, list(range(6)))
        self.assertEqual(c._specialist.calls, [5, 6])

    def test_public_signature_rejects_nearby_generic_shapes(self):
        def keeper_center(obs):
            obs.opponents[0].position = (48.8, 0.0)

        def only_three(obs):
            obs.opponents[3].position = (35.0, 10.0)
            obs.opponents[4].position = (35.0, -10.0)

        def wrong_slot_ids(obs):
            for p in obs.opponents:
                p.id = 14 - p.id

        def compact_middle(obs):
            for i, p in enumerate(obs.opponents):
                p.position = (48.8, (i - 2) * 1.4)

        def x_boundary(obs):
            for p in obs.opponents:
                p.position = (49.7, p.position[1])

        def y_boundary(obs):
            for p in obs.opponents:
                p.position = (p.position[0], p.position[1] + 1.0)

        for change in (keeper_center, only_three, wrong_slot_ids,
                       compact_middle, x_boundary, y_boundary):
            c = spied()
            for tick in range(9):
                obs = observation(tick, wall=True)
                change(obs)
                c.act(obs)
            self.assertFalse(c._active, change.__name__)
            self.assertEqual(c._specialist.calls, [], change.__name__)

    def test_four_matching_including_keeper_is_sufficient(self):
        c = spied()
        for tick in range(6):
            obs = observation(tick, wall=True)
            obs.opponents[4].position = (20.0, -14.0)
            c.act(obs)
        self.assertTrue(c._active)

    def test_signature_break_restarts_confirmation(self):
        c = spied()
        for tick in range(4):
            c.act(observation(tick, wall=True))
        c.act(observation(4, wall=False))
        for tick in range(5, 10):
            c.act(observation(tick, wall=True))
            self.assertFalse(c._active)
        c.act(observation(10, wall=True))
        self.assertTrue(c._active)

    def test_repeated_and_skipped_ticks_restart_confirmation(self):
        for bad_tick in (3, 5):
            c = spied()
            for tick in range(4):
                c.act(observation(tick, wall=True))
            c.act(observation(bad_tick, wall=True))
            self.assertFalse(c._active)
            self.assertEqual(c._wall_ticks, 1)
            for tick in range(bad_tick + 1, bad_tick + 5):
                c.act(observation(tick, wall=True))
                self.assertFalse(c._active)
            c.act(observation(bad_tick + 5, wall=True))
            self.assertTrue(c._active)

    def test_receive_contracts_defer_until_after_reverification(self):
        for plan_name in ('_receive_plan', '_relay_receive', '_x_reception'):
            c = spied()
            setattr(c._fallback, plan_name, (3, 4, 100))
            for tick in range(6):
                c.act(observation(tick, wall=True))
            self.assertFalse(c._active, plan_name)
            self.assertEqual(c._specialist.calls, [])

            def clear_plan(obs):
                setattr(c._fallback, plan_name, None)
                return marker_action(0.25)

            c._fallback.hook = clear_plan
            c.act(observation(6, wall=True))
            self.assertTrue(c._active, plan_name)
            self.assertEqual(c._fallback.calls, list(range(7)))
            self.assertEqual(c._specialist.calls, [6])

    def test_new_contract_selected_this_frame_defers(self):
        c = spied()

        def select_plan(obs):
            if obs.tick == 5:
                c._fallback._receive_plan = (3, 4, 100)
            return marker_action(0.25)

        c._fallback.hook = select_plan
        for tick in range(6):
            c.act(observation(tick, wall=True))
        self.assertFalse(c._active)
        self.assertEqual(c._specialist.calls, [])

    def test_expired_contracts_allow_activation(self):
        for plan_name in ('_receive_plan', '_relay_receive', '_x_reception'):
            c = spied()
            setattr(c._fallback, plan_name, (3, 4, 4))
            for tick in range(6):
                c.act(observation(tick, wall=True))
            self.assertTrue(c._active, plan_name)
            self.assertEqual(c._fallback.calls, list(range(6)))
            self.assertEqual(c._specialist.calls, [5])

    def test_old_score_contracts_allow_activation(self):
        for plan_name in ('_receive_plan', '_relay_receive', '_x_reception'):
            c = spied()
            setattr(c._fallback, plan_name, (3, 4, 100))

            def old_score(obs):
                c._fallback._last_score = (1, 0)
                return marker_action(0.25)

            c._fallback.hook = old_score
            for tick in range(6):
                c.act(observation(tick, wall=True, score=(0, 0)))
            self.assertTrue(c._active, plan_name)
            self.assertEqual(c._fallback.calls, list(range(6)))
            self.assertEqual(c._specialist.calls, [5])

    def test_expiry_tick_itself_is_live_then_expires(self):
        for plan_name in ('_receive_plan', '_relay_receive', '_x_reception'):
            c = spied()
            setattr(c._fallback, plan_name, (3, 4, 5))
            for tick in range(6):
                actual = c.act(observation(tick, wall=True))
            self.assertFalse(c._active, plan_name)
            self.assertEqual(snapshot(actual), snapshot(marker_action(0.25)))
            self.assertEqual(c._specialist.calls, [])
            c.act(observation(6, wall=True))
            self.assertTrue(c._active, plan_name)
            self.assertEqual(c._fallback.calls, list(range(7)))
            self.assertEqual(c._specialist.calls, [6])

    def test_selected_kick_defers_whole_action(self):
        c = spied()
        c._fallback.hook = lambda obs: marker_action(0.25, kick=obs.tick == 5)
        for tick in range(5):
            c.act(observation(tick, wall=True))
        selected = c.act(observation(5, wall=True))
        self.assertFalse(c._active)
        self.assertEqual(snapshot(selected), snapshot(marker_action(0.25, kick=True)))
        self.assertEqual(c._specialist.calls, [])
        c.act(observation(6, wall=True))
        self.assertTrue(c._active)

    def test_reset_clears_latch_and_detector_and_passes_seed(self):
        c = spied()
        for tick in range(6):
            c.act(observation(tick, wall=True))
        self.assertTrue(c._active)
        c.reset(987654)
        self.assertFalse(c._active)
        self.assertEqual(c._wall_ticks, 0)
        self.assertEqual(c._fallback.resets[-1], 987654)
        self.assertEqual(c._specialist.resets[-1], 987654)
        before = len(c._specialist.calls)
        for tick in range(5):
            c.act(observation(tick, wall=True))
            self.assertFalse(c._active)
        self.assertEqual(len(c._specialist.calls), before)

    def test_full_cold_specialist_actions_both_corners_and_goal_half(self):
        for sign in (-1, 1):
            for goal_width in (14.0, 18.0):
                c = candidate.AdaptiveChampion()
                c.reset(998)
                expected = frozen_specialist.Guardiola2011()
                expected.reset(998)
                for tick in range(5):
                    obs = observation(tick + 300, wall=True, goal_width=goal_width,
                                      ball=(44.0, sign * (goal_width / 2 + 2), 0.0, 0.0))
                    c.act(obs)
                    self.assertFalse(c._active)
                obs = observation(305, wall=True, goal_width=goal_width,
                                  ball=(44.0, sign * (goal_width / 2 + 2), 0.0, 0.0))
                actual = c.act(obs)
                reference = expected.act(obs)
                self.assertTrue(c._active)
                self.assertEqual(c._specialist._goal_half, goal_width / 2)
                self.assertEqual(snapshot(actual), snapshot(reference))
                assert_valid(self, actual)
                for tick in (306, 307):
                    obs = observation(tick, wall=True, goal_width=goal_width,
                                      ball=(45.0, sign * (goal_width / 2 + 1), 1.0, 0.0))
                    actual = c.act(obs)
                    self.assertEqual(snapshot(actual), snapshot(expected.act(obs)))
                    assert_valid(self, actual)


if __name__ == '__main__':
    unittest.main(verbosity=2)
