#!/usr/bin/env python3
"""Reproducibly embed two frozen policies and a public geometry handoff gate.

This build tool may use the standard library; generated team.py imports only
math and the official soccer SDK. No engine or match data is accessed here.
"""

import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
INPUTS = {
    "fallback": (
        Path("/workspace/work/champion-hunt-20261025/opponent/team.py"),
        "7708f5d3b10202092f1fce73abfc61a5d7a61d91326d95d69cec872d4c7ba758",
        "_FallbackPolicy",
    ),
    "specialist": (
        Path("/workspace/work/replay-finishing-handoffs/experiments/champion-hunt/team.py"),
        "05d9ce27b4e6f54db44a3e5c8b6a929e0dbce0dcf00b5a0b69f9e6ebf6681196",
        "_SpecialistPolicy",
    ),
}

WRAPPER = '''
class AdaptiveChampion(TeamController):
    name = "Public wall adaptive champion"
    version = "public-five-slot-gate-v1"

    def __init__(self):
        self._fallback = _FallbackPolicy()
        self._specialist = _SpecialistPolicy()
        self.reset(0)

    def reset(self, seed):
        self._seed = seed
        self._fallback.reset(seed)
        self._specialist.reset(seed)
        self._active = False
        self._wall_confirmed = False
        self._wall_ticks = 0
        self._wall_last_tick = None

    def initial_formation(self, field):
        return self._fallback.initial_formation(field)

    def _observe_wall(self, obs):
        if self._wall_confirmed:
            return
        target_x = obs.opponent_goal[0] - 1.2
        matches = 0
        keeper_matches = False
        for opponent in obs.opponents:
            pid = opponent.id
            if 5 <= pid <= 9:
                x, y = opponent.position
                if abs(x - target_x) < 0.9 and abs(y - (7 - pid) * 2.8) < 1.0:
                    matches += 1
                    if pid == 5:
                        keeper_matches = True
        tick = obs.tick
        if matches >= 4 and keeper_matches:
            if self._wall_last_tick is None or tick != self._wall_last_tick + 1:
                self._wall_ticks = 1
            else:
                self._wall_ticks += 1
            self._wall_last_tick = tick
            if self._wall_ticks >= 6:
                self._wall_confirmed = True
        else:
            self._wall_ticks = 0
            self._wall_last_tick = None

    def act(self, obs):
        if self._active:
            return self._specialist.act(obs)
        actions = self._fallback.act(obs)
        self._observe_wall(obs)
        if not self._wall_confirmed:
            return actions
        if (self._fallback._receive_plan is not None
                or self._fallback._relay_receive is not None
                or self._fallback._x_reception is not None):
            return actions
        if any(action.kick_direction is not None for action in actions.players.values()):
            return actions
        self._specialist.reset(self._seed)
        self._active = True
        return self._specialist.act(obs)
'''


def dump(node):
    return ast.dump(node, include_attributes=False)


class StripDocstrings(ast.NodeTransformer):
    def _visit(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return node

    visit_Module = _visit
    visit_ClassDef = _visit
    visit_FunctionDef = _visit
    visit_AsyncFunctionDef = _visit


def read_policy(label):
    path, expected, helper_name = INPUTS[label]
    source = path.read_bytes()
    digest = hashlib.sha256(source).hexdigest()
    assert digest == expected, (label, "frozen input hash changed", digest)
    module = StripDocstrings().visit(ast.parse(source))
    classes = [n for n in module.body if isinstance(n, ast.ClassDef)]
    functions = [n for n in module.body if isinstance(n, ast.FunctionDef)]
    assert len(classes) == 1 and {n.name for n in functions} == {"_clip", "_unit"}
    policy = classes[0]
    original_name = policy.name
    assert len(policy.bases) == 1 and dump(policy.bases[0]) == dump(ast.Name(id="TeamController", ctx=ast.Load()))
    assert not policy.keywords and not policy.decorator_list
    assert not any(isinstance(n, ast.Name) and n.id == original_name for n in ast.walk(policy))
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                   and n.func.id == "super" for n in ast.walk(policy))
    methods = {n.name for n in policy.body if isinstance(n, ast.FunctionDef)}
    self_calls = {n.func.attr for n in ast.walk(policy)
                  if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                  and isinstance(n.func.value, ast.Name) and n.func.value.id == "self"}
    assert self_calls <= methods, (label, "inherited calls require explicit SDK forwarding", self_calls - methods)
    policy.name = helper_name
    policy.bases = []
    record = {
        "path": str(path), "sha256": digest, "bytes": len(source),
        "helper": helper_name, "helper_ast_sha256": hashlib.sha256(dump(policy).encode()).hexdigest(),
        "normalization": "AST unparse; remove docstrings/comments; rename class; remove TeamController base only",
    }
    return functions, policy, record


def build():
    fallback_functions, fallback, fallback_record = read_policy("fallback")
    specialist_functions, specialist, specialist_record = read_policy("specialist")
    shared = {node.name: node for node in fallback_functions}
    assert all(dump(node) == dump(shared[node.name]) for node in specialist_functions), "shared helpers differ"
    imports = ast.parse("import math\nfrom soccer import PlayerAction, TeamAction, TeamController\n").body
    module = ast.Module(body=imports + fallback_functions + [fallback, specialist] + ast.parse(WRAPPER).body, type_ignores=[])
    ast.fix_missing_locations(module)
    source = (ast.unparse(module) + "\n").encode()
    assert len(source) <= 256 * 1024, len(source)
    reparsed = ast.parse(source)
    assert dump(reparsed) == dump(module), "unparse changed policy AST"
    actual_controllers = [n.name for n in reparsed.body if isinstance(n, ast.ClassDef)
                          and any(isinstance(b, ast.Name) and b.id == "TeamController" for b in n.bases)]
    assert actual_controllers == ["AdaptiveChampion"], actual_controllers
    assert len([n for n in ast.walk(reparsed) if isinstance(n, (ast.Import, ast.ImportFrom))]) == 2
    for policy in [fallback, specialist]:
        reparsed_policy = next(n for n in reparsed.body if isinstance(n, ast.ClassDef) and n.name == policy.name)
        assert dump(reparsed_policy) == dump(policy), policy.name
    manifest = {
        "candidate": "adaptive-public-five-slot-v1",
        "generation": 2,
        "source": "team.py", "controller": "AdaptiveChampion",
        "sha256": hashlib.sha256(source).hexdigest(), "source_bytes": len(source),
        "limit_bytes": 256 * 1024,
        "frozen_inputs": {"fallback": fallback_record, "specialist": specialist_record},
        "shared_helpers": {name: "AST-identical in both frozen inputs" for name in shared},
        "imports": ["math", "soccer.PlayerAction", "soccer.TeamAction", "soccer.TeamController"],
        "controller_count": 1, "embedded_policy_bases": [],
        "detector": {
            "data": "public opponent IDs/positions, opponent goal, sequential ticks only",
            "target_x": "opponent_goal.x - 1.2", "target_y": "(7 - opponent_id) * 2.8",
            "ids": [5, 6, 7, 8, 9], "minimum_matching_slots": 4,
            "required_keeper_id": 5, "keeper_target_y": 5.6,
            "strict_x_tolerance": 0.9, "strict_y_tolerance": 1.0,
            "required_consecutive_ticks": 6, "confirmed_latched_until_reset": True,
        },
        "handoff": {
            "fallback_act_first": True,
            "defer_for_non_none": ["_receive_plan", "_relay_receive", "_x_reception"],
            "defer_for_any_selected_kick_direction": True,
            "specialist_shadow_run": False, "specialist_reset_on_switch_with_stored_seed": True,
            "specialist_latched_until_reset": True,
            "initial_formation": "unchanged fallback delegation",
        },
        "evidence_policy": {
            "tests": "synthetic only; no native match loops in this work directory",
            "new_sealed_qualification": "reserved to central runner; never accessed by builder/tests",
            "new_source_after_first_qualification_failures": True,
            "qualification_claimed": False,
        },
    }
    return source, (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="verify existing frozen outputs without rewriting")
    args = parser.parse_args()
    source, manifest = build()
    for name, payload in [("team.py", source), ("manifest.json", manifest)]:
        path = ROOT / name
        if args.check:
            assert path.read_bytes() == payload, (name, "differs from deterministic build")
        else:
            path.write_bytes(payload)
    print(json.dumps({"sha256": hashlib.sha256(source).hexdigest(), "source_bytes": len(source), "check": args.check}))


if __name__ == "__main__":
    main()
