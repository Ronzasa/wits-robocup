import ast
from pathlib import Path
ROOT=Path(__file__).resolve().parent
base=(ROOT/'agent-clearance/clearance-counter-scored-tie-bait/team.py').read_text()
common='''
    def act(self, obs):
        actions=self._clear_guard_original_act(obs)
        lead=obs.score[0]-obs.score[1]
        if (not (lead==1 or lead==0 and obs.score[0]>0)
                or self._receive_plan is not None
                or self._bait_wall_ids is None
                or obs.tick<self._restart_until and self._restart_owner==1):
            return actions
        bx,by=obs.ball.position
        vx,vy=obs.ball.velocity
        if bx>self._left+12. or vx>=-8.:
            return actions
        gy=by+vy*(self._left-bx)/vx
        if abs(gy)>self._goal_half+.2:
            return actions
        views=list(obs.my_players)
        ready=[]
        for p in views:
            if p.id not in self._bait_wall_ids or not obs.can_kick(p.id):continue
            move=actions.players[p.id].movement
            px=p.velocity[0]*self._damping+move[0]*self._acc
            py=p.velocity[1]*self._damping+move[1]*self._acc
            speed=math.hypot(px,py)
            if speed>self._speed:px*=self._speed/speed;py*=self._speed/speed
            x,y=p.position[0]+px*self._dt,p.position[1]+py*self._dt
            if math.hypot(x-bx,y-by)>self._range-.12:continue
            if any(q.id!=p.id and math.hypot(x-q.position[0],y-q.position[1])<2.45
                   for q in views+list(obs.opponents)):continue
            ready.append(p.id)
MODE_BRANCH
        return actions
'''
branches={
'stack-clears':'''        if len(ready)>=2:
            for pid in ready:
                old=actions.players[pid]
                actions.set(pid,PlayerAction(movement=old.movement,kick_direction=(1.,0.),kick_power=1.))''',
'outward-clears':'''        if len(ready)==1 and abs(by)>5.0:
            pid=ready[0]
            direction=_unit(.15,1. if by>0 else -1.)
            nx,ny=self._requested_velocity(vx,vy,(direction,1.))
            hit_y=by+ny*(self._left+self._ball_radius-bx)/nx if nx<-.1 else 0.
            if nx<-.1 and abs(hit_y)>self._goal_half+.25:
                old=actions.players[pid]
                actions.set(pid,PlayerAction(movement=old.movement,kick_direction=direction,kick_power=1.))'''}
for name,branch in branches.items():
 text=base.replace('    def act(self, obs):','    def _clear_guard_original_act(self, obs):',1)+common.replace('MODE_BRANCH',branch)
 p=ROOT/'parent-clear-guard'/name/'team.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);ast.parse(text)
print('Two narrow, isolated emergency clearance variants frozen.')
