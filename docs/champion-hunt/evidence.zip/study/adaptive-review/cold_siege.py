"""Actual helper control-flow regression with public observations and action stubs."""

import ast
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace as N

ROOT = Path(__file__).resolve().parent.parent


class PlayerAction:
    def __init__(self, movement=(0., 0.), kick_direction=None, kick_power=0.):
        self.movement, self.kick_direction, self.kick_power = movement, kick_direction, kick_power


class TeamAction:
    def __init__(self, players=None, debug=None):
        self.players, self.debug = players or {}, debug

    def set(self, pid, action):
        self.players[pid] = action


def load(path):
    tree = ast.parse(path.read_bytes())
    tree.body = [node for node in tree.body if not isinstance(node, (ast.Import, ast.ImportFrom))]
    namespace = {"math": math, "PlayerAction": PlayerAction, "TeamAction": TeamAction, "TeamController": object}
    exec(compile(tree, str(path), "exec"), namespace)
    return namespace["AdaptiveChampion"]


def player(pid, pos):
    return N(id=pid, position=pos, velocity=(0.,0.), kick_cooldown_ticks=0,
             has_control=False, facing=(1.,0.))


def observation(tick, score, wall, center=False):
    field = N(width=100., height=60., my_goal=(-50.,0.), opponent_goal=(50.,0.),
              simulation_hz=20., max_speed=8., acceleration=20., ball_friction=.985,
              kick_impulse=22., kick_range=2.2, goal_width=14., centre_circle_radius=8.,
              ball_radius=.45, player_radius=1.)
    mine = [player(i, pos) for i,pos in enumerate([(-47.,0.),(-26.,0.),(-15.,-7.8),(-15.,12.),(-9.8,0.)])]
    if wall:
        enemies = [player(i, (48.8,(7-i)*2.8)) for i in range(5,10)]
    else:
        enemies = [player(i+5, pos) for i,pos in enumerate([(47.,0.),(26.,0.),(15.,7.8),(15.,-12.),(9.8,0.)])]
    ball = N(position=(0.,0.) if center else (44.,9.), velocity=(0.,0.),
             controlling_player=None, controlling_team=1 if center else None, last_touch=None)
    return N(tick=tick, max_ticks=2400, time_remaining=(2400-tick)/2400, score=score,
             field=field, my_goal=field.my_goal, opponent_goal=field.opponent_goal,
             my_players=mine, opponents=enemies, ball=ball, team=0, side=0,
             phase="DEFEND", events=[], can_kick=lambda pid: False)


def state(c):
    p = c._specialist
    return {"active": c._active, "last_score": p._last_score,
            "restart_owner": p._restart_owner, "restart_until": p._restart_until}


def run(path):
    c = load(path)()
    c.reset(1001)
    for tick in range(300,306):
        actions = c.act(observation(tick, (0,1), True))
        assert set(actions.players) == set(range(5))
    assert c._active
    activation = state(c)
    actions = c.act(observation(500, (1,1), False, center=True))
    assert set(actions.players) == set(range(5))
    equalizer = state(c)
    equalizer["actions"] = {str(pid): {"movement": action.movement,
                                      "kick_direction": action.kick_direction,
                                      "kick_power": action.kick_power}
                            for pid,action in actions.players.items()}
    return {"source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "activation": activation, "equalizer": equalizer}


def main():
    v2 = ROOT / "agent-adaptive/v2/team.py"
    v3 = ROOT / "agent-adaptive/v3/team.py"
    before, after = run(v2), run(v3)
    assert before["activation"]["last_score"] is None
    assert before["equalizer"]["restart_owner"] != 1
    assert before["equalizer"]["restart_until"] != 560
    assert after["activation"]["last_score"] == (0,1)
    assert after["equalizer"]["last_score"] == (1,1)
    assert after["equalizer"]["restart_owner"] == 1
    assert after["equalizer"]["restart_until"] == 560
    a, b = ast.parse(v2.read_bytes()), ast.parse(v3.read_bytes())
    for tree in (a,b):
        cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "AdaptiveChampion")
        for node in cls.body:
            if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "version" for target in node.targets):
                node.value = ast.Constant(value="audit ignores metadata version")
    cls = next(node for node in b.body if isinstance(node, ast.ClassDef) and node.name == "AdaptiveChampion")
    act = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "act")
    changes = [node for node in act.body if isinstance(node, ast.Assign)
               and ast.unparse(node.targets[0]) == "self._specialist._last_score"]
    assert len(changes) == 1 and ast.unparse(changes[0].value) == "obs.score"
    act.body.remove(changes[0])
    assert ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False)
    c = load(v3)()
    c.reset(1001)
    for tick in range(300,306):
        c.act(observation(tick, (0,1), True))
    sequence = []
    for tick, score, wall, center in ((400,(0,2),False,True), (420,(0,2),True,False),
                                     (450,(1,2),False,True), (470,(1,2),True,False),
                                     (500,(2,2),False,True)):
        c.act(observation(tick, score, wall, center))
        sequence.append({"tick": tick, "score": score, **state(c)})
    assert [sequence[i]["restart_owner"] for i in (0,2,4)] == [0,1,1]
    assert sequence[-1]["restart_until"] == 560
    report = {"v2": before, "v3": after,
              "behavior_diff": "single public obs.score assignment to specialist._last_score before first act",
              "frozen_helpers_and_other_wrapper_logic_exact": True,
              "uses_native_match_loop": False, "immediate_equalizer_regression_passed": True,
              "multi_goal_wall_history_with_kickoff_observations": {"sequence": sequence,
                  "restart_owners_at_goals": [sequence[i]["restart_owner"] for i in (0,2,4)], "passed": True},
              "scope_note": "Goals reset formations to kickoff. A counterexample that keeps a wall through intervening goals omits these observations and does not establish native reachability."}
    Path(__file__).with_name("cold-siege-v3.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
