"""Independent AST and synthetic gate checks. No SDK imports or match loops."""

import ast
import copy
import hashlib
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace as N


ROOT = Path(__file__).resolve().parent.parent
CANDIDATE = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "agent-adaptive/team.py"
INPUTS = {
    "_FallbackPolicy": ROOT / "opponent/team.py",
    "_SpecialistPolicy": Path("/workspace/work/replay-finishing-handoffs/experiments/champion-hunt/team.py"),
}


class StripDocstrings(ast.NodeTransformer):
    def visit(self, node):
        node = super().visit(node)
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.body and isinstance(node.body[0], ast.Expr):
                value = node.body[0].value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    del node.body[0]
        return node


def dump(node):
    return ast.dump(node, include_attributes=False)


def parsed(path):
    return StripDocstrings().visit(ast.parse(path.read_bytes()))


class Action:
    def __init__(self, movement=(0, 0), kick_direction=None, kick_power=0):
        self.movement = movement
        self.kick_direction = kick_direction
        self.kick_power = kick_power


class Actions:
    def __init__(self):
        self.players = {}

    def set(self, pid, action):
        self.players[pid] = action


class Policy:
    def __init__(self):
        self.calls = []
        self.resets = []
        self.actions = Actions()
        self.reset(0)

    def reset(self, seed):
        self.resets.append(seed)
        self._receive_plan = self._relay_receive = self._x_reception = None
        self._last_score = (0, 0)

    def act(self, obs):
        self.calls.append(obs.tick)
        return self.actions

    def initial_formation(self, field):
        return "fallback formation"


def observation(tick, wall=True):
    return N(tick=tick, score=(0,0), opponent_goal=(50., 0.),
             opponents=[N(id=i, position=(48.8, (7-i)*2.8)) for i in range(5,10)] if wall else [])


def main():
    source = CANDIDATE.read_bytes()
    tree = parsed(CANDIDATE)
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    helper_functions = {node.name: dump(node) for node in tree.body if isinstance(node, ast.FunctionDef)}
    notes = {}
    for helper_name, path in INPUTS.items():
        original = parsed(path)
        original_class = next(node for node in original.body if isinstance(node, ast.ClassDef))
        original_class.name = helper_name
        original_class.bases = []
        assert dump(original_class) == dump(classes[helper_name]), helper_name
        assert {node.name: dump(node) for node in original.body if isinstance(node, ast.FunctionDef)} == helper_functions
        methods = {node.name for node in original_class.body if isinstance(node, ast.FunctionDef)}
        calls = {node.func.attr for node in ast.walk(original_class)
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                 and isinstance(node.func.value, ast.Name) and node.func.value.id == "self"}
        assert calls <= methods, (helper_name, calls - methods)
        notes[helper_name] = {"ast_matches": True, "inherited_calls": sorted(calls-methods),
                              "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    assert len(source) <= 256*1024
    assert [name for name, cls in classes.items() if cls.bases] == ["AdaptiveChampion"]
    assert ast.unparse(classes["AdaptiveChampion"].bases[0]) == "TeamController"
    imports = [ast.unparse(node) for node in tree.body if isinstance(node, (ast.Import, ast.ImportFrom))]
    assert imports == ["import math", "from soccer import PlayerAction, TeamAction, TeamController"]

    namespace = {"TeamController": object, "_FallbackPolicy": Policy, "_SpecialistPolicy": Policy}
    wrapper_module = ast.Module(body=[copy.deepcopy(classes["AdaptiveChampion"])], type_ignores=[])
    exec(compile(ast.fix_missing_locations(wrapper_module), str(CANDIDATE), "exec"), namespace)
    wrapper = namespace["AdaptiveChampion"]
    c = wrapper()
    for tick in range(5):
        assert c.act(observation(tick)) is c._fallback.actions
        assert not c._active
    assert c.act(observation(5)) is c._specialist.actions
    assert c._active and c._fallback.calls == list(range(6)) and c._specialist.calls == [5]
    assert c.act(observation(6, wall=False)) is c._specialist.actions
    assert c._fallback.calls == list(range(6))
    c.reset(123)
    assert not c._active and not c._wall_confirmed and c._wall_ticks == 0
    for tick in (0,1,2,4,5,6,7,8):
        c.act(observation(tick))
        assert not c._active
    c.act(observation(9))
    assert c._active

    c = wrapper()
    c._fallback.actions.set(0, Action(kick_direction=(1,0), kick_power=1))
    for tick in range(8):
        assert c.act(observation(tick)) is c._fallback.actions
        assert not c._active
    c._fallback.actions.players.clear()
    assert c.act(observation(8)) is c._specialist.actions

    # Run the real fallback wall branch in isolation to prove stale fields
    # survive it, rather than assuming a fake policy's lack of reconciliation.
    frozen_fallback = parsed(INPUTS["_FallbackPolicy"])
    frozen_class = next(node for node in frozen_fallback.body if isinstance(node, ast.ClassDef))
    wall_class = ast.ClassDef(name="WallBranch", bases=[], keywords=[], decorator_list=[],
        body=[copy.deepcopy(node) for node in frozen_class.body
              if isinstance(node, ast.FunctionDef) and node.name in ("act", "_lock_wall")])
    wall_namespace = {"TeamAction": Actions, "PlayerAction": Action, "math": math}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[wall_class], type_ignores=[])), "wall_branch", "exec"), wall_namespace)
    fallback = wall_namespace["WallBranch"]()
    fallback.TRAIL_WALL, fallback.LOCK_LEAD, fallback.LOCK_MAX, fallback.LOCK_TIME = 2,1,99,1.0
    fallback.LOCK_SPACING = 2.8
    fallback._receive_plan, fallback._relay_receive, fallback._x_reception = (4,3,3), (4,3,3), (4,3,3,(0,0))
    wall_obs = observation(100)
    wall_obs.score, wall_obs.time_remaining, wall_obs.my_goal = (1,0), .5, (-50,0)
    wall_obs.field = N(player_radius=1.)
    wall_obs.my_players = [N(id=i, position=(-48.8, (i-2)*2.8)) for i in range(5)]
    wall_obs.can_kick = lambda pid: False
    fallback.act(wall_obs)
    assert fallback._receive_plan == (4,3,3) and fallback._x_reception == (4,3,3,(0,0))

    stale = {}
    for field, value in (("_receive_plan", (4,3,3)), ("_relay_receive", (4,3,3)),
                         ("_x_reception", (4,3,3,(0,0)))):
        c = wrapper()
        setattr(c._fallback, field, value)
        for tick in range(100, 112):
            c.act(observation(tick))
        stale[field] = {"confirmed": c._wall_confirmed, "active": c._active,
                        "expired_at_tick": 3, "checked_through_tick": 111}

    live_contract_checks = {}
    if CANDIDATE.parent.name in ("v2", "v3"):
        assert all(v["active"] for v in stale.values())
        for field, value in (("_receive_plan", (4,3,105)), ("_relay_receive", (4,3,105)),
                             ("_x_reception", (4,3,105,(0,0)))):
            c = wrapper()
            setattr(c._fallback, field, value)
            for tick in range(100,106):
                assert c.act(observation(tick)) is c._fallback.actions
                assert not c._active
            assert c._wall_confirmed
            assert c.act(observation(106)) is c._specialist.actions and c._active
            c = wrapper()
            setattr(c._fallback, field, value)
            c._fallback._last_score = (0,1)
            for tick in range(100,106):
                c.act(observation(tick))
            assert c._active
            live_contract_checks[field] = "same-score expiry boundary defers; expiry+1 activates; old-score unexpired activates"

    report = {"source_sha256": hashlib.sha256(source).hexdigest(), "source_bytes": len(source),
              "policies": notes, "imports": imports, "one_sdk_wrapper": True,
              "synthetic_checks": "exact fallback object, six ticks, consecutive reset, latch, reset, selected kick passed",
              "frozen_wall_preserves_expired_plans": True, "expired_field_activation": stale,
              "live_contract_checks": live_contract_checks}
    target = Path(__file__).with_name("audit-"+CANDIDATE.parent.name+".json" if CANDIDATE.parent.name in ("v2", "v3") else "audit.json")
    target.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
