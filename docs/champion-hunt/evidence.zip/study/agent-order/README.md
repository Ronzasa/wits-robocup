Two frozen order-aware wall counters
==================================

`boundary-order/team.py` derives only from the frozen boundary-crossing counter.
`speed75-order/team.py` independently applies the same order selection to the
frozen 7.5 carry-speed descendant. `build.py` verifies both parent hashes and
refuses to replace changed frozen outputs. `manifest.json` records all hashes.

The sole tactical change chooses the existing wall simulator's order argument:
public side 0 means own first; public side 1 means enemy first; absent or unknown
side still requires both orders to predict a goal. Movement, kick candidates,
goal verification, contact simulation, and per-impulse speed caps are unchanged.

This is an explicitly fixed-course assumption for engine `0.1.0`, config
`372990895c7eca2a`, and `sides_swapped=false`. Native order was established in the
parent's two accepted three-kick probes. In that mode public side agrees with
global team; the assumption is not extended to swapped engine mode. The SDK's
canonical frame remains used for all geometry. Opponent intents are still
predicted from public positions, velocities and cooldowns.

`smoke.py` makes synthetic observations and runs complete `act` calls for normal
play, both wall corner signs, both sides, and unknown/missing side. It checks
order selection, fallback admission, source preservation, legal finite action
shape, and the 7.88/21.67 native impulse calculation without running an engine.
Synthetic timings are diagnostics; the parent's native 20 ms gate remains
necessary. No new native loops or qualification seeds were used here.
