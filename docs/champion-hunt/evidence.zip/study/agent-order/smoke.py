"""Native-free synthetic full-act and narrow order-admission checks."""
import ast
import hashlib
import importlib.util
import json
import math
import sys
import time
from pathlib import Path
from types import SimpleNamespace as NS

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, "/workspace/work/exploit-lab/student-sdk")
MISSING = object()
FIELD = NS(width=100., height=60., goal_width=14., my_goal=(-50., 0.),
           opponent_goal=(50., 0.), simulation_hz=20, max_speed=8.,
           acceleration=20., ball_friction=.985, kick_impulse=22.,
           kick_range=2.2, player_radius=1., ball_radius=.45,
           centre_circle_radius=9.15)


def load(path):
    spec = importlib.util.spec_from_file_location("order_smoke_" + str(len(MODULES)), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    MODULES.append(module)
    return module.Guardiola2011


MODULES = []


def observation(bx, by, vx, wall, side):
    sign = 1. if by >= 0 else -1.
    players = [NS(id=i, position=position, velocity=velocity,
                  kick_cooldown_ticks=0, has_control=i == 3)
               for i, (position, velocity) in enumerate((
                   ((-48.8, 0.), (0., 0.)), ((20., -6.), (0., 0.)),
                   ((30., 6.), (0., 0.)), ((bx - 1., by + .6 * sign), (8., 0.)),
                   ((35., 0.), (0., 0.))))]
    positions = [(48.8, y) for y in (5.6, 2.8, 0., -2.8, -5.6)] if wall else [
        (45., 0.), (34., -8.), (32., 7.), (15., -12.), (12., 12.)]
    opponents = [NS(id=5+i, position=position, velocity=(0., 0.),
                    kick_cooldown_ticks=0, has_control=False)
                 for i, position in enumerate(positions)]
    obs = NS(field=FIELD, opponent_goal=FIELD.opponent_goal, my_goal=FIELD.my_goal,
             tick=100, max_ticks=2400, score=(0, 1), time_remaining=.8,
             phase="ATTACK", team=0, events=[], my_players=players,
             opponents=opponents,
             ball=NS(position=(bx, by), velocity=(vx, 0.), controlling_team=0,
                     controlling_player=3, last_touch=3),
             can_kick=lambda i: players[i].kick_cooldown_ticks == 0 and
             math.hypot(players[i].position[0]-bx, players[i].position[1]-by) <= FIELD.kick_range)
    if side is not MISSING:
        obs.side = side
    return obs


def serial(action):
    return {i: p.as_dict() for i, p in action.players.items()}


def check_action(action):
    assert set(action.players) == set(range(5))
    for p in action.players.values():
        assert len(p.movement) == 2 and all(math.isfinite(v) for v in p.movement)
        assert math.hypot(*p.movement) <= 1. + 1e-9
        assert math.isfinite(p.kick_power) and 0. <= p.kick_power <= 1.
        if p.kick_direction is not None:
            assert len(p.kick_direction) == 2
            assert all(math.isfinite(v) for v in p.kick_direction)
            assert abs(math.hypot(*p.kick_direction) - 1.) <= 1e-8


def method_asts(path):
    tree = ast.parse(path.read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef))
    return {n.name: ast.dump(n, include_attributes=False)
            for n in cls.body if isinstance(n, ast.FunctionDef)}


def cap_sequence(impulses):
    vx = vy = 0.
    for dx, dy in impulses:
        vx += dx
        vy += dy
        speed = math.hypot(vx, vy)
        if speed > 30.:
            vx *= 30. / speed
            vy *= 30. / speed
    return [vx * .985, vy * .985]


manifest = json.loads((ROOT / "manifest.json").read_text())
report = {"native_engine_calls": 0, "qualification_seeds_used": 0,
          "impulse_evidence": {}, "variants": []}
pair_first = cap_sequence([(22., 0.), (22., 0.), (-22., 0.)])
single_first = cap_sequence([(-22., 0.), (22., 0.), (22., 0.)])
assert abs(pair_first[0] - 7.88) < 1e-12
assert abs(single_first[0] - 21.67) < 1e-12
assert abs(pair_first[0] - 7.880000114440918) < 5e-7
assert abs(single_first[0] - 21.670000076293945) < 5e-7
report["impulse_evidence"] = {"pair_global_team0_then_single": pair_first,
                              "single_then_pair_global_team1": single_first,
                              "cap": "30 after each impulse, then .985 drag",
                              "matches_parent_native_probe_tolerance": 5e-7}

for name, meta in manifest["variants"].items():
    path = Path(meta["path"])
    parent = Path(meta["parent"])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == meta["sha256"]
    assert hashlib.sha256(parent.read_bytes()).hexdigest() == meta["parent_sha256"]
    child_methods, parent_methods = method_asts(path), method_asts(parent)
    changed = sorted(k for k in parent_methods if child_methods[k] != parent_methods[k])
    assert changed == ["_siege_act", "_siege_goal", "reset"], changed
    assert child_methods["_siege_clearance_path"] == parent_methods["_siege_clearance_path"]
    Child, Parent = load(path), load(parent)
    smokes = []
    for side in (0, 1, None, 2, MISSING):
        for label, bx, by, vx, wall in (("normal", 25., 0., 0., False),
                                        ("wall-stage", 25., 0., 0., True),
                                        ("wall-positive", 48.9, 7.9, 10.5, True),
                                        ("wall-negative", 48.9, -7.9, 10.5, True)):
            obs = observation(bx, by, vx, wall, side)
            c, baseline = Child(), Parent()
            observed = []
            original = c._siege_clearance_path
            def record(*args):
                observed.append(args[-1])
                return original(*args)
            c._siege_clearance_path = record
            start = time.perf_counter()
            action = c.act(obs)
            elapsed_ms = (time.perf_counter() - start) * 1000.
            previous = baseline.act(obs)
            check_action(action)
            assert all(action.players[i].movement == previous.players[i].movement for i in range(5))
            if not wall or side not in (0, 1):
                assert serial(action) == serial(previous)
            if wall:
                expected = False if side == 0 else True if side == 1 else None
                assert c._siege_first_order is expected
                if label.startswith("wall-") and label != "wall-stage":
                    assert observed, "Corner full act must exercise goal forecasts"
                    assert set(observed) == ({expected} if expected is not None else {False, True})
            smokes.append({"side": "missing" if side is MISSING else side,
                           "scenario": label, "elapsed_ms": elapsed_ms,
                           "forecast_orders": sorted(set(observed)),
                           "kick_actions": {str(i): p.as_dict() for i, p in action.players.items()
                                            if p.kick_direction is not None}})
    # A focused admission test makes the order selector observable independently
    # of the wall predictor: one order scores and the other does not.
    admissions = []
    for succeeds in (False, True):
        for side in (0, 1, None, 2, MISSING):
            c = Child()
            obs = observation(48.9, 7.9, 10.5, True, side)
            c._setup(FIELD)
            c._siege_act(obs, obs.opponents)
            called = []
            def outcomes(*args):
                order = args[-1]
                called.append(order)
                return (2, 1) if order is succeeds else None
            c._siege_clearance_path = outcomes
            p = obs.my_players[3]
            kick = c._siege_goal((p.id, *p.position, *p.velocity), 48.9, 7.9,
                                  10.5, 0., (0., 0.), obs.opponents)
            expected = (False if side == 0 else True if side == 1 else None)
            assert (kick is not None) == (expected is succeeds)
            assert set(called) == ({expected} if expected is not None else {False, True})
            admissions.append({"side": "missing" if side is MISSING else side,
                               "only_scoring_order_enemy_first": succeeds,
                               "accepted": kick is not None})
    # Side is refreshed per observation, so a reused instance never carries
    # a previous known-side assumption into an unknown-side forecast.
    reused = Child()
    for side, expected in ((1, True), (MISSING, None), (0, False), (2, None)):
        obs = observation(25., 0., 0., True, side)
        reused.act(obs)
        assert reused._siege_first_order is expected
    report["variants"].append({"name": name, "sha256": meta["sha256"],
                               "changed_methods_only": changed,
                               "clearance_simulator_preserved": True,
                               "full_act_smokes": smokes,
                               "order_admission_checks": admissions,
                               "side_refresh_checks": 4,
                               "max_synthetic_ms": max(s["elapsed_ms"] for s in smokes)})

(ROOT / "smoke.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"native_engine_calls": 0, "impulse_evidence": report["impulse_evidence"],
                  "variants": [{"name": v["name"], "full_act_smokes": len(v["full_act_smokes"]),
                                "admission_checks": len(v["order_admission_checks"]),
                                "max_synthetic_ms": v["max_synthetic_ms"]}
                               for v in report["variants"]]}, indent=2))
