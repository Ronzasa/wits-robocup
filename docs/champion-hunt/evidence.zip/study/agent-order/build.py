"""Build isolated order-aware descendants; never modify frozen inputs."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
PARENTS = (
    ("boundary-order", "agent-wall/v10-boundary-crossing/team.py",
     "441ba301c662917256cb30035dd10ec114b30bb069ab5855199f7cfbe5a6643f"),
    ("speed75-order", "parent-phase/speed75/team.py",
     "7a38ef0d70c71f6369a45d00a74f00a8a8eccacb65ce6a9939c9a5fd9332347c"),
)


def replace_once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def freeze(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, "Refusing to overwrite frozen artifact: " + str(path)
    else:
        path.write_bytes(data)
    path.chmod(0o444)


items = {}
for name, relative, expected in PARENTS:
    parent = WORK / relative
    raw = parent.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected, "Frozen parent changed"
    source = raw.decode()
    source = replace_once(source, '    version = "v10-boundary-crossing-v1"\n',
                          '    version = "' + name + '-v1"\n')
    source = replace_once(source, '        self._ready = False\n',
                          '        self._ready = False\n        self._siege_first_order = None\n')
    source = replace_once(source, '        obs=self._siege_obs\n        opponents=obs.opponents\n',
        '        obs=self._siege_obs\n'
        '        orders=(False,True) if self._siege_first_order is None else (self._siege_first_order,)\n'
        '        opponents=obs.opponents\n')
    source = replace_once(source, '                              for order in (False,True)]\n',
                          '                              for order in orders]\n')
    source = replace_once(source, '        self._siege_obs=obs\n',
        '        self._siege_obs=obs\n'
        '        # Fixed-course native order: global team 0 precedes team 1.\n'
        '        # Public side maps to global team only in the supported unswapped\n'
        '        # course mode; canonical geometry and all movements stay unchanged.\n'
        '        side=getattr(obs,"side",None)\n'
        '        self._siege_first_order=False if side==0 else True if side==1 else None\n')
    tree = ast.parse(source)
    classes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
    assert len(classes) == 1 and classes[0].name == "Guardiola2011"
    imports = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))]
    assert len(imports) == 2 and isinstance(imports[0], ast.Import)
    assert [a.name for a in imports[0].names] == ["math"]
    assert isinstance(imports[1], ast.ImportFrom) and imports[1].module == "soccer"
    data = source.encode()
    assert len(data) <= 256 * 1024
    output = ROOT / name / "team.py"
    freeze(output, data)
    items[name] = {
        "path": str(output), "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data), "parent": str(parent), "parent_sha256": expected,
        "version": name + "-v1", "imports": ["math", "soccer"], "controller_classes": 1,
        "change": "Choose known simultaneous-kick/body order from public side only in wall forecasts; unknown side preserves both-order requirement.",
    }

manifest = {
    "variants": items,
    "assumptions": {
        "supported_profile": "engine 0.1.0 / config 372990895c7eca2a / sides_swapped=false",
        "order": "global team 0 before global team 1; obs.side 0 => own first, obs.side 1 => enemy first",
        "unknown_side": "Require successful goal forecast in both orders",
        "swapped_engine_mode": "Not supported by this side/order assumption; not inferred or extended to swapped mode",
        "speed_cap": "Existing 30-unit cap after EACH individual impulse is preserved byte-for-byte",
        "evidence": "../order-probe/observed.md and ../order-probe/smoke-both.json; no additional native probes",
        "observation_scope": "Public side, geometry, velocity and cooldown only; no seed, opponent identity, private engine state, or opponent action access",
        "qualification": "No qualification seeds read or executed",
        "remaining_uncertainty": "Opponent intents remain predicted; future steering/player collisions remain the unchanged model uncertainty",
    },
}
freeze(ROOT / "manifest.json", (json.dumps(manifest, indent=2) + "\n").encode())
print(json.dumps(items, indent=2))
