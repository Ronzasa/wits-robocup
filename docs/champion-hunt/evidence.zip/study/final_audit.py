from pathlib import Path
import json,hashlib,random
from collections import defaultdict
root=Path('/workspace/work/champion-hunt-20261025');repo=Path('/workspace/work/replay-finishing-handoffs')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def rows(d):return [json.loads(x) for x in (root/d/'matches.jsonl').read_text().splitlines()]
def aggregate(rs):
 w=d=l=gf=ga=0;errors=misses=fouls=kicks=count=total=0;mx=0.;operrors=opmisses=0
 for r in rs:
  s=r['candidate_slot'];a,b=r['result']['score'][s],r['result']['score'][1-s];w+=a>b;d+=a==b;l+=a<b;gf+=a;ga+=b
  t=r['result']['stats'][s];o=r['result']['stats'][1-s]
  errors+=t['policy_errors'];misses+=t['policy_timeouts'];fouls+=t['fouls'];kicks+=t['validation']['rejected_kicks']
  count+=t['decision_time_ms']['count'];total+=t['decision_time_ms']['total_ms'];mx=max(mx,t['decision_time_ms']['max_ms'])
  operrors+=o['policy_errors'];opmisses+=o['policy_timeouts']
 return dict(matches=len(rs),wins=w,draws=d,losses=l,points=3*w+d,goals_for=gf,goals_against=ga,exceptions=errors,raw_misses=misses,fouls=fouls,rejected_kicks=kicks,decisions=count,mean_ms=total/count,max_ms=mx,opponent_exceptions=operrors,opponent_raw_misses=opmisses)
def pts(r):
 s=r['candidate_slot'];a,b=r['result']['score'][s],r['result']['score'][1-s];return 3 if a>b else 1 if a==b else 0
ad=rows('adaptive-qualification');field=rows('adaptive-field-qualification')
report={'direct':aggregate(ad),'field':{n:aggregate([r for r in field if r['source']==n]) for n in ('adaptive-finalist','frozen-upload')}}
for folder in ['adaptive-qualification','adaptive-field-qualification','qualification','transfer-audit']:
 reg=read(root/folder/'registration.json');sources=list(reg.get('sources',reg.get('candidates',{})).values())+list(reg.get('opponents',{}).values())+([reg['opponent']] if 'opponent' in reg else [])
 assert all(sha(Path(x['path']))==x['sha256'] for x in sources),folder
report['all_final_registered_sources_match_hashes']=True
files={'adaptive':repo/'experiments/champion-hunt-adaptive/team.py','specialist':repo/'experiments/champion-hunt/team.py','upload':root/'opponent/team.py','active_champion':repo/'my-team/team.py','v10':repo/'champions/v10.0/team.py','v91':repo/'champions/v9.1/team.py'}
report['sha256']={k:sha(v) for k,v in files.items()}
# Verify complete, uniquely paired fixtures and identical native config.
for folder in ['adaptive-qualification','adaptive-field-qualification']:
 rs=rows(folder);reg=read(root/folder/'registration.json');seen=set()
 for r in rs:
  key=(r['source'],r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff']);assert key not in seen;seen.add(key)
  assert r['result']['ticks']==2400 and r['result']['terminal_reason']=='time_limit'
  assert r['result']['config_hash']==reg['config_hash']=='372990895c7eca2a'
  assert r['result']['engine_version']=='0.1.0'
  assert r['result']['kickoff_team']==(r['candidate_slot'] if r['candidate_takes_kickoff'] else 1-r['candidate_slot'])
report['complete_unique_balanced_final_fixtures']=True
key=lambda r:(r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])
a={key(r):r for r in field if r['source']=='adaptive-finalist'};b={key(r):r for r in field if r['source']=='frozen-upload'};assert set(a)==set(b)
blocks=defaultdict(list)
for k,r in a.items():blocks[r['seed']].append(pts(r)-pts(b[k]))
means=[sum(v)/len(v) for _,v in sorted(blocks.items())];rng=random.Random(3249068002);boot=sorted(sum(rng.choices(means,k=len(means)))/len(means) for _ in range(20000))
report['field_difference']=dict(points_per_fixture=sum(means)/len(means),seed_block_95=[boot[500],boot[19499]],seed_block_975=[boot[250],boot[19749]],points_by_style={style:{n:sum(pts(r) for r in field if r['opponent_name']==style and r['source']==n) for n in ('adaptive-finalist','frozen-upload')} for style in sorted({r['opponent_name'] for r in field})})
report['activations']={style:sum(r['telemetry']['adaptive']['active_at_end'] is True for r in field if r['opponent_name']==style and r['source']=='adaptive-finalist') for style in sorted({r['opponent_name'] for r in field})}
report['direct_activations']=sum(r['telemetry']['adaptive']['active_at_end'] is True for r in ad)
report['original_strong_score_gates']=dict(win_fraction=report['direct']['wins']/len(ad),win_fraction_at_least_075=False,mean_gd=(report['direct']['goals_for']-report['direct']['goals_against'])/len(ad),mean_gd_at_least_15=False)
report['intake']=read(root/'adaptive-intake.json')
report['native_inventory']={'jsonl_full_or_early_native_results':sum(len(p.read_text().splitlines()) for p in root.rglob('matches.jsonl')),'recovered_aborted_native_result':1,'timed_diagnostic_repeats':4,'untimed_parity_matches':5,'official_intake_matches_per_final_source':5}
report['native_inventory']['timed_native_attempts']=report['native_inventory']['jsonl_full_or_early_native_results']+5
report['provenance_notes']=['adaptive-plan.json points at V2 before development; V3 public-score initialization bug fix is documented before untouched qualification by adaptive-selection.json and both final registrations. Do not change original preregistration retroactively.','One opposing-side raw deadline miss is present in paired field validation; adaptive/source baseline roles each have zero.','Strong-score gates both fail. Positive paired points evidence is not proof of live-league dominance.','Final candidate has 13 rejected kick requests direct and 1 field; these are separate from zero policy exceptions.','Parent runtime stalls remain unresolved and counted; clean reproductions do not erase original misses.']
(root/'final-audit.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'final-audit.md').write_text('''# Final evidence audit\n\nRead-only recomputation from native JSONL records, registered source hashes and official intake output. No simulation or candidate modification was performed in this audit.\n\n- Adaptive direct: **79 W / 46 D / 3 L**, **283–55 points**, **203–121 goals** across 128 complete balanced fixtures / 32 fresh seeds. Zero candidate and opposing exceptions or deadline misses; zero candidate fouls. Mean **0.115240 ms**, max **8.682870 ms**. There are **13 rejected kick requests**. Specialist activated in **65/128**.\n- Paired field: adaptive **91 W / 30 D / 39 L**, **303 points**, **177–148 goals**; frozen uploaded baseline **84 W / 23 D / 53 L**, **275 points**, **147–139 goals**; 160 matches each / 8 fresh seed blocks. Paired gain **+0.175 points/fixture**, independently reproduced seed-block 95% interval **[0.09375, 0.25]**, 97.5% interval **[0.08125, 0.25625]**.\n- Adaptive field mean **0.101954 ms**, max **16.552420 ms**; frozen source mean **0.100690 ms**, max **10.121886 ms**. Both source roles have **zero exceptions, raw misses and fouls**, and **1 rejected kick request each**. **One opposing-side raw miss exists**; do not report all sides as zero.\n- The entire field points gain is against the uploaded wall controller (**75 vs 47**, where baseline is self-play). Other styles are unchanged: counter **60/60**, press **59/59**, compact **55/55**, v9.1 **54/54**. Specialist activated in **18/32** upload matches, **0/128** ordinary-style matches.\n- Final source / opponent hashes match all four relevant frozen registrations. Final fixtures are complete, unique and balance both pitch assignments and both kickoff arrangements; engine **0.1.0**, config **372990895c7eca2a**, 2400 ticks.\n- **Original strong-score gates FAIL:** adaptive wins **61.71875%**, below 75%, and mean goal difference **0.640625**, below 1.5. Positive direct and field confidence bounds and zero final candidate exceptions/misses support an experimental improvement, not the stronger domination claim or automatic promotion.\n- Provenance: adaptive-plan.json still references V2; the public-score initialization fix was developed as V3 before fresh final qualification. adaptive-selection.json and both qualification registrations freeze the correct final source SHA. Preserve the original plan, explain this revision rather than altering it.\n- Inventory: **1577 JSONL native results + 1 separately recovered aborted native result + 4 timed diagnostic repeats = 1582 timed native attempts**. Five separate untimed parity matches and per-source five-match official intakes are not included in that count.\n- Parent timing stalls were not reproduced; their raw failures remain retained. Cache parity establishes behavior preservation and later timing observations, not proof of the original stall's cause.\n\nSee final-audit.json for recomputed totals and frozen hashes. No active champion or main branch was changed by this audit.\n''')
print(json.dumps(report,indent=2))
