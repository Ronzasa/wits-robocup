"""Post-qualification generalization audit; frozen source, no tuning/selection."""
import hashlib,json,random,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/work/replay-finishing-handoffs')
sys.path.insert(0,str(REPO/'tools/benchmarks'))
from benchmark import aggregate,points
from default_roster import native_match
from batch import compare
folder=ROOT/'transfer-audit'
reg=json.loads((folder/'registration.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for x in [*reg['sources'].values(),*reg['opponents'].values()]:assert sha(x['path'])==x['sha256']
rng=random.Random(reg['order_seed'])
fixtures=[(style,seed,side,kick) for style in reg['opponents'] for seed in reg['seeds'] for side in (0,1) for kick in (True,False)];rng.shuffle(fixtures)
rows={n:[] for n in reg['sources']}
with (folder/'matches.jsonl').open('x') as f:
 for index,(style,seed,side,kick) in enumerate(fixtures):
  names=list(rows);rng.shuffle(names)
  for n in names:
   result,telemetry,roster=native_match(reg['sources'][n]['path'],reg['opponents'][style]['path'],seed,side,kick,reg)
   row=dict(source=n,opponent_name=style,seed=seed,candidate_slot=side,candidate_takes_kickoff=kick,result=result,telemetry=telemetry,initial_roster=roster)
   rows[n].append(row);f.write(json.dumps(row)+'\n');f.flush()
  if (index+1)%8==0:print('AUDIT',index+1,'/64',{n:sum(points(r) for r in rs) for n,rs in rows.items()},flush=True)
summary={n:aggregate(rs) for n,rs in rows.items()}
key=lambda r:(r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])
a={key(r):r for r in rows['finalist']};b={key(r):r for r in rows['frozen-upload']}
blocks={seed:[] for seed in reg['seeds']}
for k,r in a.items():blocks[r['seed']].append(points(r)-points(b[k]))
means=[sum(v)/len(v) for v in blocks.values()]
rng=random.Random(3249066002);draws=sorted(sum(rng.choices(means,k=len(means)))/len(means) for _ in range(10000))
report=dict(summary=summary,paired_points_difference_per_fixture=sum(means)/len(means),paired_seed_block_95=[draws[250],draws[9749]],by_opponent={style:{n:aggregate([r for r in rs if r['opponent_name']==style]) for n,rs in rows.items()} for style in reg['opponents']},qualification_source_unchanged=True,promotion=False,interpretation='Small post-qualification transfer audit, four independent seed blocks; no tuning or reselection allowed.')
(folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
for x in [*reg['sources'].values(),*reg['opponents'].values()]:assert sha(x['path'])==x['sha256']
print('FINAL',json.dumps(report),flush=True)
