import ast
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/work/replay-finishing-handoffs')
recovery=(REPO/'experiments/replay-finishing-handoffs/team.py').read_text()
def method(source,name):
 node=next(n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name==name)
 return ''.join(source.splitlines(True)[node.lineno-1:node.end_lineno])+'\n'
helper=method(recovery,'_keeper_clearance')
for label,path in [('keeper-v10',REPO/'champions/v10.0/team.py'),('keeper-v1',REPO/'experiments/champion-candidate-review/no-trailing-wall/team.py')]:
 source=path.read_text().replace('    LOCK_LEAD = 1\n','    LOCK_LEAD = 0\n').replace('    WALL_BREAK = 1\n','    WALL_BREAK = 0\n')
 source=source.replace('    def _choose_kick(', '    def _keeper_base_choose_kick(',1)
 if 'self._goal_half = field.goal_width * 0.5' not in source:
  source=source.replace('        self._mouth = max(0.0, field.goal_width * 0.5 - 0.6)','        self._goal_half = field.goal_width * 0.5\n        self._mouth = max(0.0, field.goal_width * 0.5 - 0.6)')
 source+='\n    KEEPER_CLEAR_TICKS = 12\n\n'+helper+'''
    def _choose_kick(self,p,bx,by,vx,vy,friends,opponents):
        kick=self._keeper_base_choose_kick(p,bx,by,vx,vy,friends,opponents)
        if p[0]==0:
            movement=self._touch_movement or self._move(p,(bx+.3,by))
            return self._keeper_clearance(p,bx,by,vx,vy,kick,movement,opponents)
        return kick
'''
 p=ROOT/'parent-keeper'/label/'team.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(source);ast.parse(source)
source=(REPO/'champions/v10.0/team.py').read_text()
a=method(source,'_goal_path');b=method((REPO/'experiments/champion-candidate-review/uploaded/team.py').read_text(),'_goal_path')
source=source.replace(a,b).replace('        self._mouth = max(0.0, field.goal_width * 0.5 - 0.6)','        self._goal_half = field.goal_width * 0.5\n        self._mouth = max(0.0, field.goal_width * 0.5 - 0.6)')
p=ROOT/'parent-keeper/v10-goalplane/team.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(source);ast.parse(source)
source=(REPO/'champions/v10.0/team.py').read_text().replace('    LINK_MARGIN = 0.10\n','    LINK_MARGIN = 0.03\n')
p=ROOT/'parent-keeper/v10-link03/team.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(source)
print('4independent physical/decision controls prepared.')
