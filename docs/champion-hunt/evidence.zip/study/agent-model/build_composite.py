"""Frozen public-model shot opening + native-tested boundary-crossing wall mode."""
import ast,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
wallpath=Path('/workspace/work/champion-hunt-20261025/agent-wall/v10-boundary-crossing/team.py')
modelpath=ROOT/'model-shot/team.py'
tree=ast.parse(modelpath.read_text());walltree=ast.parse(wallpath.read_text())
controller=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Guardiola2011')
wall=next(n for n in walltree.body if isinstance(n,ast.ClassDef) and n.name=='Guardiola2011')
controller.body=[n for n in controller.body if not(isinstance(n,ast.FunctionDef) and n.name=='act')]
for n in controller.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='version' for t in n.targets):n.value=ast.Constant('public-model-shot-wall-crossing-v1')
for n in wall.body:
 if isinstance(n,ast.FunctionDef) and n.name.startswith('_siege_'):
  controller.body.append(ast.parse(ast.unparse(n)).body[0])
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id.startswith('SIEGE_') for t in n.targets):
  controller.body.append(ast.parse(ast.unparse(n)).body[0])
wrapper=ast.parse('''
class _Wrapper:
    def act(self,obs):
        # The public target model consumes every observation, including
        # siege ticks, so its private tactical memory stays synchronized.
        forecast=self._target_model.act(_Perspective(obs))
        self._predicted_opponent={pid+5:PlayerAction(movement=(-a.movement[0],-a.movement[1]),kick_direction=None if a.kick_direction is None else (-a.kick_direction[0],-a.kick_direction[1]),kick_power=a.kick_power) for pid,a in forecast.players.items()}
        self._model_obs=obs
        wall=[q for q in obs.opponents if q.position[0]>obs.opponent_goal[0]-3.0 and abs(q.position[1])<9.0]
        if len(wall)>=4:
            if not self._ready:
                self._setup(obs.field)
                self._restart_until=obs.tick+int(3.0*self._hz)
                self._restart_owner=obs.ball.controlling_team
            return self._siege_act(obs,wall)
        actions=self._base_act(obs)
        return self._model_adjust(obs,actions)
''').body[0]
controller.body.extend(wrapper.body)
ast.fix_missing_locations(tree)
text='"""Experimental public-model shooting plus target-specific wall clearance attack. Not promoted."""\n'+ast.unparse(tree)+'\n'
p=ROOT/'model-shot-wall/team.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
assert p.stat().st_size<256000
outtree=ast.parse(text);outcls=next(n for n in outtree.body if isinstance(n,ast.ClassDef) and n.name=='Guardiola2011')
for n in wall.body:
 if isinstance(n,ast.FunctionDef) and n.name.startswith('_siege_'):
  copied=next(k for k in outcls.body if isinstance(k,ast.FunctionDef) and k.name==n.name)
  assert ast.dump(n,include_attributes=False)==ast.dump(copied,include_attributes=False),n.name
manifest=dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),opening_source_sha256=hashlib.sha256(modelpath.read_bytes()).hexdigest(),wall_source_sha256=hashlib.sha256(wallpath.read_bytes()).hexdigest(),wall_method_asts_preserved=True,mirror_model_runs_every_tick=True,qualification=False)
(ROOT/'composite-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
