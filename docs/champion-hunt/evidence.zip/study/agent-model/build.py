import ast,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/work/replay-finishing-handoffs')
target=ast.parse(Path('/workspace/work/champion-hunt-20261025/opponent/team.py').read_text())
base=ast.parse((REPO/'champions/v10.0/team.py').read_text())
class StripDocs(ast.NodeTransformer):
 def visit_Module(self,n):
  self.generic_visit(n);n.body=[s for s in n.body if not (isinstance(s,ast.Expr) and isinstance(s.value,ast.Constant) and isinstance(s.value.value,str))];return n
 def visit_ClassDef(self,n):
  self.generic_visit(n);n.body=[s for s in n.body if not (isinstance(s,ast.Expr) and isinstance(s.value,ast.Constant) and isinstance(s.value.value,str))];return n
 def visit_FunctionDef(self,n):
  self.generic_visit(n);n.body=[s for s in n.body if not (isinstance(s,ast.Expr) and isinstance(s.value,ast.Constant) and isinstance(s.value.value,str))];return n
model=next(n for n in target.body if isinstance(n,ast.ClassDef));model.name='_TargetTactics';model.bases=[]
controller=next(n for n in base.body if isinstance(n,ast.ClassDef))
for n in controller.body:
 if isinstance(n,ast.FunctionDef) and n.name=='reset':
  n.body.append(ast.parse('self._target_model = _TargetTactics()').body[0])
  n.body.append(ast.parse('self._target_model.reset(seed)').body[0])
  n.body.append(ast.parse('self._predicted_opponent = {}').body[0])
 if isinstance(n,ast.FunctionDef) and n.name=='act':n.name='_base_act'
 if isinstance(n,ast.FunctionDef) and n.name=='_choose_kick':n.name='_base_choose_kick'
 if isinstance(n,ast.FunctionDef) and n.name=='_setup':
  n.body.append(ast.parse('self._goal_half = field.goal_width * .5').body[0])
helpers=ast.parse('''
class _Public:
    def __init__(self, **values):
        self.__dict__.update(values)

class _Perspective:
    def __init__(self, obs):
        self.tick=obs.tick
        self.max_ticks=obs.max_ticks
        self.time_remaining=obs.time_remaining
        self.score=(obs.score[1],obs.score[0])
        self.field=obs.field
        self.my_goal=obs.my_goal
        self.opponent_goal=obs.opponent_goal
        self.my_players=[_Public(id=p.id-5,position=(-p.position[0],-p.position[1]),velocity=(-p.velocity[0],-p.velocity[1]),kick_cooldown_ticks=p.kick_cooldown_ticks,has_control=p.has_control) for p in obs.opponents]
        self.opponents=[_Public(id=p.id+5,position=(-p.position[0],-p.position[1]),velocity=(-p.velocity[0],-p.velocity[1]),kick_cooldown_ticks=p.kick_cooldown_ticks,has_control=p.has_control) for p in obs.my_players]
        self.ball=_Public(position=(-obs.ball.position[0],-obs.ball.position[1]),velocity=(-obs.ball.velocity[0],-obs.ball.velocity[1]),controlling_team=None if obs.ball.controlling_team is None else 1-obs.ball.controlling_team,controlling_player=self._id(obs.ball.controlling_player),last_touch=self._id(obs.ball.last_touch))
    @staticmethod
    def _id(pid):
        return None if pid is None else pid-5 if pid>=5 else pid+5
    def can_kick(self,pid):
        p=self.my_players[pid]
        return p.kick_cooldown_ticks==0 and math.hypot(p.position[0]-self.ball.position[0],p.position[1]-self.ball.position[1])<=self.field.kick_range
''').body
common='''
    def act(self,obs):
        forecast=self._target_model.act(_Perspective(obs))
        self._predicted_opponent={pid+5:PlayerAction(movement=(-a.movement[0],-a.movement[1]),kick_direction=None if a.kick_direction is None else (-a.kick_direction[0],-a.kick_direction[1]),kick_power=a.kick_power) for pid,a in forecast.players.items()}
        self._model_obs=obs
        actions=self._base_act(obs)
        return self._model_adjust(obs,actions)

    def _model_step_player(self,p,move):
        vx=p[3]*self._damping+move[0]*self._acc
        vy=p[4]*self._damping+move[1]*self._acc
        speed=math.hypot(vx,vy)
        if speed>self._speed:vx*=self._speed/speed;vy*=self._speed/speed
        return [p[0],_clip(p[1]+vx*self._dt,self._left+1.,self._right-1.),_clip(p[2]+vy*self._dt,-self._half_height+1.,self._half_height-1.),vx,vy]

    def _model_adjust(self,obs,actions):
        return actions

    def _choose_kick(self,p,bx,by,vx,vy,friends,opponents):
        return self._base_choose_kick(p,bx,by,vx,vy,friends,opponents)
'''
shot='''
    def _model_shot(self,p,bx,by,vx,vy,opponents,target_y):
        ux,uy=_unit(self._right-bx,target_y-by)
        along=vx*ux+vy*uy
        perp=max(0.,vx*vx+vy*vy-along*along)
        if perp>=self._impulse*self._impulse:return None
        speed=min(self._ball_cap,along+math.sqrt(self._impulse*self._impulse-perp))
        if speed<12.:return None
        kick=self._kick_to_velocity(vx,vy,ux*speed,uy*speed)
        if kick is None:return None
        movement=self._move(p,(bx+.3,by))
        carrier=self._model_step_player(p,movement)
        if math.hypot(carrier[1]-bx,carrier[2]-by)>self._range-.025:return None
        wall_mode=sum(q[1]>self._right-3. and abs(q[2])<9. for q in opponents)>=4
        worst=10.
        for enemy_first in (False,True):
            states=[list(q) for q in opponents]
            cooldowns=[self._enemy_cooldowns.get(q[0],0) for q in opponents]
            x,y,sx,sy=bx,by,vx,vy
            cv=list(carrier)
            success=False
            for tick in range(30):
                intents=[]
                next_states=[]
                for i,q in enumerate(states):
                    if tick==0:
                        action=self._predicted_opponent.get(q[0],PlayerAction())
                        move=action.movement
                        attempted=action.kick_direction is not None and cooldowns[i]==0 and math.hypot(q[1]-x,q[2]-y)<=self._range
                        intent=(action.kick_direction,action.kick_power) if attempted else None
                    elif wall_mode:
                        tx,ty=self._right-1.2,(7-q[0])*2.8
                        dx,dy=tx-q[1],ty-q[2]
                        gap=math.hypot(dx,dy)
                        throttle=min(1.,gap/1.5)
                        move=(dx/gap*throttle,dy/gap*throttle) if gap>1e-8 else (0.,0.)
                        intent=((-1.,0.),1.) if cooldowns[i]==0 and math.hypot(q[1]-x,q[2]-y)<=self._range else None
                    else:
                        if q[0]==5:
                            tx=self._right-2.2
                            ty=y*2.2/max(3.,self._right-x)
                            if sx>8. and math.hypot(sx,sy)>=12.:
                                arrival=(tx-x)/sx
                                if 0.<arrival<1.25:ty=y+sy*arrival
                            ty=_clip(ty,-self._mouth,self._mouth)
                        else:tx,ty=x,y
                        move=self._move(q,(tx,ty))
                        intent=None
                    qn=self._model_step_player(q,move)
                    if intent is not None and math.hypot(qn[1]-x,qn[2]-y)>self._range:intent=None
                    if tick>0 and not wall_mode and cooldowns[i]==0 and math.hypot(qn[1]-x,qn[2]-y)<self._range+.03:return None
                    next_states.append(qn);intents.append(intent)
                if tick==0 and not enemy_first:sx,sy=self._requested_velocity(sx,sy,kick)
                for i,intent in enumerate(intents):
                    if intent is not None:
                        sx,sy=self._requested_velocity(sx,sy,intent)
                        cooldowns[i]=5
                if tick==0 and enemy_first:sx,sy=self._requested_velocity(sx,sy,kick)
                x+=sx*self._dt;y+=sy*self._dt
                bound=self._half_height-self._ball_radius
                if abs(y)>bound:
                    side=1. if y>0 else -1.
                    y=side*2.*bound-y;sy=-side*abs(sy)*self._wall
                if x>self._right-self._ball_radius and abs(y)>self._goal_half:return None
                sx*=self._friction;sy*=self._friction
                bodies=next_states+([cv] if tick==0 else [])
                if enemy_first:bodies=list(reversed(bodies))
                for q in bodies:
                    dx,dy=x-q[1],y-q[2]
                    gap=math.hypot(dx,dy)
                    if 1e-8<gap<self._contact:
                        nx,ny=dx/gap,dy/gap
                        x,y=q[1]+nx*self._contact,q[2]+ny*self._contact
                        closing=(sx-q[3])*nx+(sy-q[4])*ny
                        if closing<0.:
                            sx-=1.25*closing*nx;sy-=1.25*closing*ny
                if x>self._right and abs(y)<=self._goal_half:
                    success=True;worst=min(worst,10.-tick*.05);break
                states=next_states
                cooldowns=[max(0,c-1) for c in cooldowns]
                if sx<.1:return None
            if not success:return None
        return worst,kick,movement

    def _choose_kick(self,p,bx,by,vx,vy,friends,opponents):
        if p[0]!=0 and bx>20. and abs(by)<20.:
            best=None
            for aim in (-6.8,-5.4,-2.,2.,5.4,6.8):
                option=self._model_shot(p,bx,by,vx,vy,opponents,aim)
                if option is not None and (best is None or option[0]>best[0]):best=option
            if best is not None:
                self._touch_movement=best[2]
                self._pass_plan=self._bank_plan=None
                return best[1]
        return self._base_choose_kick(p,bx,by,vx,vy,friends,opponents)
'''
intercept='''
    def _model_adjust(self,obs,actions):
        if self._receive_plan is not None:return actions
        bx,by=obs.ball.position
        if obs.tick<self._restart_until and self._restart_owner==1:return actions
        vx,vy=obs.ball.velocity
        changed=False
        for q in obs.opponents:
            intent=self._predicted_opponent.get(q.id)
            if intent is None or intent.kick_direction is None or q.kick_cooldown_ticks!=0:continue
            state=self._model_step_player((q.id,*q.position,*q.velocity),intent.movement)
            if math.hypot(state[1]-bx,state[2]-by)>self._range:continue
            vx,vy=self._requested_velocity(vx,vy,(intent.kick_direction,intent.kick_power))
            changed=True
        if not changed:return actions
        path=self._trajectory(bx,by,vx,vy)
        eligible=[]
        for q in obs.my_players[1:]:
            if q.id==self._shape_cover_id or actions.players[q.id].kick_direction is not None:continue
            p=(q.id,*q.position,*q.velocity)
            race=self._intercept(p,path)
            eligible.append((race[0],q.id,p,race[1]))
        if eligible:
            _,pid,p,target=min(eligible)
            actions.set(pid,PlayerAction(movement=self._move(p,self._target(*target))))
        return actions
'''
items={}
for label,extra in [('model-shot',shot),('model-intercept',intercept)]:
 node=ast.parse(ast.unparse(controller)).body[0]
 node.body.extend(ast.parse(common+extra).body[0:] if False else [])
 # Methods must be parsed in a class to preserve their intended indentation.
 extra_cls=ast.parse('class _Extra:\n'+common+extra).body[0]
 # Last method definitions deliberately override their base defaults.
 node.body.extend(extra_cls.body)
 module=ast.Module(body=[n for n in base.body if not isinstance(n,ast.ClassDef)]+helpers+[model,node],type_ignores=[])
 module=StripDocs().visit(module);ast.fix_missing_locations(module)
 text='"""Public-observation target model; experimental, not promoted."""\n'+ast.unparse(module)+'\n'
 p=ROOT/label/'team.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 assert len(p.read_bytes())<256*1024
 items[label]=dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(ROOT/'manifest.json').write_text(json.dumps(items,indent=2)+'\n')
print(json.dumps(items,indent=2))
