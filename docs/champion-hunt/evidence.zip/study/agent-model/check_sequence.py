"""Untimed public-observation parity; never a qualification/runtime result."""
import importlib.util,json,sys
from pathlib import Path
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv
from soccer.helpers import load_controller
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('model_under_test',ROOT/'model-shot/team.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
actual=[load_controller('/workspace/work/champion-hunt-20261025/opponent/team.py') for _ in range(2)]
models=[m._TargetTactics(),m._TargetTactics()]
for c in actual+models:c.reset(3249061101)
rows=[];kicks=0;diffs=[]
with SoccerEnv(config_path='/workspace/work/replay-finishing-handoffs/configs/default.toml',max_ticks=2400) as env:
 observations=env.reset(seed=3249061101,kickoff_team=0)
 for tick in range(100):
  actions={key:actual[i].act(observations[key]) for i,key in enumerate(('team_a','team_b'))}
  for i,key,other in ((0,'team_a','team_b'),(1,'team_b','team_a')):
   pred=models[i].act(m._Perspective(observations[key]));want=actions[other]
   err=0.;different=False
   for pid,a in want.players.items():
    b=pred.players[pid]
    err=max(err,max(abs(x-y) for x,y in zip(a.movement,b.movement)),abs(a.kick_power-b.kick_power))
    if (a.kick_direction is None)!=(b.kick_direction is None):different=True
    if a.kick_direction is not None:
     kicks+=1
     if b.kick_direction is not None:err=max(err,max(abs(x-y) for x,y in zip(a.kick_direction,b.kick_direction)))
   rows.append(dict(tick=tick,perspective=i,max_command_error=err,kick_presence_difference=different))
   if err>1e-10 or different:diffs.append(rows[-1])
  observations,_=env.step(actions)
result=dict(seed=3249061101,native_ticks=100,perspective_comparisons=len(rows),kick_commands_observed=kicks,mismatches=diffs,max_command_error=max(r['max_command_error'] for r in rows),scope='untimed functional sequence; both actual controllers frozen uploaded target, no SDK/opponent edits, native default rosters')
(ROOT/'prediction-sequence-parity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
