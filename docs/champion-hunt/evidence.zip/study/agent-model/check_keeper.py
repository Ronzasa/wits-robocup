"""Synthetic public-input action priority checks, not native win evidence."""
import sys,json,importlib.util
from pathlib import Path
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv,PlayerAction,TeamAction
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('keeper_test',ROOT/'model-keeper/team.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
with SoccerEnv(config_path='/workspace/work/replay-finishing-handoffs/configs/default.toml') as env:field=env.field
c=m.Guardiola2011();c._setup(field)
P=m._Public
friends=[P(id=i,position=(-47.8,0.) if i==0 else (-10.+i,15.),velocity=(0.,0.),kick_cooldown_ticks=0) for i in range(5)]
enemy=P(id=5,position=(-22.5,0.),velocity=(0.,0.),kick_cooldown_ticks=0)
obs=P(field=field,my_players=friends,opponents=[enemy],ball=P(position=(-24.,0.),velocity=(0.,0.)))
c._predicted_opponent={5:PlayerAction(kick_direction=(-.9701425001453319,.24253562503633297),kick_power=1.)}
def actions():return TeamAction({i:PlayerAction(movement=(0.,0.)) for i in range(5)},debug={})
a=actions();before=dict(a.players);c._model_adjust(obs,a)
assert a.players[0].movement[1]>0
assert all(a.players[i] is before[i] for i in range(1,5))
checks=['anticipates_committed_near_goal_kick','all_other_players_unchanged']
a=actions();kick=PlayerAction(kick_direction=(1.,0.),kick_power=1.);a.set(0,kick);c._model_adjust(obs,a);assert a.players[0] is kick;checks.append('preserves_keeper_kick')
a=actions();a.set(2,kick);old=a.players[0];c._model_adjust(obs,a);assert a.players[0] is old;checks.append('preserves_simultaneous_own_kick')
c._receive_plan=(0,2,100);a=actions();old=a.players[0];c._model_adjust(obs,a);assert a.players[0] is old;checks.append('preserves_keeper_reception')
c._receive_plan=None;c._predicted_opponent={};a=actions();old=a.players[0];c._model_adjust(obs,a);assert a.players[0] is old;checks.append('unchanged_without_predicted_enemy_kick')
result=dict(passed=checks,scope='synthetic public-input action arbitration using native field constants, not native match or timing qualification')
(ROOT/'keeper-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
