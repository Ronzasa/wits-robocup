import json,sys,importlib.util,math,time
from pathlib import Path
sys.path.insert(0,'/workspace/work/exploit-lab/student-sdk')
from soccer import SoccerEnv,TeamAction
from soccer.helpers import load_controller
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('model_under_test',ROOT/'model-shot/team.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
rows=[]
for seed in (3249061101,3249061102):
 with SoccerEnv(config_path='/workspace/work/replay-finishing-handoffs/configs/default.toml',max_ticks=2400,per_decision_timeout_ms=20.) as env:
  observations=env.reset(seed=seed,kickoff_team=seed%2)
  for perspective,key,opposite in ((0,'team_a','team_b'),(1,'team_b','team_a')):
   actual=load_controller('/workspace/work/champion-hunt-20261025/opponent/team.py');actual.reset(seed)
   predicted=module._TargetTactics();predicted.reset(seed)
   native=actual.act(observations[opposite]);mirrored=predicted.act(module._Perspective(observations[key]))
   # Both are in the opponent's canonical frame at this point.
   errors=[]
   for pid,a in native.players.items():
    b=mirrored.players[pid]
    errors.extend(abs(x-y) for x,y in zip(a.movement,b.movement))
    assert (a.kick_direction is None)==(b.kick_direction is None)
    if a.kick_direction is not None:errors.extend(abs(x-y) for x,y in zip(a.kick_direction,b.kick_direction))
    errors.append(abs(a.kick_power-b.kick_power))
   assert max(errors)<1e-10,max(errors)
   rows.append(dict(seed=seed,perspective=perspective,max_command_error=max(errors)))
  # One real public-API step exercises each built candidate's opening branch.
  candidates=[load_controller(str(ROOT/name/'team.py')) for name in ('model-shot','model-intercept')]
  commands={}
  elapsed=[]
  for i,key in enumerate(('team_a','team_b')):
   start=time.perf_counter();commands[key]=candidates[i].act(observations[key]);elapsed.append((time.perf_counter()-start)*1000)
   assert len(commands[key].players)==5
  env.step(commands)
  rows.append(dict(seed=seed,one_native_step=True,opening_ms=elapsed))
(ROOT/'prediction-parity.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
