"""One-feature anticipatory keeper candidate on public mirrored model + raw v10."""
import ast,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=ast.parse((ROOT/'model-intercept/team.py').read_text())
controller=next(n for n in source.body if isinstance(n,ast.ClassDef) and n.name=='Guardiola2011')
controller.body=[n for n in controller.body if not(isinstance(n,ast.FunctionDef) and n.name=='_model_adjust')]
for n in controller.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='version' for t in n.targets):n.value=ast.Constant('public-model-keeper-v1')
extra=ast.parse('''
class _Add:
    def _model_adjust(self,obs,actions):
        keeper_action=actions.players.get(0)
        if keeper_action is None or keeper_action.kick_direction is not None:
            return actions
        if self._receive_plan is not None and self._receive_plan[0]==0:
            return actions
        # Simultaneous own kicks can change the pre-shot forecast depending
        # on capped impulse ordering. Retain baseline behavior in those duels.
        if any(a.kick_direction is not None for a in actions.players.values()):
            return actions
        bx,by=obs.ball.position
        vx,vy=obs.ball.velocity
        changed=False
        for q in obs.opponents:
            a=self._predicted_opponent.get(q.id)
            if (a is None or a.kick_direction is None
                    or q.kick_cooldown_ticks!=0
                    or math.hypot(q.position[0]-bx,q.position[1]-by)>self._range):
                continue
            predicted=self._model_step_player((q.id,*q.position,*q.velocity),a.movement)
            # The real engine moves a kicker before validating its range.
            # Other-player collisions may still invalidate this forecast.
            if math.hypot(predicted[1]-bx,predicted[2]-by)>self._range:
                continue
            vx,vy=self._requested_velocity(vx,vy,(a.kick_direction,a.kick_power))
            changed=True
        if not changed or vx>=-4.0 or math.hypot(vx,vy)<8.0:
            return actions
        keeper=obs.my_players[0]
        line=self._left+2.2
        if bx<=line or not 0.0<(line-bx)/vx<1.30:
            return actions
        x,y,sx,sy=bx,by,vx,vy
        wall=self._half_height-self._ball_radius
        target_y=None
        for tick in range(70):
            oldx,oldy=x,y
            x+=sx*self._dt
            y+=sy*self._dt
            if abs(y)>wall:
                side=1.0 if y>0.0 else -1.0
                y=side*2.0*wall-y
                sy=-side*abs(sy)*self._wall
            if x<=line:
                fraction=(line-oldx)/min(-1e-9,x-oldx)
                target_y=oldy+(y-oldy)*fraction
                # A current committed kick may reach just outside the posts;
                # keep the keeper's original goal-mouth target clamp.
                if abs(target_y)>self._goal_half+.5:
                    target_y=None
                break
            if abs(x)>self._right-self._ball_radius and abs(y)>self._goal_half:
                break
            sx*=self._friction
            sy*=self._friction
        if target_y is None:
            return actions
        target_y=_clip(target_y,-self._mouth,self._mouth)
        movement=self._move((keeper.id,*keeper.position,*keeper.velocity),(line,target_y))
        actions.set(0,PlayerAction(movement=movement))
        if actions.debug is not None:
            actions.debug['model_keeper']=(target_y,vx,vy)
        return actions
''').body[0]
controller.body.extend(extra.body)
ast.fix_missing_locations(source)
text='"""Experimental keeper anticipation from public predicted opponent commands."""\n'+ast.unparse(source)+'\n'
p=ROOT/'model-keeper/team.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
manifest=dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),base='Raw v10 + public mirrored target helper. Changes only keeper movement when a predicted enemy kick threatens the goal; preserves all existing kick commands and goalkeeper receptions.',prediction_validation='prediction-sequence-parity.json',qualification=False)
(ROOT/'keeper-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
