import argparse,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('folder');p.add_argument('--seeds',nargs='+',type=int,required=True);p.add_argument('--source',nargs=2,action='append',required=True);p.add_argument('--split',default='exposed development');a=p.parse_args()
folder=ROOT/a.folder;folder.mkdir()
items={}
for label,path in a.source:
 out=folder/'sources'/label/'team.py';out.parent.mkdir(parents=True);shutil.copy2(path,out)
 items[label]=dict(path=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest())
original=json.loads((ROOT/'screen-archive/registration.json').read_text())
reg={k:original[k] for k in ('opponent','config_path','config_hash','engine_version','deadline_ms','max_ticks','workers','formation','promotion')}
reg.update(split=a.split,candidates=items,seeds=a.seeds,order_seed=3249061000+len(a.folder))
(folder/'registration.json').write_text(json.dumps(reg,indent=2)+'\n')
print('Registered',len(items)*len(a.seeds)*4,'fixed matches at',folder)
