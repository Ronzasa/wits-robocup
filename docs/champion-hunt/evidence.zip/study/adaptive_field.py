"""Predeclared frozen paired field validation for adaptive generation2."""
import hashlib,json,random
from pathlib import Path
from collections import defaultdict
from adaptive_batch import observed_match
from benchmark import aggregate,points
ROOT=Path(__file__).resolve().parent
folder=ROOT/'adaptive-field-qualification'
reg=json.loads((folder/'registration.json').read_text())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for x in [*reg['sources'].values(),*reg['opponents'].values()]:assert digest(x['path'])==x['sha256']
rng=random.Random(reg['order_seed']);fixtures=[(style,seed,side,kick) for style in reg['opponents'] for seed in reg['seeds'] for side in (0,1) for kick in (True,False)];rng.shuffle(fixtures)
rows={n:[] for n in reg['sources']}
(folder/'metadata.json').write_text(json.dumps(dict(harness_sha256=digest(__file__),registration_sha256=digest(folder/'registration.json')),indent=2)+'\n')
with (folder/'matches.jsonl').open('x') as f:
 for index,(style,seed,side,kick) in enumerate(fixtures):
  names=list(rows);rng.shuffle(names)
  for n in names:
   result,telemetry,roster=observed_match(reg['sources'][n]['path'],reg['opponents'][style]['path'],seed,side,kick,reg)
   row=dict(source=n,opponent_name=style,seed=seed,candidate_slot=side,candidate_takes_kickoff=kick,result=result,telemetry=telemetry,initial_roster=roster)
   rows[n].append(row);f.write(json.dumps(row)+'\n');f.flush()
  if (index+1)%8==0:print('FIELD',index+1,'/160',{n:sum(points(r) for r in rs) for n,rs in rows.items()},flush=True)
summary={n:aggregate(rs) for n,rs in rows.items()}
key=lambda r:(r['opponent_name'],r['seed'],r['candidate_slot'],r['candidate_takes_kickoff'])
a={key(r):r for r in rows['adaptive-finalist']};b={key(r):r for r in rows['frozen-upload']};blocks=defaultdict(list)
for k,r in a.items():blocks[r['seed']].append(points(r)-points(b[k]))
means=[sum(v)/len(v) for _,v in sorted(blocks.items())];rng=random.Random(3249068002)
boots=sorted(sum(rng.choices(means,k=len(means)))/len(means) for _ in range(20000))
by={style:{n:aggregate([r for r in rs if r['opponent_name']==style]) for n,rs in rows.items()} for style in reg['opponents']}
active={style:sum(r['telemetry']['adaptive']['active_at_end'] is True for r in rows['adaptive-finalist'] if r['opponent_name']==style) for style in reg['opponents']}
diff=(summary['adaptive-finalist']['policy_timeouts']-summary['frozen-upload']['policy_timeouts'])*1000/len(rows['adaptive-finalist'])
report=dict(summary=summary,paired_points_difference_per_fixture=sum(means)/len(means),paired_seed_block_95=[boots[500],boots[19499]],paired_seed_block_975=[boots[250],boots[19749]],by_opponent=by,specialist_activated_by_opponent=active,additional_raw_misses_per1000=diff,promotion=False,no_qualification_tuning=True)
(folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
for x in [*reg['sources'].values(),*reg['opponents'].values()]:assert digest(x['path'])==x['sha256']
print('FINAL',json.dumps(report),flush=True)
