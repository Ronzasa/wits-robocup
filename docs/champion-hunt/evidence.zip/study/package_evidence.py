"""Package executed public match evidence without caches or native binaries."""
import argparse
import hashlib
import json
import shutil
import zipfile
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study-root', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    args = parser.parse_args()
    study, repo = args.study_root.resolve(), args.repo.resolve()
    dest = repo / 'docs/champion-hunt'
    archive = dest / 'evidence.zip'
    if archive.exists():
        parser.error('Archive already exists; preserve earlier evidence.')
    protected = {
        'my-team/team.py': '553bcd85a537d57a43c16e4498fab402fbbabb940e15cb8c5aa110d4c6fa9a5e',
        'champions/v10.0/team.py': '5af280cea6b6c8f9f66db5776ad5ce02dbcf51ee6c6e57690fea2c307ae0b1f6',
        'champions/v9.1/team.py': 'c7fce081f12f283b9c9f9ee200f0dcc33769339a60bf535fc3446613612fabf6',
        'experiments/champion-candidate-review/uploaded/team.py': '7708f5d3b10202092f1fce73abfc61a5d7a61d91326d95d69cec872d4c7ba758',
    }
    frozen = {
        'experiments/champion-hunt-adaptive/team.py': '27b3ef88ddede6267fd0583278b821c2abcd27de38772dfe9051307778e880ce',
        'experiments/champion-hunt/team.py': '05d9ce27b4e6f54db44a3e5c8b6a929e0dbce0dcf00b5a0b69f9e6ebf6681196',
    }
    for rel, expected in {**protected, **frozen}.items():
        assert digest(repo / rel) == expected, rel
    copies = {
        'plan.json': 'original-plan.json',
        'selection.json': 'specialist-selection.json',
        'adaptive-plan.json': 'adaptive-plan.json',
        'adaptive-selection.json': 'adaptive-selection.json',
        'qualification/registration.json': 'specialist-direct-registration.json',
        'qualification/summary.json': 'specialist-direct-summary.json',
        'transfer-audit/summary.json': 'specialist-transfer-summary.json',
        'adaptive-qualification/registration.json': 'adaptive-direct-registration.json',
        'adaptive-qualification/summary.json': 'adaptive-direct-summary.json',
        'adaptive-field-qualification/registration.json': 'adaptive-field-registration.json',
        'adaptive-field-qualification/summary.json': 'adaptive-field-summary.json',
        'adaptive-intake.json': 'adaptive-intake.json',
        'final-intake.json': 'specialist-intake.json',
        'adaptive-review/audit-v3.json': 'adaptive-helper-audit.json',
        'adaptive-review/cold-siege-v3.json': 'adaptive-kickoff-regression.json',
        'native-cache-parity.json': 'native-cache-parity.json',
        'native-cache-parity-slow.json': 'native-cache-parity-slow.json',
        'final-audit.json': 'final-audit.json',
        'final-audit.md': 'final-audit.md',
    }
    (dest / 'results').mkdir(parents=True, exist_ok=True)
    for src, dst in copies.items():
        shutil.copyfile(study / src, dest / 'results' / dst)
    payload = {}
    for path in study.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            payload['study/' + path.relative_to(study).as_posix()] = path
    repo_files = [*frozen, 'tools/benchmarks/default_roster.py',
                  'tools/benchmarks/benchmark.py', 'tools/benchmarks/champion_hunt_match.py',
                  'configs/default.toml', 'docs/champion-hunt/README.md']
    for rel in repo_files:
        payload['repo/' + rel] = repo / rel
    manifest = {
        'schema': 1,
        'base_commit': '5249bf925b579f9dde9b9739694670bfa2207493',
        'experimental_branch': 'sandbox-champion-hunt',
        'frozen_sources': frozen,
        'protected_sources_unchanged': protected,
        'excluded': ['__pycache__', '*.pyc', 'SDK/native binaries'],
        'files': {name: {'sha256': digest(path), 'bytes': path.stat().st_size}
                  for name, path in sorted(payload.items())},
    }
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, path in sorted(payload.items()):
            output.write(path, name)
        output.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        for name, record in manifest['files'].items():
            data = check.read(name)
            assert len(data) == record['bytes']
            assert hashlib.sha256(data).hexdigest() == record['sha256'], name
    manifest['archive'] = {'path': 'evidence.zip', 'bytes': archive.stat().st_size,
                           'sha256': digest(archive), 'crc_and_all_payload_hashes_verified': True}
    (dest / 'evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'files': len(payload), **manifest['archive']}, indent=2))


if __name__ == '__main__':
    main()
