"""Frozen-batch native head-to-head experiments; no automatic promotion."""
import argparse,hashlib,json,random,sys
from collections import defaultdict
from datetime import datetime,timezone
from pathlib import Path
REPO=Path('/workspace/work/replay-finishing-handoffs')
sys.path.insert(0,str(REPO/'tools/benchmarks'))
from benchmark import aggregate,points
from default_roster import native_match

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def compare(rows):
 blocks=defaultdict(list);gd=defaultdict(list)
 for r in rows:
  a,b=[r['result']['score'][i] for i in (r['candidate_slot'],1-r['candidate_slot'])]
  blocks[r['seed']].append(3 if a>b else -3 if a<b else 0)
  gd[r['seed']].append(a-b)
 means=lambda d:[sum(v)/len(v) for _,v in sorted(d.items())]
 rng=random.Random(3249060099)
 def interval(values):
  b=sorted(sum(rng.choices(values,k=len(values)))/len(values) for _ in range(10000))
  return [b[250],b[9749]]
 return dict(paired_direct_points_difference_per_fixture=sum(means(blocks))/len(blocks),paired_points_seed_bootstrap_95=interval(means(blocks)),paired_gd_seed_bootstrap_95=interval(means(gd)))

def run(folder):
 folder=Path(folder);reg=json.loads((folder/'registration.json').read_text())
 for item in [*reg['candidates'].values(),reg['opponent']]:assert digest(item['path'])==item['sha256']
 (folder/'metadata.json').write_text(json.dumps(dict(started=datetime.now(timezone.utc).isoformat(),registration_sha256=digest(folder/'registration.json'),harness_sha256=digest(__file__),native_driver_sha256=digest(REPO/'tools/benchmarks/default_roster.py')),indent=2)+'\n')
 rng=random.Random(reg['order_seed'])
 fixtures=[(seed,side,kick) for seed in reg['seeds'] for side in (0,1) for kick in (True,False)];rng.shuffle(fixtures)
 rows={label:[] for label in reg['candidates']}
 with (folder/'matches.jsonl').open('x') as f:
  for index,(seed,side,kick) in enumerate(fixtures):
   labels=list(rows);rng.shuffle(labels)
   for label in labels:
    result,telemetry,roster=native_match(reg['candidates'][label]['path'],reg['opponent']['path'],seed,side,kick,reg)
    assert result['kickoff_team']==(side if kick else 1-side)
    row=dict(source=label,opponent_name='frozen-upload',seed=seed,candidate_slot=side,candidate_takes_kickoff=kick,result=result,telemetry=telemetry,initial_roster=roster)
    rows[label].append(row);f.write(json.dumps(row)+'\n');f.flush()
   print('PROGRESS',index+1,'/',len(fixtures),{n:sum(points(r) for r in rs) for n,rs in rows.items()},flush=True)
 summaries={n:aggregate(rs) for n,rs in rows.items()}
 for n,s in summaries.items():
  s['incomplete_fixtures']=sum(r['result']['ticks']!=2400 or r['result']['terminal_reason']!='time_limit' for r in rows[n])
  s.update(compare(rows[n]))
  mirror=aggregate([dict(r,candidate_slot=1-r['candidate_slot']) for r in rows[n]])
  s['opponent_points']=mirror['points'];s['opponent_errors']=mirror['policy_errors'];s['opponent_raw_misses']=mirror['policy_timeouts']
  s['additional_raw_misses_per1000']=(s['policy_timeouts']-mirror['policy_timeouts'])*1000/s['matches']
 for item in [*reg['candidates'].values(),reg['opponent']]:assert digest(item['path'])==item['sha256']
 out=dict(summaries=summaries,split=reg['split'],promotion=False,finished=datetime.now(timezone.utc).isoformat())
 (folder/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
 print('FINAL',json.dumps(summaries),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder');run(p.parse_args().folder)
