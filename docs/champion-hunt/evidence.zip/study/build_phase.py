import ast,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=(ROOT/'agent-wall/v10-boundary-crossing/team.py').read_text()
node=next(n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name=='_siege_act')
method=''.join(source.splitlines(True)[node.lineno-1:node.end_lineno])
items={}
for name,value in [('speed75',7.5),('speed9',9.0),('speed12',12.0),('speed15',15.0),('wide83',None)]:
 changed=method.replace('10.5',str(value)) if value is not None else method.replace('self._goal_half+.90','self._goal_half+1.30')
 assert changed!=method
 text=source.replace(method,changed)
 p=ROOT/'parent-phase'/name/'team.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);ast.parse(text)
 items[name]=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(ROOT/'parent-phase/manifest.json').write_text(json.dumps(items,indent=2)+'\n')
print('Five isolated carry phase/width variants frozen.')
