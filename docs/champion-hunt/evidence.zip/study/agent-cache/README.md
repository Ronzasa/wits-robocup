Frozen variants are built only from the registered bait-slow source SHA256
`9d40fad4bc049e205f3131b591b5a14f4e99d6d2f02ebe6f8a754ea83e3b7fdd`.

- `cache-only/team.py`: per-goal immutable fixed bodies, initial carrier move,
  and cooldown values; both launch/body orders remain simulated. Existing
  normal-play methods remain AST-identical.
- `touch-table-only/team.py`: independent normal-play change; `_touch_path`
  reads the already-existing `_reach_table[steps]` instead of recalculating
  the exact same coast/reach expressions. No new cache or tracked tuples.
- `cache-all/team.py`: the two changes combined.

The siege cache is passed as a local argument and never retained on the
controller. Every candidate/order copies its mutable own state and cooldown
list. Fixed bodies preserve the original friend order, a carrier placeholder,
and both enemy-first alternatives. Candidate-specific movement, impulses,
per-impulse caps, contacts, bounds, and cooldown evolution remain unchanged.

The touch table is constructed by `_setup` from the exact original float
expressions. `_dt`, `_acc`, and `_damping` are assigned only in `_setup`.
The lookup covers `steps = tick + 1`, with tick 1..11, inside the original
table domain 0..82. There is no observation-dependent cache to invalidate.

`python build.py` reproduces the wall cache. `python build_touch_table.py`
reproduces the independent and combined touch-table variants. Existing frozen
sources are not modified. `manifest.json` and `manifest-touch-table.json`
contain exact paths, SHA256 values, parent hashes, and byte counts.

Native-free checks: `python parity.py touch-table-only` and
`python parity.py cache-all`. Each passed 111 full-act cases, including 9
normal full-act controlled-touch calls and 144 paired normal touch forecasts;
90 direct touch forecasts with different fields/cooldowns/opponents; 132
hexadecimal-float comparisons against the original coast/reach formulas;
2,160 siege candidate path pairs; 240 direct collision-heavy paths; and
22,416 exact intermediate ball/carrier/cooldown states. Tests cover both
orders, both corner signs, all carrier slots, and changed friendly order.
No native engine calls, qualification seeds, timing controls, or timers are
used by this work.

The observed original 22.381 ms miss occurred in normal/opening play. The
wall cache improves a separate siege hot path. The table reuse reduces
repeated arithmetic in the profiled touch-path work; this does not establish
the cause of the original miss or erase it from the prior report.
