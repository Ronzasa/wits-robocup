"""Build independent/combined exact reuse of the existing setup reach table."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent/"final-development-sources/bait-slow/team.py"
PARENT_SHA256="9d40fad4bc049e205f3131b591b5a14f4e99d6d2f02ebe6f8a754ea83e3b7fdd"
CACHE=ROOT/"cache-only/team.py"
CACHE_SHA256="d1f23e6257da11fd860f51fb2093fdb47547a3cab1f966603b45976ca38b4b5d"
assert hashlib.sha256(PARENT.read_bytes()).hexdigest()==PARENT_SHA256
assert hashlib.sha256(CACHE.read_bytes()).hexdigest()==CACHE_SHA256
before='''            coast=self._dt*self._damping*(1.0-self._damping**steps)/(1.0-self._damping)
            reach=(self._dt*self._acc/(1.0-self._damping)
                   *(steps-self._damping*(1.0-self._damping**steps)/(1.0-self._damping)))'''
after="            coast,reach=self._reach_table[steps]"
manifest={"parent":str(PARENT),"parent_sha256":PARENT_SHA256,
          "proof":"_setup materializes the exact same coast/reach expressions; steps is 2..12. _dt, _acc and _damping are assigned only in _setup.",
          "native_engine_calls":0,"qualification_seeds_used":0,"variants":{}}
for name,base in (("touch-table-only",PARENT),("cache-all",CACHE)):
    source=base.read_text()
    assert source.count(before)==1
    source=source.replace(before,after,1)
    ast.parse(source)
    output=ROOT/name/"team.py"
    output.parent.mkdir(exist_ok=True)
    output.write_text(source)
    manifest["variants"][name]={"path":str(output),"sha256":hashlib.sha256(source.encode()).hexdigest(),
        "bytes":len(source.encode()),"base":str(base),"base_sha256":hashlib.sha256(base.read_bytes()).hexdigest(),
        "changed_existing_methods":["_touch_path"] if name=="touch-table-only" else ["_siege_clearance_path","_siege_goal","_touch_path"]}
    assert len(source.encode())<=256*1024
(ROOT/"manifest-touch-table.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(manifest,indent=2))
