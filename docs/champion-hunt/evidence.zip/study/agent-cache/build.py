"""Build a frozen, decision-preserving siege cache from the registered source."""
import ast
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / "final-development-sources/bait-slow/team.py"
PARENT_SHA256 = "9d40fad4bc049e205f3131b591b5a14f4e99d6d2f02ebe6f8a754ea83e3b7fdd"


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after, 1)


source = PARENT.read_text()
assert hashlib.sha256(source.encode()).hexdigest() == PARENT_SHA256
source = replace_once(source, "        side=1. if by>=0. else -1.\n        best=None\n        for gy", "        cache=self._siege_clearance_cache(p,movement,frames)\n        side=1. if by>=0. else -1.\n        best=None\n        for gy")
source = replace_once(source,
    "self._siege_clearance_path(p,(bx,by,vx,vy),movement,kick,frames,order)",
    "self._siege_clearance_path(p,(bx,by,vx,vy),movement,kick,frames,order,cache)")
source = replace_once(source,
    "    def _siege_clearance_path(self,p,ball,movement,kick,frames,enemy_first):\n",
    '''    def _siege_clearance_cache(self,p,movement,frames):
        # These values are independent of the candidate launch and order.
        # None preserves the carrier's exact place among friendly bodies.
        obs=self._siege_obs
        cooldowns=tuple(q.kick_cooldown_ticks for q in obs.opponents)
        own=[p[1],p[2],p[3],p[4]]
        own[2]=own[2]*self._damping+movement[0]*self._acc
        own[3]=own[3]*self._damping+movement[1]*self._acc
        speed=math.hypot(own[2],own[3])
        if speed>self._speed:own[2]*=self._speed/speed;own[3]*=self._speed/speed
        own[0]=_clip(own[0]+own[2]*self._dt,self._left+1.,self._right-1.)
        own[1]=_clip(own[1]+own[3]*self._dt,-self._half_height+1.,self._half_height-1.)
        body_frames=[None]
        for n in range(1,13):
            coast=self._dt*self._damping*(1.-self._damping**n)/(1.-self._damping)
            damping=self._damping**n
            bodies=[]
            for friend in obs.my_players:
                if friend.id==p[0]:bodies.append(None)
                else:
                    bodies.append((friend.position[0]+friend.velocity[0]*coast,
                                   friend.position[1]+friend.velocity[1]*coast,
                                   friend.velocity[0]*damping,friend.velocity[1]*damping))
            enemy_bodies=[q[1:] for q in frames[n]]
            body_frames.append((tuple(bodies+enemy_bodies),tuple(enemy_bodies+bodies)))
        return cooldowns,tuple(own),tuple(body_frames)

    def _siege_clearance_path(self,p,ball,movement,kick,frames,enemy_first,cache=None):
''')
source = replace_once(source,
    '''        obs=self._siege_obs
        cooldowns=[q.kick_cooldown_ticks for q in obs.opponents]
        own=[p[1],p[2],p[3],p[4]]
        assists=0
        for n in range(1,13):''',
    '''        if cache is None:cache=self._siege_clearance_cache(p,movement,frames)
        cooldowns=list(cache[0])
        own=list(cache[1])
        body_frames=cache[2]
        own_kick=(kick[0][0]*self._impulse*kick[1],kick[0][1]*self._impulse*kick[1])
        wall=self._half_height-self._ball_radius
        xwall=self._right-self._ball_radius
        assists=0
        for n in range(1,13):''')
source = replace_once(source,
    '''            move=movement if n==1 else self._move((p[0],*own),(x+vx*.1,y+vy*.1))
            own[2]=own[2]*self._damping+move[0]*self._acc
            own[3]=own[3]*self._damping+move[1]*self._acc
            speed=math.hypot(own[2],own[3])
            if speed>self._speed:own[2]*=self._speed/speed;own[3]*=self._speed/speed
            own[0]=_clip(own[0]+own[2]*self._dt,self._left+1.,self._right-1.)
            own[1]=_clip(own[1]+own[3]*self._dt,-self._half_height+1.,self._half_height-1.)''',
    '''            if n>1:
                move=self._move((p[0],*own),(x+vx*.1,y+vy*.1))
                own[2]=own[2]*self._damping+move[0]*self._acc
                own[3]=own[3]*self._damping+move[1]*self._acc
                speed=math.hypot(own[2],own[3])
                if speed>self._speed:own[2]*=self._speed/speed;own[3]*=self._speed/speed
                own[0]=_clip(own[0]+own[2]*self._dt,self._left+1.,self._right-1.)
                own[1]=_clip(own[1]+own[3]*self._dt,-self._half_height+1.,self._half_height-1.)''')
source = replace_once(source,
    "            own_kick=(kick[0][0]*self._impulse*kick[1],kick[0][1]*self._impulse*kick[1])\n", "")
source = replace_once(source, "            wall=self._half_height-self._ball_radius\n", "")
source = replace_once(source, "            xwall=self._right-self._ball_radius\n", "")
source = replace_once(source,
    '''            # Predict all current friendly bodies; unrelated future steering
            # and player/player collisions remain unmodelled uncertainty.
            bodies=[]
            for friend in obs.my_players:
                if friend.id==p[0]:bodies.append(tuple(own))
                else:
                    coast=self._dt*self._damping*(1.-self._damping**n)/(1.-self._damping)
                    bodies.append((friend.position[0]+friend.velocity[0]*coast,
                                   friend.position[1]+friend.velocity[1]*coast,
                                   friend.velocity[0]*self._damping**n,friend.velocity[1]*self._damping**n))
            enemy_bodies=[q[1:] for q in after]
            if enemy_first:bodies=enemy_bodies+bodies
            else:bodies+=enemy_bodies
            for px,py,pvx,pvy in bodies:''',
    '''            # Preserve both body's orders and the carrier's original slot.
            for body in body_frames[n][enemy_first]:
                px,py,pvx,pvy=own if body is None else body''')

tree=ast.parse(source)
assert all(not isinstance(node,(ast.Import,ast.ImportFrom)) or
           ((isinstance(node,ast.Import) and all(n.name=="math" for n in node.names)) or
            (isinstance(node,ast.ImportFrom) and node.module=="soccer"))
           for node in tree.body)
variant=ROOT/"cache-only/team.py"
variant.parent.mkdir(exist_ok=True)
variant.write_text(source)
manifest={
    "parent":str(PARENT),"parent_sha256":PARENT_SHA256,
    "variants":{"cache-only":{"path":str(variant),
        "sha256":hashlib.sha256(source.encode()).hexdigest(),"bytes":len(source.encode()),
        "semantics":"Both launch/order predictions and all policies remain unchanged.",
        "cache_scope":"One _siege_goal invocation; no cross-observation reuse.",
        "changes":["Share exact fixed friendly coast/damping bodies and enemy slices across launches/orders.",
                   "Share first carrier movement and initial cooldown tuple across launches/orders.",
                   "Move constant own kick/wall calculations outside the 12-tick inner loop."],
        "private_fields_read":"Existing policy-owned _siege_obs only.",
        "native_engine_calls":0,"qualification_seeds_used":0}}
}
assert manifest["variants"]["cache-only"]["bytes"] <= 256*1024
(ROOT/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(manifest,indent=2))
