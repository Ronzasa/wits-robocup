"""Native-free exact action and intermediate physics parity for the siege cache."""
import ast
import hashlib
import json
import math
import random
import sys
from pathlib import Path
from types import SimpleNamespace as NS


ROOT=Path(__file__).resolve().parent
sys.path.insert(0,"/workspace/work/exploit-lab/student-sdk")
FIELD=NS(width=100.,height=60.,goal_width=14.,my_goal=(-50.,0.),
         opponent_goal=(50.,0.),simulation_hz=20,max_speed=8.,
         acceleration=20.,ball_friction=.985,kick_impulse=22.,
         kick_range=2.2,player_radius=1.,ball_radius=.45,
         centre_circle_radius=9.15)


def load(path,label):
    source=path.read_text()
    before="            if x>self._right and abs(y)<=self._goal_half:return n,assists"
    assert source.count(before)==1
    source=source.replace(before,
        "            self._parity_trace.append((n,x,y,vx,vy,tuple(own),tuple(cooldowns),assists))\n"+before)
    scope={"__name__":"cache_parity_"+label}
    exec(compile(source,str(path),"exec"),scope)
    return scope["Guardiola2011"]


def methods(path):
    tree=ast.parse(path.read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef))
    return {n.name:ast.dump(n,include_attributes=False)
            for n in cls.body if isinstance(n,ast.FunctionDef)}


def observation(bx,by,vx,vy,wall,side,score=(0,0),offset=0.):
    sign=1. if by>=0 else -1.
    own=[((-48.8,0.),(.2,0.)),((20.,-6.),(.1,.2)),
         ((30.,6.),(-.3,.4)),((bx-1.,by+.6*sign),(8.,offset)),
         ((35.,0.),(.4,-.2))]
    players=[NS(id=i,position=position,velocity=velocity,
                kick_cooldown_ticks=0,has_control=i==3)
             for i,(position,velocity) in enumerate(own)]
    positions=[(48.8,y) for y in (5.6,2.8,0.,-2.8,-5.6)] if wall else [
        (45.,0.),(34.,-8.),(32.,7.),(15.,-12.),(12.,12.)]
    opponents=[NS(id=i,position=position,velocity=(offset*(i-2),offset*.2),
                  kick_cooldown_ticks=(i+int(abs(offset)*10))%4,has_control=False)
               for i,position in enumerate(positions)]
    return NS(field=FIELD,opponent_goal=FIELD.opponent_goal,my_goal=FIELD.my_goal,
              tick=100,max_ticks=2400,score=score,time_remaining=80.,phase="ATTACK",
              side=side,team=side,events=[],my_players=players,opponents=opponents,
              ball=NS(position=(bx,by),velocity=(vx,vy),controlling_team=0,
                      controlling_player=3,last_touch=3),
              can_kick=lambda i: players[i].kick_cooldown_ticks==0 and
                  math.hypot(players[i].position[0]-bx,players[i].position[1]-by)<=FIELD.kick_range)


def serial(action):
    result={"players":{i:p.as_dict() for i,p in action.players.items()},"debug":action.debug}
    for p in action.players.values():
        assert all(math.isfinite(v) for v in p.movement)
        assert math.hypot(*p.movement)<=1.+1e-9
        if p.kick_direction is not None:
            assert all(math.isfinite(v) for v in p.kick_direction)
            assert abs(math.hypot(*p.kick_direction)-1.)<1e-8
            assert 0.<=p.kick_power<=1.
    return result


def watch(controller):
    records=[]
    raw=controller._siege_clearance_path
    def wrapped(*args):
        controller._parity_trace=[]
        result=raw(*args)
        records.append((args[:6],result,controller._parity_trace))
        return result
    controller._siege_clearance_path=wrapped
    return records


variant=sys.argv[1] if len(sys.argv)>1 else "cache-only"
manifest_name="manifest.json" if variant=="cache-only" else "manifest-touch-table.json"
manifest=json.loads((ROOT/manifest_name).read_text())
parent=Path(manifest["parent"])
meta=manifest["variants"][variant]
candidate=Path(meta["path"])
assert hashlib.sha256(parent.read_bytes()).hexdigest()==manifest["parent_sha256"]
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==meta["sha256"]
old_methods,new_methods=methods(parent),methods(candidate)
changed=sorted(k for k in old_methods if old_methods[k]!=new_methods[k])
expected=meta.get("changed_existing_methods",["_siege_clearance_path","_siege_goal"])
assert changed==expected,changed
assert set(new_methods)-set(old_methods)==(set() if variant=="touch-table-only" else {"_siege_clearance_cache"})
Old,New=load(parent,"old"),load(candidate,"new")
report={"variant":variant,"native_engine_calls":0,"qualification_seeds_used":0,
        "changed_existing_methods":changed,"exact_action_cases":0,
        "exact_candidate_path_pairs":0,"exact_intermediate_tick_pairs":0,
        "direct_path_cases":0,"carrier_slots":[],"orders":[],
        "description":"Exact Python equality, including each simulated ball/carrier/cooldown state after body contacts."}

# Full act includes ordinary opening, positive/negative wall staging, both
# corners, both sides, scoring/eligibility branches and nonzero body velocity.
for side in (0,1):
    for score in ((0,0),(1,0),(1,1)):
        for label,bx,by,vx,vy,wall in (
            ("normal",25.,0.,0.,0.,False),
            ("normal-edge",43.,9.,7.,-1.,False),
            ("wall-stage",25.,0.,0.,0.,True),
            ("corner-positive",48.9,7.9,10.5,0.,True),
            ("corner-negative",48.9,-7.9,10.5,0.,True),
            ("wall-top",46.2,9.5,6.,-1.5,True),
            ("wall-bottom",46.2,-9.5,6.,1.5,True),
            ("wall-fast",48.1,7.1,28.,-2.,True)):
            for offset in (0.,.37):
                obs=observation(bx,by,vx,vy,wall,side,score,offset)
                old,new=Old(),New()
                old_log,new_log=watch(old),watch(new)
                assert serial(old.act(obs))==serial(new.act(obs)),(side,score,label,offset)
                assert old_log==new_log,(side,score,label,offset,"path state")
                report["exact_action_cases"]+=1
                report["exact_candidate_path_pairs"]+=len(old_log)
                report["exact_intermediate_tick_pairs"]+=sum(len(r[2]) for r in old_log)

# Direct paths deliberately vary the carrier slot, friendly order, nonzero
# coast, enemy cooldown and collision-heavy arbitrary public frame geometry.
# No engine or match seeds are used. This RNG only generates local numbers.
rng=random.Random(578602)
orders=set()
slots=set()
for case in range(120):
    sign=(-1.,1.)[case%2]
    obs=observation(47.+rng.random()*2.,sign*(6.7+rng.random()*3.),
                    rng.uniform(-15.,29.),rng.uniform(-5.,5.),True,case%2)
    pid=case%5
    slots.add(pid)
    bx,by=obs.ball.position
    friends=obs.my_players
    for friend in friends:
        friend.position=(bx+rng.uniform(-2.5,2.5),by+rng.uniform(-2.5,2.5))
        friend.velocity=(rng.uniform(-8.,8.),rng.uniform(-8.,8.))
    friends[pid].position=(bx+rng.uniform(-1.5,1.5),by+rng.uniform(-1.5,1.5))
    if case%3==0:
        friends.reverse()
    carrier=next(q for q in friends if q.id==pid)
    p=(carrier.id,*carrier.position,*carrier.velocity)
    move=(rng.uniform(-1.,1.),rng.uniform(-1.,1.))
    angle=rng.uniform(-math.pi,math.pi)
    kick=((math.cos(angle),math.sin(angle)),rng.random())
    frames=[]
    for n in range(13):
        frames.append([(q.id,bx+rng.uniform(-3.,3.),by+rng.uniform(-3.,3.),
                        rng.uniform(-8.,8.),rng.uniform(-8.,8.)) for q in obs.opponents])
    for order in (False,True):
        old,new=Old(),New()
        for c in (old,new):
            c._setup(FIELD)
            c._siege_obs=obs
            c._parity_trace=[]
        a=old._siege_clearance_path(p,(*obs.ball.position,*obs.ball.velocity),move,kick,frames,order)
        b=new._siege_clearance_path(p,(*obs.ball.position,*obs.ball.velocity),move,kick,frames,order)
        assert a==b,(case,order,a,b)
        assert old._parity_trace==new._parity_trace,(case,order,"state")
        report["direct_path_cases"]+=1
        report["exact_intermediate_tick_pairs"]+=len(old._parity_trace)
        orders.add(order)
report["orders"]=sorted(orders)
report["carrier_slots"]=sorted(slots)

# The existing table uses exactly the original expression and operation order.
# Compare hexadecimal floats across repeated setup with multiple field profiles.
table_checks=0
for hz in (10,20,30,60):
    for acceleration in (12.,20.,34.):
        field=NS(**vars(FIELD))
        field.simulation_hz=hz
        field.acceleration=acceleration
        c=New()
        c._setup(field)
        for steps in range(2,13):
            coast=c._dt*c._damping*(1.0-c._damping**steps)/(1.0-c._damping)
            reach=(c._dt*c._acc/(1.0-c._damping)
                   *(steps-c._damping*(1.0-c._damping**steps)/(1.0-c._damping)))
            assert tuple(v.hex() for v in (coast,reach))==tuple(v.hex() for v in c._reach_table[steps])
            table_checks+=1
report["exact_table_entry_checks"]=table_checks

# Exercise ordinary full act with pressure close enough to reach the profiled
# controlled-touch search, comparing every touch candidate and returned action.
controlled_calls=touch_calls=0
for bx in (-10.,5.,15.,25.,40.):
    for by in (-5.,0.,5.):
        obs=observation(bx,by,4.,.3,False,0)
        for index,enemy in enumerate(obs.opponents):
            enemy.position=(bx+3.+index*1.3,by+(index-2)*1.3)
            enemy.kick_cooldown_ticks=index%3
        old,new=Old(),New()
        records=[]
        for c in (old,new):
            touch_log=[]
            controlled_log=[]
            raw_touch=c._touch_path
            raw_controlled=c._controlled_touch
            def wrapped_touch(*args,_raw=raw_touch,_log=touch_log):
                value=_raw(*args)
                _log.append((args,value))
                return value
            def wrapped_controlled(*args,_raw=raw_controlled,_log=controlled_log):
                value=_raw(*args)
                _log.append((args,value))
                return value
            c._touch_path=wrapped_touch
            c._controlled_touch=wrapped_controlled
            records.append((serial(c.act(obs)),touch_log,controlled_log))
        assert records[0]==records[1],(bx,by,"normal controlled-touch")
        controlled_calls+=len(records[0][2])
        touch_calls+=len(records[0][1])
        report["exact_action_cases"]+=1
assert controlled_calls>0 and touch_calls>0,(controlled_calls,touch_calls)
report["normal_full_act_controlled_touch_calls"]=controlled_calls
report["normal_full_act_touch_path_pairs"]=touch_calls

# Repeated direct calls change cooldown dictionaries, opponents and setup field.
# No call-scoped or tick-scoped state is added by the table reuse.
touch_direct=0
for case in range(90):
    field=NS(**vars(FIELD))
    field.simulation_hz=(10,20,30)[case%3]
    bx,by=rng.uniform(-20.,45.),rng.uniform(-15.,15.)
    p=(3,bx-.8,by+.1,rng.uniform(-7.,7.),rng.uniform(-7.,7.))
    vx,vy=rng.uniform(-12.,12.),rng.uniform(-5.,5.)
    opponents=[(i,bx+rng.uniform(-4.,4.),by+rng.uniform(-4.,4.),
                rng.uniform(-6.,6.),rng.uniform(-6.,6.)) for i in range(5)]
    angle=rng.uniform(-math.pi,math.pi)
    kick=((math.cos(angle),math.sin(angle)),rng.random())
    move=(rng.uniform(-.7,.7),rng.uniform(-.7,.7))
    old,new=Old(),New()
    for c in (old,new):
        c._setup(field)
        c._enemy_cooldowns={i:(i+case)%8 for i in range(5)}
    a=old._touch_path(p,bx,by,vx,vy,kick,move,opponents)
    b=new._touch_path(p,bx,by,vx,vy,kick,move,opponents)
    assert a==b,(case,"direct touch")
    touch_direct+=1
report["exact_direct_touch_path_pairs"]=touch_direct
report["status"]="passed"
output="parity.json" if variant=="cache-only" else "parity-"+variant+".json"
(ROOT/output).write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
