"""Read-only static fixture for the frozen opponent's wall-break branch.

No SoccerEnv, match loop, source mutation, or qualification seeds.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace as N

sys.dont_write_bytecode = True
sys.path.insert(0, '/workspace/work/exploit-lab/student-sdk')
from soccer import PlayerAction, TeamAction

SOURCE = Path('/workspace/work/champion-hunt-20261025/opponent/team.py')
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == '7708f5d3b10202092f1fce73abfc61a5d7a61d91326d95d69cec872d4c7ba758'
spec = importlib.util.spec_from_file_location('frozen_opponent_bait_audit', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
controller = module.Guardiola2011()

wall = [N(id=5+i, position=(48.8, y))
        for i, y in enumerate((-5.4, -1.8, 1.8, 5.4))]
friends = [N(id=i, position=(20., 0.) if i == 1 else (0., 20.+i))
           for i in range(5)]

def inspect(outlet):
    obs = N(opponent_goal=(50., 0.),
            field=N(player_radius=1., goal_width=14., ball_radius=.45),
            opponents=wall+[N(id=9, position=outlet)],
            my_players=friends, ball=N(position=(20., 0.)),
            can_kick=lambda pid: pid == 1)
    actions = TeamAction(players={i: PlayerAction() for i in range(5)})
    controller._wall_break(obs, actions)
    return {
        'kickers': [pid for pid, a in actions.players.items()
                    if a.kick_direction is not None],
        'pushers': [pid for pid, a in actions.players.items()
                    if a.movement != (0., 0.)],
        'kick_directions': [a.kick_direction for a in actions.players.values()
                            if a.kick_direction is not None],
    }

independent = inspect((10., 20.))
assert independent['kickers'] == [1]
ux, uy = independent['kick_directions'][0]
screen_y = uy/ux * (35.-20.)
screened = inspect((35., screen_y))
assert screened['kickers'] == []
assert len(screened['pushers']) == 3
print(json.dumps({'independent_outlet': independent,
                  'outlet_on_largest_gap_ray': screened}, indent=2))
