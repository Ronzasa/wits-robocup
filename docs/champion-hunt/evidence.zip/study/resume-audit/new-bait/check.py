"""Static frozen-policy geometry and complete act smoke checks; no engine loop."""
import ast
from collections import Counter
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace as N

sys.dont_write_bytecode = True
sys.path.insert(0, '/workspace/work/exploit-lab/student-sdk')
from soccer import PlayerAction, TeamAction

ROOT = Path(__file__).resolve().parent
FROZEN = Path('/workspace/work/champion-hunt-20261025/opponent/team.py')
FROZEN_SHA = '7708f5d3b10202092f1fce73abfc61a5d7a61d91326d95d69cec872d4c7ba758'
assert hashlib.sha256(FROZEN.read_bytes()).hexdigest() == FROZEN_SHA

def load(label, path):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Guardiola2011()

field = N(width=100., height=60., goal_width=14., simulation_hz=20,
          max_speed=8., acceleration=20., ball_friction=.985,
          kick_impulse=22., kick_range=2.2, my_goal=(-50., 0.),
          opponent_goal=(50., 0.), centre_circle_radius=9.15,
          ball_radius=.45, player_radius=1.)
candidate = load('front_shadow_candidate', ROOT/'team.py')
candidate._setup(field)
frozen = load('front_shadow_frozen_target', FROZEN)
wall = [(i, -47.05, y, 0., 0.)
        for i, y in enumerate((-5.4, -1.75, 1.75, 5.4))]
outlet = (4, 10., 20., 0., 0.)
friends = wall+[outlet]

def target_branch(ball, outlet_position):
    opponents = [N(id=p[0]+5, position=(-p[1], -p[2])) for p in wall]
    opponents.append(N(id=9, position=(-outlet_position[0], -outlet_position[1])))
    players = [N(id=i, position=ball if i == 1 else (0., 20.+i)) for i in range(5)]
    obs = N(opponent_goal=(50., 0.), field=field, opponents=opponents,
            my_players=players, ball=N(position=ball), can_kick=lambda pid: pid == 1)
    actions = TeamAction(players={i: PlayerAction() for i in range(5)})
    frozen._wall_break(obs, actions)
    kickers = [pid for pid, a in actions.players.items() if a.kick_direction is not None]
    pushers = [pid for pid, a in actions.players.items() if a.movement != (0., 0.)]
    return kickers, pushers

counts = Counter()
examples = []
for x in range(10, 50):
    for y in range(-25, 26):
        counts['fixtures'] += 1
        kickers, pushers = target_branch((float(x), float(y)), outlet[1:3])
        obs = N(ball=N(position=(-float(x), -float(y))), field=field)
        screen = candidate._bait_gap_screen(obs, friends, outlet)
        if not kickers:
            counts['blocked_by_wall_or_shot_gate'] += 1
            assert screen is None
        else:
            counts['original_open_ray'] += 1
            if screen is None:
                counts['deep_ball_ordinary_intercept'] += 1
                assert x >= 47
            else:
                counts['screen_requested'] += 1
                assert screen[0] >= -46.800000001
                screened_kickers, screened_pushers = target_branch((float(x), float(y)), screen)
                assert screened_kickers == []
                assert len(screened_pushers) == 3
                counts['screen_blocks_frozen_shot'] += 1
                if len(examples) < 4:
                    examples.append({'target_ball': [x, y], 'candidate_screen': screen})

# Exact horizontal selected-gap ray remains clear with four equal-x bodies.
assert target_branch((20., 3.575), outlet[1:3])[0] == [1]
horizontal_screen = candidate._bait_gap_screen(
    N(ball=N(position=(-20., -3.575)), field=field), friends, outlet)
assert horizontal_screen is not None
assert target_branch((20., 3.575), horizontal_screen)[0] == []
# The proposed central and wide perspective shadows use actual frozen logic.
shadow = {}
for x, y in ((10., 0.), (11., 0.), (20., 0.), (40., 0.),
             (47., 0.), (48., 0.), (20., 10.), (20., -10.)):
    shadow[str((x, y))] = bool(target_branch((x, y), outlet[1:3])[0])
assert not shadow[str((20., 0.))]
assert not shadow[str((20., 10.))]
assert not shadow[str((20., -10.))]
assert shadow[str((48., 0.))]

def player(pid, position, cooldown=0):
    return N(id=pid, position=position, velocity=(0., 0.),
             kick_cooldown_ticks=cooldown, has_control=False)

def observation(score, ready=False, enemy_wall=False, kickoff=False, outlet_carrier=False):
    positions = [(-48., 0.), (-30., -18.), (-30., 18.), (-8., -18.), (-8., 18.)]
    ball_position = (0., 0.) if kickoff else (-20., -3.575)
    if ready:
        positions = [p[1:3] for p in wall]+[outlet[1:3]]
    if outlet_carrier:
        positions[4] = ball_position
    mine = [player(i, p) for i, p in enumerate(positions)]
    enemy_positions = [(48.8, y) for y in (-5.6, -2.8, 0., 2.8, 5.6)] if enemy_wall else [
        (48., 0.), ball_position, (15., -18.), (10., 18.), (25., 10.)]
    enemies = [player(i+5, p) for i, p in enumerate(enemy_positions)]
    obs = N(tick=0 if kickoff else 300, score=score, field=field,
            my_goal=field.my_goal, opponent_goal=field.opponent_goal,
            my_players=mine, opponents=enemies,
            ball=N(position=ball_position, velocity=(0., 0.), controlling_team=1,
                   controlling_player=6, last_touch=6))
    obs.can_kick = lambda pid: mine[pid].kick_cooldown_ticks == 0 and math.dist(
        mine[pid].position, obs.ball.position) <= field.kick_range
    return obs

def legal(actions):
    assert set(actions.players) == set(range(5))
    for action in actions.players.values():
        assert all(math.isfinite(v) for v in action.movement)
        assert math.hypot(*action.movement) <= 1.000000001
        if action.kick_direction is not None:
            assert all(math.isfinite(v) for v in action.kick_direction)
            assert 0. <= action.kick_power <= 1.

smokes = []
scores = ((0, 0), (1, 0), (1, 1), (2, 0), (0, 1), (0, 2), (3, 1), (3, 3), (2, 1))
for score in scores:
    for mode in ('forming', 'ready', 'enemy-wall', 'protected-kickoff', 'outlet-carrier'):
        controller = load('smoke_'+str(len(smokes)), ROOT/'team.py')
        obs = observation(score, ready=mode != 'forming', enemy_wall=mode == 'enemy-wall',
                          kickoff=mode == 'protected-kickoff', outlet_carrier=mode == 'outlet-carrier')
        actions = controller.act(obs)
        legal(actions)
        smokes.append({'score': score, 'mode': mode})

# Wrapper-specific contracts: an active receiver owns all five base actions;
# an already selected kick retains its exact movement and kick together.
obs = observation((1, 1), ready=True)
controller = load('receiver_contract', ROOT/'team.py')
controller._setup(field)
expected = TeamAction(players={i: PlayerAction(movement=(i*.1, 0.)) for i in range(5)})
def receiver_core(_):
    controller._receive_plan = (2, 4, 1000)
    return expected
controller._bait_counter_act = receiver_core
assert controller.act(obs) is expected
assert controller._receive_plan == (2, 4, 1000)

controller = load('kick_contract', ROOT/'team.py')
controller._setup(field)
expected = TeamAction(players={i: PlayerAction() for i in range(5)})
expected.set(1, PlayerAction(movement=(.25, -.75), kick_direction=(1., 0.), kick_power=.6))
expected.set(4, PlayerAction(movement=(-.2, .3), kick_direction=(.6, .8), kick_power=.9))
kept = {pid: expected.players[pid] for pid in (1, 4)}
controller._bait_counter_act = lambda _: expected
actual = controller.act(obs)
for pid, action in kept.items():
    assert actual.players[pid] is action
legal(actual)

tree = ast.parse((ROOT/'team.py').read_text())
assert len([n for n in tree.body if isinstance(n, ast.ClassDef)]) == 1
result = {'candidate_sha256': hashlib.sha256((ROOT/'team.py').read_bytes()).hexdigest(),
          'frozen_opponent_sha256': FROZEN_SHA, 'grid': dict(counts),
          'selected_target_gap': {'width': 1.65, 'cy': 3.575},
          'shadow_fixtures_direct_shot_allowed': shadow,
          'screen_examples': examples, 'full_act_smokes_passed': len(smokes),
          'receiver_contract_passed': True, 'existing_kicks_preserved': True,
          'native_matches_run': 0}
(ROOT/'checks.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
