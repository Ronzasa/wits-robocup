One isolated candidate: `team.py`, SHA256
`94038d49994964381456c0840a6b7123c5a44f8436f081768dd0810cc447e41c`.

It retains the scored-tie/one-goal-lead eligibility gate and the frozen
clearance-goal counter. Four defenders form at own-goal x + 2.95, with y lanes
(-5.4, -1.75, 1.75, 5.4). The forward line casts a perspective shadow across
some goal-line gap rays. If the actual observed bodies leave the target's
selected ray clear, the fifth outlet screens that ray; otherwise it follows
the existing counter interception. The screen stays outside the detected wall
so its arrival does not alter the target's selected gap. Deep balls already
behind own-goal x + 3.20 retain ordinary interception and clearance.

The new helper exactly reflects both canonical axes and reproduces the
frozen target's positive-y gap tie break. It uses current bodies rather than
assuming the formation is complete. All 63 non-act base methods are unchanged.
Verified receivers retain the complete base action result, and existing
selected kicks keep their movement and kick together. Source imports only
math and the SDK; one TeamController; 119,170 bytes.

`python check.py` runs no engine or match loop. Across 2,040 frozen-policy
geometry fixtures, 1,701 rays were blocked by the wall or shot gate. Of 339
remaining rays, the outlet could screen 214 while remaining outside the wall;
all 214 changed the frozen branch from a direct shot to three pushers. The
other 125 were deep-ball cases and retain normal interception. Central y=0
and wide y=±10 fixtures at target x=20 are blocked by the four bodies alone;
the horizontal y=3.575 ray stays open without the outlet. Forty-five complete
act smoke cases cover nine scores and five formation/kickoff/carrier modes.
Receiver and existing-kick contracts also passed.

These are static branch and legality checks. They do not establish native
strength, screen arrival time, formation stability, or 20 ms timing. No native
match or qualification seed was used.
