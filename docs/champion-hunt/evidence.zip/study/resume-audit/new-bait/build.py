"""Build one isolated front-wall shadow bait with a conditional outlet screen."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path('/workspace/work/champion-hunt-20261025/agent-clearance/clearance-counter-scored-tie-bait/team.py')
source = BASE.read_text()
assert hashlib.sha256(BASE.read_bytes()).hexdigest() == '9aa1729b94b83edb31a5967fd88cedb912452b075a71ae4fe161073121857e0b'
source = source[:source.rindex('\n    def act(self, obs):')]
source = source.replace('version = "clearance-counter-scored-tie-bait-v1"',
                        'version = "clearance-front-shadow-bait-v1"')
addition = '''
    def _bait_gap_screen(self, obs, friends, outlet):
        # Reproduce this public target's wall-gap choice in its canonical
        # frame. Both axes reverse; max(gaps) breaks tied gaps toward +y there.
        bx,by=obs.ball.position
        gx=-self._left
        if -bx<=gx-40.0:
            return None
        radius=obs.field.player_radius
        wall=[p for p in friends if abs(p[1]-self._left)<=3.0 and abs(p[2])<=9.0]
        if len(wall)<4:
            return None
        gaps=[]
        lo=-self._goal_half
        for y in sorted(-p[2] for p in wall)+[self._goal_half+radius]:
            hi=min(y-radius,self._goal_half)
            if hi>lo:
                gaps.append((hi-lo,(lo+hi)*.5))
            lo=max(lo,y+radius)
        if not gaps:
            return None
        width,cy=max(gaps)
        if width<2.0*self._ball_radius+.25:
            return None
        dx,dy=self._left-bx,-cy-by
        distance=math.hypot(dx,dy)
        if distance<=1e-8:
            return None
        ux,uy=dx/distance,dy/distance
        # Hold an already useful outlet screen by excluding only that outlet
        # from the occlusion test. Every actual wall position remains public.
        for p in friends:
            if p[0]==outlet[0]:
                continue
            qx,qy=p[1]-bx,p[2]-by
            along=qx*ux+qy*uy
            if along<0.0:
                continue
            along=min(along,distance)
            if math.hypot(qx-ux*along,qy-uy*along)<self._contact+.12:
                return None
        # Keep this fifth body outside the target's detected goal wall, so
        # screening does not itself change the gap it selected. A ball already
        # behind this plane needs the ordinary interception/clearance instead.
        screen_plane=self._left+3.20
        if bx<=screen_plane or ux>=-1e-8:
            return None
        maximum=min(distance,(screen_plane-bx)/ux)
        minimum=min(3.0,maximum)
        projected=(outlet[1]-bx)*ux+(outlet[2]-by)*uy
        along=_clip(projected,minimum,maximum)
        return bx+ux*along,by+uy*along

    def act(self, obs):
        lead=obs.score[0]-obs.score[1]
        eligible=lead==1 or (lead==0 and obs.score[0]>0)
        enemy_wall=sum(q.position[0]>obs.opponent_goal[0]-3.0
                       and abs(q.position[1])<9.0 for q in obs.opponents)
        if not eligible or enemy_wall>=4:
            self._bait_plan_score=None
            self._bait_wall_ids=None
            return self._bait_counter_act(obs)
        actions=self._bait_counter_act(obs)
        # A verified pass keeps its receiver, passer and support movements.
        if self._receive_plan is not None:
            return actions
        friends=[(p.id,*p.position,*p.velocity) for p in obs.my_players]
        if len(friends)!=5:
            return actions
        score=tuple(obs.score)
        if self._bait_plan_score!=score or self._bait_wall_ids is None:
            self._bait_wall_ids=tuple(p[0] for p in sorted(friends[:4],key=lambda p:(p[2],p[0])))
            self._bait_plan_score=score
        by_id={p[0]:p for p in friends}
        protected=(obs.tick<self._restart_until and self._restart_owner==1)
        launching=any(a.kick_direction is not None for a in actions.players.values())
        lanes=(-5.4,-1.75,1.75,5.4)
        for index,pid in enumerate(self._bait_wall_ids):
            p=by_id[pid]
            old=actions.players[pid]
            if old.kick_direction is not None:
                continue
            # 2.95 is strictly inside the target's <=3.0 wall detector. Its
            # forward perspective can block a gap aimed at the goal line.
            movement=self._move(p,(self._left+2.95,lanes[index]))
            if not protected and not launching and obs.can_kick(pid):
                actions.set(pid,PlayerAction(movement=movement,
                            kick_direction=(1.0,0.0),kick_power=1.0))
            else:
                actions.set(pid,PlayerAction(movement=movement))
        outlet=friends[4]
        screening=False
        if not protected and actions.players[outlet[0]].kick_direction is None:
            target=self._bait_gap_screen(obs,friends,outlet)
            screening=target is not None
            if target is None:
                bx,by=obs.ball.position
                path=self._trajectory(bx,by,*obs.ball.velocity)
                target=self._intercept(outlet,path)[1]
                target=self._target(*target)
            actions.set(outlet[0],PlayerAction(movement=self._move(outlet,target)))
        if actions.debug is not None:
            actions.debug['text']='Front wall shadow; outlet screens open gap' if screening else 'Front wall shadow; counter outlet'
        return actions
'''
source += addition
tree = ast.parse(source)
classes = [n for n in tree.body if isinstance(n, ast.ClassDef)]
assert len(classes) == 1
for name in ('act', 'reset'):
    assert sum(isinstance(n, ast.FunctionDef) and n.name == name for n in classes[0].body) == 1
compile(source, str(ROOT/'team.py'), 'exec')
path = ROOT/'team.py'
path.write_text(source)
assert path.stat().st_size < 256000
manifest = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'bytes': path.stat().st_size, 'base_path': str(BASE),
            'base_sha256': hashlib.sha256(BASE.read_bytes()).hexdigest(),
            'gate': 'lead == 1 or scored tie', 'wall_goal_offset': 2.95,
            'wall_y': [-5.4, -1.75, 1.75, 5.4],
            'native_matches_run': 0, 'qualification': False}
(ROOT/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(manifest, indent=2))
