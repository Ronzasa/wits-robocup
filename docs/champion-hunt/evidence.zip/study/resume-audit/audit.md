Static audit, 2026-10-25

All current batch registration source hashes match their files. There are no
duplicate (source, seed, side, kickoff) fixture keys inside a batch. Exposed
matches use development seeds 3249061101–3249061108 only. Qualification seeds
3249063101–3249063132 remain unexposed in these batches.

Both new clearance composites compile, import only math and the SDK, contain
one TeamController class and one act/reset entry point, and are below 256 KB.
Their frozen core SHA matches the manifest. model-shot-wall likewise passes
static syntax/dependency checks, with size 242,220 bytes. Its siege donor is
v10-boundary-crossing (441ba...), not v10-clearance-goal (4478...). Non-wall
_model_shot still applies endwall rejection before body collision, unlike
confirmed native body-before-endwall ordering. Native runtime was not tested
by this audit; central screen-composites recorded zero errors/timeouts for all
three candidates (model-shot-wall max 7.553 ms).

The original clearance-goal result combines disjoint screen-new5 (1101–1102)
and expand-development (1103–1108): 12 W, 16 D, 4 L, goals 83–53, own goals 2
versus opponent own goals 38. First-goal candidate fixtures: 8 W/6 D/1 L;
first-goal opponent: 4 W/10 D/3 L. These remain selected development evidence,
not a qualification result.

New 8-fixture screen-composites: model-shot-wall 4 W/4 D, 17–10, own goals 0;
lead-bait 2 W/5 D/1 L, 18–15, own goals 2; scored-tie-bait 4 W/4 D, 17–8,
own goals 3. Their bait wall creates a specific geometric weakness: centers
at -5.4/-1.8/1.8/5.4 leave 1.6-wide internal gaps. The frozen wall breaker
shoots when its largest gap is at least 1.15 and its shooting ray is clear.
Those rays miss adjacent bodies by 1.8, above its 1.57 clearance threshold.
Four radius-1 bodies across a 14-wide mouth necessarily leave some gap at
least (14 - 8)/5 = 1.2, so a fixed four-body wall alone cannot disable the
shot branch. check_bait_gap.py reproduces a direct shot with an independent
outlet, then all three pushers with that outlet screening the selected ray.
An actionable next experiment is to screen the largest-gap ray with the fifth
player until the pushers commit, then release the outlet. No candidate was
edited, and no native match loop was run by this audit.
