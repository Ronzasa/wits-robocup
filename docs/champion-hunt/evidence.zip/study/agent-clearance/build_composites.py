"""Conditional four-wall/outlet modes on the frozen clearance-goal counter."""
from pathlib import Path
import ast,hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/work/champion-hunt-20261025/agent-wall/v10-clearance-goal/team.py')
source=BASE.read_text()
base_sha=hashlib.sha256(BASE.read_bytes()).hexdigest()
source=source.replace('    def reset(self, seed):','    def _bait_base_reset(self, seed):',1)
source=source.replace('    def act(self, obs):','    def _bait_counter_act(self, obs):',1)
method='''
    def reset(self, seed):
        self._bait_base_reset(seed)
        self._bait_plan_score = None
        self._bait_wall_ids = None

    def act(self, obs):
        lead=obs.score[0]-obs.score[1]
        eligible=ELIGIBILITY
        # The frozen siege owns every enemy home-wall position, regardless
        # of score. Bait requires their three mobile wall-breaking pushers.
        enemy_wall=sum(q.position[0]>obs.opponent_goal[0]-3.0
                       and abs(q.position[1])<9.0 for q in obs.opponents)
        if not eligible or enemy_wall>=4:
            self._bait_plan_score=None
            self._bait_wall_ids=None
            return self._bait_counter_act(obs)
        actions=self._bait_counter_act(obs)
        # A verified pass is a movement contract. Never switch the receiver,
        # add a clearance impulse, or retarget its support during that contract.
        if self._receive_plan is not None:
            return actions
        friends=[(p.id,*p.position,*p.velocity) for p in obs.my_players]
        if len(friends)!=5:
            return actions
        score=tuple(obs.score)
        if self._bait_plan_score!=score or self._bait_wall_ids is None:
            # Cache one order per score; prevent crossing during formation.
            # The initial y-order shortens the farthest setup run by~5units.
            self._bait_wall_ids=tuple(p[0] for p in sorted(friends[:4],key=lambda p:(p[2],p[0])))
            self._bait_plan_score=score
        by_id={p[0]:p for p in friends}
        protected=(obs.tick<self._restart_until and self._restart_owner==1)
        launching=any(a.kick_direction is not None for a in actions.players.values())
        for index,pid in enumerate(self._bait_wall_ids):
            p=by_id[pid]
            old=actions.players[pid]
            # Preserve an already selected kick and its movement together.
            if old.kick_direction is not None:
                continue
            movement=self._move(p,(self._left+1.2,(index-1.5)*3.6))
            if not protected and not launching and obs.can_kick(pid):
                actions.set(pid,PlayerAction(movement=movement,
                            kick_direction=(1.0,0.0),kick_power=1.0))
            else:
                actions.set(pid,PlayerAction(movement=movement))
        # Slot4 is an independent fast outlet. Kickoff-protected movement and
        # any established kick remain exactly what the frozen core selected.
        outlet=friends[4]
        if not protected and actions.players[outlet[0]].kick_direction is None:
            bx,by=obs.ball.position
            path=self._trajectory(bx,by,*obs.ball.velocity)
            target=self._intercept(outlet,path)[1]
            actions.set(outlet[0],PlayerAction(movement=self._move(outlet,self._target(*target))))
        if actions.debug is not None:
            actions.debug['text']='Conditional four-wall bait and separate outlet'
        return actions
'''
variants={
 'clearance-counter-lead-bait':'lead==1',
 'clearance-counter-scored-tie-bait':'lead==1 or (lead==0 and obs.score[0]>0)'
}
meta={}
for label,condition in variants.items():
 text=source+method.replace('ELIGIBILITY',condition)
 text=text.replace('version = "v10-clearance-goal-v1"',f'version = "{label}-v1"')
 p=ROOT/label/'team.py';p.parent.mkdir(exist_ok=True);p.write_text(text)
 tree=ast.parse(text);classes=[n for n in tree.body if isinstance(n,ast.ClassDef)];assert len(classes)==1
 assert sum(isinstance(n,ast.FunctionDef) and n.name=='act' for n in classes[0].body)==1
 assert sum(isinstance(n,ast.FunctionDef) and n.name=='reset' for n in classes[0].body)==1
 meta[label]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
manifest={'base_path':str(BASE),'base_sha256':base_sha,'candidates':meta}
(ROOT/'manifest-composites.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
