from pathlib import Path
import ast,hashlib,json
ROOT=Path(__file__).resolve().parent
base=Path('/workspace/work/replay-finishing-handoffs/champions/v10.0/team.py').read_text()
base=base.replace('    def act(self, obs):','    def _clearance_base_act(self, obs):',1)
net='''
    def _net_clearance_paths(self, obs, wall):
        bx,by = obs.ball.position
        vx,vy = obs.ball.velocity
        if vx < -3.0:
            return [self._trajectory(bx,by,vx,vy)]
        # Predict the observed lock-wall's holding motion until its first
        # legal kick. This is a model of this public opponent, not a reach bound.
        ordered = sorted(wall,key=lambda q:q.position[1])
        state = [[q.id,*q.position,*q.velocity,q.kick_cooldown_ticks,
                  (i-(len(ordered)-1)*.5)*2.8] for i,q in enumerate(ordered)]
        for tick in range(18):
            ready = 0
            for q in state:
                dx,dy = self._right-1.2-q[1],q[6]-q[2]
                d = math.hypot(dx,dy)
                scale = (1.0 if d>1.5 else d/1.5)/d if d>1e-8 else 0.0
                q[3] = q[3]*self._damping+dx*scale*self._acc
                q[4] = q[4]*self._damping+dy*scale*self._acc
                speed = math.hypot(q[3],q[4])
                if speed>self._speed:
                    q[3]*=self._speed/speed;q[4]*=self._speed/speed
                q[1]+=q[3]*self._dt;q[2]+=q[4]*self._dt
                if q[5]<=tick and math.hypot(q[1]-bx,q[2]-by)<=self._range:
                    ready += 1
            if ready:
                paths = []
                for count in range(1,min(2,ready)+1):
                    sx,sy = vx,vy
                    # Each native impulse is applied and capped separately.
                    for _ in range(count):
                        sx-=self._impulse
                        speed=math.hypot(sx,sy)
                        if speed>self._ball_cap:
                            sx*=self._ball_cap/speed;sy*=self._ball_cap/speed
                    x,y=bx+sx*self._dt,by+sy*self._dt
                    # The normal trajectory supplies all subsequent drag and
                    # wall rebounds; the first post-kick step has already moved.
                    bound=self._half_height-self._ball_radius
                    if abs(y)>bound:
                        sign=1.0 if y>0 else -1.0
                        y=2.0*sign*bound-y;sy=-sign*abs(sy)*self._wall
                    paths.append(self._trajectory(x,y,sx*self._friction,sy*self._friction))
                return paths
            bx+=vx*self._dt;by+=vy*self._dt
            vx*=self._friction;vy*=self._friction
            if bx>self._right-self._ball_radius or abs(by)>self._half_height-self._ball_radius:
                break
        return []

    def act(self, obs):
        actions = self._clearance_base_act(obs)
        bx,by = obs.ball.position
        wall=[q for q in obs.opponents if q.position[0]>self._right-3.1 and abs(q.position[1])<9.0]
        if len(wall)<4 or bx<16.0:
            return actions
        recipient=self._receive_plan[0] if self._receive_plan is not None else None
        protected={0,self._chaser,self._shape_cover_id,recipient}
        friends=[(p.id,*p.position,*p.velocity) for p in obs.my_players]
        free=[p for p in friends[1:] if p[0] not in protected
              and actions.players[p[0]].kick_direction is None]
        paths=self._net_clearance_paths(obs,wall)
        if not free or not paths:
            return actions
        assigned=set()
        # Cover both actually capped one- and two-clear branches when available.
        # A single-branch clearance retains two separated collection layers.
        for index,depth in enumerate((36.0,24.0)):
            candidates=[p for p in free if p[0] not in assigned]
            if not candidates:break
            forecast=paths[min(index,len(paths)-1)]
            sample=next((item for item in forecast if item[1]<=min(depth,bx-5.0)),forecast[-1])
            target=self._target(sample[1],sample[2])
            p=min(candidates,key=lambda q:self._eta(q,*target))
            assigned.add(p[0])
            actions.set(p[0],PlayerAction(movement=self._move(p,target)))
        return actions
'''
bait='''
    def act(self, obs):
        actions=self._clearance_base_act(obs)
        bx,by=obs.ball.position
        vx,vy=obs.ball.velocity
        friends=[(p.id,*p.position,*p.velocity) for p in obs.my_players]
        opponents=[(q.id,*q.position,*q.velocity) for q in obs.opponents]
        if len(friends)!=5:
            return actions
        # A target already using its own lock/trailing wall has no attacking
        # pushers to bait. Release our trap immediately and resume normal v10.
        enemy_wall=sum(q[1]>self._right-3.1 and abs(q[2])<9.0 for q in opponents)
        if enemy_wall>=4:
            return actions
        protected=(obs.tick<self._restart_until and self._restart_owner==1)
        outlet=friends[4]
        wall=friends[:4]
        ready=sum(p[1]<self._left+3.1 and abs(p[2])<9.0 for p in wall)==4
        recipient=self._receive_plan[0] if self._receive_plan is not None else None
        # During construction only, a verified lateral backward pass can
        # buy setup time. Deep own-goal trajectories and unplanned receivers
        # are excluded; the named receiver follows its actual rollout aim.
        if (not ready and not protected and recipient is None and obs.can_kick(outlet[0])
                and bx>self._left+18.0):
            original=actions.players[outlet[0]]
            scoring=False
            if original.kick_direction is not None:
                sx,sy=self._requested_velocity(vx,vy,(original.kick_direction,original.kick_power))
                launch=self._carrier_contact(outlet,bx,by,sx,sy,original.movement)
                scoring=launch is not None and self._goal_path(launch) is not None
            if not scoring:
                best=None
                candidates=[p for p in wall[1:] if p[1]<bx-6.0 and p[1]>self._left+12.0 and abs(p[2])>7.8]
                candidates=sorted(candidates,key=lambda p:math.hypot(p[1]-bx,p[2]-by))[:2]
                for q in candidates:
                    option=self._link_option(outlet,bx,by,vx,vy,q,opponents,q[1],q[2],18.0)
                    if option is not None:
                        aim=self._next_receive_aim or option[3][1:]
                        if best is None or option[0]>best[0][0]:best=option,aim
                if best is not None:
                    option,aim=best
                    _,kick,movement,plan=option
                    rid=plan[0];q=next(p for p in friends if p[0]==rid)
                    self._pass_plan=plan;self._bank_plan=None;self._bank_receive=None
                    self._receive_plan=(rid,outlet[0],obs.tick+int(1.8*self._hz))
                    self._receive_aim=(rid,aim)
                    actions.set(outlet[0],PlayerAction(movement=movement,kick_direction=kick[0],kick_power=kick[1]))
                    actions.set(rid,PlayerAction(movement=self._move(q,self._target(*aim))))
                    recipient=rid
        # Begin formation on the first decision, not only after the opponent
        # reaches our third. Four kick-range lanes span the whole goal mouth;
        # the fifth player remains a separate outlet rather than a fifth wall.
        for index,p in enumerate(wall):
            if p[0]==recipient:
                continue
            old=actions.players[p[0]]
            if old.kick_direction is not None:
                continue
            movement=self._move(p,(self._left+1.2,(index-1.5)*3.6))
            if obs.can_kick(p[0]) and not protected:
                actions.set(p[0],PlayerAction(movement=movement,kick_direction=(1.0,0.0),kick_power=1.0))
            else:
                actions.set(p[0],PlayerAction(movement=movement))
        if (outlet[0]!=recipient and not protected
                and actions.players[outlet[0]].kick_direction is None):
            forecast=self._trajectory(bx,by,vx,vy)
            target=self._intercept(outlet,forecast)[1]
            actions.set(outlet[0],PlayerAction(movement=self._move(outlet,self._target(*target))))
        return actions
'''
meta={}
for label,method in [('clearance-net-capped',net),('proactive-wall-bait',bait)]:
 text=(base+method).replace('version = "10.0-titan10b-r"',f'version = "hunt-{label}"')
 p=ROOT/label/'team.py';p.parent.mkdir(exist_ok=True);p.write_text(text)
 t=ast.parse(text);classes=[n for n in t.body if isinstance(n,ast.ClassDef)];assert len(classes)==1
 assert sum(isinstance(n,ast.FunctionDef) and n.name=='act' for n in classes[0].body)==1
 meta[label]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
(ROOT/'manifest-v2.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
