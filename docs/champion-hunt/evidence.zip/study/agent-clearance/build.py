from pathlib import Path
import ast,hashlib,json
ROOT=Path(__file__).resolve().parent
base=Path('/workspace/work/replay-finishing-handoffs/champions/v10.0/team.py').read_text()
base=base.replace('    def act(self, obs):','    def _clearance_base_act(self, obs):',1)
net='''
    def act(self, obs):
        actions = self._clearance_base_act(obs)
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        # Recognize the target's public all-player wall. The ordinary keeper,
        # chaser, carrier and any verified receiver retain their actions.
        wall = [q for q in obs.opponents if q.position[0] > self._right-3.1
                and abs(q.position[1]) < 9.0]
        if len(wall) < 4 or bx < 16.0:
            return actions
        recipient = self._receive_plan[0] if self._receive_plan is not None else None
        protected = {0, self._chaser, self._shape_cover_id, recipient}
        friends = [(p.id,*p.position,*p.velocity) for p in obs.my_players]
        free = [p for p in friends[1:] if p[0] not in protected
                and actions.players[p[0]].kick_direction is None]
        if not free:
            return actions
        # A locked defender requests -x in our canonical frame. Two layers
        # collect its predictable clearance; live outgoing trajectories retain
        # the native drag/wall forecast instead of extrapolating a straight line.
        outgoing = vx < -3.0
        forecast = self._trajectory(bx, by, vx if outgoing else -max(16.0,44.0-vx), vy)
        stops = (36.0,24.0)
        assigned = set()
        for depth in stops:
            candidates = [p for p in free if p[0] not in assigned]
            if not candidates:
                break
            if outgoing:
                scored = [(self._intercept(p,forecast)[0],p,self._intercept(p,forecast)[1]) for p in candidates]
                _,p,target = min(scored,key=lambda item:item[0])
            else:
                sample = next((item for item in forecast if item[1] <= min(depth,bx-5.0)),forecast[-1])
                target = self._target(sample[1],sample[2])
                p = min(candidates,key=lambda q:self._eta(q,*target))
            assigned.add(p[0])
            actions.set(p[0],PlayerAction(movement=self._move(p,self._target(*target))))
        return actions
'''
bait='''
    def act(self, obs):
        actions = self._clearance_base_act(obs)
        bx, by = obs.ball.position
        vx, vy = obs.ball.velocity
        # Preserve live receptions. A score change already resets ordinary
        # pass plans through the frozen v10 core.
        if self._receive_plan is not None:
            return actions
        # A four-player kick-range wall is used as bait when the target is
        # pressing our half; one advanced outlet stays completely separate.
        # It is released as soon as the ball or its counter escapes midfield.
        if bx > 1.0 or obs.ball.controlling_team == 0 and bx > -18.0:
            return actions
        if obs.tick < self._restart_until and self._restart_owner == 1:
            return actions
        friends = [(p.id,*p.position,*p.velocity) for p in obs.my_players]
        if len(friends) != 5:
            return actions
        outlet = max(friends[1:],key=lambda p:p[1]+(2.0 if p[0]==4 else 0.0))
        wall = [p for p in friends if p[0] != outlet[0]]
        wall.sort(key=lambda p:p[0])
        x = self._left+1.2
        for i,p in enumerate(wall):
            movement = self._move(p,(x,(i-1.5)*3.6))
            if obs.can_kick(p[0]):
                # Multiple legal ready players can clear the same frame;
                # no cooldown, speed or opponent action is bypassed.
                actions.set(p[0],PlayerAction(movement=movement,
                            kick_direction=(1.0,0.0),kick_power=1.0))
            else:
                actions.set(p[0],PlayerAction(movement=movement))
        if actions.players[outlet[0]].kick_direction is None:
            forecast = self._trajectory(bx,by,vx,vy)
            if vx > 4.0:
                target = self._intercept(outlet,forecast)[1]
            else:
                target = self._target(max(-5.0,bx+24.0),max(-13.0,min(13.0,by)))
            actions.set(outlet[0],PlayerAction(movement=self._move(outlet,self._target(*target))))
        return actions
'''
meta={}
for label,method in [('clearance-net',net),('four-wall-bait',bait)]:
 text=base+method
 text=text.replace('version = "10.0-titan10b-r"',f'version = "hunt-{label}"')
 p=ROOT/label/'team.py';p.parent.mkdir(exist_ok=True);p.write_text(text)
 tree=ast.parse(text)
 classes=[n for n in tree.body if isinstance(n,ast.ClassDef)]
 assert len(classes)==1
 assert len([n for n in classes[0].body if isinstance(n,ast.FunctionDef) and n.name=='act'])==1
 meta[label]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
(ROOT/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
