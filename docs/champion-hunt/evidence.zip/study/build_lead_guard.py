import ast
from pathlib import Path
ROOT=Path(__file__).resolve().parent
base=(ROOT/'agent-wall/v10-boundary-crossing/team.py').read_text()
recovery=Path('/workspace/work/replay-finishing-handoffs/experiments/replay-finishing-handoffs/team.py').read_text()
node=next(n for n in ast.walk(ast.parse(recovery)) if isinstance(n,ast.FunctionDef) and n.name=='_keeper_clearance')
helper=''.join(recovery.splitlines(True)[node.lineno-1:node.end_lineno])+'\n'
for threshold,smart in ((1,False),(1,True),(2,True)):
 text=base.replace('    def act(self, obs):','    def _counter_base_act(self, obs):',1)
 text+='\n    KEEPER_CLEAR_TICKS = 12\n\n'+helper+f'''
    def act(self, obs):
        if obs.score[0]-obs.score[1] < {threshold}:
            return self._counter_base_act(obs)
        if not self._ready:
            self._setup(obs.field)
        self._last_score=obs.score
        self._receive_plan=self._receive_aim=self._bank_receive=None
        self._pass_plan=self._bank_plan=None
        bx,by=obs.ball.position
        vx,vy=obs.ball.velocity
        players=sorted(obs.my_players,key=lambda p:p.id)
        opponents=[(p.id,*p.position,*p.velocity) for p in obs.opponents]
        ready=[p.id for p in players if obs.can_kick(p.id)]
        actions=TeamAction(debug={{'text':'Target counter lead guard'}})
        for p in players:
            tx=self._left+1.2
            ty=(p.id-2)*2.8
            dx,dy=tx-p.position[0],ty-p.position[1]
            gap=math.hypot(dx,dy)
            scale=min(1.,gap/1.5)/gap if gap>1e-8 else 0.
            movement=(dx*scale,dy*scale)
            kick=((1.,0.),1.) if p.id in ready else None
            if {smart} and kick is not None and len(ready)==1:
                self._touch_movement=movement
                kick=self._keeper_clearance((p.id,*p.position,*p.velocity),bx,by,vx,vy,kick,movement,opponents)
                movement=self._touch_movement or movement
            if kick is None:
                actions.set(p.id,PlayerAction(movement=movement))
            else:
                actions.set(p.id,PlayerAction(movement=movement,kick_direction=kick[0],kick_power=kick[1]))
        return actions
'''
 name=f'lead{threshold}-'+('smart' if smart else 'plain')
 p=ROOT/'parent-guard'/name/'team.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);ast.parse(text)
 print(name,len(text))
