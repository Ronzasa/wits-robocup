Two separate native diagnostic reproductions completed on 2026-10-25. Exactly two complete fixture loops ran; neither is qualification evidence. The original scheduled 41.61581599328201 ms timeout at tick 535 remains counted.

Fixture: seed 3249061104, candidate slot 0, candidate kickoff false. Candidate SHA-256 `9aa1729b94b83edb31a5967fd88cedb912452b075a71ae4fe161073121857e0b`; frozen opponent SHA-256 `7708f5d3b10202092f1fce73abfc61a5d7a61d91326d95d69cec872d4c7ba758`. Hashes were checked before and after each run. Config, native default roster, 2400 ticks and normal 20 ms deadline match the scheduled fixture. The unmodified official `default_roster.native_match` driver called the original `runner._decide` and normal native decision/failure handling. The diagnostic wrapper observed public state outside the timed call; it did not change actions, SDK files, policies, formation, GC, timers, affinity, or deadline behavior.

Both runs completed 2400 ticks with score 2–3, matching the original scheduled score, and zero timeouts for either side. Full public player positions, velocities, cooldowns and controller-owned mode state at ticks 533–537 are retained in both JSON artifacts. The two reproductions have identical pre-decision state at tick 535.

Plain reproduction timing in milliseconds:

| Tick | Official `_decide` wall | Observer wall | Thread CPU |
|---|---:|---:|---:|
| 533 | 0.221895 | 0.222917 | 0.222501 |
| 534 | 0.179251 | 0.180333 | 0.179947 |
| 535 | 1.469642 | 1.471746 | 1.470997 |
| 536 | 0.286363 | 0.288266 | 0.287498 |
| 537 | 0.245631 | 0.246693 | 0.246187 |

The largest candidate decision in this plain reproduction was 4.178348 ms at tick 546. At tick 535, wall minus thread CPU was 0.000749 ms; no sizable CPU stall was witnessed in that call. These measurements cannot identify the cause of the earlier 41.615816 ms observation, for which thread CPU was not recorded.

At tick 535 the public score is 1–1, enemy-wall count is 1, ball position is (-38.171451568603516, -3.2407138347625732), and velocity is (-9.07248306274414, 1.3298962116241455). Only candidate player 1 can kick. This selects `_opening_act`, with bait eligibility true but the bait overlay suppressed by a reception contract. `_receive_plan` changes from (1, 4, 559) to (2, 1, 587). It is not a siege call. cProfile confirms `act → _bait_counter_act → _opening_act → _choose_kick → _before_endwall → _search_links`.

The separate profiling reproduction used cProfile only on candidate tick 535. Its official decision wall time was 3.251857 ms, observer wall 3.260230 ms, and thread CPU 3.257123 ms. Profiler overhead makes this run unsuitable for timing qualification. It recorded 8423 calls, 8393 primitive calls. Relevant inclusive costs under profiling:

| Function | Calls | Cumulative ms |
|---|---:|---:|
| `_search_links` | 1 | 1.758448 |
| `_link_option` | 9 | 1.722085 |
| `_pass_race` | 11 | 1.511917 |
| `_runtime_intercept` | 66 | 0.865704 |
| `_verified_intercept` | 66 | 0.785016 |
| `_receiver_route` | 11 | 0.467176 |

Inclusive costs overlap and must not be added. The link search and repeated pass races are a witnessed local workload; identical redundant physical queries were not established. This profile does not reproduce a 20 ms overrun or explain the scheduled 41.615816 ms timeout. No isolated optimization is justified by the current causal evidence, and no policy optimization was made. A clean repeat does not establish that the environment caused the original miss.

Artifacts: `diagnose.py` is the functional diagnostic harness; `measure.json` and `profile.json` retain complete results, original scheduled row, per-decision timing, and public/controller-owned snapshots; `profile.pstats` and `profile.profile.txt` retain the tick-535 call profile. Future qualification seeds were not accessed.
